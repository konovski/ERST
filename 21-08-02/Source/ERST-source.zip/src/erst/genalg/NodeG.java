/**
 * The class for keeping the data and methods relative to a single node of the tree.
 * Will contain data needed for the implementation of the generalized algorithm.
 */
package erst.genalg;

/**
 * @author petar
 *
 */
public class NodeG {

	
	NodeG left, right;
	NodeG parent;
	String name;
	int nodeIndex; 			// That should be the position of the node in nodes[].
	int gained;				// Counter for the trait missing in the parent, present in the node.
	int lost;				// Counter for the trait present in the parent, missing in the node.
	int inherited;			// Counter for the trait present in the parent, present in the node.
	int notInherited;		// Counter for the trait missing in the parent, missing in the node.
	int casePresent;		// To save the minimum case at which the gen. algorithm achieves trait presence in the node.
	int caseAbsent;			// To save the minimum case at which the gen. algorithm achieves trait absence in the node.
	int numEqPresent = 0;	// The number of variants where the min. score is equal, if the trait is present.
	int numEqAbsent = 0;	// The number of variants where the min. score is equal, if the trait is absent.
	boolean isLeaf;			// Indicator if the node is leaf.
	boolean lambdasCalculated; // A flag to avoid redundant runs of the lambda functions.
	double nodeGainProb; // The probability for gain: gained/(Total which should be gained).
	double nodeLossProb; // The probability for loss: lost/(Total which should be lost).
	double lambda0l = 0;
	double lambda0r = 0;
	double lambda1l = 0;
	double lambda1r = 0;
	double gainWeight;
	double lossWeight;
	double gainWeight_;
	double lossWeight_;
	
	
	 
	// A constructor for leaves (name exists, children not available).
	public NodeG(String name, int num) {
		this.name = name;
		nodeIndex = num;
		isLeaf = true;
		lambdasCalculated = true;
		left = null; 
		right = null;
		parent = null;
	}

	// A constructor for internal nodes (no name, children available).
	public NodeG(int num, NodeG l, NodeG r) {
		nodeIndex = num;
		isLeaf = false;
		lambdasCalculated = false;
		left = l;
		right = r;
		parent = null;

	}

	   
	public String gltoString() {
	    if (isLeaf)
		    return name + ":[&&NHX:E=" + gained + "/"+ lost + " ]";
	    // The node is internal one, invoke conversion in leafs.   
	    return "(" + left.gltoString() + "," + right.gltoString() + ")" +  
	   						":[&&NHX:E=" + gained + " /"+ lost + " ]";
	   }
    
   
   private long proMil (double num){
      
      return Math.round(num*1000.);
   }
   
	public String probtoString() {
 		if (isLeaf)
			return name + ":[&&NHX:E=" + proMil(nodeGainProb) + " / "
       									+ proMil(nodeLossProb) + " ]";
       									
	    // The node is internal one, invoke conversion in leafs.   
		return "(" + left.probtoString() + "," + right.probtoString() + ")" +  ":[&&NHX:E=" + 
									proMil(nodeGainProb) + " / "+ proMil(nodeLossProb) + " ]";
	}
	
}
