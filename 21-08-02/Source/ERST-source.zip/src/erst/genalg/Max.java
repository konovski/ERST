/**
Output of the coefficients needed for calculation of the gain rate minimax problem.
Author: Petar
September 2018.
*/

package erst.genalg;
//import erst.tio.FormattedWriter;

import java.io.IOException;

import erst.tio.FormattedWriter;

/**
Auxiliary additional calculations for preparing data for the 
minimax problem.
*/

public abstract  class Max {
	public static void execute() {
	
		int unknowns = InnerData.nNodes - 1; // All nodes in the tree except the root can be 
		 									 // examined for specific gain rate.
		int nRestr = InnerData.nLeaves; // Every leaf from the tree is considered as an end of path 
										// and hence contributes with a restriction to the minimax problem.
		final NodeG[] nodes = InnerData.nodes; // An array containing all the nodes of the tree. 
		final int[] leavesIndex = InnerData.leavesIndex; // The positions of leaves in "nodes". 
		double[][] restr = new double[nRestr][unknowns]; // The coefficients of the restrictions.
		double eps = 0.0001; // A small number to put in the places of zeros.

		// Initialise the "restr" array. Later, some those zeroes will remain as zero coefficients.
		for (int i=0; i<nRestr; i++) {
			for (int j=0; j<unknowns; j++) {
				restr[i][j] = 0;
			}
		}
		
		/*
		Output of the coefficients of the restrictions to the gain rate.
		Fixed name of the file: "Minimax.txt".
		What else is needed:
		Number of the unknowns quantities, number of the restrictions.
		*/
		
		FormattedWriter outMin = null;
		try {
			//outMin = new FormattedWriter("D:\\Wrk\\ERST\\Example1\\Minimax.txt");
			outMin = new FormattedWriter("Minimax.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		outMin.printfln(unknowns + " " + nRestr);
		//We assume that the calculations of gains and losses are done already.
		for (int i=0; i<nRestr; i++) { // i passes the sequence numbers of the restrictions.
			int currentIindex = leavesIndex[i]; // We start the construction of a restriction from the leaf to the root.
			NodeG currentNode = nodes[currentIindex];
			while (currentIindex > 0) {
				NodeG parent = currentNode.parent;
        		int parentIndex = parent.nodeIndex;
				double p = currentNode.nodeGainProb;
				p = Math.max(p, eps);
				double q = currentNode.nodeLossProb;
				q = Math.max(q, eps);
				restr[i][currentIindex-1] = -(p * Math.log(1-p-q)) / (p + q);
				currentNode = parent;
				currentIindex = parentIndex;
			}
		} // End of for (int i=0; i<nRestr; i++) {
		
		// Output of the restriction coefficients.
		for (int i=0; i<nRestr; i++) { // i passes the sequence numbers of the restrictions.
			String currentLine = "";
			for (int j=0; j<unknowns; j++) {
				currentLine += restr[i][j] + " ";
			}
		outMin.printfln(currentLine + "\n");
		}
		outMin.close();
		
		/*
		
		*/
	
	
	
	
	} // End of public static void execute()


} // End of public abstract  class MaxLikelihood


