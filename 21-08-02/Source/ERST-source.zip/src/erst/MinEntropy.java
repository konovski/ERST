/**
 *
 * @author  Petar
 * 
 */
package erst;

import javax.swing.JOptionPane;

import erst.genalg.InnerData;
import erst.genalg.TreeG;


public abstract  class MinEntropy {
	public static void execute() {
		final int MIN_ENTROPY = InnerData.MIN_ENTROPY;
		int nIterations;
		double gainPenalty;
		nIterations = CalcParameters.getNIterations();
		gainPenalty = CalcParameters.getGainPenalty();

		TreeG tg = new TreeG();
		CalcParameters.setMethodUsed(MIN_ENTROPY);
		tg.execute(gainPenalty, nIterations, MIN_ENTROPY);
		JOptionPane.showMessageDialog(null, "Finished Minimum Entropy Reconstruction");
			
		MainMenu.enableView();
		MainMenu.enableProbME();
		MainMenu.disableProbML();
	
	} // End of public static void execute().

} // End of public class MinEntropy.
