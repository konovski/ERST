/*
 * GraphTabPanel.java
 *
 * Created on 13 March 2006, 18:32 (Renata?)
 * Rewritten by Petar in 2017, using some code.
 */

package erst;

import java.awt.BorderLayout;
import java.awt.Dimension;
//import java.awt.event.WindowAdapter; - A consequence of excluding frame.addWindowListener
//import java.awt.event.WindowEvent;
//import java.util.AbstractMap;
//import java.util.HashMap;

import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

//import erst.InputWindow;
import erst.forester.java.src.org.forester.atv.ATVapp;
import erst.forester.java.src.org.forester.phylogeny.PhylogenyNode;
import erst.genalg.InnerData;
/**
 *
 * @author  Petar
 */
public class GraphTabPanel extends JPanel implements ListSelectionListener {
    
    String[] pathTree = new String[1];
    
    public GraphTabPanel() {
  		String labels[] = InnerData.functionContents;
		JList<String> jlist = new JList<String>(labels);
        jlist.setMinimumSize(new Dimension(120, 250));
        jlist.addListSelectionListener(this);
        jlist.setSelectedIndex(-1);
		JScrollPane scrollPane = new JScrollPane(jlist);
        scrollPane.setPreferredSize( new Dimension(130, 350));
        add(scrollPane, BorderLayout.CENTER);
    }
    
    
    /** Required by ListSelectionListener interface. 
     * @param e */
    public void valueChanged(ListSelectionEvent e) {
        if (e.getValueIsAdjusting()) {
            return;
        }
        JList<?> theList = (JList<?>)e.getSource();
        int index = theList.getSelectedIndex();
        InnerData.chosenHPF = index;
        
        pathTree[0] = InputWindow.tree;
        ATVapp ATVRunTree = new ATVapp();
        PhylogenyNode.setNodeCount(0);   
        ATVRunTree.execute(pathTree);
    }

    
    public static void execute() {
        
        JFrame frame = new JFrame("Gene Function - Tree Window");
        GraphTabPanel app = new GraphTabPanel();
        frame.getContentPane().add(app, BorderLayout.CENTER);
        frame.setSize(130, 400);
        frame.setVisible(true);
        
    }
}
