/**
 *
 * @author  Petar
 * 
 */
package erst;

//import java.io.IOException;

import javax.swing.JOptionPane;

import erst.genalg.InnerData;
import erst.genalg.TreeG;


public abstract  class MaxLikelihood {
	public static void execute() {
		final int MAX_LIKELIHOOD  = InnerData.MAX_LIKELIHOOD;
		int nIterations;
		double gainPenalty;
		nIterations = CalcParameters.getNIterations();
		gainPenalty = CalcParameters.getGainPenalty();

		TreeG tg = new TreeG();
		CalcParameters.setMethodUsed(MAX_LIKELIHOOD);
		tg.execute(gainPenalty, nIterations, MAX_LIKELIHOOD);
		JOptionPane.showMessageDialog(null, "Finished Maximum Likelihood Reconstruction");
		MainMenu.enableView();
		MainMenu.enableProbML();
		MainMenu.disableProbME();
	} // End of public static void execute().

} // End of public class MaxLikelihood.
