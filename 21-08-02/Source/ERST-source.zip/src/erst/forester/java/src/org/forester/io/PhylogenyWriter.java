/*
 * Created on Oct 9, 2005 TODO To change the template for this generated file go
 * to Window - Preferences - Java - Code Style - Code Templates
 */
package erst.forester.java.src.org.forester.io;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import java.util.Stack;

import erst.forester.java.src.org.forester.phylogeny.PhyloXMLmapping;
import erst.forester.java.src.org.forester.phylogeny.Phylogeny;
import erst.forester.java.src.org.forester.phylogeny.PhylogenyNode;
import erst.forester.java.src.org.forester.phylogeny.iterators.PostOrderStackObject;

/**
 */
public final class PhylogenyWriter {
    /**
     * Creates a new PhylogenyWriter object.
     */
    public PhylogenyWriter() {
    }

    /**
     * DOCUMENT ME!
     * 
     * @param tree
     *            DOCUMENT ME!
     * @param simple_nh
     *            DOCUMENT ME!
     * @return DOCUMENT ME!
     */
    public StringBuffer toNewHampshire( final Phylogeny tree, boolean simple_nh ) {
        setOutputFormt( TO_NH );
        setSimpleNH( simple_nh );

        return getOutput( tree );
    }

    /**
     * DOCUMENT ME!
     * 
     * @param tree
     *            DOCUMENT ME!
     * @param simple_nh
     *            DOCUMENT ME!
     * @param out_file
     *            DOCUMENT ME!
     * @throws IOException
     *             DOCUMENT ME!
     */
    public void toNewHampshire( final Phylogeny tree, boolean simple_nh,
            final File out_file ) throws IOException {
        writeToFile( toNewHampshire( tree, simple_nh ), out_file );
    }

    /**
     * DOCUMENT ME!
     * 
     * @param tree
     *            DOCUMENT ME!
     * @return DOCUMENT ME!
     */
    public StringBuffer toNewHampshireX( final Phylogeny tree ) {
        setOutputFormt( TO_NHX1 );

        return getOutput( tree );
    }

    /**
     * DOCUMENT ME!
     * 
     * @param tree
     *            DOCUMENT ME!
     * @param out_file
     *            DOCUMENT ME!
     * @throws IOException
     *             DOCUMENT ME!
     */
    public void toNewHampshireX( final Phylogeny tree, final File out_file )
            throws IOException {
        writeToFile( toNewHampshireX( tree ), out_file );
    }

    /**
     * DOCUMENT ME!
     * 
     * @param tree
     *            DOCUMENT ME!
     * @return DOCUMENT ME!
     */
    public StringBuffer toPhyloXML( final Phylogeny tree ) {
        setOutputFormt( TO_PHYLOXML1 );

        return getOutput( tree );
    }

    /**
     * DOCUMENT ME!
     * 
     * @param tree
     *            DOCUMENT ME!
     * @param out_file
     *            DOCUMENT ME!
     * @throws IOException
     *             DOCUMENT ME!
     */
    public void toPhyloXML( final Phylogeny tree, final File out_file )
            throws IOException {
        writeToFile( toPhyloXML( tree ), out_file );
    }

    private StringBuffer getOutput( final Phylogeny tree ) {
        if ( ( tree != null ) && !tree.isEmpty() ) {
            init( tree );

            if ( getOutputFormt() == TO_PHYLOXML1 ) {
                getStringBuffer().append( PhyloXMLmapping.PHYLOGENY_OPEN );
            }

            while ( isHasNext() ) {
                next();
            }

            if ( getOutputFormt() == TO_PHYLOXML1 ) {
                getStringBuffer().append( PhyloXMLmapping.PHYLOGENY_CLOSE );
            }

            return getStringBuffer();
        }
        else {
            return new StringBuffer( 0 );
        }
    }

    private void init( final Phylogeny tree ) {
        setStringBuffer( new StringBuffer() );
        setSawComma( false );
        setHasNext( true );
        setRoot( tree.getRoot() );
        setStack( new Stack() );
        getStack().push( new PostOrderStackObject( tree.getRoot(), 1 ) );
        setLevel( 0 );
    }

    private void next() {
        while ( true ) {
            final PostOrderStackObject si = ( PostOrderStackObject ) getStack()
                    .pop();
            final PhylogenyNode node = si.getNode();
            int phase = si.getPhase();

            if ( phase > node.getNumberOfChildNodes() ) {
                setHasNext( node != getRoot() );
                writeNode( node );

                if ( !node.isRoot() ) {
                    if ( !node.isLastChildNode() ) {
                        writeCladeSeparator();
                    }
                    else {
                        writeCloseClade();
                    }
                }

                return;
            }
            else {
                getStack()
                        .push( new PostOrderStackObject( node, ( phase + 1 ) ) );

                if ( node.isInternal() ) {
                    getStack().push(
                            new PostOrderStackObject( node
                                    .getChildNode( phase - 1 ), 1 ) );
                    writeOpenClade();
                }
            }
        }
    } // next()

    private void writeOpenClade() {
        if ( getOutputFormt() == TO_PHYLOXML1 ) {
            for ( int i = 0; i < getLevel(); ++i ) {
                getStringBuffer().append( PhyloXMLmapping.IND );
            }

            getStringBuffer().append( PhyloXMLmapping.CLADE_OPEN );
        }
        else if ( ( getOutputFormt() == TO_NHX1 )
                || ( getOutputFormt() == TO_NH ) ) {
            if ( !isSawComma() ) {
                getStringBuffer().append( "(" );
            }

            setSawComma( false );
        }

        increaseLevel();
    }

    private void writeCloseClade() {
        if ( getOutputFormt() == TO_PHYLOXML1 ) {
            getStringBuffer().append( PhyloXMLmapping.CLADE_CLOSE );
        }
        else if ( ( getOutputFormt() == TO_NHX1 )
                || ( getOutputFormt() == TO_NH ) ) {
            getStringBuffer().append( ")" );
        }

        decreaseLevel();
    }

    private void writeCladeSeparator() {
        if ( getOutputFormt() == TO_PHYLOXML1 ) {
            getStringBuffer().append( PhyloXMLmapping.NL );
        }
        else if ( ( getOutputFormt() == TO_NHX1 )
                || ( getOutputFormt() == TO_NH ) ) {
            getStringBuffer().append( "," );
            setSawComma( true );
        }
    }

    private void writeNode( final PhylogenyNode node ) {
        if ( getOutputFormt() == TO_PHYLOXML1 ) {
            getStringBuffer().append( node.toXML() );
        }
        else if ( getOutputFormt() == TO_NHX1 ) {
            getStringBuffer().append( node.toNewHampshireX() );
        }
        else if ( getOutputFormt() == TO_NH ) {
            getStringBuffer().append( node.toNewHampshire( isSimpleNH() ) );
        }
    }

    private static void writeToFile( final StringBuffer sb, final File out_file )
            throws IOException {
        if ( out_file.exists() ) {
            throw new IOException( "Attempt to overwrite existing file \""
                    + out_file.getAbsolutePath() + " \"." );
        }

        if ( !out_file.canWrite() ) {
            throw new IOException( "Can not write to file \""
                    + out_file.getAbsolutePath() + " \"." );
        }

        PrintWriter out = new PrintWriter( new FileWriter( out_file ), true );
        out.print( sb );
        out.flush();
        out.close();
    }

    private boolean isHasNext() {
        return _has_next;
    }

    private void setHasNext( boolean has_next ) {
        _has_next = has_next;
    }

    private void increaseLevel() {
        ++_level;
    }

    private void decreaseLevel() {
        --_level;
    }

    private PhylogenyNode getRoot() {
        return _root;
    }

    private void setRoot( final PhylogenyNode root ) {
        _root = root;
    }

    private StringBuffer getStringBuffer() {
        return _sb;
    }

    private void setStringBuffer( final StringBuffer sb ) {
        _sb = sb;
    }

    private Stack getStack() {
        return _stack;
    }

    private void setStack( final Stack stack ) {
        _stack = stack;
    }

    private boolean isSawComma() {
        return _saw_comma;
    }

    private void setSawComma( boolean saw_comma ) {
        _saw_comma = saw_comma;
    }

    private byte getOutputFormt() {
        return _output_formt;
    }

    private void setOutputFormt( byte output_formt ) {
        _output_formt = output_formt;
    }

    private boolean isSimpleNH() {
        return _simple_nh;
    }

    private void setSimpleNH( boolean simple_nh ) {
        _simple_nh = simple_nh;
    }

    private int getLevel() {
        return _level;
    }

    private void setLevel( int level ) {
        _level = level;
    }

    private boolean           _saw_comma;
    private StringBuffer      _sb;
    private PhylogenyNode     _root;
    private boolean           _has_next;
    private Stack             _stack;
    private byte              _output_formt;
    private boolean           _simple_nh;
    private int               _level;
    final static private byte TO_NH        = 0;
    final static private byte TO_NHX1      = 1;
    final static private byte TO_PHYLOXML1 = 2;
} // end of public final class PhylogenyWriter.
