package erst.forester.java.src.org.forester.phylogeny.data;

public class EcNumber implements PhylogenyData {

    private int _first;
    private int _second;
    private int _third;
    private int _forth;
    private Support _support;
    
    public void init() {
        // TODO Auto-generated method stub
    }
    
    public StringBuffer toPhyloXML( int level ) {
        // TODO Auto-generated method stub
        return null;
    }

    public PhylogenyData copy() {
        // TODO Auto-generated method stub
        return null;
    }

    public boolean isEqual( PhylogenyData data ) {
        // TODO Auto-generated method stub
        return false;
    }

    public StringBuffer asText() {
        // TODO Auto-generated method stub
        return null;
    }

    public StringBuffer asSimpleText() {
        // TODO Auto-generated method stub
        return null;
    }

}
