/*
 * ATVnodeSeqPanel.java Added to ATV by Ethy Cannon 7/9/04
 */

package erst.forester.java.src.org.forester.atv;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.awt.datatransfer.*;

import javax.swing.JPanel;

import erst.forester.java.src.org.forester.phylogeny.*;

public class ATVnodeSeqPanel extends JPanel implements ActionListener,
        ClipboardOwner {

    private boolean         can_use_clipboard;

    private PhylogenyNode   node;

    private ATVnodeSeqFrame atvnodeseqframe;
  
    private Vector          sequence_names = new Vector();

    //added by renata
////    private Vector          atvNumbers = new Vector();
////    private Vector          parsNumbers = new Vector();
//    private Vector          atvtopars = new Vector();
   
    JLabel                  popup_title;

    JButton                 close_button;

    JButton                 copy_button;
    JTextArea               name_list;

    ATVnodeSeqPanel( PhylogenyNode n, ATVnodeSeqFrame anf ) {
        node = n;
//        System.out.println("&&&&&&&&&&& node &&&&&&&"  + n);
        atvnodeseqframe = anf;
        String title = "ATV - PARS";
        atvnodeseqframe.setTitle( title );

        // check to see if we have permission to use the clipboard:
        can_use_clipboard = true;
        /* Obsolete method used. Exclude for now. (Petar)

        SecurityManager sm = System.getSecurityManager();
        if (sm != null) {
            try {
                sm.checkSystemClipboardAccess();
            } catch (Exception e) {
                //nope!
                can_use_clipboard = false;
            }
        }
        */       
        setLayout( new BorderLayout( 10, 10 ) );

        popup_title = new JLabel( "Genomes for this Node " + n.getID() );
        popup_title.setHorizontalAlignment( SwingConstants.CENTER );
        add( popup_title, "North" );

        getNodeInfo();
        displayNodeInfo();

        JPanel button_panel = new JPanel( new FlowLayout() );
        close_button = new JButton( "Close" );
        close_button.addActionListener( this );
        button_panel.add( close_button );

        if (can_use_clipboard) {
            copy_button = new JButton("Copy to Clipboard");
            copy_button.addActionListener(this);
            button_panel.add(copy_button);
        }

        add( button_panel, "South" );
    }


    public void actionPerformed( ActionEvent e ) {
        if ( e.getSource() == close_button ) {
            close();
        } else if (e.getSource() == copy_button) {
            copy();
        }
    }


    void close() {
        atvnodeseqframe.remove(); // to release slot in array
        atvnodeseqframe.dispose();
        atvnodeseqframe = null;
    }


    private void copy() { 
        if (!can_use_clipboard) {
            // can't do this!
            return;
        }
        
        Clipboard sys_clipboard = getToolkit().getSystemClipboard(); 
        StringSelection contents = new StringSelection(name_list.getText());
        sys_clipboard.setContents(contents, this); 
    }


    private void getNodeInfo() {
        getSequenceNames( node );
    }


    private void displayNodeInfo() {
        name_list = new JTextArea( "" );
        name_list.setEditable( false );
        name_list.setWrapStyleWord( true );
        name_list.setLineWrap( true );
        add( new JScrollPane( name_list ), "Center" );
        
        int num_names = sequence_names.size();
        String list = "";
        for ( int i = 0; i < num_names; i++ ) {
            list += ( String ) sequence_names.elementAt( i ) + "\n"; // node number " + node.getID() + "\n"; //added by renata node number and node.getID()
        }
        name_list.setText( list );
    }
//    //added by renata
//    private void getNodeNumberInfo() {
//        getSequenceNumbers( node );
//    }
    
//    //added by renata
//    private void getSequenceNumbers( PhylogenyNode n ) {
//        if ( n != null ) {
//                      if ( !n.isExternal() &&
//                              n.getChildNode1() != null && 
//                                  n.getChildNode2() != null ) {
//                getSequenceNumbers( n.getChildNode1() );
//                getSequenceNumbers( n.getChildNode2() );
//                System.out.println("  **************** Internal  node getID " + n.getID() + "  getChildNodeIndex " + n.getChildNodeIndex());                
//            }
//            else {
//                atvNumbers.add(n.getID());
//                parsNumbers.add(atvtopars.elementAt(n.getID()));
//                System.out.println(" %%%%%%%%%%%%%%%external node getID " + n.getID() + "  getChildNodeIndex " + n.getChildNodeIndex());
//            }      
//        }
//    }



    public void lostOwnership( Clipboard clipboard, Transferable contents ) {
    }


    private void getSequenceNames( PhylogenyNode n ) {
        if ( n != null ) {
                      if ( !n.isExternal() &&
                              n.getChildNode1() != null && 
                                  n.getChildNode2() != null ) {
                getSequenceNames( n.getChildNode1() );
                getSequenceNames( n.getChildNode2() );
//                System.out.println("  **************** Internal  node getID " + n.getID() + "  getChildNodeIndex " + n.getChildNodeIndex());                
            }
            else {
                sequence_names.add( n.getSeqName() );
//                System.out.println(" %%%%%%%%%%%%%%%external node getID " + n.getID() + "  getChildNodeIndex " + n.getChildNodeIndex());
            }      
        }
    }
}