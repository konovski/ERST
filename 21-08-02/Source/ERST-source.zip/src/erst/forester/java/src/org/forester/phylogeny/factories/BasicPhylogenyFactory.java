/*
 * Created on Jun 11, 2005
 */
package erst.forester.java.src.org.forester.phylogeny.factories;

import java.io.IOException;

import erst.forester.java.src.org.forester.phylogeny.Phylogeny;



/**
 * Convinience class for  PhylogenyFactories not using parameters.
 * 
 * @author Christian M. Zmasek 
 */
public abstract class BasicPhylogenyFactory implements PhylogenyFactory {

    public Phylogeny create() {
        return new Phylogeny();
    }

    public Phylogeny[] create( Object source, Object creator ) throws IOException {
        return create( source, creator, null );
    }
 

}
