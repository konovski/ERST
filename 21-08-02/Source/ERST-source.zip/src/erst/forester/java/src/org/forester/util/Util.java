/*
 * Created on Jun 5, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package erst.forester.java.src.org.forester.util;

import java.util.Vector;

import erst.forester.java.src.org.forester.phylogeny.Phylogeny;
import erst.forester.java.src.org.forester.phylogeny.PhylogenyNode;
import erst.forester.java.src.org.forester.phylogeny.iterators.PreorderTreeIterator;

/**
 * @author Christian Zmasek
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public final class Util {
    // Adds all element from Vector from into Vector addto.
    // (Last modified: 11/22/00)
	// Modified by Petar (2016)
	//    public static void addIntoVector( final Vector from, final Vector addto ) {
    public static void addIntoVector( final Vector<Object> from, final Vector<Object> addto ) {
        for ( int i = 0; i < from.size(); ++i ) {
            addto.addElement( from.elementAt( i ) );
        }
    } // addIntoVector( Vector, Vector )

    public static String sanitize( final String s ) {
        if ( s == null ) {
            return "";
        }
        else {
            return s.trim();    
        }
    }
    
    public static boolean isEmpty( final String s ) {
        return ( s == null || s.trim().length() < 1 );
    }
    
    public static double atLeastZero( double d ) {
        if ( d > 0.0 ) {
            return d;
        }
        else {
            return 0.0;
        }
    }

    /**
     * Rounds d to an int.
     */
    public static int roundToInt( double d ) {
        return ( int ) ( d + 0.5 );
    }

    public static String StringArrayToString( String[] a ) {
        StringBuffer sb = new StringBuffer();
        if ( a != null && a.length > 0 ) {
            for ( int i = 0; i < a.length - 1; ++i ) {
                sb.append( a[ i ] + ", " );
            }
            sb.append( a[ a.length - 1 ] );
        }
        return sb.toString();
    
    }

    /**
     * Removes all white space from String s.
     * 
     * @return String s with white space removed
     */
    public static String removeWhiteSpace( String s ) {
        int i;
        for ( i = 0; i <= s.length() - 1; i++ ) {
            if ( s.charAt( i ) == ' ' || s.charAt( i ) == '\t'
                    || s.charAt( i ) == '\n' || s.charAt( i ) == '\r' ) {
                s = s.substring( 0, i ) + s.substring( i + 1 );
                i--;
            }
        }
        return s;
    }

    /**
     * This determines whether String[] a and String[] b have at least one
     * String in common (intersect). Returns false if at least one String[] is
     * null or empty. (added: 11/27/03) (last modified: 11/27/03)
     * 
     * @param a
     *            a String[] b a String[]
     * @return true if both a and b or not empty or null and contain at least
     *         one element in common false otherwise
     */
    public static boolean doIntersect( String[] a, String[] b ) {
    
        if ( a == null || b == null ) {
            return false;
        }
        if ( a.length < 1 || b.length < 1 ) {
            return false;
        }
    
        for ( int i = 0; i < a.length; ++i ) {
            String ai = a[ i ];
            for ( int j = 0; j < b.length; ++j ) {
    
                if ( ai != null && b[ j ] != null && ai.equals( b[ j ] ) ) {
                    return true;
                }
            }
        }
        return false;
    
    } // doIntersect( String[], String[] )
    
    private Util() {
    }

    /**
     * For each external node of Phylogeny tree: Cleans up SWISS-PROT species
     * names: It removes everything (including ) after a potential "/", "_",
     * "-", "\", ";", ".". It removes everything which comes after the fifth
     * letter.
     * <p>
     * (last modified: 10/03/01)
     */
    public static void cleanSpeciesNamesInExtNodes( Phylogeny tree ) {
    
        PhylogenyNode node = tree.getFirstExternalNode();
    
        String species = "";
        int i = 0;
    
        while ( node != null ) {
    
            species = node.getTaxonomy().trim();
            if ( species.length() > 0 ) {
    
                i = species.indexOf( "/" );
                if ( i >= 0 ) {
                    species = species.substring( 0, i );
                }
                i = species.indexOf( "_" );
                if ( i >= 0 ) {
                    species = species.substring( 0, i );
                }
                i = species.indexOf( "-" );
                if ( i >= 0 ) {
                    species = species.substring( 0, i );
                }
                i = species.indexOf( "\\" );
                if ( i >= 0 ) {
                    species = species.substring( 0, i );
                }
                i = species.indexOf( ";" );
                if ( i >= 0 ) {
                    species = species.substring( 0, i );
                }
                i = species.indexOf( "." );
                if ( i >= 0 ) {
                    species = species.substring( 0, i );
                }
    
                node.setTaxonomy( species );
    
            }
            node = node.getNextExternalNode();
        }
    
    }

    /**
     * Copies the content of the sequence name field to the species name field
     * (if empty - does not overwrite!) for each node of Phylogeny tree.
     * <p>
     * If the sequence name appears to be (contain) a SWISS-PROT name, the
     * species name is extracted in the following manner: It extracts all
     * characters after the <b>last <\b>"_" and before any potential "/", "-",
     * "\", ";", ".".
     * <p>
     * If the sequence name appears not to be (contain) a SWISS-PROT, name it is
     * just copied unchanged to the species name field.
     * <p>
     * (last modified: 10/03/01)
     * 
     * @param tree
     *            the Phylogeny for which species' names are to be
     *            extracted/copied
     */
    public static void extractSpeciesNameFromSeqName( Phylogeny tree ) {
    
        PreorderTreeIterator it = null;
        int i = 0;
    
        it = new PreorderTreeIterator( tree );
    
        String seqname = "";
    
        while ( it.hasNext() ) {
            PhylogenyNode n = it.next();
            if ( n.getTaxonomy().length() < 1 ) {
                seqname = n.getSeqName();
                i = seqname.lastIndexOf( "_" );
                if ( i >= 0 ) {
                    seqname.trim();
                    seqname = seqname.substring( i + 1 );
                    i = seqname.indexOf( "/" );
                    if ( i >= 0 ) {
                        seqname = seqname.substring( 0, i );
                    }
                    i = seqname.indexOf( "-" );
                    if ( i >= 0 ) {
                        seqname = seqname.substring( 0, i );
                    }
                    i = seqname.indexOf( "\\" );
                    if ( i >= 0 ) {
                        seqname = seqname.substring( 0, i );
                    }
                    i = seqname.indexOf( ";" );
                    if ( i >= 0 ) {
                        seqname = seqname.substring( 0, i );
                    }
                    i = seqname.indexOf( "." );
                    if ( i >= 0 ) {
                        seqname = seqname.substring( 0, i );
                    }
                    n.setTaxonomy( seqname );
                }
                else {
                    n.setTaxonomy( seqname );
                }
            }
            //it.next();
        }
    
    }
    
}
