/*
 * Created on May 15, 2005 TODO To change the template for this generated file
 * go to Window - Preferences - Java - Code Style - Code Templates
 */
package erst.forester.java.src.org.forester.atv;

import java.awt.Color;

/**
 * @author Christian Zmasek TODO To change the template for this generated type
 *         comment go to Window - Preferences - Java - Code Style - Code
 *         Templates
 */
public final class ATVconstants {

     public final static Color    GUI_BACKGROUND_DEFAULT            = new Color(
                                                                           255,
                                                                           255,
                                                                           255 );

    public final static Color    CHECKBOX_TEXT_COLOR_DEFAULT       = new Color(
                                                                           0,
                                                                           0, 
                                                                           0 );

    public final static Color    CHECKBOX_BACKGROUND_COLOR_DEFAULT = GUI_BACKGROUND_DEFAULT;

    public final static Color    BUTTON_TEXT_COLOR_DEFAULT         = new Color(
                                                                           0,
                                                                           0, 
                                                                           0 );

    public final static Color    BUTTON_BACKGROUND_COLOR_DEFAULT   = new Color(
                                                                           176,
                                                                           196,
                                                                           222 );

    public final static Color    MENU_BACKGROUND_COLOR_DEFAULT     = GUI_BACKGROUND_DEFAULT;

    protected final static Color MENU_TEXT_COLOR_DEFAULT           = new Color(
                                                                           0,
                                                                           0, 
                                                                           0 );
}
