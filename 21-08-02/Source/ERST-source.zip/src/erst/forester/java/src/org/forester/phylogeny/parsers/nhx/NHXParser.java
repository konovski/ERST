/*
 * Copyright 2005, Christian M. Zmasek, Ethalinda K.S. Cannon Created on Oct 3,
 * 2005. $Id: NHXParser.java,v 1.1 2005/12/04 03:46:02 cmzmasek Exp $
 */
package erst.forester.java.src.org.forester.phylogeny.parsers.nhx;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import java.util.ArrayList;
import java.util.Date;

import erst.forester.java.src.org.forester.development.Development;
import erst.forester.java.src.org.forester.phylogeny.Phylogeny;
import erst.forester.java.src.org.forester.phylogeny.PhylogenyNode;
import erst.forester.java.src.org.forester.phylogeny.parsers.PhylogenyParser;
import erst.forester.java.src.org.forester.phylogeny.parsers.PhylogenyParserException;

/**
 * Parsing of phylogenies described in New Hamphshire (NH) or New Hamphshire
 * Extended (NHX) format. Last modified: 10/04/2005 Created: 10/03/2005 by
 * Christian M. Zmasek. Last modified: 10/23/2005 by Christian M. Zmasek.
 * 
 * @version 1.000
 * @author Christian M Zmasek
 */
public final class NHXParser implements PhylogenyParser {

    // Public methods
    // --------------

    /**
     * This sets the source to be parsed. The source can be: String,
     * StringBuffer, char[], File, or InputStream. The source can contain more
     * than one phylogenies in either New Hamphshire (NH) or New Hamphshire
     * Extended (NHX) format. There is no need to separate phylogenies with any
     * special character. White space is always ignored, as are semicolons
     * inbetween phylogenies. Example of a source describing two phylogenies
     * (source is a String, in this example): "(A,(B,(C,(D,E)de)cde)bcde)abcde
     * ((((A,B)ab,C)abc,D)abcd,E)abcde"
     * 
     * @see #parse()
     * @see org.forester.phylogeny.parsers.PhylogenyParser#setSource(java.lang.Object)
     * @param nhx_source
     *            the source to be parsed (String, StringBuffer, char[], File,
     *            or InputStream)
     * @throws IOException
     * @throws PhylogenyParserException
     */
    public void setSource( final Object nhx_source ) throws IOException {
        if ( nhx_source == null ) {
            throw new PhylogenyParserException( getClass()
                    + ": attempt to parse null object." );
        }
        else if ( nhx_source instanceof String ) {
            setInputType( STRING );
            setSourceLength( ( ( String ) nhx_source ).length() );
            setNhxSource( nhx_source );
        }
        else if ( nhx_source instanceof StringBuffer ) {
            setInputType( STRING_BUFFER );
            setSourceLength( ( ( StringBuffer ) nhx_source ).length() );
            setNhxSource( nhx_source );
        }
        else if ( nhx_source instanceof char[] ) {
            setInputType( CHAR_ARRAY );
            setSourceLength( ( ( char[] ) nhx_source ).length );
            setNhxSource( nhx_source );
        }
        else if ( nhx_source instanceof File ) {
            setInputType( BUFFERED_READER );
            setSourceLength( 0 );

            final File f = ( File ) nhx_source;

            if ( !f.exists() ) {
                throw new IOException( "\"" + f.getAbsolutePath()
                        + "\" does not exist." );
            }
            else if ( !f.isFile() ) {
                throw new IOException( "\"" + f.getAbsolutePath()
                        + "\" is not a file." );
            }
            else if ( !f.canRead() ) {
                throw new IOException( "\"" + f.getAbsolutePath()
                        + "\" is not a readable." );
            }

            setNhxSource( new BufferedReader( new FileReader( f ) ) );
        }
        else if ( nhx_source instanceof InputStream ) {
            setInputType( BUFFERED_READER );
            setSourceLength( 0 );

            final InputStreamReader isr = new InputStreamReader(
                    ( InputStream ) nhx_source );
            setNhxSource( new BufferedReader( isr ) );
        }
        else {
            throw new IllegalArgumentException( getClass()
                    + " can only parse objects of type String,"
                    + " StringBuffer, char[], File," + " or InputStream "
                    + " [attempt to parse object of " + nhx_source.getClass()
                    + "]." );
        }
    } // setSource( final Object nhx_source )

    /**
     * Parses the source set with setSource( final Object nhx_source ). Returns
     * the Phylogenies found in the source as Phylogeny[].
     * 
     * @see #setSource( final Object nhx_source )
     * @see org.forester.phylogeny.parsers.PhylogenyParser#parse()
     * @return Phylogeny[]
     * @throws IOException
     * @throws PhylogenyParserException
     */
    public Phylogeny[] parse() throws IOException {
        if ( DEBUG ) {
            System.out.println( "\n[DEBUG] " + getClass() + ": START." );
        }

        long start_time = 0;

        if ( TIME ) {
            start_time = new Date().getTime();
        }

        setPhylogenies( new ArrayList() );
        setCladeLevel( 0 );
        newCurrentAnotation();

        int i = 0;

        while ( true ) {
            char c = '\b';

            if ( getInputType() == BUFFERED_READER ) {
                int ci = ( ( BufferedReader ) getNhxSource() ).read();

                if ( ci >= 0 ) {
                    c = ( char ) ci;
                }
                else {
                    break;
                }
            }
            else {
                if ( i >= getSourceLength() ) {
                    break;
                }
                else {
                    switch ( getInputType() ) {
                    case STRING:
                        c = ( ( String ) getNhxSource() ).charAt( i );

                        break;

                    case STRING_BUFFER:
                        c = ( ( StringBuffer ) getNhxSource() ).charAt( i );

                        break;

                    case CHAR_ARRAY:
                        c = ( ( char[] ) getNhxSource() )[ i ];

                        break;
                    }
                }
            }

            if ( c == '(' ) {
                processOpenParen();
            }
            else if ( c == ')' ) {
                processCloseParen();
            }
            else if ( c == ',' ) {
                processComma();
            }
            else if ( ( c == '\b' ) || ( c == '\t' ) || ( c == '\n' )
                    || ( c == '\f' ) || ( c == '\r' ) || ( c == ' ' )
                    || ( ( getCladeLevel() == 0 ) && ( c == ';' ) ) ) {}
            else {
                getCurrentAnotation().append( c );
            }

            ++i;
        }

        if ( getCladeLevel() != 0 ) {
            setPhylogenies( null );
            throw new PhylogenyParserException(
                    "Error in NH / NHX: Most likely cause: Number of open parens does not equal number of close parens." );
        }

        if ( getCurrentPhylogeny() != null ) {
            finishPhylogeny();
        }
        else if ( getCurrentAnotation().length() > 0 ) {
            finishSingleNodePhylogeny();
        }
        else if ( getPhylogenies().size() < 1 ) {
            getPhylogenies().add( new Phylogeny() );
        }

        if ( TIME ) {
            System.out.println( "[TIME] Parsing required "
                    + ( new Date().getTime() - start_time ) + "ms." );
        }

        if ( DEBUG ) {
            System.out.println( "[DEBUG] " + getClass() + ": END." );
        }

        return getPhylogeniesAsArray();
    } // parse()

    // Private methods
    // ----------------

    /**
     * Called if a opening paren is encountered.
     * 
     * @throws PhylogenyParserException
     */
    private void processOpenParen() throws PhylogenyParserException {
        PhylogenyNode new_node = new PhylogenyNode();

        if ( getCladeLevel() == 0 ) {
            if ( getCurrentPhylogeny() != null ) {
                finishPhylogeny();
            }

            setCladeLevel( 1 );
            newCurrentAnotation();
            setCurrentPhylogeny( new Phylogeny() );
            getCurrentPhylogeny().setRoot( new_node );

            if ( DEBUG ) {
                System.out.println( "[DEBUG] "
                        + "Starting a new Phylogeny [(]." );
            }
        }
        else {
            if ( DEBUG ) {
                System.out.println( "[DEBUG] [level=" + getCladeLevel()
                        + "] [(]." );
            }

            increaseCladeLevel();
            getCurrentNode().addAsChild( new_node );
        }

        setCurrentNode( new_node );
        setSawClosingParen( false );
    } // processOpenParen()

    /**
     * Called if a closing paren is encountered.
     * 
     * @throws PhylogenyParserException
     */
    private void processCloseParen() throws PhylogenyParserException {
        decreaseCladeLevel();

        if ( !isSawClosingParen() ) {
            PhylogenyNode new_node = new PhylogenyNode();
            new_node.parseNHX( getCurrentAnotation().toString() );

            if ( DEBUG ) {
                System.out.println( "[DEBUG] New node created for: "
                        + getCurrentAnotation() + " [level=" + getCladeLevel()
                        + "] [)]." );
            }

            newCurrentAnotation();
            getCurrentNode().addAsChild( new_node );
        }
        else {
            getCurrentNode().getLastChildNode().parseNHX(
                    getCurrentAnotation().toString() );

            if ( DEBUG ) {
                System.out.println( "[DEBUG] Node annotated with: "
                        + getCurrentAnotation() + " [level=" + getCladeLevel()
                        + "] [)]." );
            }

            newCurrentAnotation();
        }

        if ( !getCurrentNode().isRoot() ) {
            setCurrentNode( getCurrentNode().getParent() );
        }

        setSawClosingParen( true );
    } // processCloseParen()

    /**
     * Called if a comma is encountered.
     * 
     * @throws PhylogenyParserException
     */
    private void processComma() throws PhylogenyParserException {
        if ( !isSawClosingParen() ) {
            PhylogenyNode new_node = new PhylogenyNode();
            new_node.parseNHX( getCurrentAnotation().toString() );
            getCurrentNode().addAsChild( new_node );

            if ( DEBUG ) {
                System.out.println( "[DEBUG] New node created for: "
                        + getCurrentAnotation() + " [level=" + getCladeLevel()
                        + "] [,]." );
            }
        }
        else {
            getCurrentNode().getLastChildNode().parseNHX(
                    getCurrentAnotation().toString() );

            if ( DEBUG ) {
                System.out.println( "[DEBUG] Node annotated with: "
                        + getCurrentAnotation() + " [level=" + getCladeLevel()
                        + "] [,]." );
            }
        }

        newCurrentAnotation();

        setSawClosingParen( false );
    } // processComma()

    /**
     * Replaces the current annotation with a new StringBuffer.
     */
    private void newCurrentAnotation() {
        setCurrentAnotation( new StringBuffer() );
    }

    /**
     * Finishes the current Phylogeny and adds it to the list of Phylogenies
     * created.
     * 
     * @throws PhylogenyParserException
     */
    private void finishPhylogeny() throws PhylogenyParserException {
        setCladeLevel( 0 );

        if ( getCurrentPhylogeny() != null ) {
            getCurrentPhylogeny().getRoot().parseNHX(
                    getCurrentAnotation().toString() );

            if ( DEBUG ) {
                System.out.println( "[DEBUG] Node annotated with: "
                        + getCurrentAnotation() + " [level=" + getCladeLevel()
                        + "]." );
                System.out.println( "[DEBUG] " + "Completed Phylogeny: "
                        + getCurrentPhylogeny().toNewHampshireX() );
            }

            getPhylogenies().add( getCurrentPhylogeny() );
        }
    } // finishPhylogeny()

    private void finishSingleNodePhylogeny() throws PhylogenyParserException {
        setCladeLevel( 0 );

        PhylogenyNode new_node = new PhylogenyNode();
        new_node.parseNHX( getCurrentAnotation().toString() );
        setCurrentPhylogeny( new Phylogeny() );
        getCurrentPhylogeny().setRoot( new_node );

        if ( DEBUG ) {
            System.out.println( "[DEBUG] "
                    + "Completed single node Phylogeny: "
                    + getCurrentPhylogeny().toNewHampshireX() );
        }

        getPhylogenies().add( getCurrentPhylogeny() );
    }

    /**
     * Returns the Phylogenies created as Array.
     * 
     * @return the Phylogenies created as Array
     */
    private Phylogeny[] getPhylogeniesAsArray() {
        Phylogeny[] p = new Phylogeny[ getPhylogenies().size() ];

        for ( int i = 0; i < getPhylogenies().size(); ++i ) {
            p[ i ] = ( Phylogeny ) getPhylogenies().get( i );
        }

        return p;
    }

    /**
     * Increases the clade level by one.
     */
    private void increaseCladeLevel() {
        ++_clade_level;
    }

    /**
     * Decreases the clade level by one.
     * 
     * @throws PhylogenyParserException
     *             if level goes below zero.
     */
    private void decreaseCladeLevel() throws PhylogenyParserException {
        if ( getCladeLevel() < 0 ) {
            throw new PhylogenyParserException(
                    "Error in NH / NHX: Most likely cause: Number of close parens is larger than number of open parens." );
        }

        --_clade_level;
    }

    // Private accessor methods
    // ------------------------
    private StringBuffer getCurrentAnotation() {
        return _current_anotation;
    }

    private void setCurrentAnotation( StringBuffer current_anotation ) {
        _current_anotation = current_anotation;
    }

    private Object getNhxSource() {
        return _nhx_source;
    }

    private void setNhxSource( final Object nhx_source ) {
        _nhx_source = nhx_source;
    }

    private boolean isSawClosingParen() {
        return _saw_closing_paren;
    }

    private void setSawClosingParen( boolean saw_closing_paren ) {
        _saw_closing_paren = saw_closing_paren;
    }

    private int getSourceLength() {
        return _source_length;
    }

    private void setSourceLength( int source_length ) {
        _source_length = source_length;
    }

    private ArrayList getPhylogenies() {
        return _phylogenies;
    }

    private void setPhylogenies( final ArrayList phylogenies ) {
        _phylogenies = phylogenies;
    }

    private Phylogeny getCurrentPhylogeny() {
        return _current_phylogeny;
    }

    private void setCurrentPhylogeny( final Phylogeny current_phylogeny ) {
        _current_phylogeny = current_phylogeny;
    }

    private PhylogenyNode getCurrentNode() {
        return _current_node;
    }

    private void setCurrentNode( final PhylogenyNode current_node ) {
        _current_node = current_node;
    }

    private byte getInputType() {
        return _input_type;
    }

    private void setInputType( byte input_type ) {
        _input_type = input_type;
    }

    private int getCladeLevel() {
        return _clade_level;
    }

    private void setCladeLevel( int clade_level ) {
        if ( clade_level < 0 ) {
            throw new IllegalArgumentException(
                    "Attempt to set clade level to a number smaller than zero." );
        }

        _clade_level = clade_level;
    }

    // Static constants
    // ----------------
    final static private boolean DEBUG           = Development.isDebug();
    final static private boolean TIME            = Development.isTime();
    final static private byte    STRING          = 0;
    final static private byte    STRING_BUFFER   = 1;
    final static private byte    CHAR_ARRAY      = 2;
    final static private byte    BUFFERED_READER = 3;

    // Instance variables
    // ------------------
    private boolean              _saw_closing_paren;
    private byte                 _input_type;
    private int                  _source_length;
    private PhylogenyNode        _current_node;
    private StringBuffer         _current_anotation;
    private Object               _nhx_source;
    private int                  _clade_level;
    private ArrayList            _phylogenies;
    private Phylogeny            _current_phylogeny;

} // end of class NHXParser.
