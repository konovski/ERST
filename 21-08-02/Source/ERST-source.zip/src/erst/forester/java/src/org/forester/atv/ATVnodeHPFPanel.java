/*
 * ATVnodeHPFPanel.java Added to ATV by Ethy Cannon 7/9/04
 * 
 * Modified by Petar, 2016-2021.
 */

package erst.forester.java.src.org.forester.atv;

import java.io.*;
import java.util.ArrayList; 
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
//import java.util.*; Never used (Petar).
import java.awt.datatransfer.*;

import erst.CalcParameters;
//import erst.InputWindow; Never used (Petar).
import erst.forester.java.src.org.forester.phylogeny.*;
import erst.genalg.GetGL;
import erst.genalg.InnerData;
//import erst.tio.FormattedWriter;
import java.nio.file.StandardOpenOption;
import java.nio.file.Files;



public class ATVnodeHPFPanel extends JPanel implements ActionListener, ClipboardOwner {          
    //private boolean         can_use_clipboard; Not used (Petar).
    //private PhylogenyNode   node; Never used (Petar).
    private ATVnodeHPFFrame atvnodehpfframe;
    JLabel                  popup_title;
    JButton                 close_button;
    //JButton                 copy_button; Not used (Petar).
    JButton                 save_button;
    JTextArea               name_list;
	String 					list = "";
	String 					popup_title_text = "";

    // InnerData extractions added by Petar.
    protected static final int MAX_PARSIMONY  = InnerData.MAX_PARSIMONY;
    protected static final int MAX_LIKELIHOOD = InnerData.MAX_LIKELIHOOD;
    protected static final int MIN_ENTROPY    = InnerData.MIN_ENTROPY;
    /*
    */

    final JFileChooser fc = new JFileChooser();
    
    private static String currentDirectory = System.getProperty("user.dir"); // The name of the current directory.
   	public static JFileChooser fileCh = new JFileChooser(new File (currentDirectory));

     
//     private void displayHPFInfo(int n) {
     public void displayHPFInfo(int n) {
         //String tmpeleg = "", tmpelel = ""; Never used (Petar).
    	 list = "";
         name_list = new JTextArea( "" );
         name_list.setEditable( false );
         name_list.setWrapStyleWord( true );
         name_list.setLineWrap( true );
         add( new JScrollPane( name_list ), "Center" );
         
         //readGL readgainslosses = new readGL(); Replaced (Petar).
         // int elemento, tamanho; Never used (Petar).
         //readgainslosses.execute();  Replaced (Petar).
         
         /*The following two paragraphs: "getting gains" and "getting losses" are for
           diagnostic purposes only and can be commented off (Petar).
         //getting gains
         for (int i = 0; i < readgainslosses.getGain(n).size(); i ++) {
             tmpeleg = readgainslosses.getGainElement(n, i);
//             System.out.println(" size read gain " + tmpeleg + " node " + n);
         }
         //getting losses
         for (int i = 0; i < readgainslosses.getLoss(n).size(); i ++) {
             tmpelel = readgainslosses.getLossElement(n, i);
//             System.out.println(" size read loss " + tmpelel + " node " + n);
         }
         */
         
         //Display Gains and Losses at this node
         // Replacement of the original segment, which is commented out:
         ArrayList<String> gains = GetGL.getGains(n);
         ArrayList<String> losses = GetGL.getLosses(n);
         int numberOfGains = gains.size(); 
         int numberOfLosses = losses.size();
         
         // In many cases, the lists are empty. Proceed accordingly. 
         if (numberOfGains == 0) 
             list =  " NO  GAINS\n\n";
         else if (numberOfGains == 1)
             list = " " + numberOfGains + " GAIN\n\n";
         else 
             list =  " " + numberOfGains + " GAINS\n\n";
             
         for ( int i = 0; i < numberOfGains; i++ )
             list += gains.get(i) + "\t";

         if (numberOfLosses == 0)
             list += "\n\n  NO  LOSSES";
         else if (numberOfLosses == 1)  
             list += "\n\n " + numberOfLosses + " LOSS\n\n";
         else 
             list += "\n\n " + numberOfLosses + " LOSSES\n\n";
         
         for ( int i = 0; i < numberOfLosses; i++ )
             list += losses.get(i) + "\t";
             
         list += "\n";
         name_list.setText(list);
        /*
        */
         
         /* The original segment, which was replaced in order to stick with the new algorithm (Petar)
         int numberOfGains = readgainslosses.getGain(n).size();
         int numberOfLosses = readgainslosses.getLoss(n).size();
         String list;
         //Conditions for Gains
         if (readgainslosses.getGain(n).contains("")) { // zero gains however I had to store "" empty string that is count as 1 element in the array.
             list =  "NO  GAINS\n\n";
             numberOfGains--;
         }
         else if ((numberOfGains == 1) &&  !(readgainslosses.getGain(n).contains(""))) 
             list = numberOfGains + "  GAIN\n\n";
         else 
             list =  numberOfGains + "  GAINS\n\n";
         
         for ( int i = 0; i < numberOfGains; i++ )
             list += ( String ) readgainslosses.getGainElement(n, i) + "\t";
         list += "\n\n\n";
         
         // Conditions for Losses
         if (readgainslosses.getLoss(n).contains("")) { // zero gains however I had to store "" empty string that is count as 1 element in the array.
             list +=  "NO  LOSSES\n\n";
             numberOfLosses--;
         }
         else if ((numberOfLosses == 1) &&  !(readgainslosses.getLoss(n).contains("")))  
             list += numberOfLosses + "  LOSS\n\n";
         else 
             list +=  numberOfLosses + "  LOSSES\n\n";
         
         for ( int i = 0; i < numberOfLosses; i++ )
             list += ( String ) readgainslosses.getLossElement(n, i) + "\t";
         list += "\n";
         name_list.setText( list );
         /*
         */
         
         return;
     } // End of public void displayHPFInfo(int n)
    
     
    ATVnodeHPFPanel( PhylogenyNode n, ATVnodeHPFFrame anf ) {
        //node = n; Never used (Petar).
        atvnodehpfframe = anf;
        // Title creation added by Petar.
		String title = "ATV";
		int methodUsed = CalcParameters.getMethodUsed();
		switch (methodUsed) {
			case MAX_PARSIMONY:
				title += " - MP";
				break;
			case MAX_LIKELIHOOD:
				title += " - ML";
				break;
			case MIN_ENTROPY:
				title += " - ME";
		}		
        /*
        */
        atvnodehpfframe.setTitle( title );
        
         // check to see if we have permission to use the clipboard:
         //can_use_clipboard = true;
         /* Obsolete method used. Exclude for now. (Petar)
         SecurityManager sm = System.getSecurityManager();
          if (sm != null) {
             try {
                 sm.checkSystemClipboardAccess();
             } catch (Exception e) {
                //nope!
                 can_use_clipboard = false;
             }
         }
         */
        
         setLayout( new BorderLayout( 10, 10 ) );

         popup_title_text = "Genes Gained and Lost at Node " + n.getID();
         popup_title = new JLabel( popup_title_text );
         popup_title.setHorizontalAlignment( SwingConstants.CENTER );
         add( popup_title, "North" );

//         if (n.getID() >= 1)
//              displayHPFInfo(n.getID());
//             displayHPFInfo(0);
         displayHPFInfo(n.getID());

         JPanel button_panel = new JPanel( new FlowLayout() );
         close_button = new JButton( "Close" );
         close_button.addActionListener( this );
         button_panel.add( close_button );

         save_button = new JButton( "Save" );
         save_button.addActionListener( this );
         save_button.setToolTipText("Choose a file and save the text in it");
         button_panel.add( save_button );
         
//         if (can_use_clipboard) {
//             copy_button = new JButton("Copy to Clipboard");
//             copy_button.addActionListener(this);
//             button_panel.add(copy_button);
//         }

         add( button_panel, "South" );
     }


     public void actionPerformed( ActionEvent e ) {
         if ( e.getSource() == close_button ) {
             close();
         } else if (e.getSource() == save_button) {
             save();
//         } else if (e.getSource() == copy_button) {
//             copy();
         }
     }


     void close() {
         atvnodehpfframe.remove(); // to release slot in array
         atvnodehpfframe.dispose();
         atvnodehpfframe = null;
     }

     
	/*
		*/
	// A proper variant of the 'save' function (Petar).
    void save() {
    	// Choose a file, update the current directory.
		int returnVal = fileCh.showOpenDialog(ATVnodeHPFPanel.this);
		if (returnVal != JFileChooser.APPROVE_OPTION)
			return;
		File fileHPFsave = fileCh.getSelectedFile();
		fileCh.setSelectedFile(fileHPFsave);
		currentDirectory = fileHPFsave.getAbsoluteFile().getParent();
		final StandardOpenOption APPEND = StandardOpenOption.APPEND;
		final StandardOpenOption CREATE = StandardOpenOption.CREATE;
		
		// Write the already prepared contents in the file.
		try {
			Files.writeString(fileHPFsave.toPath(), popup_title_text + "\n\n" + list + "\n\n", CREATE, APPEND);
			//Files.writeString(fileHPFsave.toPath(), list, CREATE, APPEND);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	JOptionPane.showMessageDialog(null, "The data written in file " + fileHPFsave.getName());
    } // End of void save ().
		 
		/*
		*/
     
    /* The previous version of 'save'(not working).
    void save () {
         int returnVal = fc.showSaveDialog( this );
         File savelist = fc.getSelectedFile();
         fc.setSelectedFile( savelist );
     }
	*/

     //private void copy() { //throws java.io.IOException  {       
//         int returnVal = fc.showOpenDialog(this);
//         File phT = fc.getSelectedFile();
//         fc.setSelectedFile(phT);
//         String pOUT = phT.getAbsolutePath();
//         try {
//             PrintWriter out = new PrintWriter(new FileWriter(pOUT));  
//             out.println("saving something just for test ");
//             out.close();
//         }
//         catch (Exception e) {
//             System.err.println("Couldn't save to " + pOUT + " error was " + e);
//         }
             
//         if (!can_use_clipboard) {
//             // can't do this!
//             return;
//         }
//       
//         Clipboard sys_clipboard = getToolkit().getSystemClipboard(); 
//         StringSelection contents = new StringSelection(name_list.getText());
//         sys_clipboard.setContents(contents, this); 
     //}
     

     // Never used, but must be available as an implementation of inherited abstract method  (Petar).
     public void lostOwnership( Clipboard clipboard, Transferable contents ) {
     }
}