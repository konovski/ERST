/*
 */
package erst.forester.java.src.org.forester.phylogeny.parsers.xml;

import java.net.MalformedURLException;
import java.net.URL;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import erst.forester.java.src.org.forester.phylogeny.PhyloXMLmapping;
import erst.forester.java.src.org.forester.phylogeny.Phylogeny;
import erst.forester.java.src.org.forester.phylogeny.PhylogenyNode;
import erst.forester.java.src.org.forester.phylogeny.TagValueUnit;
import erst.forester.java.src.org.forester.phylogeny.parsers.PhylogenyParserException;

final class SimplePhyloXMLParser1Handler1 extends DefaultHandler {

    SimplePhyloXMLParser1Handler1() {
        initialize();
    }

    public void startDocument() throws SAXException {
        initialize();
    }

    public void startElement( String namespaceUri, String localName,
            String qualifiedName, Attributes attributes ) throws SAXException {

        setCurrentElementName( qualifiedName );

        if ( qualifiedName.equals( PhyloXMLmapping.CLADE ) ) {
            increaseCladeLevel();
            setCladeAnnotationElement( new CladeAnnotationElement( "", "", "",
                    null ) );
            newClade();
        }
        else if ( qualifiedName.equals( PhyloXMLmapping.PHYLOGENY ) ) {
            setInPhylogeny( true );
            setCladeAnnotationElement( new CladeAnnotationElement( "", "", "",
                    null ) );
            newPhylogeny();
        }
        else {

            CladeAnnotationElement element = new CladeAnnotationElement(
                    namespaceUri, localName, qualifiedName, attributes );
            getCladeAnnotationElement().addChildElement( element );
            setCladeAnnotationElement( element );

        }
    }

    public void endElement( String namespaceUri, String localName,
            String qualifiedName ) throws SAXException {

        if ( getCladeLevel() == 0 && isInPhylogeny()
                && !qualifiedName.equals( PhyloXMLmapping.PHYLOGENY ) ) {
            try {
                mapCladeAnnotationElementToPhylogeny(
                        getCladeAnnotationElement(), getPhylogeny() );
            }
            catch ( PhylogenyParserException ex ) {
                throw new SAXException( ex.getMessage() );
            }
        }
        else if ( qualifiedName.equals( PhyloXMLmapping.CLADE ) ) {
            decreaseCladeLevel();
            try {
                mapCladeAnnotationElementToPhylogenyNode(
                        getCladeAnnotationElement(), getCurrentNode() );
                if ( !getCurrentNode().isRoot() ) {
                    setCurrentNode( getCurrentNode().getParent() );
                }
            }
            catch ( PhylogenyParserException ex ) {
                throw new SAXException( ex.getMessage() );
            }
        }
        else if ( qualifiedName.equals( PhyloXMLmapping.PHYLOGENY ) ) {
            setInPhylogeny( false );
            finishPhylogeny();
        }
        else if ( getCladeAnnotationElement().getParent() != null ) {
            setCladeAnnotationElement( getCladeAnnotationElement().getParent() );
        }

        setCurrentElementName( null );
    }

    public void characters( char[] chars, int startIndex, int endIndex ) {

        final String data = new String( chars, startIndex, endIndex ).trim();
        //      if ( data.length() < 1 ) {
        //          return;
        //     }

        if ( getCurrentElementName() != null
                && !getCurrentElementName().equals( PhyloXMLmapping.CLADE )
                && !getCurrentElementName().equals( PhyloXMLmapping.PHYLOGENY ) ) {
            getCladeAnnotationElement().setValue( data );
        }
    }

    private void initialize() {
        setPhylogeny( null );
        setCurrentNode( null );
        setCurrentElementName( null );
        setCladeAnnotationElement( null );
        setCladeLevel( 0 );
        setInPhylogeny( false );
    }

    private void newPhylogeny() {
        setPhylogeny( new Phylogeny() );
    }

    private void newClade() {
        if ( getCurrentNode() == null ) {
            initCurrentNode();
        }
        else {
            addNode();
        }
    }

    private void addNode() {
        PhylogenyNode new_node = new PhylogenyNode();
        getCurrentNode().addAsChild( new_node );
        setCurrentNode( new_node );
    }

    private void finishPhylogeny() throws SAXException {
        getPhylogeny().adjustNodeCount( false );
    }

    private void initCurrentNode() {
        if ( getCurrentNode() != null ) {
            throw new IllegalStateException(
                    "Attempt to create new current node when current node already exists." );
        }
        if ( getPhylogeny() == null ) {
            throw new IllegalStateException(
                    "Attempt to create new current node for non-existing phylogeny." );
        }
        PhylogenyNode node = new PhylogenyNode();
        getPhylogeny().setRoot( node );
        setCurrentNode( getPhylogeny().getRoot() );
    }

    private void setPhylogeneyName( final String data ) {
        getPhylogeny().setName( data );
    }

    Phylogeny getPhylogeny() {
        return _phylogeny;
    }

    private void setPhylogeny( Phylogeny phylogeny ) {
        _phylogeny = phylogeny;
    }

    private PhylogenyNode getCurrentNode() {
        return _current_node;
    }

    private void setCurrentNode( PhylogenyNode current_node ) {
        _current_node = current_node;
    }

    private void setCladeAnnotationElement( CladeAnnotationElement saxElement ) {
        _cladeAnnotationElement = saxElement;
    }

    private CladeAnnotationElement getCladeAnnotationElement() {
        return _cladeAnnotationElement;
    }

    private int getCladeLevel() {
        return _cladeLevel;
    }

    private void setCladeLevel( int cladeLevel ) {
        if ( cladeLevel < 0 ) {
            throw new IllegalArgumentException(
                    "Attempt to set clade level to a number smaller than zero." );
        }
        _cladeLevel = cladeLevel;
    }

    private void increaseCladeLevel() {
        ++_cladeLevel;
    }

    private void decreaseCladeLevel() {
        if ( _cladeLevel < 0 ) {
            throw new IllegalStateException(
                    "Attempt to decrease clade level beyond zero." );
        }
        --_cladeLevel;
    }

    private boolean isInPhylogeny() {
        return _inPhylogeny;
    }

    private void setInPhylogeny( boolean inPhylogeny ) {
        _inPhylogeny = inPhylogeny;
    }

    private String getCurrentElementName() {
        return _currentElementName;
    }

    private void setCurrentElementName( String currentElementName ) {
        _currentElementName = currentElementName;
    }

    private static void mapCladeAnnotationElementToPhylogeny(
            final CladeAnnotationElement annotationElement,
            final Phylogeny phylogeny ) throws PhylogenyParserException {
        final CladeAnnotationElement root = annotationElement.getRoot();

        for ( int i = 0; i < root.getNumberOfChildElements(); ++i ) {

            final CladeAnnotationElement element = root.getChildElement( i );
            final String qualifiedName = element.getQualifiedName();
            if ( qualifiedName.equals( PhyloXMLmapping.PHYLOGENY_NAME ) ) {
                phylogeny.setName( element.getValueAsString() );
            }
            else if ( qualifiedName
                    .equals( PhyloXMLmapping.PHYLOGENY_DESCRIPTION ) ) {
                phylogeny.setDescription( element.getValueAsString() );
            }
        }
    }

    private static void mapCladeAnnotationElementToPhylogenyNode(
            final CladeAnnotationElement annotationElement,
            final PhylogenyNode node ) throws PhylogenyParserException {

        final CladeAnnotationElement root = annotationElement.getRoot();

        for ( int i = 0; i < root.getNumberOfChildElements(); ++i ) {
            final CladeAnnotationElement element = root.getChildElement( i );
            final String qualifiedName = element.getQualifiedName();
            if ( qualifiedName.equals( PhyloXMLmapping.SEQUENCE_NAME ) ) {
                node.setSeqName( element.getValueAsString() );
            }
            else if ( qualifiedName.equals( PhyloXMLmapping.TAXONOMY ) ) {
                node.setTaxonomy( element.getValueAsString() );
            }
            else if ( qualifiedName.equals( PhyloXMLmapping.TAXONOMY_ID ) ) {
                node.setTaxonomyID( element.getValueAsString() );
            }
            else if ( qualifiedName.equals( PhyloXMLmapping.DISTANCE ) ) {
                node.setDistanceToParent( element.getValueAsDouble() );
            }
            else if ( qualifiedName.equals( PhyloXMLmapping.DUPLICATION ) ) {
                node.setDuplication( element.getValueAsBoolean() );
            }
            else if ( qualifiedName.equals( PhyloXMLmapping.CONFIDENCE ) ) {
                if ( attributeEqualsValue( element,
                        PhyloXMLmapping.CONFIDENCE_ATTRIBUTE_TYPE,
                        PhyloXMLmapping.CONFIDENCE_BOOTSTRAP_TYPE ) ) {
                    node.setBootstrap( element.getValueAsInt() );
                }
            }
            else if ( qualifiedName.equals( PhyloXMLmapping.COLOR ) ) {
                if ( attributeEqualsValue( element,
                        PhyloXMLmapping.COLOR_ATTRIBUTE_TYPE,
                        PhyloXMLmapping.COLOR_RGB_TYPE ) ) {
                    int red = 0;
                    int green = 0;
                    int blue = 0;
                    for ( int j = 0; j < element.getNumberOfChildElements(); ++j ) {
                        final CladeAnnotationElement c = element
                                .getChildElement( j );
                        if ( c.getQualifiedName().equals(
                                PhyloXMLmapping.COLOR_RED ) ) {
                            red = c.getValueAsInt();
                        }
                        else if ( c.getQualifiedName().equals(
                                PhyloXMLmapping.COLOR_GREEN ) ) {
                            green = c.getValueAsInt();
                        }
                        else if ( c.getQualifiedName().equals(
                                PhyloXMLmapping.COLOR_BLUE ) ) {
                            blue = c.getValueAsInt();
                        }
                        node.setColor( red, green, blue );
                    }
                }
            }
            // Custom data, handled by FORESTER (displayed by ATV)
            else if ( element.getNumberOfChildElements() == 0
                    && element.getAttributes().size() < 4 ) {
                TagValueUnit tvu = null; // TODO: Extend to clad, or node, or
                                         // branch!!!!
                boolean for_node = attributeEqualsValue( element,
                        PhyloXMLmapping.CUSTOM_ATTRIBUTE_PROPERTY,
                        PhyloXMLmapping.CUSTOM_NODE_PROPERTY );
                if ( attributeEqualsValue( element,
                        PhyloXMLmapping.CUSTOM_ATTRIBUTE_TYPE,
                        PhyloXMLmapping.CUSTOM_LONG_TYPE ) ) {
                    tvu = new TagValueUnit( qualifiedName, element
                            .getValueAsInt(), getAtttributeValue( element,
                            PhyloXMLmapping.CUSTOM_ATTRIBUTE_UNIT ) );
                }
                else if ( attributeEqualsValue( element,
                        PhyloXMLmapping.CUSTOM_ATTRIBUTE_TYPE,
                        PhyloXMLmapping.CUSTOM_DOUBLE_TYPE ) ) {
                    tvu = new TagValueUnit( qualifiedName, element
                            .getValueAsDouble(), getAtttributeValue( element,
                            PhyloXMLmapping.CUSTOM_ATTRIBUTE_UNIT ) );
                }
                else if ( attributeEqualsValue( element,
                        PhyloXMLmapping.CUSTOM_ATTRIBUTE_TYPE,
                        PhyloXMLmapping.CUSTOM_URL_TYPE ) ) {
                    try {
                        tvu = new TagValueUnit( qualifiedName, new URL( element
                                .getValueAsString() ) );
                    }
                    catch ( MalformedURLException e ) {
                        throw new PhylogenyParserException( e.getMessage() );
                    }
                }
                else if ( attributeEqualsValue( element,
                        PhyloXMLmapping.CUSTOM_ATTRIBUTE_TYPE,
                        PhyloXMLmapping.CUSTOM_BOOLEAN_TYPE ) ) {
                    tvu = new TagValueUnit( qualifiedName, element
                            .getValueAsBoolean() );
                }
                else {
                    tvu = new TagValueUnit( qualifiedName, element
                            .getValueAsString(), getAtttributeValue( element,
                            PhyloXMLmapping.CUSTOM_ATTRIBUTE_UNIT ) );
                }

                node.addCustomTagValue( tvu, for_node );
            }

        }
    }

    /**
     * Returns true if attribute attributeName of element is not null and equals
     * attributeValue.
     * 
     * @param element
     * @param attributeName
     * @param attributeValue
     * @return true if attribute attributeName of element is not null and equals
     *         attributeValue
     */
    private static boolean attributeEqualsValue(
            final CladeAnnotationElement element, final String attributeName,
            final String attributeValue ) {
        String attr = element.getAttribute( attributeName );
        return ( attr != null && attr.equals( attributeValue ) );
    }

    private static String getAtttributeValue(
            final CladeAnnotationElement element, final String attributeName ) {
        String attr = element.getAttribute( attributeName );
        if ( attr != null ) {
            return attr;
        }
        else {
            return "";
        }
    }

    private int                    _cladeLevel;

    private boolean                _inPhylogeny;

    private String                 _currentElementName;

    private Phylogeny              _phylogeny;

    private CladeAnnotationElement _cladeAnnotationElement;

    private PhylogenyNode          _current_node;

    // private final static String PARSER_WARNING = "phyloXML parsing: WARNING:
    // ";

}
