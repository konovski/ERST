// printAllSpecies
//
// Copyright (C) 2001 Washington University School of Medicine
// and Howard Hughes Medical Institute
// All rights reserved
//
// Created: 02/2601
// Author: Christian M. Zmasek
// zmasek@genetics.wustl.edu
// http://www.genetics.wustl.edu/eddy/people/zmasek/

// Requires forester packages.

package erst.forester.java.src.org.forester.tools;

import java.io.*;

import erst.forester.java.src.org.forester.phylogeny.Phylogeny;
import erst.forester.java.src.org.forester.phylogeny.PhylogenyNode;
import erst.forester.java.src.org.forester.phylogeny.factories.ParserBasedPhylogenyFactory;
import erst.forester.java.src.org.forester.phylogeny.factories.PhylogenyFactory;
import erst.forester.java.src.org.forester.phylogeny.parsers.nhx.NHXParser;
import erst.forester.java.src.org.forester.util.Util;

public class printAllSpecies {

    public static void main( String args[] ) {

        Phylogeny tree = null;
        PhylogenyNode node = null;
        PrintWriter out = null;
        File infile = null, outfile = null;

        if ( args.length != 2 ) {
            System.err
                    .println( "\nprintAllSpecies: Wrong number of arguments." );
            System.err
                    .println( "Usage: \"java printAllSpecies <infile> <outfile>\"\n" );
            System.exit( -1 );
        }

        infile = new File( args[ 0 ] );
        outfile = new File( args[ 1 ] );

        try {
            final PhylogenyFactory factory = ParserBasedPhylogenyFactory
            .getInstance();
            tree = factory.create( infile, new NHXParser() )[ 0 ];
        }
        catch ( Exception e ) {
            System.err.println( e + "\nCould not read " + infile + "\n" );
            System.exit( -1 );
        }

        Util.cleanSpeciesNamesInExtNodes( tree );
        node = tree.getFirstExternalNode();

        try {

            out = new PrintWriter( new FileWriter( outfile ), true );

            while ( node != null ) {
                out.println( node.getTaxonomy() );
                node = node.getNextExternalNode();
            }

        }
        catch ( Exception e ) {
            System.err.println( e + "\nException during writing.\n" );
            System.exit( -1 );
        }
        finally {
            out.close();
        }
    }

}

