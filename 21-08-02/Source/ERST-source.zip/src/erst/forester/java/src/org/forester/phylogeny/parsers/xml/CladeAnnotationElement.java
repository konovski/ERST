package erst.forester.java.src.org.forester.phylogeny.parsers.xml;

import org.xml.sax.Attributes;

import erst.forester.java.src.org.forester.phylogeny.parsers.PhylogenyParserException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 * @author Christian M. Zmasek
 */
public class CladeAnnotationElement {

    CladeAnnotationElement( final String namespaceUri, final String localName,
            final String qualifiedName, final Attributes attributes ) {
        _namespaceUri = namespaceUri;
        _localName = localName;
        _qualifiedName = qualifiedName;

        if ( attributes != null ) {
            _attributes = new HashMap( attributes.getLength() );
            for ( int i = 0; i < attributes.getLength(); ++i ) {
                getAttributes().put( new String( attributes.getQName( i ) ),
                        new String(attributes.getValue( i )  ));
            }
        }
        else {
            _attributes = new HashMap();
        }

        _childElements = new ArrayList();
        _parent = null;
    }

    void setValue( final String value ) {
        _value = new String(value );
        if ( DEBUG ) {
            System.out.println();
            System.out.println( "Value is \"" + value + "\" for" );
            System.out.println( "Local name     = " + getLocalName() );
            System.out.println( "Qualified name = " + getQualifiedName() );
            System.out.println( "Namespace URI  = " + getNamespaceUri() );
            System.out.print( "Attributes     : " );
            for ( Iterator iter = getAttributes().keySet().iterator(); iter
                    .hasNext(); ) {
                String key = ( String ) iter.next();
                System.out.print( key + " = \"" + getAttributes().get( key )
                        + "\"  " );
            }
            System.out.println();
            System.out.println();
        }
    }

    String getValueAsString() {
        return _value;
    }

    double getValueAsDouble() throws PhylogenyParserException {
        double d = 0.0;
        try {
            d = Double.parseDouble( getValueAsString() );
        }
        catch ( NumberFormatException ex ) {
            throw new PhylogenyParserException( "Attempt to parse + \""
                    + getValueAsString() + "\" into double" );
        }
        return d;
    }

    int getValueAsInt() throws PhylogenyParserException {
        int i = 0;
        try {
            i = Integer.parseInt( getValueAsString() );
        }
        catch ( NumberFormatException ex ) {
            throw new PhylogenyParserException( "Attempt to parse + \""
                    + getValueAsString() + "\" into integer" );
        }
        return i;
    }

    boolean getValueAsBoolean() throws PhylogenyParserException {
        boolean b = false;
        try {
            b = ( new Boolean( getValueAsString() ) ).booleanValue();
        }
        catch ( NumberFormatException ex ) {
            throw new PhylogenyParserException( "Attempt to parse + \""
                    + getValueAsString() + "\" into boolean" );
        }
        return b;
    }

    String getNamespaceUri() {
        return _namespaceUri;
    }

    String getLocalName() {
        return _localName;
    }

    String getQualifiedName() {
        return _qualifiedName;
    }

    HashMap getAttributes() {
        return _attributes;
    }

    String getAttribute( final String name ) {
        return ( String ) getAttributes().get( name );
    }

    ArrayList getChildElements() {
        return _childElements;
    }

    int getNumberOfChildElements() {
        return getChildElements().size();
    }

    CladeAnnotationElement getParent() {
        return _parent;
    }

    void setParent( final CladeAnnotationElement parent ) {
        _parent = parent;
    }

    CladeAnnotationElement getChildElement( int i ) {
        if ( ( i < 0 ) || ( i >= getNumberOfChildElements() ) ) {
            throw new IllegalArgumentException(
                    "Attempt to get child element with index " + i
                            + " for element with " + getNumberOfChildElements()
                            + " child elements" );
        }

        return ( CladeAnnotationElement ) getChildElements().get( i );
    }

    void addChildElement( final CladeAnnotationElement element ) {
        element.setParent( this );
        getChildElements().add( element );
    }
    
    CladeAnnotationElement getRoot() {
        CladeAnnotationElement e = this;
        while ( e.getParent() != null ) {
           e = e.getParent();
        }
        return e;
    }

    public final static boolean    DEBUG = true;

    private final String           _namespaceUri;
    private final String           _localName;
    private final String           _qualifiedName;
    private String                 _value;
    private final HashMap          _attributes;
    private final ArrayList        _childElements;
    private CladeAnnotationElement _parent;

}
