// ATVeditNodePanel.java
//
// Copyright (C) 1999-2002 Washington University School of Medicine
// and Howard Hughes Medical Institute
// All rights reserved
//
// Created: 1999
// Author: Christian M. Zmasek
// zmasek@genetics.wustl.edu
// http://www.genetics.wustl.edu/eddy/people/zmasek/

package erst.forester.java.src.org.forester.atv;
import java.util.StringTokenizer;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.TitledBorder;

import erst.forester.java.src.org.forester.phylogeny.*;

import java.util.*;

/**
 * @author Christian Zmasek
 * @version 1.2 -- last modified: 11/28/05 by eksc
 */
class ATVeditNodePanel extends JPanel implements ActionListener {

    private Phylogeny     tree;
    private PhylogenyNode node;
    private Hashtable<?, ?>     nodes;

    private ATVeditNodeFrame atveditnodeframe;

    private boolean editable = false;

    private JLabel seq_name_label, Species_label, EC_label,
            GO_label,
            Distance_parent_label, Bootstrap_label, color_label,
            width_label,
            Sum_ext_nodes_label, Sum_ext_nodes_tf,
            taxo_id_label, orthologous_label,
            super_orthologous_label, sn_label, message_label;

    private JTextField Seq_name_tf, Species_tf, EC_tf, GO_tf, Distance_parent_tf,
            taxo_id_tf, Bootstrap_tf, color_tf, width_tf, 
            orthologous_tf, super_orthologous_tf, sn_tf;

    private JRadioButton Duplication_rb, Speciation_rb, NA_rb;

    private JPanel headerpanel, messagepanel, buttonjpanel, radiobuttonjpanel;

    private ButtonGroup radiobuttongroup;

    private JButton cancel_button, reset_button, write_button;

    private JPanel standard_data, custom_data;

    private Hashtable<String, JComponent> tvu_label_tags, tvu_textfield_values,
            tvu_textfield_units;

    /*  Change the font size to 14. (Petar)
    private final static Font header_font = new Font("Helvetica", Font.BOLD, 11),
            label_font = new Font( "Helvetica", Font.PLAIN, 10 ),
            tf_font = new Font( "Helvetica", Font.PLAIN, 10 ),
            button_font = new Font( "Helvetica", Font.PLAIN, 10 ),
            message_font = new Font( "Helvetica", Font.BOLD, 10 );
    */
    private final static Font header_font = new Font("Helvetica", Font.BOLD, 14),
            label_font = new Font( "Helvetica", Font.PLAIN, 14 ),
            tf_font = new Font( "Helvetica", Font.PLAIN, 14 ),
            button_font = new Font( "Helvetica", Font.PLAIN, 14 ),
            message_font = new Font( "Helvetica", Font.BOLD, 14 );

    private final static Color 	background_color = new Color( 215, 215, 215 ),
            					label_text_color = new Color( 0, 0, 0 ), 
            					tf_text_color = new Color( 0, 0, 0 ),
            					tf_background_color = new Color( 250, 250, 250 ),
            					//button_background_color = new Color( 165, 165, 165 ), 
            					// Not used (Petar)
            					button_text_color = new Color( 0, 0, 0 ),
            					//message_color = new Color( 205, 0, 0 ) // Let play a little (Petar).
            					message_color = new Color( 0, 0, 0 )
            					;

    private static String header_str = "Set values for this node";
    
    private String message = " ";
    
    private static String badcolor_err = "Not a valid color string.<br>Color should be in the format, red, green, blue.<br>For example: '100,100,100'";
    private static String badbootstrap_err = "NumberFormatException in bootstrap value. ";
    private static String baddistance_err = "NumberFormatException in distance value. ";
    private static String badwidth_err = "NumberFormatException in branch width value. ";
    

    /**
     * Construct an edit popup for a collection of nodes
     */
    ATVeditNodePanel( Hashtable<?, ?> nodes, Phylogeny t, boolean editable, ATVeditNodeFrame anf ) {
        this.nodes = nodes;
        this.tree = t;
        this.editable = editable;
        this.atveditnodeframe = anf;
        buildPanel();
    }//multi-select constructor
    
    
    /**
     * @param n the node to edit
     * @param display_options display-options object
     * @param anf the parent frame
     */
    ATVeditNodePanel( PhylogenyNode n, Phylogeny t, boolean editable, ATVeditNodeFrame anf ) {
        this.node = n;
        this.tree = t;
        this.editable = editable;
        this.atveditnodeframe = anf;
        buildPanel();
    }//single node constructor
    
    
    /**
     *
     */
    private void buildPanel() {
        this.setSize(atveditnodeframe.getSize());
        this.setPreferredSize(atveditnodeframe.getSize());
        //int width = atveditnodeframe.getWidth(); //Not used (Petar)

        setBackground( background_color );
        setLayout( new BoxLayout(this, BoxLayout.Y_AXIS));
        
        headerpanel = new JPanel();
        standard_data = new JPanel();
        custom_data = new JPanel();
        radiobuttonjpanel = new JPanel();
        messagepanel = new JPanel();
        buttonjpanel = new JPanel();

        add( headerpanel );
        add( standard_data );
        add( custom_data );
        add( radiobuttonjpanel );
        add( messagepanel );
        add( buttonjpanel );
        
        // The header panel
        JLabel header = new JLabel( header_str );
        header.setFont( header_font );
        headerpanel.add(header);
        
        // The standard fields:
        standard_data.setLayout( new java.awt.GridLayout( 0, 2, 3, 0 ) );
        addStandardFields();
        
        // The radio buttons (only if single node):
        if ( node != null && !node.isExternal() ) {
            addRadioButtons();
        }

        // The fields for custom data (if any)
        if (node != null) {
          addCustomFields();
        }
        
        // The  message label:
        // ----------------------------------------------
        message_label = new JLabel( " " );
        message_label.setFont( message_font );
        message_label.setForeground( message_color );
        messagepanel.add(message_label);
        
        // The buttons
        addButtons();
        
        // Setting the text of all the text fields and status of radio buttons:
        reset();
        this.revalidate(); //~~~vvv^^^
        this.setSize( this.getPreferredSize() );//~~~vvv^^^
    }//buildPanel


    /**
     * 
     */
    public void actionPerformed( ActionEvent e ) {

        if ( e.getSource() == cancel_button ) {
            close();
        }
        else {

            if ( editable && e.getSource() == reset_button ) {
                reset();
//                atveditnodeframe.getATVtreePanel().getTree().recalculateAndReset();
                atveditnodeframe.getATVtreePanel().repaint();
            }

            if ( editable && e.getSource() == write_button ) {
                writeToTree();
                if (message.length() == 0) {
                  // all is well, redraw tree and close popup
//                  atveditnodeframe.getATVtreePanel().getTree().recalculateAndReset();
                  atveditnodeframe.getATVtreePanel().repaint();
                  close();
                }
            }
        }
    }//actionPerformed
     

    /***
     * 
     */
    private void addButtons() {
        buttonjpanel.setLayout(new FlowLayout());

        buttonjpanel.setBackground( background_color );

        if ( editable ) {
            write_button = new JButton( "OK" );
            write_button.setFont( button_font );
            write_button.setForeground( button_text_color );
            write_button.setBackground( background_color );
            write_button
                    .setToolTipText( "Write the values for this node to the tree" );
            write_button.addActionListener( this );
            //gbc.gridwidth = GridBagConstraints.REMAINDER;
            buttonjpanel.add( write_button );
            
            reset_button = new JButton( "Reset" );
            reset_button.setFont( button_font );
            reset_button.setForeground( button_text_color );
            reset_button.setBackground( background_color );
            reset_button.setToolTipText( "Read values for this node from tree" );
            reset_button.addActionListener( this );
            buttonjpanel.add( reset_button );

            cancel_button = new JButton( "Cancel" );
            cancel_button.setFont( button_font );
            cancel_button.setForeground( button_text_color );
            cancel_button.setBackground( background_color );
            cancel_button.addActionListener( this );
            buttonjpanel.add( cancel_button );

        } else {
        
          cancel_button = new JButton( "Close" );
          cancel_button.setFont( button_font );
          cancel_button.setForeground( button_text_color );
          cancel_button.setBackground( background_color );
          cancel_button.addActionListener( this );
          buttonjpanel.add( cancel_button );
        }

    }//addButtons


    /**
     * 
     */
    private void addCustomFields() {
        // ---------------------------------
        // Adding the custom tag value units:
        // ---------------------------------

        TagValueUnit[] tvus = node.getCustomTagValueUnitsAsArray();
        Hashtable tvu_hash = tree.getCustomTagNames();

        // clean Booleans out of hash (this shouldn't be necessary)
          for (Enumeration keys=tvu_hash.keys(); keys.hasMoreElements();) {
              String key = (String)keys.nextElement();
              tvu_hash.put(key, new TagValueUnit(key, "", ""));
          }


        if (tvu_hash.size() > 0) {
            custom_data.setLayout( new java.awt.GridLayout( tvu_hash.size()+1, 3, 3, 0 ) );
            custom_data.setBorder(BorderFactory.createTitledBorder("Custom Data"));
            //((TitledBorder)custom_data.getBorder()).setTitleFont(new Font("Sans Serif", Font.PLAIN, 9)); Change the font size to 14. (Petar)
            ((TitledBorder)custom_data.getBorder()).setTitleFont(new Font("Sans Serif", Font.PLAIN, 14));

            JLabel h1 = new JLabel("Name  ");
            h1.setFont( message_font );
            h1.setHorizontalAlignment(SwingConstants.RIGHT);
            custom_data.add( h1 );
            JLabel h2 = new JLabel("  Value");
            h2.setFont(message_font);
            custom_data.add(h2);
            JLabel h3 = new JLabel("  Unit");
            h3.setFont(message_font);
            custom_data.add(h3);
                
            tvu_label_tags = new Hashtable();
            tvu_textfield_values = new Hashtable();
            tvu_textfield_units = new Hashtable();
            for ( int i = 0; i < tvus.length; ++i ) {
                tvu_hash.put(tvus[i].getTag(), tvus[i]);
            }
            for (Enumeration keys=tvu_hash.keys(); keys.hasMoreElements();) {
                String key = (String)keys.nextElement();
                TagValueUnit tvu = (TagValueUnit)tvu_hash.get(key);
                JLabel tag = new JLabel( key );
                JTextField value = new JTextField( 14 );
                JTextField unit = new JTextField( 4 );
                tvu_label_tags.put( key, tag );
                tvu_textfield_values.put( key, value );
                tvu_textfield_units.put( key, unit );
                addJTFforValue( tag, value, unit );
            }
        }
    }//addCustomFields
    

    /**
     * 
     */
    private void addJLabel( JLabel jl ) {
        //gbc.weightx = 0.3;
        jl.setFont( label_font );
        jl.setForeground( label_text_color );
        jl.setHorizontalAlignment( SwingConstants.RIGHT );
        //gbc.gridwidth = 1;
        //add( jl, gbc );
        this.standard_data.add( jl );
    }//addJLabel
    

    /**
     * 
     */
    private void addJTF( JTextField jtf ) {

        jtf.setMinimumSize( jtf.getPreferredSize() );
        jtf.setFont( tf_font );
        jtf.setForeground( tf_text_color );
        jtf.setBackground( tf_background_color );
        jtf.setEditable( editable );

        standard_data.add( jtf );
    }//addJTF
    

    /**
     * 
     */
    private void addJTFforValue( JLabel tag, JTextField value, JTextField unit ) {

        tag.setFont( label_font );
        tag.setForeground( label_text_color );
        tag.setHorizontalAlignment( SwingConstants.RIGHT );

        value.setFont( tf_font );
        value.setForeground( tf_text_color );
        value.setBackground( tf_background_color );
        value.setEditable( editable );

        unit.setFont( tf_font );
        unit.setForeground( tf_text_color );
        unit.setBackground( tf_background_color );
        unit.setEditable( editable );

        custom_data.add( tag );
        custom_data.add( value );
        custom_data.add( unit );

    }//addJTFforValue
     
    
    /**
     * 
     */
    private void addRadioButtons() {

        // Adding the Duplication, Speciation, NA radiobuttons:
        // ----------------------------------------------------
        radiobuttongroup = new ButtonGroup();
        radiobuttonjpanel.setLayout( new GridLayout( 1, 3, 0, 0 ) );
        radiobuttonjpanel.setBackground( background_color );
        Duplication_rb = new JRadioButton( "duplication" );
        Speciation_rb = new JRadioButton( "speciation" );
        NA_rb = new JRadioButton( "not assigned" );
        radiobuttongroup.add( Duplication_rb );
        radiobuttongroup.add( Speciation_rb );
        radiobuttongroup.add( NA_rb );
    
        // Does not look nice AT ALL, but there seems to be no other easy
        // way
        // to make radiobuttons uneditable......
        Duplication_rb.setEnabled( editable );
    
        Duplication_rb.setFont( label_font );
        Duplication_rb.setForeground( label_text_color );
        Duplication_rb.setBackground( background_color );
    
        radiobuttonjpanel.add( Duplication_rb );
    
        Speciation_rb.setEnabled( editable );
        Speciation_rb.setFont( label_font );
        Speciation_rb.setForeground( label_text_color );
        Speciation_rb.setBackground( background_color );
        radiobuttonjpanel.add( Speciation_rb );
    
        NA_rb.setEnabled( editable );
        NA_rb.setFont( label_font );
        NA_rb.setForeground( label_text_color );
        NA_rb.setBackground( background_color );
        radiobuttonjpanel.add( NA_rb );
    
        //gbc.gridwidth = GridBagConstraints.REMAINDER;
        //gbc.fill = GridBagConstraints.HORIZONTAL;
        //add( radiobuttonjpanel, gbc );
    
        //gbc.fill = GridBagConstraints.NONE;
    }//addRadioButtons
    
    
    /**
     * 
     */
    private void addStandardFields() {
        // Adding the Seq name (if single node):
        // -------------------------------------
        if (node != null) {
          seq_name_label = new JLabel( "seq name" );
          addJLabel( seq_name_label );

          Seq_name_tf = new JTextField( 25 );
          addJTF( Seq_name_tf );
        }
        
        // Adding the Species:
        // -------------------
        Species_label = new JLabel( "species" );
        addJLabel( Species_label );
         
        Species_tf = new JTextField( 25 );
        addJTF( Species_tf );

        // Adding the Taxonomy ID:
        // -----------------------
        taxo_id_label = new JLabel( "taxonomy ID" );
        addJLabel( taxo_id_label );

        taxo_id_tf = new JTextField( 25 );
        taxo_id_tf.setDocument( new IntegerDocument() );
        addJTF( taxo_id_tf );

        // Adding the EC number (if single node):
        // --------------------------------------
        if (node != null) {
          EC_label = new JLabel( "EC number" );
          addJLabel( EC_label );

          EC_tf = new JTextField( 25 );
          addJTF( EC_tf );
        }
        
        // Adding the GO term:
        // -------------------
        GO_label = new JLabel( "GO term (term or ID)" );
        addJLabel( GO_label );
        
        GO_tf = new JTextField( 25 );
        addJTF( GO_tf );

        // Adding the Distance to Parent (if single node):
        // -----------------------------------------------
        if (node != null) {
          Distance_parent_label = new JLabel( "distance to parent" );
          addJLabel( Distance_parent_label );

          Distance_parent_tf = new JTextField( 25 );
          Distance_parent_tf.setDocument( new DoubleDocument() );
          addJTF( Distance_parent_tf );
        }
        
        // Only set bootstrap if dealing with one node
        if ( node != null && !node.isExternal() ) {
            // Adding the Bootstrap:
            // ---------------------

            Bootstrap_label = new JLabel( "bootstrap value" );
            addJLabel( Bootstrap_label );

            Bootstrap_tf = new JTextField( 25 );
            Bootstrap_tf.setDocument( new IntegerDocument() );
            addJTF( Bootstrap_tf );
        }

        // Only set orthologous settings if dealing with one node
        if ( node != null && node.isExternal() ) {
            // Adding the Orthologous:
            // -----------------------
            if ( node.getOrthologous() != PhylogenyNode.ORTHOLOGOUS_DEFAULT ) {
                orthologous_label = new JLabel( "orthologous to query" );
                addJLabel( orthologous_label );

                orthologous_tf = new JTextField( 25 );
                orthologous_tf.setDocument( new IntegerDocument() );
                addJTF( orthologous_tf );
                orthologous_tf.setEnabled( false );
            }

            // Adding the Subtree-Neighborings:
            // --------------------------------
            if ( node.getSubtreeNeighborings() != PhylogenyNode.ORTHOLOGOUS_DEFAULT ) {
                sn_label = new JLabel( "subtr-neighb to query" );
                addJLabel( sn_label );

                sn_tf = new JTextField( 25 );
                sn_tf.setDocument( new IntegerDocument() );
                addJTF( sn_tf );
                sn_tf.setEnabled( false );
            }

            // Adding the Super Orthologous:
            // -----------------------------
            if ( node.getSuperOrthologous() != PhylogenyNode.ORTHOLOGOUS_DEFAULT ) {
                super_orthologous_label = new JLabel( "s-orthologous to query" );
                addJLabel( super_orthologous_label );

                super_orthologous_tf = new JTextField( 25 );
                super_orthologous_tf.setDocument( new IntegerDocument() );
                addJTF( super_orthologous_tf );
                super_orthologous_tf.setEnabled( false );
            }

        }

        // Adding the parent branch color:
        // ------------------------------------------------
        color_label = new JLabel( "color of parent branch (r, g, b)" );
        addJLabel( color_label );
        color_tf = new JTextField( 25 );
        addJTF( color_tf );
        
        // Adding the parent branch width (if single node):
        // ------------------------------------------------
        width_label = new JLabel( "width of parent branch" );
        addJLabel( width_label );
        width_tf = new JTextField( 25 );
        addJTF( width_tf );
        
        // Only if dealing with a single node
        if ( node != null && !node.isExternal() ) {

            // Adding the Sum ext nodes:
            // -------------------------
            Sum_ext_nodes_label = new JLabel( "sum of ext nodes" );
            addJLabel( Sum_ext_nodes_label );

            Sum_ext_nodes_tf = new JLabel( ""+25 );
            addJLabel( Sum_ext_nodes_tf );
            Sum_ext_nodes_tf.setHorizontalAlignment(SwingConstants.LEFT);
//            Sum_ext_nodes_tf.setEditable( false );

        }
    }//addStandardFields


    /**
     *
     */
    void reset() {
        if ( nodes != null ) {
          resetMultiple();
        } else if ( node != null) {
          resetSingle();
        }
     }//reset
   

     /**
      *
      */
     void resetMultiple() {
       String species = null;
       String taxonomy = null;
       String go = null;
       String br_color_str = null;
       String br_width = null;
       
       Enumeration e = nodes.keys();
       while (e.hasMoreElements()) {
           PhylogenyNode n = (PhylogenyNode)e.nextElement();
         
           // species
           String s = n.getTaxonomy();
           if (species == null) {
               species = s;
           } else if (!species.equals(s)) {
               // multiple species represented in selected nodes
               species = "-";
           }
          
           // taxonomy id
           String t = n.getTaxonomyID();
           if (taxonomy == null) {
               taxonomy = t;
           } else if (!taxonomy.equals(t)) {
               // multiple taxonomy ids represented in selected nodes
               taxonomy = "-";
           }
         
           // GO
           String g = "not implemented";
           if (go == null) {
               go = g;
           } else if (!g.equalsIgnoreCase(go)) {
               // multiple go terms represented in selected nodes
               go = "-";
           }

           // branch color
           Color c = null;
           if (n.isParentBranchColorAssigned()) {
              c = n.getColor();
           }
           String color_str = "";
           if (c != null) {
              color_str = ""+c.getRed()+","+c.getGreen()+","+c.getBlue();
           }
           if (br_color_str == null) {
               br_color_str = color_str;
           } else if (!br_color_str.equalsIgnoreCase(color_str)) {
               // multiple branch colors represented in selected nodes
               br_color_str = "-";
           }

           // branch width
           String w = "";
           if (n.isParentBranchWidthAssigned()) {
             w = ""+n.getParentBranchWidth();
           }
           if (br_width == null) {
               br_width = w;
           } else if (!br_width.equalsIgnoreCase(w)) {
               // multiple branch represented in selected nodes
               br_width = "-";
           }
       }

       if (species != null && species.length() > 0) { // && !species.equals("-")) {
           Species_tf.setText( species );
       }
       if (taxonomy != null && taxonomy.length() > 0) { // && !taxonomy.equals("-")) {
           taxo_id_tf.setText( taxonomy );
       }
       if (go != null && go.length() > 0) { // && !go.equals("-")) {
           GO_tf.setText( go );
       }
       if (br_color_str != null && br_color_str.length() > 0) { // && !br_color_str.equals("-")) {
           color_tf.setText(br_color_str);
       }
       if (br_width != null && br_width.length() > 0) { // && !br_width.equals("-")) {
           width_tf.setText(br_width);
       }
     }//resetMultiple
     
     
     /**
      *
      */
     void resetSingle() {
        message_label.setText( " " );
        message = "";

        // Seq name:
        if ( !node.isPseudoNode() ) {
            Seq_name_tf.setText( node.getSeqName() );
        }
        else {
            Seq_name_tf.setText( "*pseudo node*" );
        }

        // Species:
        Species_tf.setText( node.getTaxonomy() );

        // Taxonomy ID:
        taxo_id_tf.setText( node.getTaxonomyID() );

        // EC:
        EC_tf.setText( node.getECnumber() );
        
        // GO: 
        GO_tf.setText( "not implemented" );

        // Distance to parent:
        if ( !node.isPseudoNode()
                && node.getDistanceToParent() != PhylogenyNode.DISTANCE_DEFAULT ) {
            Distance_parent_tf.setText( "" + node.getDistanceToParent() );
        }
        else {
            Distance_parent_tf.setText( "" );
        }

        // LnL:
        /*
         * ~if ( node.isLnLonParentBranchAssigned() ) { color_tf.setText( "" +
         * node.getLnLonParentBranch() ); } else { LnL_tf.setText( "" ); }~
         */
         
        if ( node.isParentBranchColorAssigned() ) {
          Color c = node.getColor();
          String s = c.toString();
          color_tf.setText(""+c.getRed()+","+c.getGreen()+","+c.getBlue());
        }
        
        // parent branch width
        if (node.isParentBranchWidthAssigned()) {
          width_tf.setText(""+node.getParentBranchWidth());
        }

        if ( !node.isExternal() ) {

            // Bootstrap:
            if ( node.getBootstrap() != PhylogenyNode.BOOTSTRAP_DEFAULT ) {
                Bootstrap_tf.setText( "" + node.getBootstrap() );
            }
            else {
                Bootstrap_tf.setText( "" );
            }

            // Sum ext nodes:
            Sum_ext_nodes_tf.setText( "" + node.getSumExtNodes() );

            // Duplication, speciation, NA:
            if ( !node.isDuplicationOrSpecAssigned() ) {
                NA_rb.setSelected( true );
            }
            else {
                if ( node.isDuplication() ) {
                    Duplication_rb.setSelected( true );
                }
                else {
                    Speciation_rb.setSelected( true );
                }
            }
        }

        if ( node.isExternal() ) {
            // Orthologous:
            if ( node.getOrthologous() != PhylogenyNode.ORTHOLOGOUS_DEFAULT
                    && node.getOrthologous() != PhylogenyNode.SEQ_X ) {
                orthologous_tf.setText( "" + node.getOrthologous() );
            }
            // else {
            //     orthologous_tf.setText( "" );
            // }
            // Super Orthologous:
            if ( node.getSuperOrthologous() != PhylogenyNode.ORTHOLOGOUS_DEFAULT
                    && node.getSuperOrthologous() != PhylogenyNode.SEQ_X ) {
                super_orthologous_tf.setText( "" + node.getSuperOrthologous() );
            }
            //   else {
            //      super_orthologous_tf.setText( "" );
            // }
            // Subtree-neighborings:
            if ( node.getSubtreeNeighborings() != PhylogenyNode.ORTHOLOGOUS_DEFAULT
                    && node.getSubtreeNeighborings() != PhylogenyNode.SEQ_X ) {
                sn_tf.setText( "" + node.getSubtreeNeighborings() );
            }
            // else {
            //     sn_tf.setText( "" );
            // }
        }

        //vvvvvvvvvvvvvvvvvvvvvvvvvvv
//        if ( SHOW_CUSTOM_VALUES ) {
            //tvu_textfields
            TagValueUnit[] tvua = node.getCustomTagValueUnitsAsArray();
            
                for ( int i = 0; i < tvua.length; ++i ) {
                    JTextField value = ( JTextField ) tvu_textfield_values
                            .get( tvua[ i ].getTag() ), unit = ( JTextField ) tvu_textfield_units
                            .get( tvua[ i ].getTag() );
                    value.setText( tvua[ i ].getValue().toString() );
                    unit.setText( tvua[ i ].getUnit() );
                }
           

//        }

        //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    }//resetSingle


    /**
     *
     */
    void writeToTree() {
        if ( nodes != null ) {
          writeMultiple();
        } else {
          writeSingle();
        }
    }//writeToTree
    
    
    /**
     *
     */
    void writeMultiple() {
        message = "";
        message_label.setText( " " );

        String species = Species_tf.getText();
        String taxonomy = taxo_id_tf.getText();
        String go = GO_tf.getText();
        String br_color_str = color_tf.getText();
        String br_width_str = width_tf.getText();

        // Create Color object if color exists and is valid
        Color br_color = null;
        if (br_color_str.length() > 0 && !br_color_str.equals("-")) {
            // split into 3 ints
            StringTokenizer st = new StringTokenizer(br_color_str, ",");
            if (st.countTokens() == 3) {
                try {
                    int r = Integer.parseInt((String)st.nextToken());
                    int g = Integer.parseInt((String)st.nextToken());
                    int b = Integer.parseInt((String)st.nextToken());
                    br_color = new Color(r, g, b);
                } catch (Exception e) {
                    message += badcolor_err;
                }
            } else {
                message += badcolor_err;
            }
        }
  
        // Convert branch width to int if it exists as if valid
        int br_width = 0;
        if ( br_width_str.length() > 0) {
          try {
            br_width = Integer.parseInt(br_width_str);
          } catch (Exception e) {
            message += badwidth_err;
          }
        }

        // set each node in the set
        Enumeration keys = nodes.keys();
        while ( message.length() == 0 && keys.hasMoreElements() ) {
             PhylogenyNode n = (PhylogenyNode)keys.nextElement();
             if ( species.length() > 0 && !species.equals("-") ) {
                 n.setTaxonomy( species );
             }
             if ( taxonomy.length() > 0 && !taxonomy.equals("-") ) {
                 n.setTaxonomyID( taxonomy );
             }
             if ( go.length() > 0 && !go.equals("-") ) {
  //           n.setGO( go );
             }
             if ( br_color != null ) {
                 n.setColor(br_color);
             }
             if ( br_width > 0 ) {
                 n.setParentBranchWidth(br_width);
             }
        }
        
       
        if ( message.length() > 1 ) {
            Toolkit.getDefaultToolkit().beep();
            message_label.setText( "<html>" + message + "</html>" );
        }
        else {
            reset();
        }
    }//writeMultiple
    
    
    /**
     *
     */
    void writeSingle() {
        boolean exception = false;
        double d = 0.0;
        int i = 0;

        message = "";
        message_label.setText( " " );

        // Set sequence name, taxonomy name and ID, EC
        node.setSeqName( replaceInappropriateChars( Seq_name_tf.getText()
                .trim() ) );
        node.setTaxonomy( replaceInappropriateChars( Species_tf.getText()
                .trim() ) );
        node.setECnumber( replaceInappropriateChars( EC_tf.getText().trim() ) );

        node.setTaxonomyID( replaceInappropriateChars( taxo_id_tf.getText()
                .trim() ) );

        // Set distance to parent
        if ( Distance_parent_tf.getText().trim().length() > 0 ) {
            exception = false;
            try {
                d = Double.valueOf( Distance_parent_tf.getText().trim() )
                        .doubleValue();
                //d = Double.parseDouble(g.trim()); // JDK 1.2 only
                if ( d < 0.0 ) {
                    d = 0.0;
                }
            }
            catch ( NumberFormatException e ) {
                exception = true;
                message = baddistance_err;
            }
            if ( !exception ) {
                node.setDistanceToParent( d );
            }
        }
        else {
            node.setDistanceToParent( PhylogenyNode.DISTANCE_DEFAULT );
        }// if (Distance_parent_tf)

        /*
         * ~~if ( LnL_tf.getText().trim().length() > 0 ) { exception = false;
         * try { f = Float.valueOf( LnL_tf.getText().trim() ).floatValue(); }
         * catch ( NumberFormatException e ) { exception = true; message =
         * "NumberFormatException. "; } if ( !exception ) {
         * node.setLnLonParentBranch( f ); } } else { node.setLnLonParentBranch(
         * 0.0F ); node.setLnLonParentBranchAssigned( false ); }
         */
        
        // Set parent branch color
        if ( color_tf.getText().trim().length() > 0 ) {
          String s = color_tf.getText();
          // split into 3 ints
          StringTokenizer st = new StringTokenizer(s, ",");
          if (st.countTokens() == 3) {
            try {
              int r = Integer.parseInt((String)st.nextToken());
              int g = Integer.parseInt((String)st.nextToken());
              int b = Integer.parseInt((String)st.nextToken());
              Color c = new Color(r, g, b);
              node.setColor(c);
            } catch (Exception e) {
              message += badcolor_err;
            }
          } else {
            message += badcolor_err;
          }
        }

        // parent branch width
        if ( width_tf.getText().trim().length() > 0) {
          try {
            int w = Integer.parseInt(width_tf.getText());
            node.setParentBranchWidth( w );
          } catch (Exception e) {
            message += badwidth_err;
          }
        }
        
        // Set Bootstrap, duplication, speciation
        if ( !node.isExternal() ) {
            if ( Bootstrap_tf.getText().trim().length() > 0 ) {
                exception = false;
                try {
                    i = Integer.parseInt( Bootstrap_tf.getText().trim() );
                }
                catch ( NumberFormatException e ) {
                    exception = true;
                    message = badbootstrap_err;
                }
                if ( !exception ) {
                    node.setBootstrap( i );
                }
            }
            else {
                node.setBootstrap( PhylogenyNode.BOOTSTRAP_DEFAULT );
            }

            if ( Duplication_rb.isSelected() ) {
                node.setDuplication( true );
            }
            else if ( Speciation_rb.isSelected() ) {
                node.setDuplication( false );
            }
            else {
                node.setDuplicationOrSpecAssigned( false );
            }
        }

        
        if ( message.length() > 1 ) {
            Toolkit.getDefaultToolkit().beep();
            message_label.setText( "<html>" + message + "</html>" );
//            message = " ";
        }
        else {
            reset();
        }
    }//writeSingle


    /**
     *
     */
    void close() {
        atveditnodeframe.remove(); // to release slot in array
        atveditnodeframe.dispose();
        atveditnodeframe = null;
    }//close


    // VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVv~~~~~~~~~~~~~~~~~~~~`vvvv^^^^
    // [] -> {} () -> {} : -> * , -> | ' ' -> _
    private String replaceInappropriateChars( String s ) {
        s = s.replace( '[', '{' );
        s = s.replace( ']', '}' );
        s = s.replace( '(', '{' );
        s = s.replace( ')', '}' );
        s = s.replace( ':', '*' );
        s = s.replace( ',', '|' );
        s = s.replace( ' ', '_' );
        return s;
    }//replaceInappropriateChars

} // End of class ATVnodePanel.

