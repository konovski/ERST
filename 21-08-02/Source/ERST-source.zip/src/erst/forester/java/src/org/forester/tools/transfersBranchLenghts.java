// transfersBranchLenghts.java
// Copyright (C) 1999-2000 Washington University School of Medicine
// and Howard Hughes Medical Institute
// All rights reserved

package erst.forester.java.src.org.forester.tools;


import java.io.*;

import erst.forester.java.src.org.forester.io.PhylogenyWriter;
import erst.forester.java.src.org.forester.phylogeny.*;
import erst.forester.java.src.org.forester.phylogeny.factories.ParserBasedPhylogenyFactory;
import erst.forester.java.src.org.forester.phylogeny.factories.PhylogenyFactory;
import erst.forester.java.src.org.forester.phylogeny.iterators.PhylogenyNodeIterator;
import erst.forester.java.src.org.forester.phylogeny.parsers.nhx.NHXParser;

/**
 * @author Christian M. Zmasek
 * @version 1.200 -- last modified: 10/24/05
 */
public final class transfersBranchLenghts {

    /**
     * Transfers branch length values from one Phylogeny to another. It is mainly a
     * "main method" for method "copyBranchLengthValuesFrom( Phylogeny )" of
     * org.forester.phylogeny.Phylogeny, to be used in other (Perl) programs.
     * 
     * @param args[0]
     *            Filename (String) for Phylogeny which has correct branch length
     *            values
     * @param args[1]
     *            String Filename (String) for Phylogeny to which the branch lengths
     *            of the first Phylogeny are to be copied, both Trees must only
     *            differ in their branch length values, i.e. topology and
     *            sequence names, etc. must be the same
     * @param args[2]
     *            String Filename (String) for outputfile
     * @param args[3]
     *            R to reroot both trees in the same manner
     * @see org.forester.phylogeny.Phylogeny#copyBranchLengthValuesFrom( Phylogeny )
     */
    public static void main( String args[] ) {

        Phylogeny tree1 = null, // Has correct branch lengths (:...).
        tree2 = null; // Has bootsrap in the b.l. field (will be transferred
        // to the bootstrap field by the Phylogeny constructor) or
        // has regular boostraps (NHX, :B=...).

        File f1 = null, f2 = null, f3 = null;

        boolean reroot = false;

        if ( args.length != 3 && args.length != 4 ) {
            System.err
                    .println( "transfersBranchLenghts: Wrong number"
                            + " of arguments. Usage: \"java transfersBranchLenghts"
                            + " <treefile with correct b.l.> <treefile with bootstraps>"
                            + "<outputfile> [R to reroot both trees in the same manner]\"" );
            System.exit( -1 );
        }

        if ( args.length == 4 && args[ 3 ].equals( "R" ) ) {
            reroot = true;
        }

        try {
            f1 = new File( args[ 0 ] );
            f2 = new File( args[ 1 ] );
            f3 = new File( args[ 2 ] );

            if ( f3.exists() ) {
                System.err.println( "transfersBranchLenghts: "
                        + f3.getAbsolutePath() + " does already exist." );
                System.exit( -1 );
            }

            final PhylogenyFactory factory = ParserBasedPhylogenyFactory
            .getInstance();
            tree1 = factory.create( f1, new NHXParser() )[ 0 ];
            tree2 = factory.create( f2, new NHXParser() )[ 0 ];

        }
        catch ( Exception e ) {
            System.err.println( "treeCombine: Could not read tree(s): " + e );
            System.exit( -1 );
        }

        // Ensure that both trees are rooted in the same manner.
        // This is important if the branch length calculation is done by
        // PHILIP FITCH -- which changes the rooting of its input tree.
        if ( reroot ) {
            try {
                PhylogenyNode tree2extnode0 = tree2.getFirstExternalNode();
                tree2.reRoot( tree2extnode0 );
                tree2.adjustNodeCount( false );
                tree1.reRoot( tree1.getNode( tree2extnode0.getSeqName() ) );
                tree1.adjustNodeCount( false );
            }
            catch ( Exception e ) {
                System.err.println( "Exception during rerooting" + e );
                System.exit( -1 );
            }
        }

        try {
            // If bl have not been transferred into boostraps (because
            // external nodes have bootstrap values which are not divisible
            // by 10, as a result of using PHYLIP PROTPARS, for example),
            // transfer them now.
            // Added 03/16/04
            if ( tree2.getFirstExternalNode().getParent() != null
                    && tree2.getFirstExternalNode().getParent().getBootstrap() == PhylogenyNode.BOOTSTRAP_DEFAULT ) {
                System.out.println();
                System.out.println( "transfersBranchLengths: WARNING: Phylogeny \""
                        + f2 + "\" seems to have unusual bootstrap values." );
                moveBranchLengthsToBootstrap( tree2 );
                double max_bs = tree2.getMaximumBootstrapValue();
                System.out.println( "Maximum bootstrap value is: " + max_bs );
                System.out.println( "Will normalize bootstrap values to 100." );
                System.out.println();
                tree2.normalizeBootstrapValues( max_bs, 100 );
            }
            else {
                double max_bs = tree2.getMaximumBootstrapValue();
                System.out.println( "Maximum bootstrap value is: " + max_bs );
            }

            copyBranchLengthValues( tree1, tree2 );
        }
        catch ( Exception e ) {
            System.err
                    .println( "Exception during copying of branch length values:"
                            + e );
            System.exit( -1 );
        }

        try {
            final PhylogenyWriter writer = new PhylogenyWriter();
            writer.toPhyloXML( tree2, f3 );
        }
        catch ( Exception e ) {
            System.err.println( "Could not write tree: " + e );
            System.exit( -1 );
        }
    }
    
    /**
     * Modifies this Phylogeny with the branch lenghts of Phylogeny t. Important
     * (but obvious): The topology of both trees needs to be the same. (The
     * method is not robust in this point, and will produce wrong results if the
     * internal topology differs.) Furthermore, the combination of sequence
     * name, species, and EC number needs to be unique for each external node.
     * <p>
     * (Last modified: 05/22/01)
     * 
     * @param from
     *            the Phylogeny to copy the branch lenghts from
     *  * @param to
     *            the Phylogeny to copy the branch lenghts from
     */
    private final static void copyBranchLengthValues( Phylogeny from, Phylogeny to ) {
        // TODO use iterator
        PhylogenyNode node0 = null, node2_ = null, node1_ = null;
        PhylogenyNode[] nodes1 = null, nodes2 = null;
        int i = 0;

        if ( to.isEmpty() || from.isEmpty() ) {
            return;
        }

        to.setIndicatorsToZero();
        from.setIndicatorsToZero();

        // Visit each node of this and set distance to parent to 0.0:
        PhylogenyNode node2, node1 = to.getFirstExternalNode();
        while ( node1 != null ) {
            node2 = node1;
            while ( node2 != null ) {
                if ( !node2.isExternal() ) {
                    node2.setDistanceToParent( 0.0 );
                }
                node2 = node2.getParent();
            }
            node1 = node1.getNextExternalNode();
        }

        // Visit each internal node of t:
        node1 = from.getFirstExternalNode();
        while ( node1 != null ) {
            node2 = node1;
            while ( node2 != null ) {
                if ( node2.getIndicator() == 0 && !node2.isPseudoNode() ) {
                    node2.setIndicator( 1 );
                    nodes2 = node2.copyAllExtChildren();
                    node0 = nodes2[ 0 ];
                    i++;
                    node1_ = to.getFirstExternalNode();
                    // Visit each internal node of this:
                    while ( node1_ != null ) {
                        node2_ = node1_;
                        if ( node0.equals( node1_ ) ) {
                            while ( node2_ != null ) {
                                if ( node2_.getIndicator() != i
                                        && node2_.getIndicator() != -1 ) {
                                    node2_.setIndicator( i );
                                    if ( nodes2.length == node2_
                                            .getSumExtNodes() ) {
                                        nodes1 = node2_.copyAllExtChildren();
                                        if ( PhylogenyNode
                                                .compareArraysOfNodes( nodes2,
                                                        nodes1 ) ) {
                                            node2_.setIndicator( -1 );
                                            node2_.setDistanceToParent( node2
                                                    .getDistanceToParent() );
                                        }
                                        else {
                                            String message = "Trees were ";
                                            message += "not identical.";
                                            throw new IllegalArgumentException(
                                                    message );
                                        }
                                    }
                                }
                                node2_ = node2_.getParent();
                            }
                        }
                        node1_ = node1_.getNextExternalNode();
                    } //end of visiting each internal node of this.
                }
                node2 = node2.getParent();
            }
            node1 = node1.getNextExternalNode();
        }
        if ( !from.isRooted() ) {
            to.setRooted( false );
        }
        else {
            to.setRooted( true );
        }
        PhylogenyNode.setNodeCount( to.preorderReID( PhylogenyNode.getNodeCount() + 1 ) );

        return;

    } // copyBranchLengthValuesFrom( Phylogeny )
    
    /**
     * Moves the values in the branch length field to the bootstrap field, for
     * each PhylogenyNode of this Phylogeny. Converts a Phylogeny originating
     * from a phylip treefile after bootstrapping and which therefore has its
     * bootstrap values where the branch lenghts would be.
     * <p>
     * [Last modified Jun 1, 2005 by CMZ]
     */
    private final static void moveBranchLengthsToBootstrap( Phylogeny p )  {
        for ( PhylogenyNodeIterator iter = p.iteratorPreorder(); iter.hasNext(); ) {
            PhylogenyNode node = iter.next();
            if ( node.isInternal() && node.getDistanceToParent() > 0 ) {
                node.setBootstrap( ( int ) node.getDistanceToParent() );
            }
            else {
                node.setBootstrap( PhylogenyNode.BOOTSTRAP_DEFAULT );
            }
            node.setDistanceToParent( PhylogenyNode.DISTANCE_DEFAULT );
            //it.next();
        }

    } // moveBranchLengthsToBootstrap()
}