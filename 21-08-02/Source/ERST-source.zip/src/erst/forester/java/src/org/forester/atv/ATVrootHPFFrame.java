/*
 * ATVrootHPFFrame.java Added to ATV by Ethy Cannon 7/8/04
 */

package erst.forester.java.src.org.forester.atv;


import java.awt.*;
import java.awt.event.*;

import javax.swing.JFrame;

import erst.forester.java.src.org.forester.phylogeny.*;

public class ATVrootHPFFrame extends JFrame {

    private ATVrootHPFPanel atvroothpfpanel;

//    private ATVtreePanel    atvtreepanel;

//    private int             i;

    ATVrootHPFFrame() {
//        atvtreepanel = tp;
//        i = x;
        atvroothpfpanel = new ATVrootHPFPanel();
        setSize( 360, 320 );

        Container contentPane = getContentPane();
        contentPane.add( atvroothpfpanel, BorderLayout.CENTER );
        addWindowListener( new WindowAdapter() {

            public void windowClosing( WindowEvent e ) {
                remove(); // to release slot in array
                dispose();
            }
        } );

        setVisible( true );
    }
    
//    ATVrootHPFFrame( PhylogenyNode n, ATVtreePanel tp, int x ) {
//        atvtreepanel = tp;
//        i = x;
//        atvroothpfpanel = new ATVrootHPFPanel( n, this );
//        setSize( 360, 320 );
//
//        Container contentPane = getContentPane();
//        contentPane.add( atvroothpfpanel, BorderLayout.CENTER );
//        addWindowListener( new WindowAdapter() {
//
//            public void windowClosing( WindowEvent e ) {
//                remove(); // to release slot in array
//                dispose();
//            }
//        } );
//
//        setVisible( true );
//    }

//    ATVtreePanel getATVtreePanel() {
//        return atvtreepanel;
//    }

    void remove() {
        addWindowListener( new WindowAdapter() {

            public void windowClosing( WindowEvent e ) {
                remove(); // to release slot in array
                dispose();
            }
        } );

//        atvtreepanel.removeNodeHPFFrame( i ); // to release slot in array
    }
}