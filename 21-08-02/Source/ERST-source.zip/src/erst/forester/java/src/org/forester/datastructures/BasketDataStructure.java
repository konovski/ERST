// BasketDataStructure.java
//
// Copyright (C) 1999-2001 Washington University School of Medicine
// and Howard Hughes Medical Institute
// All rights reserved
//
// Created: 2000
// Author: Christian M. Zmasek
// zmasek@genetics.wustl.edu
// http://www.genetics.wustl.edu/eddy/people/zmasek/

package erst.forester.java.src.org.forester.datastructures;

/**
 * An implementation of the "Basket" datastructure. This datastructure is used
 * in Eulenstein's algorithm for gene duplication inference
 * ("forester/tools/OE").
 * <p>
 * Reference: Oliver Eulenstein (1998) Vorhersage von Genduplikationen und deren
 * Entwicklung in der Evolution. GMD Research Series, No 20/1998 GMD -
 * Forschungszentrum Informationstechnik GmbH. - Sankt Augustin
 * (http://www.gmd.de/publications/research/1998/020/)
 * <p>
 * More information about FORESTER (including download) is available at: <A HREF
 * ="http://www.genetics.wustl.edu/eddy/people/zmasek/forester/">
 * http://www.genetics.wustl.edu/eddy/people/zmasek/forester/ </A>
 * </p>
 * 
 * @author Christian M. Zmasek
 * @version 1.000 -- last modified: 10/12/00
 */
public class BasketDataStructure {

    /**
     * Constructs a BasketDataStructure of size s.
     * 
     * @param s
     *            initial size
     */
    public BasketDataStructure( int s ) {

        link = new int[s];
        rank = new int[s];
    }

    /**
     * Creates a basket( s ), which is affiliated with the PhylogenyNode s of the species
     * Phylogeny and which contains the PhylogenyNode g of the gene Phylogeny. (Corresponds to
     * method makeSet of DisjointSet.)
     * 
     * @param g
     *            a PhylogenyNode ID of the gene Phylogeny
     * @param s
     *            a PhylogenyNode ID of the species Phylogeny which will become the
     *            representative of a basket
     */
    public void createBasket( int g, int s ) {

        link[ s ] = link[ g ] = s;
        rank[ s ] = rank[ g ] = DEFAULT_RANK;

    }

    /**
     * Changes the affiliation of basket( s1 ) from s1 to s2.
     * 
     * @param s1
     *            a PhylogenyNode ID of the species Phylogeny and representative of a existing
     *            basket( s1 )
     * @param s2
     *            a PhylogenyNode ID of the species Phylogeny
     */
    public void moveBasket( int s1, int s2 ) {

        link[ s2 ] = link[ s1 ] = s2;

    }

    /**
     * Adds the elements of basket( s1 ) to the elements of basket( s2 ) and
     * deletes basket( s1 ). (Corresponds to method link of DisjointSet.)
     * 
     * @param s1
     *            a PhylogenyNode ID of the species Phylogeny and representative of a existing
     *            basket( s1 )
     * @param s2
     *            a PhylogenyNode ID of the species Phylogeny and representative of a existing
     *            basket( s2 )
     */
    public void mergeBasket( int s1, int s2 ) {

        link[ s1 ] = s2;

        if ( rank[ s1 ] == rank[ s2 ] ) {
            rank[ s2 ]++;
        }

    }

    /**
     * Finds the basket containing the PhylogenyNode g of the gene Phylogeny. (Corresponds to
     * method findSet of DisjointSet.)
     * 
     * @param g
     *            a PhylogenyNode ID of the gene Phylogeny
     * @return the representative of the basket containing gene Phylogeny node g
     */
    public int findBasket( int g ) {

        if ( link[ g ] == g ) {
            return g;
        }
        else {
            return link[ g ] = findBasket( link[ g ] );
        }

    }

    /**
     * Inserts gene Phylogeny PhylogenyNode g into basket( s ).
     * 
     * @param g
     *            a PhylogenyNode ID of the gene Phylogeny
     * @param s
     *            a PhylogenyNode ID of the species Phylogeny and representative of a existing
     *            basket( s1 )
     */
    public void insertIntoBasket( int g, int s ) {

        link[ g ] = s;

    }

    /**
     * Transfers this to a String.
     */
    public String toString() {

        String s = new String();

        for ( int i = 0; i < link.length; ++i ) {
            s += i + ":   ";
            s += "Link : " + link[ i ] + "    ";
            s += "Rank : " + rank[ i ] + "\n";
        }

        return s;
    }

    private int[]            link;

    int[]                    rank;

    private final static int DEFAULT_RANK = 0;

} // End of class BasketDataStructure.
