package erst.forester.java.src.org.forester.phylogeny.data;


import java.util.ArrayList;

public class Taxonomy implements PhylogenyData {

    private String    _scientific_name;

    private String    _common_name;

    private String    _taxonomy_identifier;

    private String    _rank;

    private String    _distribution;

    private Uri       _uri;
    
    private Support   _support;

    private ArrayList _custom;

    public Taxonomy() {
        init();
    }

    public void init() {
        setScientificName( "" );
        setCommonName( "" );
        setTaxonomyIdentifier( "" );
        setRank( "" );
        setDistribution( "" );
        setUri( null );
        setCustom( new ArrayList() );
    }

    public PhylogenyData copy() {
        Taxonomy t = new Taxonomy();
        t.setScientificName( getScientificName() );
        t.setCommonName( getCommonName() );
        t.setTaxonomyIdentifier( getTaxonomyIdentifier() );
        t.setRank( getRank() );
        t.setDistribution( getDistribution() );
        t.setUri( getUri() );
        t.setCustom( Util.copy( getCustom() ) );
        return t;
    }

  

    public boolean isEqual( final PhylogenyData data ) {
        // TODO Auto-generated method stub
        return false;
    }

    public StringBuffer asText() {
        // TODO Auto-generated method stub
        return null;
    }

    public StringBuffer asSimpleText() {
        // TODO Auto-generated method stub
        return null;
    }

    public StringBuffer toPhyloXML( int level ) {
        // TODO Auto-generated method stub
        return null;
    }

    public String getCommonName() {
        return _common_name;
    }

    public void setCommonName( final String common_name ) {
        _common_name = common_name;
    }

    public ArrayList getCustom() {
        return _custom;
    }

    public void setCustom( final ArrayList custom ) {
        _custom = custom;
    }

    public String getDistribution() {
        return _distribution;
    }

    public void setDistribution( final String distribution ) {
        _distribution = distribution;
    }

    public String getRank() {
        return _rank;
    }

    public void setRank( final String rank ) {
        _rank = rank;
    }

    public String getScientificName() {
        return _scientific_name;
    }

    public void setScientificName( final String scientific_name ) {
        _scientific_name = scientific_name;
    }

    public String getTaxonomyIdentifier() {
        return _taxonomy_identifier;
    }

    public void setTaxonomyIdentifier( final String taxonomy_identifier ) {
        _taxonomy_identifier = taxonomy_identifier;
    }

    public Uri getUri() {
        return _uri;
    }

    public void setUri( final Uri uri ) {
        _uri = uri;
    }

    public Support getSupport() {
        return _support;
    }

    public void setSupport( final Support support ) {
        _support = support;
    }

}
