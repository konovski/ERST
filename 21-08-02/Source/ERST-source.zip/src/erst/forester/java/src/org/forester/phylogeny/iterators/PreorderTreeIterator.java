// PreorderTreeIterator.java
//
// Copyright (C) 1999-2001 Washington University School of Medicine
// and Howard Hughes Medical Institute
// All rights reserved
//
// Created: 1999
// Author: Christian M. Zmasek
// zmasek@genetics.wustl.edu
// http://www.genetics.wustl.edu/eddy/people/zmasek/
package erst.forester.java.src.org.forester.phylogeny.iterators;

import java.util.NoSuchElementException;
import java.util.Stack;

import erst.forester.java.src.org.forester.phylogeny.Phylogeny;
import erst.forester.java.src.org.forester.phylogeny.PhylogenyNode;

//import java.util.Iterator; TODO should implement this, not some iterator of
// this package.

/**
 * @author Christian M. Zmasek
 * @version 1.020 -- last modified: 10/10/05
 */
public class PreorderTreeIterator implements PhylogenyNodeIterator {
    /**
     * @param tree
     *            Phylogeny for which a Iterator is to be constructed.
     */
    public PreorderTreeIterator( Phylogeny tree )
            throws IllegalArgumentException {
        if ( tree.isEmpty() ) {
            throw new IllegalArgumentException(
                    "Attempt to use PreorderTreeIterator on empty tree." );
        }

        _stack = new Stack();
        _tree = tree;
        reset();
    }

    /**
     * DOCUMENT ME!
     */
    public void reset() {
        getStack().clear();
        getStack().push( getTree().getRoot() );
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.util.Iterator#hasNext()
     */
    public boolean hasNext() {
        return !getStack().isEmpty();
    }

    /**
     * Advances the Iterator by one.
     */
    public PhylogenyNode next() throws NoSuchElementException{
        if ( !hasNext() ) {
            throw new NoSuchElementException(
                    "Attempt to call \"next()\" on iterator which has no more next elements." );
        }

        final PhylogenyNode node = ( PhylogenyNode ) getStack().pop();

        if ( !node.isExternal() ) {
            for ( int i = node.getNumberOfChildNodes() - 1; i >= 0; --i ) {
                getStack().push( node.getChildNode( i ) );
            }
        }

        return node;
    } // next()

    private Stack getStack() {
        return _stack;
    }

    private Phylogeny getTree() {
        return _tree;
    }

    final private Phylogeny _tree;
    final private Stack     _stack;
} // End of class PreorderTreeIterator.
