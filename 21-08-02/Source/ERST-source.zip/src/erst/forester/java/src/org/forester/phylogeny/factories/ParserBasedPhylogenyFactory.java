/*
 * Created on Jun 5, 2005
 */
package erst.forester.java.src.org.forester.phylogeny.factories;

import java.io.IOException;
import java.util.List;

import erst.forester.java.src.org.forester.phylogeny.Phylogeny;
import erst.forester.java.src.org.forester.phylogeny.parsers.PhylogenyParser;
import erst.forester.java.src.org.forester.phylogeny.parsers.PhylogenyParserException;

/**
 * Singleton.
 * 
 * @author Christian Zmasek 
 */
public class ParserBasedPhylogenyFactory extends BasicPhylogenyFactory {
    /**
     * DOCUMENT ME!
     * 
     * @return DOCUMENT ME!
     */
    public static synchronized PhylogenyFactory getInstance() {
        if ( _instance == null ) {
            _instance = new ParserBasedPhylogenyFactory();
        }
        return _instance;
    }

    /**
     */
    public Phylogeny[] create( Object source, Object parser, List parameters )
            throws IOException, PhylogenyParserException {
        if ( !( parser instanceof PhylogenyParser ) ) {
            throw new IllegalArgumentException(
                    "Attempt to use object of type other than PhylogenyParser as creator for ParserBasedPhylogenyFactory." );
        }

        PhylogenyParser my_parser = ( PhylogenyParser ) parser;
        my_parser.setSource( source );

        return my_parser.parse();
    }

   
    /**
     * DOCUMENT ME!
     * 
     * @return DOCUMENT ME!
     * @throws CloneNotSupportedException
     *             DOCUMENT ME!
     */
    public Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException();
    }

    private ParserBasedPhylogenyFactory() {
    }

    private static PhylogenyFactory _instance;
}
