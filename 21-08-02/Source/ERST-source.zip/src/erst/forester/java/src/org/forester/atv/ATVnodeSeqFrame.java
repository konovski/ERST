/*
 * ATVnodeSeqFrame.java Added to ATV by Ethy Cannon 7/8/04
 */

package erst.forester.java.src.org.forester.atv;


import java.awt.*;
import java.awt.event.*;

import javax.swing.JFrame;

import erst.forester.java.src.org.forester.phylogeny.*;

public class ATVnodeSeqFrame extends JFrame {

    private ATVnodeSeqPanel atvnodeseqpanel;

    private ATVtreePanel    atvtreepanel;

    private int             i;

    ATVnodeSeqFrame( PhylogenyNode n, ATVtreePanel tp, int x ) {
        atvtreepanel = tp;
        i = x;
        atvnodeseqpanel = new ATVnodeSeqPanel( n, this );
        setSize( 360, 320 );

        Container contentPane = getContentPane();
        contentPane.add( atvnodeseqpanel, BorderLayout.CENTER );
        addWindowListener( new WindowAdapter() {

            public void windowClosing( WindowEvent e ) {
                remove(); // to release slot in array
                dispose();
            }
        } );

        setVisible( true );
    }

    ATVtreePanel getATVtreePanel() {
        return atvtreepanel;
    }

    void remove() {
        atvtreepanel.removeNodeSeqFrame( i ); // to release slot in array
    }
}