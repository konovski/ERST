/*
 * Created on Nov 13, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package erst.forester.java.src.org.forester.phylogeny;

import erst.forester.java.src.org.forester.phylogeny.data.PhylogenyData;

/**
 * @author Christian Zmasek
 *
 * Interface for edges connecting nodes, for example branches in
 * a phylgenetic network/tree.
 * 
 */
public interface Edge {
    public PhylogenyNode getFirstNode();

    public PhylogenyNode getSecondNode();
    
    public PhylogenyData getData();
    
    
}