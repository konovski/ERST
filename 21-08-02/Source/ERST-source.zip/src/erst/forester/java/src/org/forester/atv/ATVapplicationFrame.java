// ATVapplicationFrame.java
//
// Copyright (C) 1999-2001 Washington University School of Medicine
// and Howard Hughes Medical Institute
// All rights reserved
//
// Created: 1999
// Author: Christian M. Zmasek
// zmasek@genetics.wustl.edu
// http://www.genetics.wustl.edu/eddy/people/zmasek/

// Modified by Renata.
// Modified by Petar - 2008 - 2021.

package erst.forester.java.src.org.forester.atv;
// import javax.accessibility.AccessibleContext; - Excluded by Petar.

import java.util.Vector;
import java.awt.BorderLayout;
import java.awt.event.*;
import java.io.File;
import java.net.URL;
import javax.swing.filechooser.FileFilter;
// import java.util.*; - Excluded by Petar.

import erst.CalcParameters;
import erst.forester.java.src.org.forester.io.PhylogenyWriter;
import erst.forester.java.src.org.forester.phylogeny.Phylogeny;
import erst.forester.java.src.org.forester.phylogeny.PhylogenyNode;
import erst.forester.java.src.org.forester.phylogeny.factories.ParserBasedPhylogenyFactory;
import erst.forester.java.src.org.forester.phylogeny.factories.PhylogenyFactory;
import erst.forester.java.src.org.forester.phylogeny.parsers.nhx.NHXParser;
import erst.forester.java.src.org.forester.phylogeny.parsers.xml.SimplePhyloXMLParser1;
import erst.forester.java.src.org.forester.util.Util;
import erst.genalg.InnerData;

import javax.swing.*;

/**
 * @author Christian M. Zmasek
 * @version 2.110 -- last modified: 11/28/05 by eksc
 */
public class ATVapplicationFrame extends ATVframe {
  
	protected final static int FRAME_X_SIZE = 640, FRAME_Y_SIZE = 580,
	PRINT_X_SIZE = 580, PRINT_Y_SIZE = 700;

	protected File          treefile       = null;
	protected  JFileChooser open_filechooser, saveas_filechooser;
  
	// Filters for the file-open dialog (classes defined in this file)
	protected  final static NHXFilter nhxfilter     = new NHXFilter();
	protected  final static NHFilter  nhfilter      = new NHFilter();
	protected  final static XMLFilter xmlfilter     = new XMLFilter();
  
	// Remember last file-open location
	File open_dir;
  
	// Application-only print menu items
	protected  JMenuItem    print_item, print_options_jmenu;
  
	// Checkbox for print options menu menu
	protected  JCheckBox    print_in_color;
  
	// Print size support:
	protected  JSlider      x_slider, y_slider;
	protected  final static int
	SLIDER_MIN  = 0, 
	SLIDER_MAX = 200,
	SLIDER_VAL = 100, 
	SLIDER_MAJS = 50, 
	SLIDER_MINS = 10;
  
    protected static final int MAX_PARSIMONY  = InnerData.MAX_PARSIMONY;
    protected static final int MAX_LIKELIHOOD = InnerData.MAX_LIKELIHOOD;
    protected static final int MIN_ENTROPY    = InnerData.MIN_ENTROPY;

  String HName = "";
  /**
   * This constructor creates and displays a JFrame containing the image of a
   * Phylogeny t plus all the necessary controls. Requirement: Java 1.4 or
   * greater.
   * 
   * @param t
   *            the Phylogeny to display
   * @see #showWhole()
   */
  
	public ATVapplicationFrame(Phylogeny t, String config_file) {
		
		int chosenHPF = InnerData.chosenHPF;
		
		// hide until everything is ready
		setVisible( false );
		config_filename = config_file;

		// set tree, if any
		if ( t != null && !t.isEmpty() ) {
			reload_tree_ = t.copy();
		}
    
		atvtextframe = null;
		species_tree_ = null;
    
		// set title
		// The title generation was swapped by Petar. 
		String title = "ATV";
		int methodUsed = CalcParameters.getMethodUsed();
		switch (methodUsed) {
			case MAX_PARSIMONY:
				title += " - MP";
				break;
			case MAX_LIKELIHOOD:
				title += " - ML";
				break;
			case MIN_ENTROPY:
				title += " - ME";
		}
		
		if (chosenHPF >= 0) {
			HName = InnerData.functionContents[chosenHPF];
			title += " - EVOLUTIONARY RECONSTRUCTION FOR GENE " + HName;
		}
		else if (InnerData.GainsLossesSelected)
        	title += " - GAINS/LOSSES FOR ALL GENES";
		else // Selected is display of probabilities.
        	title += " - PER THOUSAND PROBABILITIES - GAINS/LOSSES";
        	
		setTitle(title);
		
    /*
    if ( t != null && !t.isEmpty() &&	!Util.isEmpty( t.getName() ) ) {
      setTitle( "ATV - PARS [" + t.getName() + "]" );
    }
    else {
        if (GraphTabPanel.key == true) {
            HName = TickerListPanelNotWorking.hpfList[GraphTabPanel.index];
            setTitle( "ATV - PARS - EVOLUTIONARY RECONSTRUCTION FOR GENE = " + HName);
        }
        else if (MainMenu.MLselected) { // Added by Petar.
            setTitle( "ATV - ML - PER THOUSAND PROBABILITIES - GAINS/LOSSES" );
        }
        else { // Modified by Petar.
            setTitle( "ATV - PARS - EVOLUTIONARY RECONSTRUCTION FOR ALL GENES - Gains/Losses" );
        }
        
    }
    /*
    */

    // Read config file (false, false => not url, not applet)
    config_settings = new ATVConfig(config_file, false, false);
    
    // The ATV panel
    atvpanel = new ATVpanel( t, config_settings, this );
    
    // The file dialogs
    open_filechooser = new JFileChooser();
    open_filechooser.setCurrentDirectory( new File( "." ) );
    open_filechooser.setMultiSelectionEnabled( false );
    open_filechooser.setFileFilter( nhxfilter );
    open_filechooser.addChoosableFileFilter( nhfilter );
    open_filechooser.addChoosableFileFilter( open_filechooser.getAcceptAllFileFilter() );
    
    saveas_filechooser = new JFileChooser();
    saveas_filechooser.setCurrentDirectory( new File( "." ) );
    saveas_filechooser.setMultiSelectionEnabled( false );
    saveas_filechooser.setFileFilter( nhxfilter );
    saveas_filechooser.addChoosableFileFilter( xmlfilter );
    saveas_filechooser.addChoosableFileFilter( nhfilter );
    saveas_filechooser.addChoosableFileFilter( saveas_filechooser
      .getAcceptAllFileFilter() );
    
    // build the menu bar
    jmenubar = new JMenuBar();
    jmenubar.setBackground( ATVconstants.MENU_BACKGROUND_COLOR_DEFAULT );
    
    buildFileMenu();
    //buildEditMenu(); Excluded by Petar
//    buildViewMenu();
    buildOptionsMenu();
//    buildSDIMenu();
    // don't display until there's something in it:
    //			buildGenomicsMenu();
    
    buildHelpMenu();
    setJMenuBar( jmenubar );
    jmenubar.add( help_jmenu );
    
    
    // add the ATV panel to the content pane
    contentpane = getContentPane();
    contentpane.setLayout( new BorderLayout() );
    contentpane.add( atvpanel, BorderLayout.CENTER );
    
    // App is this big
    setSize( FRAME_X_SIZE, FRAME_Y_SIZE );
    
    // The window listener
    addWindowListener( new WindowAdapter() {
        /**
		 * @param e is not used.
		 */
        @Override // Added by Petar.
        public void windowClosing( WindowEvent e ) {
          close();
        }
      } );
    
    // The component listener
    addComponentListener( new ComponentAdapter() {
        /**
		 * @param e is not used.
		 */
        @Override // Added by Petar.
		public void componentResized( ComponentEvent e ) {
          atvpanel.getATVtreePanel().setParametersForPainting(
            atvpanel.getATVtreePanel().getWidth(),
            atvpanel.getATVtreePanel().getHeight() );
//          atvpanel.getATVcontrol().showWhole(); // I Renata added
        }
      } );
      
    // All done: show the frame
    setVisible( true );
    
    // ...and its children
    atvpanel.getATVcontrol().showWhole();
    contentpane.repaint();
  } // End of public void ATVapplicationFrame(Phylogeny t, String config_file)
  
  
  /**
   * Called automatically.
   * @param e is not used.
   */
  @Override // Added by Petar.
  public void actionPerformed( ActionEvent e ) {
    
    super.actionPerformed(e);
    Object o = e.getSource();
    
    // Handle app-specific actions here:
    if ( o == open_item ) {
      openFile();
    }
    else if ( o == save_item ) {
      save( atvpanel.getATVtreePanel().getTree() );
      // (Always saves the complete tree.) = not true anymore!
      // If subtree currently displayed, save it, instead of complete
      // tree.
    }
    else if ( o == saveas_item ) {
      saveAs( atvpanel.getATVtreePanel().getTree() );
      // If subtree currently displayed, save it, instead of complete
      // tree.
    }
    else if ( o == print_item ) {
      printTree();
    }
//    else if ( o == view_as_NH_item ) {
//      viewAsNH();
//    }
//    else if ( o == view_as_NHX_item ) {
//      viewAsNHX();
//    }
//    else if ( o == view_as_XML_item ) {
//      viewAsXML();
//    }
//    else if ( o == load_species_tree_item ) {
//      openSpeciesTreeFile();
//    }
//    else if ( o == infer_dups_item ) {
//      inferDups();
//    }
//    else if ( o == root_min_dups_height_item ) {
//      rootMinDupsHeight();
//    }
//    else if ( o == root_min_L_height_item ) {
//      rootMinLHeight();
//    }
//    else if ( o == root_min_height_item ) {
//      rootMinHeight();
//    }
    contentpane.repaint();
  }//actionPerformed
  
  
  /**
   *
   */
  @Override // Added by Petar.
  protected void buildFileMenu() {
    file_jmenu = createMenu( "File" );
    
    print_options_jmenu = new JMenu( "Print Options" );
    print_options_jmenu.setFont( menu_font );
    print_options_jmenu
    .setBackground( ATVconstants.MENU_BACKGROUND_COLOR_DEFAULT );
    print_options_jmenu
    .setForeground( ATVconstants.MENU_TEXT_COLOR_DEFAULT );
    
    file_jmenu.add( reload_item = new JMenuItem( "Reload tree" ) );
    file_jmenu.addSeparator();
    file_jmenu.add( open_item = new JMenuItem( "Open tree..." ) );
    file_jmenu.add( open_url_item = new JMenuItem(
        "Open tree URL..." ) );
    file_jmenu.add( saveas_item = new JMenuItem( "Save As..." ) );
    file_jmenu.add( save_item = new JMenuItem( "Save" ) );
    file_jmenu.addSeparator();
    file_jmenu.add( print_options_jmenu );
    file_jmenu.add( print_item = new JMenuItem( "Print..." ) );
    file_jmenu.addSeparator();
    file_jmenu.add( close_item = new JMenuItem( "Close" ) );
    
    // For print in color option item
    print_in_color = new JCheckBox( "Print in color" ); 
    print_in_color.setFont( menu_font );
    print_in_color.setForeground( ATVconstants.MENU_TEXT_COLOR_DEFAULT );
    print_options_jmenu.add( print_in_color );
    
    // For print size in option item
    xs_label = new JLabel( "X size:" );
    xs_label.setForeground( ATVconstants.MENU_TEXT_COLOR_DEFAULT );
    xs_label.setFont( menu_font );
    ys_label = new JLabel( "Y size:" );
    ys_label.setFont( menu_font );
    ys_label.setForeground( ATVconstants.MENU_TEXT_COLOR_DEFAULT );
    
    x_slider = new JSlider( SLIDER_MIN, SLIDER_MAX, SLIDER_VAL ); 
    x_slider.setFont( menu_font );
    x_slider.setMajorTickSpacing( SLIDER_MAJS );
    x_slider.setMinorTickSpacing( SLIDER_MINS );
    x_slider.setPaintTicks( true );
    x_slider.setPaintLabels( true );
    x_slider.setSnapToTicks( true );
    print_options_jmenu.add( xs_label );
    print_options_jmenu.add( x_slider );
    
    y_slider = new JSlider( SLIDER_MIN, SLIDER_MAX, SLIDER_VAL );
    y_slider.setFont( menu_font );
    y_slider.setMajorTickSpacing( SLIDER_MAJS );
    y_slider.setMinorTickSpacing( SLIDER_MINS );
    y_slider.setPaintTicks( true );
    y_slider.setPaintLabels( true );
    y_slider.setSnapToTicks( true );
    print_options_jmenu.add( ys_label );
    print_options_jmenu.add( y_slider );
    
    customizeJMenuItem( reload_item );
    customizeJMenuItem( open_item );
    customizeJMenuItem( open_url_item );
    customizeJMenuItem( save_item );
    customizeJMenuItem( saveas_item );
    customizeJMenuItem( print_item );
    customizeJMenuItem( close_item );
    //      customizeJMenuItem( exit_item );
    jmenubar.add( file_jmenu );
  }//buildFileMenu
  
  
  /**
   *
   */
//  protected void buildGenomicsMenu() {
//    genomics_jmenu = createMenu( "Phylogenomics" );
//    jmenubar.add( genomics_jmenu );
//  }//buildGenomicsMenu
  
  
  /**
   *
   */
//  protected void buildSDIMenu() {
//    SDI_jmenu = new JMenu( "SDI" );
//    SDI_jmenu.setFont( menu_font );
//    SDI_jmenu.setBackground( ATVconstants.MENU_BACKGROUND_COLOR_DEFAULT );
//    SDI_jmenu.setForeground( ATVconstants.MENU_TEXT_COLOR_DEFAULT );
//    
//    SDI_jmenu.add( infer_dups_item = new JMenuItem(
//        "SDI (Speciation Duplication Inference)" ) );
//    SDI_jmenu.addSeparator();
//    SDI_jmenu.add( root_min_dups_height_item = new JMenuItem(
//        "SDI and root by minimizing duplications | height" ) );
//    SDI_jmenu.add( root_min_L_height_item = new JMenuItem(
//        "SDI and root by minimizing cost L | height" ) );
//    SDI_jmenu.add( root_min_height_item = new JMenuItem(
//        "SDI and root by minimizing height" ) );
//    SDI_jmenu.addSeparator();
//    SDI_jmenu.add( load_species_tree_item = new JMenuItem(
//        "Load species tree" ) );
//    
//    customizeJMenuItem( infer_dups_item );
//    customizeJMenuItem( root_min_dups_height_item );
//    customizeJMenuItem( root_min_L_height_item );
//    customizeJMenuItem( root_min_height_item );
//    customizeJMenuItem( load_species_tree_item );
//    
//    jmenubar.add( SDI_jmenu );
//  }//buildSDIMenu
  
  
    /**
   *
   */
//  public void openFileListHPF(String open_fileHPF) {
//      boolean exception = false;
//      Phylogeny t = null;
//      
//      File f = new File( open_fileHPF );    
//      PhylogenyFactory factory = ParserBasedPhylogenyFactory.getInstance();
//      System.out.println("startup file: "+f.getName()+" exists: "+f.exists());
//      try {           
//          if ( f.getName().toLowerCase().endsWith( ".xml" ) ) {
//              t = factory.create( f, new SimplePhyloXMLParser1() )[ 0 ];
//          }
//          else {
//              t = factory.create( f, new NHXParser() )[ 0 ];
//          }
//      }
//      catch ( Exception e ) {
//          exception = true;
//          exceptionOccuredDuringOpenFile( e );
//      }
//      if ( !exception && t != null && !t.isEmpty() ) {
//          reload_tree_ = t.copy();
//          removeatvtextframe();
//          atvpanel.terminate();
//          contentpane.removeAll();
//          atvpanel = new ATVpanel( t, config_settings, this );
//          jmenubar.remove( help_jmenu );
//          jmenubar.add( help_jmenu );
//          contentpane.add( atvpanel, BorderLayout.CENTER );
//          setVisible( true );
////          treefile = file;
//          if ( !Util.isEmpty( t.getName() ) ) {
//              setTitle( "ATV - PARS [" + t.getName() + "]" + " [" + treefile + "]" );
//          }
//          else {
//              setTitle( "ATV - PARS [" + treefile + "]" );
//          }
//          atvpanel.getATVtreePanel().setParametersForPainting(
//                    atvpanel.getATVtreePanel().getWidth(),
//                    atvpanel.getATVtreePanel().getHeight() );
//          atvpanel.getATVcontrol().showWhole();
//      }
//      contentpane.repaint();
//  }//openFileListHPF
  
  /**
   *
   */
  private void openFile() {
    boolean exception = false;
    Phylogeny t = null;
    
    // Set an initial directory if none set yet
    if (open_dir == null) {
//System.out.println("System properties:");
//Properties p = System.getProperties();
//Enumeration te = p.keys();
//while (te.hasMoreElements()) {
//  String key = (String)te.nextElement();
//  System.out.println("   "+key+" -> "+p.getProperty(key));
//}
//System.out.println("-----------------");
      // Make an intelligent guess about the best initial directory
      if (System.getProperty("user.dir") != null) {
        // open in directory from which the app was launched
        open_dir = new File(System.getProperty("user.dir"));
      } else {
        // open in user's home directory
        open_dir = new File(System.getProperty("user.home"));
      }
    }
    
    // Open file-open dialog and set current directory
    open_filechooser.setCurrentDirectory(open_dir);
    int result = open_filechooser.showOpenDialog( contentpane );
    
    // All done: get the file
    File file = open_filechooser.getSelectedFile();
    open_dir = open_filechooser.getCurrentDirectory();
    if ( file != null && result == JFileChooser.APPROVE_OPTION ) {
        if ( open_filechooser.getFileFilter() == nhfilter
                || open_filechooser.getFileFilter() == nhxfilter ) {
            try {
                PhylogenyFactory factory = ParserBasedPhylogenyFactory
                 .getInstance();
                 t = factory.create( file, new NHXParser() )[ 0 ];
            }
            catch ( Exception e ) {
                exception = true;
                exceptionOccuredDuringOpenFile( e );
             }
        }
        else if ( open_filechooser.getFileFilter() == xmlfilter ) {
            try {
                PhylogenyFactory factory = ParserBasedPhylogenyFactory
                        .getInstance();
                t = factory.create( file, new SimplePhyloXMLParser1() )[ 0];
            }
            catch ( Exception e ) {
                exception = true;
                exceptionOccuredDuringOpenFile( e );
            }
        }
        // "*.*":
        else {
            try {
                if ( file.getName().toLowerCase().endsWith( ".xml" ) ) {
                    PhylogenyFactory factory = ParserBasedPhylogenyFactory.getInstance();
                    t = factory.create( file, new SimplePhyloXMLParser1() )[ 0 ];
                }
                else {
                    PhylogenyFactory factory = ParserBasedPhylogenyFactory.getInstance();
                        t = factory.create( file, new NHXParser() )[ 0 ];
                }
            }
            catch ( Exception e ) {
                exception = true;
                exceptionOccuredDuringOpenFile( e );
            }
        }
        if ( !exception && t != null && !t.isEmpty() ) {
            reload_tree_ = t.copy();
            removeatvtextframe();
            atvpanel.terminate();
            contentpane.removeAll();
            atvpanel = new ATVpanel( t, config_settings, this );
            jmenubar.remove( help_jmenu );
            jmenubar.add( help_jmenu );
            contentpane.add( atvpanel, BorderLayout.CENTER );
            setVisible( true );
            treefile = file;
            if ( !Util.isEmpty( t.getName() ) ) {
                setTitle( "ATV - PARS [" + t.getName() + "]" + " [" + treefile
                       + "]" );
            }
            else {
               setTitle( "ATV - PARS [" + treefile + "]" );
            }

            atvpanel.getATVtreePanel().setParametersForPainting(
                    atvpanel.getATVtreePanel().getWidth(),
                    atvpanel.getATVtreePanel().getHeight() );
            atvpanel.getATVcontrol().showWhole();
        }
        contentpane.repaint();
    }
  }//openFile
  
  
  @Override // Added by Petar.
  protected void openURL() {
    URL url = null;
    Phylogeny t = null;
    String message = "Please enter a complete URL";
    
    String url_string = JOptionPane.showInputDialog( this, message,
      "Open URL to read a phyloXML/NH/NHX tree",
      JOptionPane.QUESTION_MESSAGE );
    
    if ( url_string != null && url_string.length() > 0 ) {
      
            try {
                url = new URL( url_string );
                if ( url.getFile().toLowerCase().endsWith( ".xml" ) ) {
                    PhylogenyFactory factory = ParserBasedPhylogenyFactory
                            .getInstance();
                    t = factory.create( url.openStream(), new SimplePhyloXMLParser1() )[ 0 ];
                }
                else {
                    PhylogenyFactory factory = ParserBasedPhylogenyFactory
                    .getInstance();
                    t = factory.create( url.openStream(), new NHXParser() )[ 0 ];
                }
            }
            catch ( Exception e ) {
                JOptionPane.showMessageDialog( this,
                        "TreeJAppletJFrame: openURL(): " + "Exception: " + e,
                        "Malformed URL", JOptionPane.ERROR_MESSAGE );
            }
            if ( url != null ) {
                try {
                    PhylogenyFactory factory = ParserBasedPhylogenyFactory
                    .getInstance();
                    t = factory.create( url.openStream(), new NHXParser() )[ 0 ];
                }
                catch ( Exception e ) {
                    JOptionPane.showMessageDialog( this,
                            "TreeJAppletJFrame: openURL(): " + "\nException: "
                                    + e, "Could not read Phylogeny",
                            JOptionPane.ERROR_MESSAGE );
                }
                if ( t != null && !t.isEmpty() ) {
                    reload_tree_ = t.copy();
                    removeatvtextframe();
                    atvpanel.terminate();
                    contentpane.removeAll();
                    atvpanel = new ATVpanel( t, config_settings, this );
                    jmenubar.remove( help_jmenu );
//                    setupCustomTagNamesMenu( t );
                    jmenubar.add( help_jmenu );
                    contentpane.add( atvpanel, BorderLayout.CENTER );
                    setVisible( true );
                    contentpane.repaint();
                    setTitle( "ATV: " + url );
                    treefile = null;
                    atvpanel.getATVtreePanel().setParametersForPainting(
                            atvpanel.getATVtreePanel().getWidth(),
                            atvpanel.getATVtreePanel().getHeight() );

                }

            }
            contentpane.repaint();
        }
  }//openURL
  
  
  @Override // Added by Petar.
  protected void reLoad() {
    // Verify that the user wants to reload the tree
    int retval 
    = JOptionPane.showConfirmDialog(this, 
      "Are you sure you want to undo all of your changes?", 
      "Verify Reload", 
      JOptionPane.YES_NO_OPTION);
    boolean do_reload_tree = (retval == JOptionPane.YES_OPTION) ?
    true : false;
    
    // If user verifies action, reload the tree:
    if ( do_reload_tree &&
      reload_tree_ != null && !reload_tree_.isEmpty() ) {
//      Phylogeny t = reload_tree_.copyTree();
      Phylogeny t = reload_tree_.copy();
      removeatvtextframe();
      atvpanel.terminate();
      contentpane.removeAll();
      atvpanel = new ATVpanel( t, config_settings, this );
      contentpane.add( atvpanel, BorderLayout.CENTER );
      setVisible( true );
      if ( treefile != null ) {
        setTitle( "ATV - PARS: " + treefile );
      }
      else {
        setTitle( "ATV - PARS" );
      }
      atvpanel.getATVtreePanel().setParametersForPainting(
        atvpanel.getATVtreePanel().getWidth(),
        atvpanel.getATVtreePanel().getHeight() );
      atvpanel.getATVcontrol().showWhole();
      contentpane.repaint();
    }
  }//reLoad
  
  
  /**
   *
   */
    private void save( Phylogeny t ) {

        if ( treefile == null ) {
            if ( t != null ) {
                saveAs( t );
            }
            return;
        }

        if ( treefile.exists() ) {
            int i = JOptionPane.showConfirmDialog( this, treefile
                    + " already exists. Overwrite?", "File|Save",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE );

            if ( i != JOptionPane.OK_OPTION ) {
                return;
            }
        }

        try {
            final PhylogenyWriter writer = new PhylogenyWriter();
            writer.toPhyloXML( t, treefile );
        }
        catch ( Exception e ) {
            JOptionPane.showMessageDialog( this, "Exception: " + e,
                    "Error during File|Save", JOptionPane.ERROR_MESSAGE );
        }

    }//save
  
  
  /**
   *
   */
  private void saveAs( Phylogeny t ) {
    
    if ( t == null ) {
      return;
    }
    
    boolean ow = false;  
    boolean exception = false;
    
        int result = saveas_filechooser.showSaveDialog( contentpane );
        File file = saveas_filechooser.getSelectedFile();
        if ( file != null && result == JFileChooser.APPROVE_OPTION ) {

            if ( file.exists() ) {
                int i = JOptionPane.showConfirmDialog( this, file
                        + " already exists. Overwrite?", "File|SaveAs",
                        JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.WARNING_MESSAGE );

                if ( i == JOptionPane.OK_OPTION ) {
                    ow = true;
                }
                else {
                    return;
                }
            }

            if ( saveas_filechooser.getFileFilter() == nhfilter ) {
                try {
                    final PhylogenyWriter writer = new PhylogenyWriter();
                    writer.toNewHampshire( t, false, file );
                }
                catch ( Exception e ) {
                    exception = true;
                    exceptionOccuredDuringSaveAs( e );
                }
            }
            else if ( saveas_filechooser.getFileFilter() == nhxfilter ) {
                try {
                    final PhylogenyWriter writer = new PhylogenyWriter();
                    writer.toNewHampshireX( t, file );
                }
                catch ( Exception e ) {
                    exception = true;
                    exceptionOccuredDuringSaveAs( e );
                }
            }
            else if ( saveas_filechooser.getFileFilter() == xmlfilter ) {
                try {
                    final PhylogenyWriter writer = new PhylogenyWriter();
                    writer.toPhyloXML( t, file );
                }
                catch ( Exception e ) {
                    exception = true;
                    exceptionOccuredDuringSaveAs( e );
                }
            }

            // "*.*":
            else {
                if ( file.getName().trim().toLowerCase().endsWith( ".nh" ) ) {
                    try {
                        final PhylogenyWriter writer = new PhylogenyWriter();
                        writer.toNewHampshire( t, false, file );
                    }
                    catch ( Exception e ) {
                        exception = true;
                        exceptionOccuredDuringSaveAs( e );
                    }
                }
                // XML is default:
                else {
                    try {
                        final PhylogenyWriter writer = new PhylogenyWriter();
                        writer.toPhyloXML( t, file );
                    }
                    catch ( Exception e ) {
                        exception = true;
                        exceptionOccuredDuringSaveAs( e );
                    }
                }
            }
            if ( !exception ) {
                treefile = file;
                setTitle( "ATV - PARS: " + treefile );
            }
        }
  }//saveAs
  
  
  /**
   *
   */
  private void printTree() {
    
    if ( atvpanel.getATVtreePanel().getTree() == null
      || atvpanel.getATVtreePanel().getTree().isEmpty() ) {
      return;
    }
    
    ATVprinter atvprinter = null;
    atvpanel.getATVtreePanel().setParametersForPainting(
      PRINT_X_SIZE * x_slider.getValue() / SLIDER_VAL,
      PRINT_Y_SIZE * y_slider.getValue() / SLIDER_VAL );
    
    // same as "show whole":
    if ( treefile != null ) {
      atvprinter = new ATVprinter( atvpanel.getATVtreePanel(), 
                                   atvpanel.getATVcontrol(),
                                   treefile.toString(), 
                                   print_in_color.isSelected() );
    }
    else {
      atvprinter = new ATVprinter( atvpanel.getATVtreePanel(),
                                   atvpanel.getATVcontrol(), "ATVprinter", 
                                   print_in_color.isSelected() );
    }
    
    atvpanel.getATVtreePanel().setParametersForPainting(
      atvpanel.getATVtreePanel().getWidth(),
      atvpanel.getATVtreePanel().getHeight() );
    
    contentpane.repaint();
  }//printTree
  
  
    private void openSpeciesTreeFile() {
        Phylogeny t = null;
        boolean exception = false;
        int result = open_filechooser.showOpenDialog( contentpane );
        File file = open_filechooser.getSelectedFile();
        if ( file != null && result == JFileChooser.APPROVE_OPTION ) {
            if ( open_filechooser.getFileFilter() == nhfilter
                    || open_filechooser.getFileFilter() == nhxfilter ) {
                try {
                    PhylogenyFactory factory = ParserBasedPhylogenyFactory
                    .getInstance();
                    t = factory.create( file, new NHXParser() )[ 0 ];
                }
                catch ( Exception e ) {
                    exception = true;
                    exceptionOccuredDuringOpenFile( e );
                }
            }
            else if ( open_filechooser.getFileFilter() == xmlfilter ) {
                try {
                    PhylogenyFactory factory = ParserBasedPhylogenyFactory
                            .getInstance();
                    t = factory.create( file, new SimplePhyloXMLParser1() )[ 0 ];
                }
                catch ( Exception e ) {
                    exception = true;
                    exceptionOccuredDuringOpenFile( e );
                }
            }
            // "*.*":
            else {
                try {
                    if ( file.getName().toLowerCase().endsWith( ".xml" ) ) {
                        PhylogenyFactory factory = ParserBasedPhylogenyFactory
                                .getInstance();
                        t = factory.create( file, new SimplePhyloXMLParser1() )[ 0 ];
                    }
                    else {
                        PhylogenyFactory factory = ParserBasedPhylogenyFactory
                        .getInstance();
                        t = factory.create( file, new NHXParser() )[ 0 ];
                    }
                }
                catch ( Exception e ) {
                    exception = true;
                    exceptionOccuredDuringOpenFile( e );
                }
            }

            if ( !exception && t != null && !t.isRooted() ) {
                exception = true;
                t = null;
                JOptionPane.showMessageDialog( this,
                        "Species tree is not rooted.",
                        "Species tree not loaded", JOptionPane.ERROR_MESSAGE );
            }
            if ( !exception && t != null && !t.isCompletelyBinary() ) {
                exception = true;
                t = null;
                JOptionPane.showMessageDialog( this,
                        "Species tree is not completely binary.",
                        "Species tree not loaded", JOptionPane.ERROR_MESSAGE );
            }
            if ( !exception && t != null ) {
                Util.cleanSpeciesNamesInExtNodes( t );
                String s = "";
                Vector<Object> v1 = t.getRoot().getAllExternalChildren(); // Modified by Petar.
                Vector<String> v2 = new Vector<String>();  // Modified by Petar.
                for ( int i = 0; i < v1.size(); ++i ) {
                    s = ((PhylogenyNode)v1.elementAt(i)).getTaxonomy();
                    if ( s == null || s == "" ) {
                        exception = true;
                        t = null;
                        JOptionPane.showMessageDialog( this,
                                "Species tree contains empty species fields.",
                                "Species tree not loaded",
                                JOptionPane.ERROR_MESSAGE );
                        break;
                    }
                    v2.addElement(s);
                }
                for ( int i = 0; i < v2.size(); ++i ) {
                    s = v2.elementAt(i);
                    if ( v2.indexOf( s ) != v2.lastIndexOf( s ) ) {
                        exception = true;
                        t = null;
                        JOptionPane.showMessageDialog( this,
                                "Species tree contains duplicate species.",
                                "Species tree not loaded",
                                JOptionPane.ERROR_MESSAGE );
                        break;
                    }
                }
            }
            if ( !exception && t != null ) {
                species_tree_ = t;
                JOptionPane.showMessageDialog( this,
                        "Species tree successfully loaded.", "SDI",
                        JOptionPane.INFORMATION_MESSAGE );
            }
            contentpane.repaint();
        }
    }
  
  
  /* Excluded by Petar.
  private void exit() {
    System.exit( 0 );
  }//exit
   */
  
} // End of class ATVapplicationFrame.java.


class NHFilter extends FileFilter {
  
  public boolean accept( File f ) {
    return f.getName().trim().toLowerCase().endsWith( ".nh" )
    || f.isDirectory();
  }
  
  public String getDescription() {
    return "NH (*.nh)";
  }
} // End of class NHFilter.


class NHXFilter extends FileFilter {
  
  public boolean accept( File f ) {
    return f.getName().trim().toLowerCase().endsWith( ".nhx" )
    || f.isDirectory();
  }
  
  public String getDescription() {
    return "NHX (*.nhx)";
  }
} // End of class NHXFilter.


class XMLFilter extends FileFilter {
  
  public boolean accept( File f ) {
    return f.getName().trim().toLowerCase().endsWith( ".xml" )
    || f.isDirectory();
  }
  
  public String getDescription() {
    return "phyloXML (*.xml)";
  }
} // End of class XMLFilter.

