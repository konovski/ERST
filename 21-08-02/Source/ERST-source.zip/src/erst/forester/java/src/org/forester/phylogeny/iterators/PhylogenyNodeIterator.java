/*
 * Created on Jun 4, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package erst.forester.java.src.org.forester.phylogeny.iterators;

import java.util.NoSuchElementException;

import erst.forester.java.src.org.forester.phylogeny.PhylogenyNode;
/**
 * @author Christian Zmasek
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface PhylogenyNodeIterator {

    public boolean hasNext();
    
    public PhylogenyNode next() throws NoSuchElementException;
    
    public void reset();
    
}
