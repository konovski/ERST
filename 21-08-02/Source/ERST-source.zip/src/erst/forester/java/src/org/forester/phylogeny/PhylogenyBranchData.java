/*
 * Created on Oct 30, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package erst.forester.java.src.org.forester.phylogeny;

import erst.forester.java.src.org.forester.phylogeny.data.PhylogenyData;

/**
 * This class holds PhylogenyBranchData for branches and nodes.
 * 
 * @author Christian Zmasek
 *
 * 
 */
public interface PhylogenyBranchData extends PhylogenyData {

    
}
