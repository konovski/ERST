/*
 * Created on Oct 23, 2005 TODO To change the template for this generated file
 * go to Window - Preferences - Java - Code Style - Code Templates
 */
package erst.forester.java.src.org.forester.datastructures;

import java.util.LinkedList;
import java.util.NoSuchElementException;

/**
 * A simple Queue data structure. Created: 10/23/2005 by Christian M. Zmasek.
 * Last modified: 10/23/2005 by Christian M. Zmasek.
 * 
 * @author Christian M. Zmasek
 * @version 1.000
 */
public class Queue {
    
    // Constructor
    // -----------

    /**
     * This created a new, empty Queue object.
     */
    public Queue() {
        _data = new LinkedList();
    }

    // Public methods
    // --------------

    /**
     * Adds Object element to thisqueue.
     * 
     * @param element
     *            the Object to be enqueued
     */
    public void enqueue( final Object element ) {
        getData().add( element );
    }

    /**
     * Dequeues one element from this queue.
     * 
     * @return the dequeued object
     * @throws NoSuchElementException
     *             if this queue is empty
     */
    public Object dequeue() throws NoSuchElementException {
        if ( isEmpty() ) {
            throw new NoSuchElementException(
                    "Attempt to dequeue from an empty Queue." );
        }

        return getData().removeFirst();
    }

    /**
     * Removes all elements from this queue.
     */
    public void clear() {
        getData().clear();
    }

    /**
     * Returns whether or not this queue is empty.
     * 
     * @return true if this queue is empty, false otherwise
     */
    public boolean isEmpty() {
        return getData().isEmpty();
    }

    // Private methods
    // ---------------

    /**
     * Returns the LinkedList upon which this queue is based.
     * 
     * @return the LinkedList upon which this queue is based
     */
    private LinkedList getData() {
        return _data;
    }

    // Instance variables
    // ------------------
    private final LinkedList _data;
    
} // end of class Queue.
