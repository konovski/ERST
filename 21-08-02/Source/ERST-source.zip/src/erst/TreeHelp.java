/*
 * TreeHelp.java
 *
 * Created on 14 July 2006, 15:32
 * Modified by Petar.
 */

/**
 *
 * @author  renata
 */
package erst;

import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.UIManager;


// import java.awt.event.WindowAdapter; - Removed by Petar.
// import java.awt.event.WindowEvent; - Removed by Petar.

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeSelectionModel;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;

import java.net.URL;
import java.io.IOException;
import java.awt.Dimension;
import java.awt.GridLayout;


public class TreeHelp extends JPanel implements TreeSelectionListener {
	
	private JEditorPane htmlPane;
    private JTree tree;
    private URL helpURL;
    private static boolean playWithLineStyle = false;
    private static String lineStyle = "Horizontal";
    
    //Optionally set the look and feel.
    private static boolean useSystemLookAndFeel = false;
    
    /** Creates a new instance of TreeHelp */
    public TreeHelp() {
        super(new GridLayout(1,0));
         //Create the nodes.
        DefaultMutableTreeNode top = new DefaultMutableTreeNode("ERST Guide");
        createNodes(top);

        //Create a tree that allows one selection at a time.
        tree = new JTree(top);
        tree.getSelectionModel().setSelectionMode
                (TreeSelectionModel.SINGLE_TREE_SELECTION);
        //Listen for when the selection changes.
        tree.addTreeSelectionListener(this);

        if (playWithLineStyle) {
            System.out.println("line style = " + lineStyle);
            tree.putClientProperty("JTree.lineStyle", lineStyle);
        }
        //Create the scroll pane and add the tree to it. 
        JScrollPane treeView = new JScrollPane(tree);

        //Create the HTML viewing pane.
        htmlPane = new JEditorPane();
        htmlPane.setEditable(false);
        initHelp();
        JScrollPane htmlView = new JScrollPane(htmlPane);

        //Add the scroll panes to a split pane.
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT); //VERTICAL_SPLIT);
        splitPane.setTopComponent(treeView);
        splitPane.setBottomComponent(htmlView);

        Dimension minimumSize = new Dimension(100, 70);
        htmlView.setMinimumSize(minimumSize);
        treeView.setMinimumSize(minimumSize);
        splitPane.setDividerLocation(150); //XXX: ignored in some releases
                                           //of Swing. bug 4101306
        //workaround for bug 4101306:
        //treeView.setPreferredSize(new Dimension(100, 100)); 

        splitPane.setPreferredSize(new Dimension(800, 600));
        add(splitPane);
    }
    
    /** Required by TreeSelectionListener interface. 
     * @param e is not used. */
    public void valueChanged(TreeSelectionEvent e) {
        DefaultMutableTreeNode node = (DefaultMutableTreeNode)
                           tree.getLastSelectedPathComponent();

        if (node == null) return;

        Object nodeInfo = node.getUserObject();
        if (node.isLeaf()) {
            BookInfo book = (BookInfo)nodeInfo;
            displayURL(book.bookURL);
            
        } else {
            displayURL(helpURL); 
        }
    }
    
    private class BookInfo {
        //public String bookName; - Never read locally (Petar).
        public String bookName;
        public URL bookURL;

        /**
		 * @param book 
		 */
        public BookInfo(String book, String filename) {
            //bookName = book; - excluded according to the commenting above (Petar).
            bookName = book;
            bookURL = TreeHelp.class.getResource(filename);
            if (bookURL == null) {
                System.err.println("Couldn't find file: " + filename);
            }
        }
        
        public String toString() {
            return bookName;
        }
    }
        
    private void initHelp() {
        String s = "TreeHelpERST.html";
        helpURL = TreeHelp.class.getResource(s);
        if (helpURL == null) {
            System.err.println("Couldn't open help file: " + s);
        } 
        
        displayURL(helpURL);
    }
    
    private void displayURL(URL url) {
        try {
            if (url != null) {
                htmlPane.setPage(url);
            } else { //null url
            	htmlPane.setText("File Not Found");
            }
        } catch (IOException e) {
            System.err.println("Attempted to read a bad URL: " + url);
        }
    }
    
    private void createNodes(DefaultMutableTreeNode top){
        DefaultMutableTreeNode category = null;
        DefaultMutableTreeNode book = null;

        category = new DefaultMutableTreeNode("Glossary");
        top.add(category);

        //original Tutorial
        book = new DefaultMutableTreeNode(new BookInfo
        ("Glossary",
            "GlossaryERST.html"));
        category.add(book);

        category = new DefaultMutableTreeNode("Getting Started");
        top.add(category);
        
        book = new DefaultMutableTreeNode(new BookInfo
            ("File Formats",
            "FileFormatsERST.html"));
        category.add(book);
//
        book = new DefaultMutableTreeNode(new BookInfo
            ("Tutorial",
            "TutorialERST.html"));
        category.add(book);
        
//
        category = new DefaultMutableTreeNode("Using ATV");
        top.add(category);
        //Bloch
        book = new DefaultMutableTreeNode(new BookInfo
            ("Using ATV",
	     "UsingAtv.html"));
        category.add(book);
    }
    
    protected static void createAndShowGUI() { // Modified by Petar - "private" changed to "protected".
        if (useSystemLookAndFeel) {
            try {
                UIManager.setLookAndFeel(
                    UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                System.err.println("Couldn't use system look and feel.");
            }
        }

        //Make sure we have nice window decorations.
        JFrame.setDefaultLookAndFeelDecorated(false);//true);

        //Create and set up the window.
        JFrame frame = new JFrame("ERST GUIDE");
        
        /* Removed by Petar.
        frame.addWindowListener (
            new WindowAdapter() {
                // public void windowCloseing (WindowEvent e) { - Modified by Petar
                public void windowClosing (WindowEvent e) {
                    System.exit(0);
                }
            }
        );
        */
        
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Create and set up the content pane.
        TreeHelp newContentPane = new TreeHelp();
        newContentPane.setOpaque(true); //content panes must be opaque
        frame.setContentPane(newContentPane);

        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }
//    public static void main(String[] args){
    
    /* Removed by Petar.
    public static void execute(){
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }    
        });
    }
    */
}