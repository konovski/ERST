/**
 *
 * @author  Petar
 * 
 * The purpose is to prepare the data for running the Maximum Parsimony reconstruction.
 */
package erst;

import javax.swing.JOptionPane;

import erst.genalg.InnerData;
import erst.genalg.TreeG;


public abstract class MaxParsimony {
	
	public static void execute() {
		final int MAX_PARSIMONY  = InnerData.MAX_PARSIMONY;
		int nIterations = 0;
		double gainPenalty;
		gainPenalty = CalcParameters.getGainPenalty();

		TreeG tg = new TreeG();
		CalcParameters.setMethodUsed(MAX_PARSIMONY);
		tg.execute(gainPenalty, nIterations, MAX_PARSIMONY);
        //An attempt to set the background color directly. (Petar) 
        //dialog.getContentPane().setBackground( Color.red );

		JOptionPane.showMessageDialog(null, "Finished Maximum Parsimony Reconstruction");
				
		MainMenu.enableView();
		MainMenu.disableProbML();
		MainMenu.disableProbME();
		
	} // End of public static void execute().
	
}// End of public class MaxParsimony.
