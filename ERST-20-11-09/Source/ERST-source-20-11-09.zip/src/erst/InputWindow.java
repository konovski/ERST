/*
 * InputWindow.java
 *
 * Created on 07 June 2006, 11:13
 * Modified by Petar in 2008 - 2019 - extensive style & functionality refurbishing.
 **/

/**
 *
 * @author Petar, renata
 * 
 */

package erst;

import javax.swing.*;

import erst.genalg.InnerData;

import java.awt.*;              //for layout managers
import java.awt.event.*;        //for action and window events
import java.io.*;


public class InputWindow extends JFrame implements ActionListener {

	JTextField treePath;
	JTextField matrixPath;
	JTextField orderPath;
	JTextField gFuncPath;
	
	JButton buttonBTree;
	JButton buttonBMatrix;
	JButton buttonBOrder;
	JButton buttonBGFunc;
	JButton buttonSubmit;
	// JButton buttonExit;
	
	
	/*
    private static String currentDirectory = System.getProperty("user.dir"); // The name of the current directory.
	fileCh.setCurrentDirectory(new File (currentDirectory));
	JFileChooser chooser = new JFileChooser("C:\\Users\\Fre\\Music\\");	
	*/
    private static String currentDirectory = System.getProperty("user.dir"); // The name of the current directory.
	//public static JFileChooser fileCh = new JFileChooser();
	//fileCh.setCurrentDirectory(new File (currentDirectory));
	public static JFileChooser fileCh = new JFileChooser(new File (currentDirectory));
	public static File curDirect; // The current directory for choosing files will be stored here.
	public static File defaultFilenamesFile;
	public static String tree, matrix, order, function; // The names for the input files.
	private static String absDefaultFilenames; // The absolute path to "defaultFilenames.txt".
	// It is needed to update "defaultFilenames.txt", because the current directory might be changed.
	
	public static boolean successfulInput = false; // It will become true only when the input is successful.
	
	
	public InputWindow() {
		super("Input Files");
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	   
		if (InnerData.isJar == true) {
			// The package is run from a jar file. Proceed accordingly.
			defaultFilenamesFile = new File ("resources/defaultFilenames.txt");
		}
		else {
			// The package is run from the Eclipse IDE. Proceed accordingly.
			defaultFilenamesFile = new File ("defaultFilenames1.txt");
		}
		/*
		*/
		
		absDefaultFilenames = defaultFilenamesFile.getAbsolutePath();
		//System.out.println("absDefaultFilenames = " + absDefaultFilenames);		
		
		/* We read the default values of the file names if the file 
		 * with the names exist in the current directory.*/
		BufferedReader inputStream = null;
		//InputStream inputStream = ShowImage.class.getResourceAsStream(defaultFilenamesFile);
		try {
			inputStream = new BufferedReader(new FileReader(defaultFilenamesFile));
			
			tree = inputStream.readLine();
			matrix = inputStream.readLine();
			order = inputStream.readLine();
			function = inputStream.readLine();
		} catch (FileNotFoundException e) {
			// Nothing dangerous - this was expected. Use empty strings instead.
			System.out.println("FileNotFoundException");
			tree	= "";
			matrix  = "";
			order   = "";
			function = "";
		} catch (IOException e) {
			// The "defaultFilenames.txt" exists, but the reading fails.
			// Nothing dangerous - this was expected. Use empty strings instead.
			tree	= "";
			matrix  = "";
			order   = "";
			function = "";
			e.printStackTrace();
		}finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e1) {
					/* Very unlikely - "defaultFilenames.txt" exists and was read successfully,
					 * but can't be closed :). Maybe such situation can be performed by ejecting 
					 * the removable media which contains the file.
					 */
					e1.printStackTrace();
				}
			}
		}
		
		// The configuration of the text boxes is modified by Petar.
		treePath = new JTextField(30);
		treePath.setText(tree);
		treePath.setToolTipText("Input the full pathname of the Tree file or use Browse.");
		
		matrixPath = new JTextField(30);
		matrixPath.setText(matrix);
		matrixPath.setToolTipText("Input the full pathname of the Profile matrix file or use Browse.");

		orderPath = new JTextField(30);
		orderPath.setText(order);
		orderPath.setToolTipText("Input the full pathname of the Profile order file or use Browse.");
		
		gFuncPath = new JTextField(30);
		gFuncPath.setText(function);
		gFuncPath.setToolTipText("Input the full pathname of the Gene function file or use Browse.");
		
		JPanel textTreePane = new JPanel();
		BoxLayout treePane = new BoxLayout(textTreePane, BoxLayout.LINE_AXIS);
		textTreePane.setLayout(treePane);
		textTreePane.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder("Tree"),
																BorderFactory.createEmptyBorder(5, 5, 5, 5)));
		textTreePane.add(treePath);
		buttonBTree = new JButton("Browse");
		buttonBTree.setToolTipText("Browse for the Tree file.");
		
		// Putting buttonBTree to work.
		buttonBTree.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == buttonBTree) {
					//In response to a button click:
					int returnVal = fileCh.showOpenDialog(InputWindow.this);
					if (returnVal == JFileChooser.APPROVE_OPTION) {
						File phTree = fileCh.getSelectedFile();
						fileCh.setSelectedFile(phTree);
						curDirect = fileCh.getCurrentDirectory();
						tree = phTree.getAbsolutePath();
						treePath.setText(tree);
					}
				}
			}
		});
		textTreePane.add(treePath);
		textTreePane.add(buttonBTree);
		
		JPanel textMatrixPane = new JPanel();
		BoxLayout matrixPane = new BoxLayout(textMatrixPane, BoxLayout.X_AXIS);
		textMatrixPane.setLayout(matrixPane);
		textMatrixPane.setBorder(BorderFactory.createCompoundBorder
				(BorderFactory.createTitledBorder("Profile Matrix"),BorderFactory.createEmptyBorder(5, 5, 5, 5)));
		textMatrixPane.add(matrixPath);
		buttonBMatrix = new JButton("Browse");
		buttonBMatrix.setToolTipText("Browse for the Profile matrix file.");
		
		// putting buttonBMatrix to work
		buttonBMatrix.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == buttonBMatrix) {
					int returnVal = fileCh.showOpenDialog(InputWindow.this);
					if (returnVal == JFileChooser.APPROVE_OPTION) {
						File phMatrix = fileCh.getSelectedFile();
						fileCh.setSelectedFile(phMatrix);
						curDirect = fileCh.getCurrentDirectory();
						matrix = phMatrix.getAbsolutePath();
						matrixPath.setText(matrix);
					}
				}
			}
		});
		textMatrixPane.add(matrixPath);
		textMatrixPane.add(buttonBMatrix);
		
		JPanel textOrderPane = new JPanel();
		BoxLayout orderPane = new BoxLayout(textOrderPane, BoxLayout.X_AXIS);
		textOrderPane.setLayout(orderPane);
		textOrderPane.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder("Profile Order"),BorderFactory.createEmptyBorder(5, 5, 5, 5)));		   
		textOrderPane.add(orderPath);
		buttonBOrder = new JButton("Browse");
		buttonBOrder.setToolTipText("Browse for the Profile Order file.");
		
		// putting buttonBOrder to work
		buttonBOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == buttonBOrder) {
					int returnVal = fileCh.showOpenDialog(InputWindow.this);
					if (returnVal == JFileChooser.APPROVE_OPTION) {
						File phOrder = fileCh.getSelectedFile();
						fileCh.setSelectedFile(phOrder);
						curDirect = fileCh.getCurrentDirectory();
						order = phOrder.getAbsolutePath();
						orderPath.setText(order);
					}
				}
			}
		});
		textOrderPane.add(orderPath);
		textOrderPane.add(buttonBOrder);
		
		JPanel textgFuncPane = new JPanel();
		BoxLayout gFuncPane = new BoxLayout(textgFuncPane, BoxLayout.X_AXIS);
		textgFuncPane.setLayout(gFuncPane);
		textgFuncPane.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder("Gene Function"),BorderFactory.createEmptyBorder(5, 5, 5, 5)));		   
		textgFuncPane.add(gFuncPath);
		buttonBGFunc = new JButton("Browse");
		buttonBGFunc.setToolTipText("Browse for the Gene Function file.");
		
		// putting buttonBOrder to work
		buttonBGFunc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == buttonBGFunc) {
					int returnVal = fileCh.showOpenDialog(InputWindow.this);
					if (returnVal == JFileChooser.APPROVE_OPTION) {
						File phGFUNC = fileCh.getSelectedFile();
						fileCh.setSelectedFile(phGFUNC);
						curDirect = fileCh.getCurrentDirectory();
						function = phGFUNC.getAbsolutePath();
						gFuncPath.setText(function);
					}
				}
			}
		});
		textgFuncPane.add(gFuncPath);
		textgFuncPane.add(buttonBGFunc);
		
		JPanel textControlsPane = new JPanel();
		BoxLayout textPane = new BoxLayout(textControlsPane, BoxLayout.Y_AXIS);
		textControlsPane.setLayout(textPane);
		textControlsPane.setBorder(BorderFactory.createCompoundBorder(
									BorderFactory.createTitledBorder("Input Files"),
									BorderFactory.createEmptyBorder(15, 15, 15, 15))); 
		textControlsPane.add(textTreePane);
		textControlsPane.add(Box.createRigidArea(new Dimension(5,10)));
		textControlsPane.add(textMatrixPane);
		textControlsPane.add(Box.createRigidArea(new Dimension(5,10)));
		textControlsPane.add(textOrderPane);
		textControlsPane.add(Box.createRigidArea(new Dimension(5,10)));
		textControlsPane.add(textgFuncPane);
		textControlsPane.add(Box.createRigidArea(new Dimension(5,10)));
		
		JPanel textComboPanel = new JPanel();
		BoxLayout joinBox = new BoxLayout(textComboPanel, BoxLayout.X_AXIS);
		textComboPanel.setLayout(joinBox);
		textComboPanel.add(textControlsPane);
		
		JPanel buttonsPane = new JPanel();
		BoxLayout bottonBox = new BoxLayout(buttonsPane, BoxLayout.X_AXIS);
		buttonsPane.setLayout(bottonBox);
		
		buttonSubmit = new JButton("Submit");
		buttonSubmit.setToolTipText("Click this button to submit the filenames.");
		buttonSubmit.addActionListener(this);
		
		buttonsPane.add(Box.createRigidArea(new Dimension(10,47)));
		buttonsPane.add(buttonSubmit);
		buttonsPane.add(Box.createRigidArea(new Dimension(50,47)));
		
		JPanel contentPane = new JPanel();
		BoxLayout box = new BoxLayout(contentPane, BoxLayout.Y_AXIS);
		contentPane.setLayout(box);
		contentPane.add(Box.createRigidArea(new Dimension(10,10)));
		contentPane.add(textComboPanel);
		contentPane.add(Box.createRigidArea(new Dimension(10,10)));
		contentPane.add(buttonsPane);
		contentPane.add(Box.createRigidArea(new Dimension(10,10)));
		
		setContentPane(contentPane);
	} // End of public InputWindow().
	
	
	/**
	 * @param e is not used.
	 * This is performed with pressing the Submit button.
	 */
	public void actionPerformed(ActionEvent e) {
		
		// We retrieve the latest versions of the filenames from the text boxes.
		tree = treePath.getText();
		matrix = matrixPath.getText();
		order = orderPath.getText();
		function = gFuncPath.getText();
		
		PrintWriter outputStream = null;
		try {
			outputStream = new PrintWriter(new FileWriter(absDefaultFilenames));
			//			outputStream = new PrintWriter(new FileWriter(defaultFilenames));

			outputStream.println(tree);
			outputStream.println(matrix);
			outputStream.println(order);
			outputStream.println(function);
			} catch (IOException e1) {
				JOptionPane.showMessageDialog(null, "Something prevented to write the selected filenames.");
				e1.printStackTrace();
			} finally {
				if (outputStream !=null) {
				outputStream.close();
			}
		}
		// Check if all datafiles are provided.
		File TreeFile = new File(tree);
		if (!TreeFile.exists()) {
			JOptionPane.showMessageDialog(null, tree + " doesn't exist.");
			MainMenu.disableReconstruct();
			return;
		}
		
		File MatrixFile = new File(matrix);
		if (!MatrixFile.exists()) {
			JOptionPane.showMessageDialog(null, matrix + " doesn't exist.");
			MainMenu.disableReconstruct();
			return;
		}
		
		File OrderFile = new File(order);
		if (!OrderFile.exists()) {
			JOptionPane.showMessageDialog(null, order + " doesn't exist.");
			MainMenu.disableReconstruct();
			return;
		}
		
		File FunctionFile = new File(function);
		if (!FunctionFile.exists()) {
			JOptionPane.showMessageDialog(null, function + " doesn't exist.");
			MainMenu.disableReconstruct();
			return;
		}
		
		if (!InnerData.readDataFiles()) { //Reads the data files and creates the internal structures needed.
			// Not success with submitting the files.
			JOptionPane.showMessageDialog(null, "Problems in the input files. Fix the problems.");
			return;
		}
		
		MainMenu.enableReconstruct();
		dispose();
		
		return;
		
	} // End of public void actionPerformed(ActionEvent e).

} // End of public InputWindow()
