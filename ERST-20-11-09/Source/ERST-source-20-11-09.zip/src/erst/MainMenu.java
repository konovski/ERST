/*
 * MainMenu.java
 *
 * Created on 28 February 2006, 11:36
 ** Modified by Petar in 2008 - 2016 - extensive refurbishing.
 ** To improve the readability, the code excluded by Renata by commenting it, was deleted.
*/

/**
 *
 * @author  renata
 */

package erst;

import javax.swing.*;
/* The excluded imports were never used (Petar).
import javax.swing.event.*;
import javax.swing.JMenuBar.*;

import java.awt.*;
*/

import java.awt.event.*;

public class MainMenu extends JMenuBar {
	// The following booleans are used for choosing the title of the output window (Petar).

    // "FILE" Menu
    public JMenu menuFile = new JMenu("File");
    public JMenuItem fileInput = new JMenuItem("Input Files");
    public JMenuItem fileExit = new JMenuItem("Exit");
    
    // "Reconstruct" Menu
    public static JMenu menuReconstruct = new JMenu("Reconstruct");
    public JMenuItem commonSettings = new JMenuItem("Common Settings");
    public JMenuItem maximumParsimony = new JMenuItem("Maximum Parsimony");
    public JMenuItem maximumLikelihood = new JMenuItem("Maximum Likelihood");
    public JMenuItem minimumEntropy = new JMenuItem("Minimum Entropy");

    // "View" Menu
    public static JMenu menuView = new JMenu("View");
    public static JMenuItem viewAllHPFs = new JMenuItem("Gene Summary");
    public static JMenuItem viewChosenHPF = new JMenuItem("Choose Gene");
    public static JMenuItem viewProbMP = new JMenuItem ("Probabilities after MP");
    public static JMenuItem viewProbML = new JMenuItem ("Probabilities after ML");
    public static JMenuItem viewProbME = new JMenuItem ("Probabilities after ME");
    public static JMenuItem viewShortReport = new JMenuItem ("Short Report");
    
    // "Help" Menu
    public JMenu menuHelp = new JMenu("Help");
    public JMenuItem helpAbout = new JMenuItem("About");
    public JMenuItem helpContents = new JMenuItem("ERST Guide");
    
    // Constructor
    public MainMenu() {
    	
        // "File" menu
        // Add our "File" menu 
        add(menuFile);
        
        // Add our items to the "File" menu
        menuFile.add(fileInput);
        menuFile.addSeparator();
        menuFile.add(fileExit);
        
        // "Reconstruct" menu
        // Add our "Reconstruct" menu
        add(menuReconstruct);
        disableReconstruct(); // It will stay disabled until input data are provided.
        
        // Add our items to the "Reconstruct" menu
        menuReconstruct.add(commonSettings);
        menuReconstruct.add(maximumParsimony);
        menuReconstruct.add(maximumLikelihood);
        menuReconstruct.add(minimumEntropy);
        
        // "View" Menu
        // Add our "View" menu
        add(menuView);
        disableView();
        
        // Add our items to the "View" menu
        menuView.add(viewAllHPFs);
        menuView.addSeparator();
        menuView.add(viewChosenHPF);
        menuView.addSeparator();
        menuView.add(viewProbMP);
        menuView.addSeparator();
        menuView.add(viewProbML);
        menuView.addSeparator();
        menuView.add(viewProbME);
        menuView.addSeparator();
        menuView.add(viewShortReport); 
        
        // "Help" Menu
        // Add our "Help" menu
        add(menuHelp);
        
        // Add our items to the "Help" menu
        menuHelp.add(helpAbout);
        menuHelp.addSeparator();
        menuHelp.add(helpContents);
    } // End of public MainMenu() {

    
    // Forwards the listener to all menu items
    public void addActionListener(ActionListener listener) {
        
        // Add listener as the action listener for the "File" menu items.
        fileInput.addActionListener(listener);
        fileExit.addActionListener(listener);
        
        // Add listener as the action listener for the "Reconstruct" menu items.
        menuReconstruct.addActionListener(listener);
        commonSettings.addActionListener(listener);
        maximumParsimony.addActionListener(listener);
        maximumLikelihood.addActionListener(listener);
        minimumEntropy.addActionListener(listener);
        
        // Add listener as the action listener for the "View" menu items.
        viewAllHPFs.addActionListener(listener);
        viewAllHPFs.setToolTipText("View gains/losses distribution after the last reconstruction method.");
        viewChosenHPF.addActionListener(listener);
        viewProbMP.addActionListener(listener);
        viewProbML.addActionListener(listener);
        viewProbME.addActionListener(listener);
        viewShortReport.addActionListener(listener);
        
        // Add listener as the action listener for the "Help" menu items.
        helpContents.addActionListener(listener);
        helpAbout.addActionListener(listener);

    }
    
    
    // Disables the "Reconstruct" menu. Sets an appropriate tooltip.
   public static void disableReconstruct() {
        menuReconstruct.setEnabled(false);
        menuReconstruct.setToolTipText("Reconstruct is disabled until input files are given.");
    }
    
   // Enables the "Reconstruct" menu. Sets an appropriate tooltip.
    public static void enableReconstruct() {
        menuReconstruct.setEnabled(true);
        menuReconstruct.setToolTipText("Start reconstruction of gene histories");
    }
    
    
    // Disables the "View" menu. Sets an appropriate tooltip.
    public static void disableView() {
        menuView.setEnabled(false);
        menuView.setToolTipText("View is disabled until you run any reconstruction method.");
    }
    
    
    // Enables the "View" menu. Sets an appropriate tooltip.
    public static void enableView() {
        menuView.setEnabled(true);
        menuView.setToolTipText("View the results of reconstruction.");
    }

    
   // Disables the "Probabilities after ML" menu. Sets an appropriate tooltip.
    public static void disableProbML() {
    	viewProbML.setEnabled(false);
    	viewProbML.setToolTipText("Vewing Probabilities after ML is disabled until you run ML reconstruction method.");
    }

    
    // Enables the "Probabilities after ML" menu. Sets an appropriate tooltip.
    public static void enableProbML() {
    	viewProbML.setEnabled(true);
    	viewProbML.setToolTipText("View probabilities after ML reconstruction.");
    }
    
    
   // Disables the "Probabilities after ME" menu. Sets an appropriate tooltip.
    public static void disableProbME() {
    	viewProbME.setEnabled(false);
    	viewProbME.setToolTipText("Vewing Probabilities after ME is disabled until you run ME reconstruction method.");
    }

    
    // Enables the "Probabilities after ME" menu. Sets an appropriate tooltip.
    public static void enableProbME() {
    	viewProbME.setEnabled(true);
    	viewProbME.setToolTipText("View probabilities after ME reconstruction.");
    }
    
} // End of public class MainMenu extends JMenuBar.
