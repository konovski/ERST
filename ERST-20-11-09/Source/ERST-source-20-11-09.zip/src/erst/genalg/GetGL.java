/**
 * @author Petar
 * Created 2016
 * */
package erst.genalg;

import java.util.ArrayList;

/*
 * This class should replace and make redundant readGL and readGLatv.
 * It resembles the methods in readGL and readGLatv, using direct
 * extraction of the data from InnerData.
 * The classes readGL and readGLatv will be disabled.
 */
public class GetGL{
	static int nTraits = InnerData.nTraits;
	static NodeG[] nodes = InnerData.nodes; // An array containing all the nodes of the tree. 
	static boolean[][] nodesProfile = InnerData.nodesProfile;	// The gains and losses in the nodes.
	static String[] functionContents = InnerData.functionContents;	// A list with the function for every trait.
	static int nNodes = InnerData.nNodes;	  // The length of nodes[].
    
         
    public static ArrayList<Integer> getHPFGains(int traitIndex) {
        ArrayList<Integer> hpfGains = new ArrayList<Integer>();
        if (nodesProfile[0][traitIndex]) // Check if the root has the trait.
     		hpfGains.add((Integer)0);	 // If existent, the trait is counted as gained.
        
    	for (int nodeIndex=1; nodeIndex<nNodes; nodeIndex++) { // Proceed for all nodes, except the root.
        	int parentIndex = nodes[nodeIndex].parent.nodeIndex;
    		if (!nodesProfile[parentIndex][traitIndex] && nodesProfile[nodeIndex][traitIndex])
    			hpfGains.add((Integer)nodeIndex);
    			// The trait is not present in the parent, but is present in the node: gain!
    	}
        
        return hpfGains;
    } // End of public ArrayList<Integer> getHPFGains(int traitIndex)
    
     
    public static ArrayList<Integer> getHPFLosses(int traitIndex) {
        ArrayList<Integer> hpfLosses = new ArrayList<Integer>();
        
        // No losses in the root, so it is skipped.
    	for (int nodeIndex=1; nodeIndex<nNodes; nodeIndex++) { // Proceed for all nodes, except the root.
        	int parentIndex = nodes[nodeIndex].parent.nodeIndex;
    		if (nodesProfile[parentIndex][traitIndex] && !nodesProfile[nodeIndex][traitIndex])
    			hpfLosses.add((Integer)nodeIndex);
    			// The trait is present in the parent, but is not present in the node: loss!
    	}
        
        return hpfLosses;
    } // End of public ArrayList<Integer> getHPFLosses(int traitIndex)
    
    
    public static ArrayList<Integer> getHPFInherited(int traitIndex) {
        ArrayList<Integer> hpfInherited = new ArrayList<Integer>();
        
        // No inherited in the root, so it is skipped.
    	for (int nodeIndex=1; nodeIndex<nNodes; nodeIndex++) { // Proceed for all nodes, except the root.
        	int parentIndex = nodes[nodeIndex].parent.nodeIndex;
    		if (nodesProfile[parentIndex][traitIndex] && nodesProfile[nodeIndex][traitIndex])
    			hpfInherited.add((Integer)nodeIndex);
    			// The trait is present both in the parent, and in the node: inherited!
    	}
        
        return hpfInherited;
    } // End of public ArrayList<Integer> getHPFInherited(int traitIndex)
      
   
    public static ArrayList<String> getGains(int nodeIndex) {
        ArrayList<String> gains = new ArrayList<String>();
    	
        if (nodeIndex == 0) { // Catch the case when the node is root.
        	// All existent traits are counted as gained.
    		for (int traitIndex=0; traitIndex<nTraits; traitIndex++) {
    			if (nodesProfile[nodeIndex][traitIndex])
					gains.add(functionContents[traitIndex]);    		
        	}
    		
    		return gains;
        }
        
        // The parent node exists, i.e. the node is not root.
        int parentIndex = nodes[nodeIndex].parent.nodeIndex;
    	for (int traitIndex=0; traitIndex<nTraits; traitIndex++) {
    		if (!nodesProfile[parentIndex][traitIndex] && nodesProfile[nodeIndex][traitIndex]) 
    			gains.add(functionContents[traitIndex]);
    			// The trait is not present in the parent, but is present in the node: gain!
    	}
    	
        return gains;
    } // End of public ArrayList<String> getGains(int nodeIndex) {
    

    public static ArrayList<String> getLosses(int nodeIndex) {
        ArrayList<String> losses = new ArrayList<String>();
    	
        if (nodeIndex == 0) // Catch the case when the node is root.
    		return losses;
        	// No traits are counted as lost in the root.
        
        // The parent node exists: The node is not root.
        int parentIndex = nodes[nodeIndex].parent.nodeIndex;
    	for (int traitIndex=0; traitIndex<nTraits; traitIndex++) {
    		if (nodesProfile[parentIndex][traitIndex] && !nodesProfile[nodeIndex][traitIndex])
    			losses.add(functionContents[traitIndex]);
    			// The trait is present in the parent, but is not present in the node: loss!
    	}
    	
        return losses;
    } // End of public ArrayList<String> getLosses(int nodeIndex) {
    
}
