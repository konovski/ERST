/**
 * An implementation of the generalised algorithm, which covers 
 * Maximum Parsimony, Maximum Likelihood and Minimum Entropy approaches.
 */
package erst.genalg;

import java.io.IOException;
import java.util.Calendar;
import javax.swing.JOptionPane;

import erst.CalcParameters;
import erst.InputWindow;
import erst.tio.FormattedWriter;

/**
 * @author Petar
 *
 */
public class TreeG {
	
	static final int MAX_PARSIMONY  = InnerData.MAX_PARSIMONY;
	static final int MAX_LIKELIHOOD = InnerData.MAX_LIKELIHOOD;
	static final int MIN_ENTROPY    = InnerData.MIN_ENTROPY;
	
	static int nTraits;			// The number of traits.
	static NodeG[] nodes; 		// An array containing all the nodes of the tree. 
								// Its length is equal to 2*nLeaves-1.
	static NodeG root;			// The root of the tree. should be the same as NodeG[0].
	static int nNodes;			// The number of nodes, i.e. the length of "nodes" array.
	
	static int[] leavesIndex;	// The positions of leaves in "nodes". (No children for leaves and a non-empty name exists.)
	boolean[][] nodesProfile;	// The gains and losses in the nodes.
	private static String preamble;		// The basic initial data in the reports;
	private static String shortRep; 	// Short report information generated after every run.
	static String method; 		// Description of the method performed in the last calculation.
	private static int totGains;
	private static int totLosses;
	private static int numIterations;	// The actually performed iterations.
	private static int branchingCounter;// A counter for the alternative ways of inheritance with the same score.
	private static String altScenList;  // A list of the points for the traits where the scoring is indecisive.

	
	
	public static void error(String s) {
		JOptionPane.showMessageDialog(null, s + "\n The programme terminates.");
		
		throw new IllegalArgumentException(s);
	}
	
	
	/*
	 * The first of the auxiliary functions of the generalised algorithm.
	 * It counts for the case when the trait is absent in the node.
	 * Parameters:
	 * node: the node of which the minimisation is performed towards the leaves.
	 * nTrait: the position of the trait for which the minimisation is performed.
	 */
	private double lambda0(NodeG node, int nTrait) {
		double penalty = 0.0;
		double one, two, three, four; // That are the four cases where minimum can be reached.
		double min; 			// The reached minimum among the four opportunities.
		double max; 			// The reached maximum among the four opportunities.
		int numEqAbs = 0;

		//System.out.println("Trait: " + nTrait + ", Node number: " + node.nodeIndex);
		if (node.isLeaf) { 
			//System.out.println("Trait: " + nTrait + ", Node number: " + node.nodeIndex); // Diagnostic output.
			return penalty;	// For leaves, lambda0 == 0.
		} 
		// The node is inner one.
		if (!node.lambdasCalculated) {
			node.lambda0l = lambda0(node.left, nTrait);
			node.lambda0r = lambda0(node.right, nTrait);
			node.lambda1l = lambda1(node.left, nTrait);
			node.lambda1r = lambda1(node.right, nTrait);
			node.lambdasCalculated = true;
		}
		one   = node.lambda0l + node.lambda0r + node.left.gainWeight_ + node.right.gainWeight_;
		two   = node.lambda0l + node.lambda1r + node.left.gainWeight_ + node.right.gainWeight;
		three = node.lambda1l + node.lambda0r + node.left.gainWeight + node.right.gainWeight_;
		four  = node.lambda1l + node.lambda1r + node.left.gainWeight + node.right.gainWeight;
		
		max = Math.max(one, Math.max(two, Math.max(three, four)));
		if (node.left.isLeaf) {
			if (nodesProfile[node.left.nodeIndex][nTrait]) {
				one = max + 1.0;
				two = max + 1.0;
			} else {
				three = max + 1.0;
				four = max + 1.0;
			}
		}
		if (node.right.isLeaf) {
			if (nodesProfile[node.right.nodeIndex][nTrait]) {
				one = max + 1.0;
				three = max + 1.0;
			} else {
				two = max + 1.0;
				four = max + 1.0;
			}
		}
		
		// Considerations to find where the minimum appears.
		min = Math.min(one, Math.min(two, Math.min(three, four)));
		
		numEqAbs = 0;
		if  (min == one) {
			penalty = one;
			node.caseAbsent = 1;
			
			// Tests for alternative branches in the algorithm: 
			if (min == two)
				numEqAbs++;
			if (min == three)
				numEqAbs++;
			if (min == four)
				numEqAbs++;
		} else if (min == two) { // Here, min < one.
			penalty = two;
			node.caseAbsent = 2;
			if ((min == three) || (min == four)) { 
				// Tests for alternative branches in the algorithm: 
				if (min == three)
					numEqAbs++;
				if (min == four)
					numEqAbs++;
			}
		} else if (min == three) { // Here, min < one and min < two.
			penalty = three;
			node.caseAbsent = 3;
			if (min == four) { 
				// Tests for alternative branches in the algorithm: 
				if (min == four)
					numEqAbs++;
			}
		} else  {// min == four and min < one and min < two and min < three.
			penalty = four;
			node.caseAbsent = 4;
		}
		node.numEqAbsent = numEqAbs;
		
		return penalty;
	} //End of private double lambda0 (NodeG node, int nTrait).
	
	
	/*
	 * The second of the auxiliary functions of the generalised algorithm.
	 * It counts for the case when the trait is present in the node.
	 * Parameters:
	 * node: the node of which the minimisation is performed towards the leaves.
	 * nTrait: the position of the trait for which the minimisation is performed.
	 */
	private double lambda1(NodeG node, int nTrait) {
		double penalty = 0.0;
		double one, two, three, four; // That are the four cases where minimum can be reached.
		double min; 				  // The reached minimum among the four opportunities.
		double max; 				  // The reached maximum among the four opportunities.
		int numEqPres = 0;

		if (node.isLeaf) {
			return penalty;	// For leaves, lambda1 == 0.
		} 
		// The node is inner one.
		if (!node.lambdasCalculated) {
			node.lambda0l = lambda0(node.left, nTrait);
			node.lambda0r = lambda0(node.right, nTrait);
			node.lambda1l = lambda1(node.left, nTrait);
			node.lambda1r = lambda1(node.right, nTrait);
			node.lambdasCalculated = true;
		}

		one   = node.lambda0l + node.lambda0r + node.left.lossWeight + node.right.lossWeight;
		two   = node.lambda0l + node.lambda1r + node.left.lossWeight + node.right.lossWeight_;
		three = node.lambda1l + node.lambda0r + node.left.lossWeight_ + node.right.lossWeight;
		four  = node.lambda1l + node.lambda1r + node.left.lossWeight_ + node.right.lossWeight_;
		
		// We try to eliminate assigning wrong cases for the leaves,
		// because the traits are defined there already.
		// Increase the wrong estimates where leaves appear in order not to
		// be able to qualify for the minimum.
		max = Math.max(one, Math.max(two, Math.max(three, four)));
		if (node.left.isLeaf) {
			if (nodesProfile[node.left.nodeIndex][nTrait]) {
				one = max + 1.0;
				two = max + 1.0;
			} else {
				three = max + 1.0;
				four = max + 1.0;
			}
		}
		if (node.right.isLeaf) {
			if (nodesProfile[node.right.nodeIndex][nTrait]) {
				one = max + 1.0;
				three = max + 1.0;
			} else {
				two = max + 1.0;
				four = max + 1.0;
			}
		}
		
		// Considerations to find where the minimum appears.
		min = Math.min(one, Math.min(two, Math.min(three, four)));
		numEqPres = 0;
		if  (min == one) {
			penalty = one;
			node.casePresent = 1;
			// Tests for alternative branches in the algorithm: 
			if (min == two)
				numEqPres++;
			if (min == three)
				numEqPres++;
			if (min == four)
				numEqPres++;
		} else if (min == two) { // Here, min < one.
			penalty = two;
			node.casePresent = 2;
			// Tests for alternative branches in the algorithm: 
			if (min == three)
				numEqPres++;
			if (min == four)
				numEqPres++;
		} else if (min == three) { // Here, min < one and min < two.
			penalty = three;
			node.casePresent = 3;
			// Tests for alternative branches in the algorithm: 
			if (min == four)
				numEqPres++;
		} else  {// min == four and min < one and min < two and min < three.
			penalty = four;
			node.casePresent = 4;
		}
		node.numEqPresent = numEqPres;
		
		return penalty;
	} //End of private double lambda1 (NodeG node, int nTrait).
	
	
	/*
	 * Part of the reverse pass of the algorithm:
	 * Set gain and loss events in the node and initiate 
	 * the same in its descendants. 
	 */
	private void setEvents(NodeG node, int nTrait, boolean event) {
		
		if (node.isLeaf) // Skip the leaves: The events there are set a priori.
			return;
		
		nodesProfile[node.nodeIndex][nTrait] = event;
		if (event) { // Proceed the variant defined by presence of the trait.
			
			// Some diagnostic printing:
			//if (node.numEqPresent > 0)
			//	System.out.println("numEqPresent = " + node.numEqPresent);

			switch (node.casePresent) {
			case 1:
				setEvents(node.left, nTrait, false);
				setEvents(node.right, nTrait, false);
				break;
			case 2:
				setEvents(node.left, nTrait, false);
				setEvents(node.right, nTrait, true);
				break;
			case 3:
				setEvents(node.left, nTrait, true);
				setEvents(node.right, nTrait, false);
				break;
			case 4:
				setEvents(node.left, nTrait, true);
				setEvents(node.right, nTrait, true);
			}
		} else { // Proceed the variant defined by absence of the trait.
			
			// Some diagnostic printing:
			//if (node.numEqAbsent > 0)
			//	System.out.println("numEqAbsent = " + node.numEqAbsent);
			
			switch (node.caseAbsent) {
			case 1:
				setEvents(node.left, nTrait, false);
				setEvents(node.right, nTrait, false);
				break;
			case 2:
				setEvents(node.left, nTrait, false);
				setEvents(node.right, nTrait, true);
				break;
			case 3:
				setEvents(node.left, nTrait, true);
				setEvents(node.right, nTrait, false);
				break;
			case 4:
				setEvents(node.left, nTrait, true);
				setEvents(node.right, nTrait, true);
			}
		}
		
		return;
	} //End of private void setEvents (NodeG node, int nTrait, char event).

	
	/*
	 * listAltScen(int nTrait) prepares the list of the alternative scenario points
	 * for the trait nTrait and adds it to the common list altScenList.
	 * It should be run while the node fields numEqPresent and numEqAbsent are actual.
	 * This is the case after the minimisation for the trait is performed. 
	 */
	private void listAltScen(int nTrait) {
	
		boolean toBeListed = false;
		String traitList = "\n Alternative scenarios for " + InnerData.functionContents[nTrait] + ": \n   ";
		
		for (int i=0; i<nNodes; i++) { 
			NodeG node = nodes[i]; 
			if (node.isLeaf) // No alternative scenarios for the leaves.
				continue;
				
			if (node.numEqPresent > 0) {
			
				// Some diagnostic printing:
				//if (node.numEqPresent > 1)
				//	System.out.println("Present: " + Integer.toString(node.numEqPresent));
									
				if 	(toBeListed) 
					traitList += ", ";

				traitList += Integer.toString(i);
				toBeListed = true;
			}

			if (node.numEqAbsent > 0) {
				
				// Some diagnostic printing:
				//if (node.numEqAbsent > 1)
				//	System.out.println("Absent: " + Integer.toString(node.numEqAbsent));
				
				if 	(toBeListed) 
					traitList += ", ";

				traitList += Integer.toString(i);
				toBeListed = true;
			}
			
			branchingCounter += node.numEqPresent + node.numEqAbsent;
		}
		
		if (toBeListed)
			altScenList += traitList; 
		
	return;		
	} // End of private void listAltScen(int nTrait).

	/*
	*/
	
	
	/*
	 * The weight coefficients are distributed already over the nodes of the tree
	 * and now we should make the pass of the generalised algorithm.
	 * "minimise" calculates the penalties for "root" in the alternative scenarios
	 * when the trait is present in root or is not present.
	 */
	private double minimise() {
		double penalty = 0.0;
		double l0; // to keep the cumulative penalty value when the trait is absent
		double l1; // to keep the penalty cumulative value when the trait is present

		branchingCounter = 0;	// To count the cases when alternative scenarios with equal 
								// scores arise.
		altScenList = "";		// Start with a blank list for the bifurcations.
		for (int nTrait=0; nTrait<nTraits; nTrait++) { // Do the minimisation algorithm.
			for (int i=0; i<nNodes; i++) { // Initialise the calculation flags.
				if (!nodes[i].isLeaf)
					nodes[i].lambdasCalculated = false;
			}
			l0 = lambda0 (root, nTrait);
			l1 = lambda1 (root, nTrait);
			 
			if (l0 <= (l1 + root.gainWeight)) { // The trait is absent in root.
				penalty = penalty + l0;
				setEvents (root, nTrait, false);
				
				// Check for alternative scenarios.
				//if (l0 == (l1 + root.gainWeight)) // Ambiguity in the root if the given trait should appear.
				//	branchingCounter++;
			} else {	// The trait is present in root.
				penalty = penalty + l1 + root.gainWeight;
				setEvents (root, nTrait, true);
			}
		listAltScen(nTrait);
		}
		
		return penalty;
	} // End of private double minimise().

	
	/*
	 * Count gains and losses in the nodes.
	 * Count total gains and total losses over the tree.
	 */
	private void countGainsLosses() {
		totGains = 0;
		totLosses = 0;
		
		// Proceed with the root (it happens to be nodes[0]): Gains only.
		// The root does not have a parent node, so the common approach is not applicable.
		int countGained = 0;
		for (int j=0; j<nTraits; j++) {
			if (nodesProfile[0][j])
				countGained++;
		}
		root.gained = countGained;
		totGains += countGained;		
		// Proceed with the non-root nodes.
		for (int i=1; i<nNodes; i++) {
			countGained = 0;
			int countLost = 0;
			int countInherited = 0;
			int countNotInherited = 0;
			NodeG node = nodes[i];
			int numNode = node.nodeIndex;
			int numParent = node.parent.nodeIndex;
			for (int j=0; j<nTraits; j++) {
				if (nodesProfile[numParent][j]) { // The trait is present in the parent.
					if (nodesProfile[numNode][j]) // The trait is present in the node.
						countInherited++;
					else // The trait is absent in the node.
						countLost++;
				} else { // The trait is absent in the parent.
					if (nodesProfile[numNode][j]) // The trait is present in the node.
						countGained++;
					else // The trait is absent in the node.
						countNotInherited++;
				}
			}
			node.gained = countGained;
			totGains += countGained;		
			node.lost = countLost;
			totLosses += countLost;		
			node.inherited = countInherited;
			node.notInherited = countNotInherited; // Maybe not needed at all.
		} // End of for (int i=1; i<nNodes; i++) 
		
		return;
	} // End of private void countGainsLosses().
	
	
	/*
	 * Calculate probabilities for gains and losses over the tree 
	 * based on the counted gains and losses in the nodes.
	 * Experimental: Do not set zero probabilities.
	 */
	/*
	private void calcProb() {
		for (int i=0; i<nNodes; i++) {
			// Experimental: Do not set zero probability, simply set a miniscule value.
			// Gain probability.
		 	NodeG node = nodes[i];
		 	double prob;
		 	prob = (double)node.gained/(double)nTraits;
		 	if (prob == 0.0) 
		 		node.nodeGainProb = 1.0/(2.0*(double)nTraits);
		 	else
		 		node.nodeGainProb = prob;
		 	
			// Loss probability.
		 	prob = (double)node.lost/(double)nTraits;
		 	if (prob == 0.0) 
		 		node.nodeLossProb = 1.0/(2.0*(double)nTraits);
		 	else
		 		node.nodeLossProb = prob;
		}
	} // End of private void calcProb().
	*/


	/*
	 * This alternative of calcProb is to provide conformity with MALS algorithm.
	 * Because some of the probabilities will be 0., corresponding changes in 
	 * weights calculations will be needed.
	 */
	private void calcProbMALS () {
		double gained;			// Casting as double of the corresponding value from NodeG.
		double lost;			// Casting as double of the corresponding value from NodeG.
		double inherited;		// Casting as double of the corresponding value from NodeG.
		double notInherited;	// Casting as double of the corresponding value from NodeG.
		double nodeGainProb; // The probability for gain: gained/(Total which should be gained).
		double nodeLossProb; // The probability for loss: lost/(Total which should be lost).
		
		// Special treatment for the root:
		nodes[0].nodeGainProb = (double)nodes[0].gained/(double)nTraits;
		nodes[0].nodeLossProb = 0.;
		
		for (int i=1; i<nNodes; i++) {
			gained = (double)nodes[i].gained;
			lost = (double)nodes[i].lost;
			inherited = (double)nodes[i].inherited;
			notInherited = (double)nodes[i].notInherited;
			
        	if (gained == 0.)
        		nodeGainProb = 0.;
        	else
        		nodeGainProb = gained/(notInherited + gained); // Divided to all absent in the parent.

        	if (lost == 0.)
        		nodeLossProb = 0.;
        	else
        		nodeLossProb = lost/(inherited + lost); // Divided to all present in the parent.
        		
        nodes[i].nodeGainProb = nodeGainProb;	
        nodes[i].nodeLossProb = nodeLossProb;	
        }
    } // End of private void calcProbMALS ()

	
	/*
	 * Sets the weight coefficients for Maximum Parsimony algorithm.
	 */
	private void setMPweights(double gainPenalty) {
		for (int i=0; i<nNodes; i++) {
			NodeG node = nodes[i];
			node.gainWeight = gainPenalty;
			node.lossWeight = 1;
			node.gainWeight_ = 0;
			node.lossWeight_ = 0;
		}  // End of for (int i=0; i<nNodes; i++)
	} // End of private void setMPweights(double gainPenalty)

	
	/*
	 * Sets the weight coefficients for Maximum Likelihood algorithm.
	 */
	private void setMLweights() {
		double minProb = 1.0/(2.0*(double)nTraits);
		for (int i=0; i<nNodes; i++) {
			double nodeGainProb = nodes[i].nodeGainProb;
			double nodeLossProb = nodes[i].nodeLossProb;
			double gainWeight;
			double lossWeight;
			double gainWeight_;
			double lossWeight_;
			
			if (nodeGainProb == 0.)
				gainWeight = -Math.log(minProb);
			else 
				gainWeight = -Math.log(nodeGainProb);
				
			if (nodeLossProb == 0.)
				lossWeight =  -Math.log(minProb);
			else 
				lossWeight = -Math.log(nodeLossProb);
			
			if (nodeGainProb == 1.)
				gainWeight_ =  -Math.log(minProb);
			else 
				gainWeight_ = -Math.log(1.0 - nodeGainProb);
				
			if (nodeLossProb == 1.)
				lossWeight_ =  -Math.log(minProb);
			else 
				lossWeight_ = -Math.log(1.0 - nodeLossProb);
			/*
			*/
			
			nodes[i].gainWeight = gainWeight;
			nodes[i].lossWeight = lossWeight;
			nodes[i].gainWeight_ = gainWeight_;
			nodes[i].lossWeight_ = lossWeight_;
			
		}  // End of for (int i=0; i<nNodes; i++)
		
		return;
	} // End of private void setMLweights()


	/**
	 * Sets the weight coefficients for Minimum Entropy algorithm.
	 */
	private void setMEweights() {
		for (int i=0; i<nNodes; i++) {
			double nodeGainProb = nodes[i].nodeGainProb;
			double nodeLossProb = nodes[i].nodeLossProb;
			double gainWeight;
			double lossWeight;
			double gainWeight_;
			double lossWeight_;
			
			if (nodeGainProb == 0.)
				gainWeight = 0.;
			else 
				gainWeight = -nodeGainProb*Math.log(nodeGainProb);
				
			if (nodeLossProb == 0.)
				lossWeight = 0.;
			else 
				lossWeight = -nodeLossProb*Math.log(nodeLossProb);
			
			// No need to check if the arguments are 0.: Not possible in the algorithm.
			gainWeight_ = -(1.0 - nodeGainProb)*Math.log(1.0 - nodeGainProb);
			lossWeight_ = -(1.0 - nodeLossProb)*Math.log(1.0 - nodeLossProb);
			
			nodes[i].gainWeight = gainWeight;
			nodes[i].lossWeight = lossWeight;
			nodes[i].gainWeight_ = gainWeight_;
			nodes[i].lossWeight_ = lossWeight_;
		}  // End of for (int i=0; i<nNodes; i++)
		
		return;
	} // End of private void setMEweights()


	private boolean compareProfiles() {
		for (int i=0; i<nNodes; i++) {
			for (int j=0; j<nTraits; j++) {
				if (nodesProfile[i][j] != InnerData.nodesProfile[i][j]) {
					return false;
				}
			}
		}
		return true;
	} // End of private boolean compareProfiles()

	
	/**
	 * Counts the genes with horizontal transfers in the last reconstruction.
	 * The result is displayed in the short report.
	 */
	private int count_genHGT() {
		
		int genHGT = 0;

		for (int j=0; j<nTraits; j++) { // Loop over the traits (genes).
			boolean gained = false; // Detects if a given gene is gained.
			for (int i=1; i<nNodes; i++) { // Loop over the nodes (genomes), excluding the root.
				int parentIndex = nodes[i].parent.nodeIndex;
				if (nodesProfile[i][j] && !nodesProfile[parentIndex][j]) { // The gene is gained in the node.
					if (!gained)
						gained = true;
					else {// The gene is gained more than once.
						genHGT++;
						break; // That is inserted to count HGT only once for a gene.
					}
				}
			}
		}
		
	return genHGT;
	} // End of int count_genHGT()

	/**
	 * 
	 * Counts the number of all horizontal transfers in the last reconstruction.
	 * The result is displayed in the short report.
	 */
 	private int count_numHGT() {
		
		int numHGT = 0;

		for (int j=0; j<nTraits; j++) { // Loop over the traits (genes).
			boolean gained = false; // Detects if a given gene is gained.
			for (int i=1; i<nNodes; i++) { // Loop over the nodes (genomes), excluding the root.
				int parentIndex = nodes[i].parent.nodeIndex;
				if (nodesProfile[i][j] && !nodesProfile[parentIndex][j]) { // The gene is gained in the node.
					if (!gained)
						gained = true;
					else {// The gene is gained more than once. Count all these cases.
						numHGT++;
					}
				}
			}
		}
		
	return numHGT;
	} // End of int count_numHGT()
	/* 
	*/
	
	
	
	/**
	makePreamble - Prepares a string describing the context of the reconstruction.
	double 	gainPenalty - The Gain Penalty used at the beginning of the Maximum Likelihood reconstruction.
	int 	version 	- The method applied for the reconstruction: 
								MAX_PARSIMONY, MAX_LIKELIHOOD or MIN_ENTROPY.
	*/	  
	private String makePreamble (double gainPenalty, int version) {
	
		String output = "";
		String method = "";
		switch (version) {
			case MAX_PARSIMONY:
				method = "Maximum Parsimony";
				break;
			case MAX_LIKELIHOOD:
				method = "Maximum Likelihood";
				break;
			case MIN_ENTROPY: 
				method = "Minimum Entropy";
		}
		Calendar now = Calendar.getInstance();
		int hour = now.get(Calendar.HOUR_OF_DAY);
		int minute = now.get(Calendar.MINUTE);
		int month = now.get(Calendar.MONTH) + 1;
		int day = now.get(Calendar.DAY_OF_MONTH);
		int year = now.get(Calendar.YEAR);
		output = "Date: " + day + "." + month + "." + year + " Time: " + hour + ":" + minute + "\n";						
		output += "Tree: " + InputWindow.tree + "\n";
		output += "Profile Matrix: " + InputWindow.matrix + "\n";
		output += "Profile order: " + InputWindow.order + "\n";
		output += "Gene function: " + InputWindow.function + "\n";
		output += "Gain penalty: " + CalcParameters.getGainPenalty_txt() + "\n";
		output += "Method: " + method + "\n";
		
		return output;
	} //End of private String makePreamble (double gainPenalty, int version)
	
	
	/**
	outputHGT - Finds the cases of Horizontal Gene Transfer over the tree and makes output
	of the cases found in a dedicated file.
	*/	  
	private void outputHGT() {
		
		// Open the file for HGT output
		FormattedWriter outTXT = null;

		try {
			outTXT = new FormattedWriter(CalcParameters.getHGTransferFile_TXT());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Output of the initial data, just as in the Short report.
		outTXT.printfln(preamble);

		for (int j=0; j<nTraits; j++) { // Loop over the traits (genes).
			boolean gained = false; // Detects the first time when given gene is gained. 
			boolean hgt = false; // Detects the first time when given gene is gained. 
			String nodesList = "";
			for (int i=1; i<nNodes; i++) { // Loop over the nodes (genomes), excluding the root.
				int parentIndex = nodes[i].parent.nodeIndex;
				if (nodesProfile[i][j] && !nodesProfile[parentIndex][j]) { // The gene is gained in the node.
					if (!gained) {
						gained = true;
						// Start a list of nodes where the gene is gained. 	
						nodesList = Integer.toString(i);
					}	
					else {		// The gene is gained more than once.
						hgt = true;
						// Amend the list nodes where the gene is gained.
						nodesList += ", " + Integer.toString(i);
					}	
				}
			}
			
			if (hgt) {
				// Output the name of the gene.
				outTXT.printfln("Horizontal Gene Transfer for " + InnerData.functionContents[j]);
				// Output the list of nodes where the gene is gained multiple times.
				outTXT.printfln("Nodes " + nodesList + "\n");
			
			} 
		}
		
		outTXT.close(); // Close the HGT file.
		 
		return;
	} // End of int outputHGT()
 
	/**
	outputAltScen - Writes in a dedicated file the list of points where alternative scenarios 
	with the same total score sum can be chosen.
	*/	  
	private void outputAltScen() {
		FormattedWriter outTXT = null;
		String altScenFile = CalcParameters.getAltScenFile_TXT();

 		// Open the file for HGT output
		try {
			//String 
			//outTXT = new FormattedWriter(CalcParameters.getAltScenFile_TXT());
			outTXT = new FormattedWriter(altScenFile);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Output of the initial data, just as in the Short report.
		outTXT.printfln(preamble);
		
		outTXT.printfln("Points with potential alternative scenarios: " + branchingCounter + "\n");

		
		//Output the list itself.		
		outTXT.printfln(altScenList);
		
		outTXT.close(); // Close the HGT file.
		 
		return;
	} // End of int outputAltScen().
	/* 
	*/

	
	
	
	/**
	 * Short report output.
	 * Parameters:
	 * version:		The type of the optimisation algorithm.
	 * 				The values are MAX_PARSIMONY, MAX_LIKELIHOOD and MIN_ENTROPY
	 */
	private void shortReport (double gainPenalty, int version) {
		
		shortRep = preamble;
		
		
		int genHGT = count_genHGT();
		shortRep += "Genes with horizontal transfers: " + genHGT + "\n";
		
		int numHGT = count_numHGT();
		shortRep += "Total number of horizontal transfers: " + numHGT + "\n";

		if (version != MAX_PARSIMONY)
			shortRep += "Performed iterations: " + numIterations + "\n";
		else
			shortRep += "Score (gains*penalty + losses): " + (totGains*gainPenalty + totLosses) + "\n";

		shortRep += "Alternative scenario points: " + branchingCounter + "\n";
		//TODO: Average probability, Overall probability. (Are they needed?)
		
		FormattedWriter outTXT = null;
		try {
			outTXT = new FormattedWriter(CalcParameters.getShortReport_TXT());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		outTXT.printfln(shortRep);
		outTXT.close();
		InnerData.shortReport = shortRep;
		
		return;
	} // End of private void shortReport (int version)

	
	/**
	 * Parameters:
	 * gainPenalty: The chosen gain penalty coefficient (>1). 
	 * 				Used in the Maximum parsimony phase only.
	 * nIterations:	The maximum number of iterations for the Minimum Surprisal
	 * 				and Minimum Entropy approaches.
	 * 				It is not used in the Maximum Parsimony part.
	 * version:		The type of the optimisation algorithm.
	 * 				The values are MAX_PARSIMONY, MAX_LIKELIHOOD and MIN_ENTROPY
	 */
	public void execute(double gainPenalty, int nIterations, int version) {
		
		FormattedWriter outATV = null;
		try {
			//System.out.println("FormattedWriter for ATV is created: " + CalcParameters.outputFile_ATV); 
			outATV = new FormattedWriter(CalcParameters.outputFile_ATV);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//System.out.println("FormattedWriter for ATV creation failure: " ); 
			e.printStackTrace();
		} 	// For an output of a tree structure with sums of gains and losses for every node.
		

		nTraits = InnerData.nTraits;
		nodes = InnerData.nodes;
		root = InnerData.root;
		nNodes = InnerData.nNodes;
		nodesProfile = InnerData.cloneArray(InnerData.nodesProfile);

		/* PHASE 1 - Maximum Parsimony.
		 * It will be passed on every run of "execute", and after that we should proceed further 
		 * or we will stop the execution and output the results.
		 */
		
		setMPweights(gainPenalty); // Set the weights for the Maximum Parsimony over the nodes.
		minimise();
		
		countGainsLosses();
		InnerData.nodesProfile = InnerData.cloneArray(nodesProfile);
		// Initial probabilities can be calculated already.
		//calcProb(); // Calculate the probabilities based on the achieved gains and losses.
		calcProbMALS(); // Calculate the probabilities based on the achieved gains and losses using MALS approach.
		FormattedWriter outIPROB = null;
		try {
			outIPROB = new FormattedWriter(CalcParameters.outputFile_IPROB);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 	// For an output of a tree structure with initial probabilities of gains and losses for every node.
		outIPROB.printfln(root.probtoString());
		outIPROB.close();
		
		if (version == MAX_PARSIMONY) { 
			// Output what is needed after Maximum Parsimony calculations only.
			outATV.printfln(root.gltoString());
			outATV.close();
			preamble = makePreamble(gainPenalty, MAX_PARSIMONY);
			shortReport(gainPenalty, MAX_PARSIMONY);
			outputHGT();
			outputAltScen();
			return;
		}
		
		/* PHASE 2 - Maximum Likelihood or Minimum Entropy.
		 * It is based on the results achieved by the Maximum Parsimony pass.
		 */
		numIterations = nIterations;
		int iCounter = 0;
		while (iCounter++<nIterations) { //A cycle for iterations for ML and ME.
			InnerData.nodesProfile = InnerData.cloneArray(nodesProfile);
			switch (version) {
			case MAX_LIKELIHOOD:
				setMLweights();
				break;
			case MIN_ENTROPY: 
				setMEweights();
			}
			minimise(); // A pass of the minimisation for the higher level approaches.
			if (compareProfiles()) {
				numIterations = iCounter - 1;
				break;  // We have reached a stall point: There is no any difference from 
						// the previous run.
			}
			countGainsLosses();
			//calcProb(); // Calculate the probabilities based on the achieved gains and losses.
			calcProbMALS(); // Calculate the probabilities based on the achieved gains and losses.
		}
		if (numIterations == nIterations)
			InnerData.nodesProfile = InnerData.cloneArray(nodesProfile);
		
		// Output of gains and losses from the higher level algorithms: ML and ME.
		outATV.printfln(root.gltoString());
		outATV.close();
		
		// Output for the ML and ME results: Final probabilities.
		FormattedWriter outFPROB = null;
		try {
			outFPROB = new FormattedWriter(CalcParameters.outputFile_FPROB);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 	// For an output of a tree structure with initial probabilities of gains and losses for every node.
		outFPROB.printfln(root.probtoString());
		outFPROB.close();
		preamble = makePreamble(gainPenalty, version);
		shortReport(gainPenalty, version);
		outputHGT();
		outputAltScen();

		return;
	} //End of public void execute(double gainPenalty, int nIterations, int version)

} //End of public class TreeG.
