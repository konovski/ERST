/*
 * InnerData.java
 * Created  in  2016.
 * 
 * Reads the files specified in InputWindow and builds the data structures 
 * needed for further computations.
*/

/**
 * Reads the files specified in InputWindow and builds the data structures 
 * needed for further computations.
 * @author Petar
 * 
 */

package erst.genalg;

import java.awt.Font;
import java.io.*;
import javax.swing.JOptionPane;

import erst.InputWindow;
import erst.tio.*;


public class InnerData {
	static int functionLines; 			// Must be the same as the number of the rows in the matrix.
	public static String[] functionContents;	// A list with the name (function) for every trait.
	static String treeContents; // The contents of the file with the tree.
	static int pos; 			// A pointer for parsing treeContents.
	public static final int MAX_PARSIMONY  = 0;
	public static final int MAX_LIKELIHOOD = 1;
	public static final int MIN_ENTROPY    = 2;
	public static int chosenHPF = -1;		// The index of the trait chosen for display. the value < 0 means that nothing is chosen.
	public static boolean GainsLossesSelected = true;
	public static boolean isJAR = false; // 'true' if the package is started from JAR file.
	public static String shortReport;	// The contents of the short report generated at every run.
	
	static int nCurrentNode;	// The number of the first free place in "nodes".
								// It is used during the tree building, while parsing treeContents.
	static int nLeaves;			// The number of the leaves according to treeContents. 
								// It is assumed to be equal to the number of the substrings separated by commas.
								// It should be the same as in the matrix description.
								// Separated by commas. It should be equal to the number of the leaf names
								// (alphanumeric substrings plus '-') in "treeContents".
	static int nTraits;			// The number of traits.
	static NodeG[] nodes; 		// An array containing all the nodes of the tree. 
								// Its size is equal to 2*nLeaves-1.
	static NodeG root;			// The root of the tree. should be the same as nodes[0].
	static int nNodes;			// The number of nodes.
	
	static int[] leavesIndex;	// The positions of leaves in "nodes". (No children for leaves and a non-empty name exists.)
	static int[] orderIndex;	// Mapping of the columns of the matrix to the leaves. The position is the number of the
								// column in the matrix. The contents is the position of the corresponding leaf in nodes[].
	static int currentLeafNum;	// A pointer for processing "leavesIndex".
	static boolean[][] nodesProfile;	// The gains and losses in the nodes. At the end, it contains the 
										// gains and losses after the iterations have been passed. 
	static boolean[][] itNodesProfile;	// The gains and losses after some iterations (ML or ME) has been passed.  
										// It will serve the "previous probabilities" (i.e., before iterations) output. 
	static boolean[][] prevNodesProfile;	// The gains and losses in the nodes at the previous iteration.
											// It helps to detect if the iteration has changed anything. 
	public static boolean isJar;

	
	public static void error(String s) {
		JOptionPane.showMessageDialog(null, s);
		
		throw new IllegalArgumentException(s);
	}
	
	/*
	Provides a string, which contains symbol, shifted to a given number
	of spaces from the beginning. 
	The function is used in the function errorPoint for visualising a pointer 
	to a given position of a string.
	*/
	private static String shifting(int position, char ch) {
		String output = "";
		for (int i=0; i<position; i++)
			//output += " ";
		output += "_";
		output += ch;
		
		return output;
	}
	
	/*
	Example: ("Comma is missing here:", 4, "four five, six")
	*/
	private static void errorPoint(String s, int position, String excerpt) {
		String message;
		Font fnt;
		JOptionPane pane = new JOptionPane();
		message = s + "\n" + shifting(position, 'V') + "\n" + excerpt;
		fnt = new Font("monospaced", Font.PLAIN, 14); // "monospaced" did not work previously. (Petar)
		//fnt = new Font("Courier New", Font.PLAIN, 14);
        //pane.setFont(new Font("monospaced", Font.PLAIN, 14));
        pane.setFont(fnt);
        //fnt = pane.getFont();
        JOptionPane.showMessageDialog(null, message);
        //fnt = pane.getFont();
        //JOptionPane.showMessageDialog(null, message);
		/*
		*/
		
		throw new IllegalArgumentException(s);
	}
	
	private static boolean readFunction() throws IOException {
		String function = InputWindow.function; // That is the file with the function descriptions.
		functionLines = CountLines.countMeaningfulLines(function);
		functionContents = new String[functionLines]; 
        ReadInput functionRead = new ReadInput(function);
        
        for (int ct=0; ct < functionLines; ct++) {
        	// Every line of the file must contain exactly two words 
        	// separated by white space. We check if that is the situation.
        	 
            String line = functionRead.readMeaningfulLine();
            String words[] = line.split("[\\s]+");
            if (words.length != 2) {
            	//TODO: Notification of the user about the odd case.
            	return false;
            }
            // TODO: Keep the enumerated list of function names for display in the list choice.
            functionContents[ct] = words[1];
        }
        
       	return true;
	} // End of private boolean readFunction() throws IOException
	
	
	/**
	 * In a given string, finds the first occurrence of a character which is not white space.
	 * If there is no such, returns -1.
	 * */
	public static int findNonWhitespace(String sequence) {
		int index;
		int end = sequence.length();
		for (index=0; index < end; index++) {
			if (!Character.isWhitespace(sequence.charAt(index)))
				break;
		}

		// Check if something is found or the cycle simply finished without finding.
		if (Character.isWhitespace(sequence.charAt(index)))
			return -1;
	
		return index;
	}

	
	/*
	 * Count symbols of given type in a given sequence.
	 */
	public static int countChar(char ch, String sequence) {
		int count = 0;
		int length = sequence.length();
		for (int place = 0; place < length; place++) {
			if (ch == sequence.charAt(place)) 
				count++;
		}
		return count;
	}
	/*
	*/

	
	/**
	An auxiliary function for building the tree structure.
	The argument is expected to start with an opening bracket.
	If we find the corresponding closing bracket, an element has been localised.
	If there is no closing bracket, the function returns -1 as an error code.
	*/
	public static int findClosingBracket(String contents) {
		int countBrackets = 0;
		int length = contents.length();
		int place;
		for (place = 0; place < length; place++) {
			char ch = contents.charAt(place);
			if (ch == '(')
				countBrackets++;
			else if (ch == ')')
				countBrackets--;
			if (countBrackets == 0)
				return place;
		}
		
		return -1;	
	}
	/*
	*/
	
	/**
	 * Verifies the leaf name.
	 * "nameField" should contain a single leaf name, plus eventually
	 * some trailing whitespaces.
	 * All characters of the leaf name should be letters, digits, 
	 * whitespaces or'-'. The name must begin with a letter.
	 * The function issues error if the name does not conform the rules.
	 * 
	 */
	//private static String readName() {
	private static String checkName(String nameField) {
		String name = nameField;
		name.trim(); //Get rid of the trailing whitespaces.
		int length = name.length();
		if (length < 1) {
			error("Position " + pos + ": Empty leaf name.");
			return null;
		}
		
		if (!Character.isLetter(nameField.charAt(0))) {
			errorPoint("Invalid leaf name: Should begin with a letter.", 0, nameField);
			//errorPoint("Invalid leaf name: Should begin with a letter.", 5, nameField);
			return null;
		}
		/*
		*/

		// We repeat the check for i=0 in order to simplify the code.
		for (int i = 0; i < length; i++) {
			char ch = name.charAt(i);
			if (!Character.isLetterOrDigit(ch) && !Character.isWhitespace(ch) && (ch != '-')) {
				error("Invalid leaf name: Wrong symbol in position " + (pos+i) + " .");
				return null;
			}
		}		
		/*
		int beginpos = pos; 
		if (!Character.isLetter(treeContents.charAt(pos++))) 
			error("Not a leaf name: Should begin with a letter.");
		while(Character.isLetterOrDigit(treeContents.charAt(pos)) ||
			  Character.isWhitespace(treeContents.charAt(pos)) ||
	 									(treeContents.charAt(pos) == '-')
				)
			pos++;
		return treeContents.substring(beginpos, pos);
		*/
		pos += nameField.length(); // Put the pointer at the position after the name.
		return name;
	} // End of private static String checkName(String nameField)

	
	/**
	 * The programme goes through the tree description and builds the corresponding structure of
	 * NodeG nodes. It makes parsing from root to the leaves, and recursively builds the nodes.
	 * It uses the tree description previously read in the string "treeContents".
	 * The recursive runs deal with substrings of "treeContents".
	 * The easing of the restrictions comparing to "New Hampshire Extended" format 
	 * is that blank spaces are allowed in the string. When they are leading
	 * or trailing, they are ignored. When they are inside the leaf names, they are 
	 * incorporated in the leaf names.
	 * The tree must be binary and rooted.
	 * All nodes are elements of the array "nodes".
	 * It uses the current position "pos" in the string "treeContents".
	 * Parameters:
	 *    nodeContents: The contents of the node, without eventual enclosing brackets.
	 * 
	 * */
	//public static NodeG buildTreeG() {
	public static NodeG buildTreeG(String nodeContents) {
		String contents = nodeContents;
		NodeG left, right;
		int oldPos;
		int commaPosition;
		int nThis = nCurrentNode++; // Reserve place in nodes[] for the current node. Shift the pointer one step ahead.
		int start = findNonWhitespace(nodeContents);
		if (start < 0) { 
			error("Tree: Only whitespaces after position" + pos);
			return null;
		}
		/*
		*/
		pos += start; // We continue maintaining the global position in the tree string (useful for error messages).
		oldPos = pos; // Keep the position which has been reached before processing with the subtree.
		
		contents = contents.trim(); // Get rid of the whitespaces at the beginning and the end.
		 
		// PROCEED WITH THE FIRST ELEMENT
		// "contents" must begin with a subtree or a leaf.
		if (contents.charAt(0) == '(') { // The case of a subtree.
			//oldPos = pos; // Keep the position which has been reached before processing with the subtree.
			pos++; // pos will point at the position after the opening bracket. 
			// Find the scope of the first element.
			int firstElementEnd = findClosingBracket(contents);
			if (firstElementEnd < 0) {
				// No matching closing bracket for the first opening bracket.
				error("Tree: No matching closing bracket for the bracket at position" + (pos));
				return null;
			}

			//
			left = buildTreeG(contents.substring(1, firstElementEnd)); // Deals with the stuff inside brackets.
			if (left == null) // Something odd happened inside.
				return null;
				
			
			// Exclude the first element subtree from further considerations.
			pos = oldPos + firstElementEnd + 1; // Now pos points at the first element after the closing bracket.
			contents = contents.substring(firstElementEnd + 1);
			commaPosition = contents.indexOf(','); // The first element is separated by comma from the second element.
			if (commaPosition < 0) {
				// No comma.
				error("Tree: No comma after position" + (pos));
				return null;
			}

			pos += commaPosition + 1; //Set to the first element after the comma.
			contents = contents.substring(commaPosition + 1);
			
		}
		else { //If there is not '(', the next substring should be a leaf name.
			commaPosition = contents.indexOf(','); // The first element is separated by comma from the second element.
			if (commaPosition < 0) {
				// No comma.
				error("Tree: No comma after position" + (pos));
				return null;
			}
			String name = checkName(contents.substring(0, commaPosition));
			if (name == null) // Something odd happened inside.
				return null;
			nodes[nCurrentNode] = new NodeG(name, nCurrentNode); // Create the left leaf.	
			left = nodes[nCurrentNode]; 		 
			
			leavesIndex[currentLeafNum++] = nCurrentNode++;
			pos = oldPos + commaPosition + 1;
			contents = contents.substring(commaPosition + 1);
		}
		
		// PROCEED WITH THE SECOND ELEMENT
		// After excluding the first element, and the comma, the rest should be the second element 
		// plus eventual leading whitespaces.
		start = findNonWhitespace(contents);
		if (start < 0) { 
			error("Tree: Only whitespaces after position" + pos);
			return null;
		}
		pos += start;
		oldPos = pos; // Keep the position which has been reached before processing with the subtree.
		contents = contents.substring(start);
		// Do considerations similar to those for the first element.
		if (contents.charAt(0) == '(') { // The case of a subtree.
			// The second element should be till the end of the string: The closing bracket should be at the end.
			int secondElementEnd = contents.length() - 1;
			if (contents.charAt(secondElementEnd) != ')') {
				error("Tree: No matching closing bracket for the bracket at position" + (pos));
				return null;
			}	

			pos++; // pos will point at the position after the opening bracket. 
			right = buildTreeG(contents.substring(1, secondElementEnd)); // Deals with the stuff inside brackets.
			if (right == null) // Something odd happened inside.
				return null;
			
		}
		else { //If there is not '(', the next substring should be a leaf name.
			String name = checkName(contents);
			if (name == null) // Something odd happened inside.
				return null;
			
			nodes[nCurrentNode] = new NodeG(name, nCurrentNode); // Create the right leaf.	
			right = nodes[nCurrentNode];
			
			leavesIndex[currentLeafNum++] = nCurrentNode++;
		}
		
		nodes[nThis] =  new NodeG(nThis, left, right); // Create the entry for the current node
														// in the place reserved previously.
		left.parent = nodes[nThis];
		right.parent = nodes[nThis];
		
		/*
		if (treeContents.charAt(pos) == '(') { // Proceedings with an internal node.
			pos++;
			NodeG left = buildTreeG(); 			 // Deals with the first element after '('.
			if (treeContents.charAt(pos++) != ',') { // ',' is obligatory after the first sibling.
				String  errMessage = "A comma is expected in the tree description at position " +
																		Integer.toString(pos) +".";
				error(errMessage);
			}
			
			NodeG right = buildTreeG();  // Deals with the second element after '('.
			if (treeContents.charAt(pos++) != ')') { // ')' is obligatory after the second element.
				String  errMessage = "A closing bracket is expected in the tree description at position " +
																		Integer.toString(pos) +".";
				error(errMessage);
			}
			
			nodes[nThis] =  new NodeG(nThis, left, right); // Create the entry for the current node
														   // in the place reserved previously.
			left.parent = nodes[nThis];
			right.parent = nodes[nThis];
		} // End of if (treeContents.charAt(++pos) == '(')
		
		else { //If there is not '(', the next substring is a leaf name.
			
			String name = readName();
			nodes[nThis] =  new NodeG(name, nThis); // Create the entry for the current node.
			leavesIndex[currentLeafNum++] = nThis;
		}
		*/

		return nodes[nThis];

	} //End of public static NodeG buildTreeG()
	
	
	/**
	 * This function reads the contents of the "Tree file".
	 * For now, the contents of the "Tree file" must not contain "new line" marks, 
	 * but it can contain spaces, as a relaxation to the "New Hampshire format".
	 */
	private static boolean readTree() throws IOException {
		ReadInput inTree = new ReadInput(InputWindow.tree);
		
		// Read the file that contains the tree. For now, the tree description is fitted in  single line.
		treeContents = inTree.readLine();
		// Find the first non-whitespace character.
		pos = findNonWhitespace(treeContents);
		treeContents = treeContents.trim(); // Get rid of the whitespaces at the beginning and the end.
		// Check for the brackets.
		//if (!bracketsOK(treeContents)) {
		//error ("A problem with the outermost brackets in the tree.");
		//return false;
		//}
		//countChar(char ch, String sequence)
		int contentsEnd = treeContents.length();
		// Check if the autermost brackets are in place.
		if ((treeContents.charAt(0) != '(') || (treeContents.charAt(contentsEnd-1) != ')')) {
			error ("The outermost brackets in the tree are not at place.");
			return false;
		}

		nLeaves = treeContents.split(",").length;
		leavesIndex = new int[nLeaves];
		nNodes = 2*nLeaves-1;
		nodes = new NodeG[nNodes];
		currentLeafNum = 0;
		nCurrentNode = 0;
		pos++; // Pass the initial bracket.
		
		root = buildTreeG(treeContents.substring(1, contentsEnd-1)); // root should be the same as nodes[0];
		if (root == null) // Something odd happened inside.
			return false;
		nodes[0] = root;
		
		return true;
	} // End of private static boolean readTree()  throws IOException {
	

	/*
	Reads the file containing the positions of the tree leaves relatively to the columns of the matrix.
	Produces static int[] orderIndex, which is further used during the reading of the matrix to put the
	contents in the proper positions in nodesProfile[][].
    */
	private static boolean readOrder() throws IOException {
	
		orderIndex = new int[nLeaves];
		String order = InputWindow.order; // That is the file with the function descriptions.
		int orderLines = CountLines.countMeaningfulLines(order);
		if (orderLines != nLeaves) {
			JOptionPane.showMessageDialog(null, "The number of lines in Profile Order and the number of leaves are different.");
			return false;
		}
        ReadInput orderRead = new ReadInput(order);
        
        for (int ct = 1; ct <= orderLines; ct++) {
        	// Every line of the file must contain exactly two words 
        	// separated by white space. We check if that is the situation.
        	int i; // The counter in searching and the index of found leaf name.
        	boolean found = false;
            String line = orderRead.readMeaningfulLine();
            String words[] = line.split("[\\s]+");	// The first word contains the column number.
            										// The second contains the leaf name.
            if (words.length != 2) {
				JOptionPane.showMessageDialog(null, "Wrong contents in line" + (ct+1) + "in Profile Order.");
            	return false;
            }
            int columnNumber = Integer.parseInt(words[0]); // Retrieving the column number.
            String leafName = words[1];
            
            for (i = 0; i < nLeaves; i++) { //Find the index of the leaf with name leafName.
            	String nodeName = nodes[leavesIndex[i]].name;
            	if (leafName.equals(nodeName)) {
            		found = true;
            		break;
            	}
            }
            
            if (found)
				orderIndex[columnNumber-1] = leavesIndex[i]; // 
			else {	// No leaf with such a name. Error, exit.
				String  errMessage = "In line " + ct + " of " + order + " " + leafName + " is not a leaf name.";
				error(errMessage);
				return false;
			}	
        }
        
       	return true;
	} // End of private static boolean readOrder() throws IOException

	
	/*
	 * Read the file with profile matrix.
	 * The first line contains the number of species and the number of traits. 
	 * Every column corresponds to the thaits present or absent in one of the species.
	 * The columns are in the order imposed by the tree, which is presented in 
	 * "leavesIndex[]"
	 */ 
	private static boolean readMatrix() throws IOException {
		
		ReadInput inMatrix = new ReadInput(InputWindow.matrix);
		 
		int nSpecies = inMatrix.readInt();
		if(nSpecies != nLeaves) error("Different number of species between the matrix and the tree."); 
		nTraits = inMatrix.readInt();
		inMatrix.readLine(); // This is to clear off the remainder of the first line from the file.
		nodesProfile = new boolean[nNodes][nTraits]; // '0' or '1' contents of the matrix.

		for (int i = 0; i < nTraits; i++) { // Proceed with the main part of the matrix file.
			//TODO: Defensive reading of the line.
			String matrixRow = inMatrix.readLine();
			String[] tokens = matrixRow.split("[\\s]+"); // Make tokens from the matrix row. The separators are
														 // whitespaces with arbitrary length.
			if(tokens.length != nSpecies) 
				error("Wrong number of tokens in the matrix in row " + (i+2));
			for (int j = 0; j < nSpecies; j++) {
				String mElem = tokens[j];
				if (mElem.length() != 1)
					error("Matrix element containing more than 1 symbol in position " + (i+2) + "," + (j+1));
				char elem = mElem.charAt(0);
				if ((elem!='0') && (elem!='1'))
					 error("Matrix element different than 0 or 1 in position " + (i+2) + "," + (j+1));
				nodesProfile[orderIndex[j]][i] = (elem == '1'); // Set gains and losses in the leaves.
			}
		} // End of for (int i = 0; i < nTraits; i++).

		return true;
	} // End of private static boolean readMatrix()  throws IOException {

	
	public static boolean readDataFiles() {
	//	public static boolean readDataFiles() throws IOException {
	 
		try {
			if (!readFunction()) {
				error("Error reading the Gene Function file.");
				return false;
			}
			
			if (!readTree()) {
				error("Error reading the Tree file.");
	        	return false;
			}

			if (!readOrder()) { // The profile order is well to be read before the matrix.
			 					// Then, while reading the matrix, we rearrange the read column
			 					// elements according to the corresponding leaves.
				error("Error reading the Profile Order file.");
	        	return false;
			}

			if (!readMatrix()) {
				error("Error reading the Profile Matrix file.");
	        	return false;
			}
		} catch (IOException e) {
			error("Error reading the input files.");
			e.printStackTrace();
			return false;
		}

       	return true;
	} // End of public void readDataFiles() throws IOException 
	

	public static boolean[][] cloneArray(boolean[][] src) {
    	int length = src.length;
    	boolean[][] target = new boolean[length][src[0].length];
    	for (int i = 0; i < length; i++) {
        	System.arraycopy(src[i], 0, target[i], 0, src[i].length);
    	}
    	return target;
	}	
	/*
	*/


} // End of public class InnerData
