/**
 * genalg contains the programmes which implement the generalized algorithm for 
 * finding optimal scenarios for Maximum Parsimony, Maximum Likelihood and Minimum Entropy.
 */
/**
 * @author Petar
 *
 */
package erst.genalg;