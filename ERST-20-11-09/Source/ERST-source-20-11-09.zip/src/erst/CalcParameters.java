/*
 * @author Petar
 * 
 * The purpose of this class is to actualise and save the calculation parameters for the 
 * reconstruction calculation:
 * 1. Gain Penalty Weight.
 * 2. Output file name.
 * 3. The number of iterations.
 * 4. The previously chosen metod for calculation.
 * 5. The filenames, derived from the output file name.
 * 
 * These parameters (except those from 5.) are stored in a file which is maintained by CalcParameters.
 * The (initial) absence or corruption of the file doesn't disturb the work, simply default values are 
 * accepted in the place of the missing ones.
 * 
 * A constructor is not provided for this class. Its stored data is used by through the methods provided, 
 * or (in the case of derived filenames) - through publicly available strings. 
 */

package erst;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import erst.genalg.InnerData;
import erst.tio.FormattedWriter;

public abstract class CalcParameters { // 
	
	private static String gainPenalty_txt;
	private static String nIterations_txt;
	private static String methodUsed_txt;
	private static int    methodUsed;
	private static String outputFile_TXT;
	private static String shortReport_TXT;
	private static String hGTransferFile_TXT;
	//private static String altScenFile_TXT = "altScenFile.txt";
	
	/* The following filenames are derived from outputFile_TXT and are used for the output of the
	 * calculations. They are refreshed every time when outputFile_TXT is altered. 
	 * */
	public static String outputFile_ATV, outputFile_IPROB, outputFile_FPROB;
	
	/* The following flags determine the actuality of the parameters and their record in the file.
	 * At the beginning the parameters are not read from the file but it is assumed that the file
	 * is OK (until an evidence appears for the opposite).
	 * */
	private static boolean parametersUpToDate = false;
	private static boolean fileUpToDate = true;
	private static String defaultParameters;
	private static String altScenFile;
	private static BufferedReader inputStream;
	
	private static void refreshParameters() {
		
		// We read the default values of the parameters if the file with the parameters who exists 
		// in the current directory.
		
		if (InnerData.isJar == true) {
			// The package is run from a jar file. Proceed accordingly.
			defaultParameters = "resources/defaultParameters.txt";
			altScenFile = "output/altScenFile.txt";
		}
		else {
			// The package is run from the Eclipse IDE. Proceed accordingly.
			defaultParameters = "defaultParameters1.txt";
			altScenFile = "altScenFile.txt";
		}
		/*
		*/
		
		try {
			inputStream = new BufferedReader(new FileReader(defaultParameters));
			
			gainPenalty_txt 		= inputStream.readLine();
			nIterations_txt 		= inputStream.readLine();
			methodUsed_txt 			= inputStream.readLine();
			methodUsed 				= Integer.parseInt(methodUsed_txt);
			outputFile_TXT  		= inputStream.readLine();
			shortReport_TXT			= inputStream.readLine();
			hGTransferFile_TXT		= inputStream.readLine();
			
			
		} catch (FileNotFoundException e) {
			// Nothing dangerous - this was expected. Use default values instead.
			setDefaultValues();
		} catch (IOException e) {
			// The "defaultParameters.txt" exists, but the reading fails. Use default values again.
			e.printStackTrace();
			setDefaultValues();
		}finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e1) {
					// Very unlikely - "defaultParameters.txt" exists and was read successfully,
					// but can't be closed :). Maybe such situation can be performed by unmounting 
					// the media which contains the file.
					
					e1.printStackTrace();
				}
			}
		}
		
		/* Derive the secondary output filenames from the already chosen one, e.g.
		 * "defaultOutput_txt.txt" would produce "defaultOutput_ATV.txt", "defaultOutput_GL.txt", etc.
		 */
		int outNameLen = outputFile_TXT.length();
		if (outputFile_TXT.endsWith("TXT.txt")) {
			outputFile_ATV = outputFile_TXT.substring(0, outNameLen-7) + "ATV.txt";
			outputFile_IPROB = outputFile_TXT.substring(0, outNameLen-7) + "IPROB.txt";
			outputFile_FPROB = outputFile_TXT.substring(0, outNameLen-7) + "FPROB.txt";
		} else if (outputFile_TXT.endsWith(".txt")) {
			outputFile_ATV = outputFile_TXT.substring(0, outNameLen-3) + "ATV.txt";
			outputFile_IPROB = outputFile_TXT.substring(0, outNameLen-3) + "IPROB.txt";
			outputFile_FPROB = outputFile_TXT.substring(0, outNameLen-3) + "FPROB.txt";
		} else {
			outputFile_ATV = outputFile_TXT + "ATV.txt";
			outputFile_IPROB = outputFile_TXT + "IPROB.txt";
			outputFile_FPROB = outputFile_TXT + "FPROB.txt";
		}
		
		parametersUpToDate = true;
		
	} // End of private void refreshParameters().
	
	
	private static void setDefaultValues() {
		gainPenalty_txt = "1.0";
		nIterations_txt = "0";
		outputFile_TXT = "defaultOutput_TXT.txt";
		shortReport_TXT = "shortReport.txt";
		hGTransferFile_TXT = "hGTransferFile.txt";
		methodUsed_txt = "0";
		methodUsed = 0;
		parametersUpToDate = true;
		fileUpToDate = false;
		
		return;
	}
	
	
	public static void saveValues() {
		
		if (fileUpToDate) 
			return;
		
		FormattedWriter out;
		try {
			out = new FormattedWriter(defaultParameters);
			out.printfln (gainPenalty_txt);
			out.printfln (nIterations_txt);
			out.printfln (methodUsed_txt);
			out.printfln (outputFile_TXT);
			out.printfln (shortReport_TXT);
			out.printfln (hGTransferFile_TXT);
		} catch (IOException e) {
			// Saving the parameter values failed.
			System.out.println ("Writing the calculation parameters in defaultParameters.txt failed.");
			e.printStackTrace();
		}
		fileUpToDate = true;
		
		return;
	}
	
	
	public static String getOutputFile_TXT() {
		
		if (!parametersUpToDate)
			refreshParameters();
		
		return outputFile_TXT;
	}
	
	
	public static double getGainPenalty() {
		
		if (!parametersUpToDate)
			refreshParameters();
		
		return Double.parseDouble(gainPenalty_txt);
	}
	
	
	public static String getGainPenalty_txt() {
		
		if (!parametersUpToDate)
			refreshParameters();
		
		return gainPenalty_txt;
	}

	
	public static int getNIterations() {
		
		if (!parametersUpToDate)
			refreshParameters();
		
		return Integer.parseInt(nIterations_txt);
	}
	
	
	public static String getNIterations_txt() {
		
		if (!parametersUpToDate)
			refreshParameters();
		
		return nIterations_txt;
	}
	
	
	public static int getMethodUsed() {
		
		if (!parametersUpToDate)
			refreshParameters();
		
		return methodUsed;
	}


	public static String getShortReport_TXT() {
		
		if (!parametersUpToDate)
			refreshParameters();
		
		return shortReport_TXT;
	}
	
	
	public static String getHGTransferFile_TXT() {
		
		if (!parametersUpToDate)
			refreshParameters();
		
		return hGTransferFile_TXT;
	}
	

	public static String getAltScenFile_TXT() {
		
		if (!parametersUpToDate)
			refreshParameters();
		
		return altScenFile;
	}
	/*
	*/
	
	public static void setOutputFile_TXT(String name) {
		
		if (outputFile_TXT != null) {
			if (outputFile_TXT.contentEquals(name))
				return;
		}
		outputFile_TXT = name;
		fileUpToDate = false;
		return;
	}

	
	public static void setShortReport_TXT(String name) {
		
		if (shortReport_TXT != null) {
			if (shortReport_TXT.contentEquals(name))
				return;
		}	
		shortReport_TXT = name;
		fileUpToDate = false;
		return;
	}
	
	// If the file with the name 'name' is missing, create it.
	private static void createFileIfMissing(String name) {
	
		File tempFile = new File(name);
		try {
			tempFile.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return;
	}
	/*
	*/

	
	public static void setHGTransferFile_TXT(String name) {
		
		if (hGTransferFile_TXT != null) {
			if (hGTransferFile_TXT.contentEquals(name))
				return;
		}
		// Check if the 'name' is valid:
		// If the file does not exist, create it:
		createFileIfMissing(name);
		
		/*
		*/
		hGTransferFile_TXT = name;
		fileUpToDate = false;
		return;
	}
	
	
	public static void setGainPenalty_txt(String newGainPenalty_txt) {
		
		if (gainPenalty_txt != null) {
			if (gainPenalty_txt.contentEquals(newGainPenalty_txt))
				return;
		}
		gainPenalty_txt = newGainPenalty_txt;
		fileUpToDate = false;
		return;
	}
	
	
	public static void setNIterations_txt(String newNIterations_txt) {
		
		if (nIterations_txt != null) {
			if (nIterations_txt.contentEquals(newNIterations_txt))
				return;
		}
		nIterations_txt = newNIterations_txt;
		fileUpToDate = false;
		return;
	}
	
	
	public static void setMethodUsed(int index) {
		
		if (methodUsed == index)
			return;
		methodUsed = index;
		methodUsed_txt = Integer.toString(index);
		fileUpToDate = false;
		return;
	}
	
	
} // End of public class CalcParameters.