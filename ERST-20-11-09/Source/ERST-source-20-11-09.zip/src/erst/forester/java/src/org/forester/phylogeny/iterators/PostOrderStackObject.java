// PostOrderStackObject.java
//
// Copyright (C) 1999-2001 Washington University School of Medicine
// and Howard Hughes Medical Institute
// All rights reserved
//
// Created: 1999
// Author: Christian M. Zmasek
// zmasek@genetics.wustl.edu
// http://www.genetics.wustl.edu/eddy/people/zmasek/
// A helper class for Iterators.
package erst.forester.java.src.org.forester.phylogeny.iterators;

import erst.forester.java.src.org.forester.phylogeny.PhylogenyNode;

/**
 * @author Christian M. Zmasek
 * @version 1.00 -- last modified: 06/15/00
 */
public class PostOrderStackObject {
    /**
     * Creates a new PostOrderStackObject object.
     * 
     * @param n
     *            DOCUMENT ME!
     * @param i
     *            DOCUMENT ME!
     */
    public PostOrderStackObject( final PhylogenyNode n, int i ) {
        _node = n;
        _phase = i;
    }

    /**
     * DOCUMENT ME!
     * 
     * @return DOCUMENT ME!
     */
    public PhylogenyNode getNode() {
        return _node;
    }

    /**
     * DOCUMENT ME!
     * 
     * @return DOCUMENT ME!
     */
    public int getPhase() {
        return _phase;
    }

    final private PhylogenyNode _node;
    final private int           _phase;
}
