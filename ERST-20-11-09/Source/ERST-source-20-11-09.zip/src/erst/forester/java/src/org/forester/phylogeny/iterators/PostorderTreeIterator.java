// PostorderTreeIterator.java
//
// Copyright (C) 1999-2001 Washington University School of Medicine
// and Howard Hughes Medical Institute
// All rights reserved
//
// Created: 1999
// Author: Christian M. Zmasek
// zmasek@genetics.wustl.edu
// http://www.genetics.wustl.edu/eddy/people/zmasek/
package erst.forester.java.src.org.forester.phylogeny.iterators;

import java.util.NoSuchElementException;
import java.util.Stack;

import erst.forester.java.src.org.forester.phylogeny.Phylogeny;
import erst.forester.java.src.org.forester.phylogeny.PhylogenyNode;

/**
 */
public class PostorderTreeIterator implements PhylogenyNodeIterator {
    /**
     * @param t
     *            Phylogeny for which a Iterator is to be constructed.
     */
    public PostorderTreeIterator( final Phylogeny tree )
            throws IllegalArgumentException {
        if ( tree.isEmpty() ) {
            throw new IllegalArgumentException(
                    "Attempt to use PostorderTreeIterator on an empty phylogeny." );
        }

        _tree = tree;
        _root = getTree().getRoot();
        _stack = new Stack();
        reset();
    }

    /**
     * DOCUMENT ME!
     */
    public void reset() {
        setHasNext( true );
        getStack().clear();
        getStack().push( new PostOrderStackObject( getTree().getRoot(), 1 ) );
    }

    /**
     * Advances the Iterator by one.
     */
    public PhylogenyNode next() throws NoSuchElementException {
        if ( !hasNext() ) {
            throw new NoSuchElementException(
                    "Attempt to call \"next()\" on iterator which has no more next elements." );
        }

        while ( true ) {
            final PostOrderStackObject si = ( PostOrderStackObject ) getStack()
                    .pop();
            final PhylogenyNode node = si.getNode();
            int phase = si.getPhase();

            //if ( node != null ) {
            if ( phase > node.getNumberOfChildNodes() ) {
                setHasNext( node != getRoot() );

                return node;
            }
            else {
                getStack()
                        .push( new PostOrderStackObject( node, ( phase + 1 ) ) );

                if ( node.isInternal() ) {
                    getStack().push(
                            new PostOrderStackObject( node
                                    .getChildNode( phase - 1 ), 1 ) );
                }

                //   else {
                //    getStack().push( new PostOrderStackObject( null, 1 ) );
                //  }
            }

            //}
        }
    }

    /**
     * DOCUMENT ME!
     * 
     * @return DOCUMENT ME!
     */
    public boolean hasNext() {
        return _has_next;
    }

    private void setHasNext( boolean has_next ) {
        _has_next = has_next;
    }

    private PhylogenyNode getRoot() {
        return _root;
    }

    private Stack getStack() {
        return _stack;
    }

    private Phylogeny getTree() {
        return _tree;
    }

    final private Phylogeny     _tree;
    final private PhylogenyNode _root;
    private boolean             _has_next;
    final private Stack         _stack;
} // End of class PostorderTreeIterator.
