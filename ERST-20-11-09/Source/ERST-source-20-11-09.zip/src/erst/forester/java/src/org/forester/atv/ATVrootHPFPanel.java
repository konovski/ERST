/*
 * ATVrootHPFPanel.java Added to ATV by Ethy Cannon 7/9/04
 * 
 * Modified by Petar, 2016.
 */

package erst.forester.java.src.org.forester.atv;


import java.awt.*;
import java.util.ArrayList; 
import java.awt.event.*;
import javax.swing.*;
//import java.util.*;  Not used (Petar)
import java.awt.datatransfer.*;
import javax.swing.JPanel;

import erst.genalg.GetGL;

//import erst.forester.java.src.org.forester.phylogeny.*; Never used (Petar).

//import erst.readGL; Not used (Petar)

public class ATVrootHPFPanel extends JPanel implements ActionListener, ClipboardOwner {          
     private boolean         can_use_clipboard;

     //private PhylogenyNode   node; Never used (Petar).

     private ATVrootHPFFrame atvroothpfframe;

     JLabel                  popup_title_root;

     JButton                 close_button;

     JButton                 copy_button;
     JTextArea               name_list;


//     private void displayHPFInfo(int n) {
     public void displayRootHPFInfo(int n) {
         //String tmpeleg = "", tmpelel = ""; Never used (Petar).
    	 String list = "";
         name_list = new JTextArea( "" );
         name_list.setEditable( false );
         name_list.setWrapStyleWord( true );
         name_list.setLineWrap( true );
         add( new JScrollPane( name_list ), "Center" );
         
         //readGL readgainslosses = new readGL();
         //int elemento, tamanho; Never used (Petar).
         //readgainslosses.execute();         
         
         /*The following two paragraphs: "getting gains" and "getting losses" are for
         diagnostic purposes only and can be commented off (Petar).
         //getting gains
         for (int i = 0; i < readgainslosses.getGain(n).size(); i ++) {
             tmpeleg = readgainslosses.getGainElement(n, i);
//             System.out.println(" size read gain " + tmpeleg);
         }
         //getting losses
         for (int i = 0; i < readgainslosses.getLoss(n).size(); i ++) {
             tmpelel = readgainslosses.getLossElement(n, i);
//             System.out.println(" size read loss " + tmpelel);
         }                  
         */
         
         
         ArrayList<String> gains = GetGL.getGains(n);
         ArrayList<String> losses = GetGL.getLosses(n);
         int numberOfGains = gains.size(); 
         int numberOfLosses = losses.size();
         
         // In many cases, the the lists are empty. Proceed accordingly. 
         if (numberOfGains == 0) 
             list =  "NO  GAINS\n\n";
         else if (numberOfGains == 1)
             list = numberOfGains + "  GAIN\n\n";
         else 
             list =  numberOfGains + "  GAINS\n\n";
             
         for ( int i = 0; i < numberOfGains; i++ )
             list += gains.get(i) + "\t";

         if (numberOfLosses == 0)
             list +=  "\n\n  NO  LOSSES";
         else if (numberOfLosses == 1)  
             list += numberOfLosses + "\n\n  LOSS\n\n";
         else 
             list +=  numberOfLosses + "\n\n  LOSSES\n\n";
         
         for ( int i = 0; i < numberOfLosses; i++ )
             list += losses.get(i) + "\t";
             
         list += "\n";
         name_list.setText( list );
		/*
        */
         
  		/*
        int numberOfGains = readgainslosses.getGain(n).size();
         int numberOfLosses = readgainslosses.getLoss(n).size();
         String list;
         //Conditions for Gains
         if (readgainslosses.getGain(n).contains("")) { // zero gains however I had to store "" empty string that is count as 1 element in the array.
             list =  "NO  GAINS\n\n";
             numberOfGains--;
         }
         else if ((numberOfGains == 1) &&  !(readgainslosses.getGain(n).contains(""))) 
             list = numberOfGains + "  GAIN\n\n";
         else 
             list =  numberOfGains + "  GAINS\n\n";
         
         for ( int i = 0; i < numberOfGains; i++ )
             list += ( String ) readgainslosses.getGainElement(n, i) + "\t";
         list += "\n\n\n";
         
         // Conditions for Losses
         if (readgainslosses.getLoss(n).contains("")) { // zero gains however I had to store "" empty string that is count as 1 element in the array.
             list +=  "NO  LOSSES\n\n";
             numberOfLosses--;
         }
         else if ((numberOfLosses == 1) &&  !(readgainslosses.getLoss(n).contains("")))  
             list += numberOfLosses + "  LOSS\n\n";
         else 
             list +=  numberOfLosses + "  LOSSES\n\n";
         
         for ( int i = 0; i < numberOfLosses; i++ )
             list += ( String ) readgainslosses.getLossElement(n, i) + "\t";
         list += "\n";
         name_list.setText( list );
         */
     }
    
     public ATVrootHPFPanel() {
//         node = n;
//         atvroothpfframe = anf;
         String title = "ATV - PARS";
         atvroothpfframe.setTitle( title );
        
         // check to see if we have permission to use the clipboard:
         can_use_clipboard = true;
         /* Obsolete method used. Exclude for now. (Petar)
         SecurityManager sm = System.getSecurityManager();
         if (sm != null) {
             try {
                 sm.checkSystemClipboardAccess();
             } catch (Exception e) {
                //nope!
                 can_use_clipboard = false;
             }
         }
         /* Obsolete method used. Exclude for now. (Petar)
         */
        
         setLayout( new BorderLayout( 10, 10 ) );

         popup_title_root = new JLabel( "Genes gained and lost at root " );
         popup_title_root.setHorizontalAlignment( SwingConstants.CENTER );
         add( popup_title_root, "North" );

         
         displayRootHPFInfo(0);

         JPanel button_panel = new JPanel( new FlowLayout() );
         close_button = new JButton( "Close" );
         close_button.addActionListener( this );
         button_panel.add( close_button );

         if (can_use_clipboard) {
             copy_button = new JButton("Copy to Clipboard");
             copy_button.addActionListener(this);
             button_panel.add(copy_button);
         }

         add( button_panel, "South" );
     }
     
     
//     ATVrootHPFPanel( PhylogenyNode n, ATVrootHPFFrame anf ) {
//         node = n;
//         atvroothpfframe = anf;
//         String title = "ATV - PARS";
//         atvroothpfframe.setTitle( title );
//        
//         // check to see if we have permission to use the clipboard:
//         can_use_clipboard = true;
//         SecurityManager sm = System.getSecurityManager();
//         if (sm != null) {
//             try {
//                 sm.checkSystemClipboardAccess();
//             } catch (Exception e) {
//                //nope!
//                 can_use_clipboard = false;
//             }
//         }
//        
//         setLayout( new BorderLayout( 10, 10 ) );
//
//         popup_titlett = new JLabel( "Genes gained and lost at node " + n.getID() );
//         popup_titlett.setHorizontalAlignment( SwingConstants.CENTER );
//         add( popup_title, "North" );
//
//         if (n.getID() >= 1)
//              displayHPFInfo(n.getID());
////             displayHPFInfo(0);
//         displayHPFInfo(n.getID());
//
//         JPanel button_panel = new JPanel( new FlowLayout() );
//         close_button = new JButton( "Close" );
//         close_button.addActionListener( this );
//         button_panel.add( close_button );
//
//         if (can_use_clipboard) {
//             copy_button = new JButton("Copy to Clipboard");
//             copy_button.addActionListener(this);
//             button_panel.add(copy_button);
//         }
//
//         add( button_panel, "South" );
//     }


     public void actionPerformed( ActionEvent e ) {
         if ( e.getSource() == close_button ) {
             close();
         } else if (e.getSource() == copy_button) {
             copy();
         }
     }


     void close() {
//         atvroothpfframe.remove(); // to release slot in array
         atvroothpfframe.dispose();
         atvroothpfframe = null;
     }


     private void copy() { 
         if (!can_use_clipboard) {
             // can't do this!
             return;
         }
        
         Clipboard sys_clipboard = getToolkit().getSystemClipboard(); 
         StringSelection contents = new StringSelection(name_list.getText());
         sys_clipboard.setContents(contents, this); 
     }


     // Never used, but must be available as an implementation of inherited abstract method  (Petar).
     public void lostOwnership( Clipboard clipboard, Transferable contents ) {
     }
}