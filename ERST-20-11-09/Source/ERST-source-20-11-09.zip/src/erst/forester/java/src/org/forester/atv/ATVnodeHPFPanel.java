/*
 * ATVnodeHPFPanel.java Added to ATV by Ethy Cannon 7/9/04
 * 
 * Modified by Petar, 2016.
 */

package erst.forester.java.src.org.forester.atv;

import java.io.*;
import java.util.ArrayList; 
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
//import java.util.*; Never used (Petar).
import java.awt.datatransfer.*;

import javax.swing.JPanel;

import erst.forester.java.src.org.forester.phylogeny.*;
import erst.genalg.GetGL;

public class ATVnodeHPFPanel extends JPanel implements ActionListener, ClipboardOwner {          
     private boolean         can_use_clipboard;

     //private PhylogenyNode   node; Never used (Petar).

     private ATVnodeHPFFrame atvnodehpfframe;

     JLabel                  popup_title;

     JButton                 close_button;

     JButton                 copy_button;
     
     JButton                 save_button;
     
     JTextArea               name_list;

     final JFileChooser fc = new JFileChooser();
     
//     private void displayHPFInfo(int n) {
     public void displayHPFInfo(int n) {
         //String tmpeleg = "", tmpelel = ""; Never used (Petar).
    	 String list = "";
         name_list = new JTextArea( "" );
         name_list.setEditable( false );
         name_list.setWrapStyleWord( true );
         name_list.setLineWrap( true );
         add( new JScrollPane( name_list ), "Center" );
         
         //readGL readgainslosses = new readGL(); Replaced (Petar).
         // int elemento, tamanho; Never used (Petar).
         //readgainslosses.execute();  Replaced (Petar).
         
         /*The following two paragraphs: "getting gains" and "getting losses" are for
           diagnostic purposes only and can be commented off (Petar).
         //getting gains
         for (int i = 0; i < readgainslosses.getGain(n).size(); i ++) {
             tmpeleg = readgainslosses.getGainElement(n, i);
//             System.out.println(" size read gain " + tmpeleg + " node " + n);
         }
         //getting losses
         for (int i = 0; i < readgainslosses.getLoss(n).size(); i ++) {
             tmpelel = readgainslosses.getLossElement(n, i);
//             System.out.println(" size read loss " + tmpelel + " node " + n);
         }
         */
         
         //Display Gains and Losses at this node
         // Replacement of the original segment, which is commented out:
         ArrayList<String> gains = GetGL.getGains(n);
         ArrayList<String> losses = GetGL.getLosses(n);
         int numberOfGains = gains.size(); 
         int numberOfLosses = losses.size();
         
         // In many cases, the lists are empty. Proceed accordingly. 
         if (numberOfGains == 0) 
             list =  " NO  GAINS\n\n";
         else if (numberOfGains == 1)
             list = " " + numberOfGains + " GAIN\n\n";
         else 
             list =  " " + numberOfGains + " GAINS\n\n";
             
         for ( int i = 0; i < numberOfGains; i++ )
             list += gains.get(i) + "\t";

         if (numberOfLosses == 0)
             list += "\n\n  NO  LOSSES";
         else if (numberOfLosses == 1)  
             list += " " + numberOfLosses + " LOSS\n\n";
         else 
             list += " " + numberOfLosses + " LOSSES\n\n";
         
         for ( int i = 0; i < numberOfLosses; i++ )
             list += losses.get(i) + "\t";
             
         list += "\n";
         name_list.setText(list);
         /*
        */
         
         /* The original segment, which was replaced in order to stick with the new algoritm (Petar)
         int numberOfGains = readgainslosses.getGain(n).size();
         int numberOfLosses = readgainslosses.getLoss(n).size();
         String list;
         //Conditions for Gains
         if (readgainslosses.getGain(n).contains("")) { // zero gains however I had to store "" empty string that is count as 1 element in the array.
             list =  "NO  GAINS\n\n";
             numberOfGains--;
         }
         else if ((numberOfGains == 1) &&  !(readgainslosses.getGain(n).contains(""))) 
             list = numberOfGains + "  GAIN\n\n";
         else 
             list =  numberOfGains + "  GAINS\n\n";
         
         for ( int i = 0; i < numberOfGains; i++ )
             list += ( String ) readgainslosses.getGainElement(n, i) + "\t";
         list += "\n\n\n";
         
         // Conditions for Losses
         if (readgainslosses.getLoss(n).contains("")) { // zero gains however I had to store "" empty string that is count as 1 element in the array.
             list +=  "NO  LOSSES\n\n";
             numberOfLosses--;
         }
         else if ((numberOfLosses == 1) &&  !(readgainslosses.getLoss(n).contains("")))  
             list += numberOfLosses + "  LOSS\n\n";
         else 
             list +=  numberOfLosses + "  LOSSES\n\n";
         
         for ( int i = 0; i < numberOfLosses; i++ )
             list += ( String ) readgainslosses.getLossElement(n, i) + "\t";
         list += "\n";
         name_list.setText( list );
         /*
         */
         
         return;
     } // End of public void displayHPFInfo(int n)
    
     
     ATVnodeHPFPanel( PhylogenyNode n, ATVnodeHPFFrame anf ) {
         //node = n; Never used (Petar).
         atvnodehpfframe = anf;
         String title = "ATV - PARS";
         atvnodehpfframe.setTitle( title );
        
         // check to see if we have permission to use the clipboard:
         can_use_clipboard = true;
         /* Obsolete method used. Exclude for now. (Petar)
         SecurityManager sm = System.getSecurityManager();
          if (sm != null) {
             try {
                 sm.checkSystemClipboardAccess();
             } catch (Exception e) {
                //nope!
                 can_use_clipboard = false;
             }
         }
         /* Obsolete method used. Exclude for now. (Petar)
         */
        
         setLayout( new BorderLayout( 10, 10 ) );

         popup_title = new JLabel( "Genes Gained and Lost at Node " + n.getID() );
         popup_title.setHorizontalAlignment( SwingConstants.CENTER );
         add( popup_title, "North" );

//         if (n.getID() >= 1)
//              displayHPFInfo(n.getID());
//             displayHPFInfo(0);
         displayHPFInfo(n.getID());

         JPanel button_panel = new JPanel( new FlowLayout() );
         close_button = new JButton( "Close" );
         close_button.addActionListener( this );
         button_panel.add( close_button );

         save_button = new JButton( "Save " );
         save_button.addActionListener( this );
         button_panel.add( save_button );
         
//         if (can_use_clipboard) {
//             copy_button = new JButton("Copy to Clipboard");
//             copy_button.addActionListener(this);
//             button_panel.add(copy_button);
//         }

         add( button_panel, "South" );
     }


     public void actionPerformed( ActionEvent e ) {
         if ( e.getSource() == close_button ) {
             close();
         } else if (e.getSource() == save_button) {
             save();
//         } else if (e.getSource() == copy_button) {
//             copy();
         }
     }


     void close() {
         atvnodehpfframe.remove(); // to release slot in array
         atvnodehpfframe.dispose();
         atvnodehpfframe = null;
     }

     void save () {
         int returnVal = fc.showSaveDialog( this );
         File savelist = fc.getSelectedFile();
         fc.setSelectedFile( savelist );
     }

     //private void copy() { //throws java.io.IOException  {   Never used (Petar).        
//         int returnVal = fc.showOpenDialog(this);
//         File phT = fc.getSelectedFile();
//         fc.setSelectedFile(phT);
//         String pOUT = phT.getAbsolutePath();
//         try {
//             PrintWriter out = new PrintWriter(new FileWriter(pOUT));  
//             out.println("saving something just for test ");
//             out.close();
//         }
//         catch (Exception e) {
//             System.err.println("Couldn't save to " + pOUT + " error was " + e);
//         }
             
//         if (!can_use_clipboard) {
//             // can't do this!
//             return;
//         }
//       
//         Clipboard sys_clipboard = getToolkit().getSystemClipboard(); 
//         StringSelection contents = new StringSelection(name_list.getText());
//         sys_clipboard.setContents(contents, this); 
     //}
     

     // Never used, but must be available as an implementation of inherited abstract method  (Petar).
     public void lostOwnership( Clipboard clipboard, Transferable contents ) {
     }
}