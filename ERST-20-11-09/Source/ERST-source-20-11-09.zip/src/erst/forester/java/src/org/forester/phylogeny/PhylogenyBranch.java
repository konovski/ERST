// PostOrderStackObject.java
//
// Copyright (C) 2002 Washington University School of Medicine
// and Howard Hughes Medical Institute
// All rights reserved
//
// Created: 09/28/01
// Author: Christian M. Zmasek
// zmasek@genetics.wustl.edu
// http://www.genetics.wustl.edu/eddy/people/zmasek/
package erst.forester.java.src.org.forester.phylogeny;

import erst.forester.java.src.org.forester.phylogeny.data.PhylogenyData;

/**
 * @author Christian M. Zmasek
 * @version 1.000 -- last modified: 10/30/2005
 */
public class PhylogenyBranch implements Edge {

    public PhylogenyBranch( final PhylogenyNode first_node,
            final PhylogenyNode second_node ) {
        _node_1 = first_node;
        _node_2 = second_node;
        _is_directed = false;
    }

    public PhylogenyBranch( final PhylogenyNode first_node,
            final PhylogenyNode second_node, boolean direction_towards_first ) {
        _node_1 = first_node;
        _node_2 = second_node;
        _is_directed = true;
        _towards_1 = direction_towards_first;
    }

    public PhylogenyNode getConnectedNode( final PhylogenyNode node )
            throws IllegalArgumentException {
        if ( node == _node_1 ) {
            return _node_2;
        }
        else if ( node == _node_2 ) {
            return _node_1;
        }
        else {
            throw new IllegalArgumentException( "Attempt to get "
                    + "connected node on branch with node which is "
                    + "not connected by the branch." );
        }
    }

    public boolean isDirectionTowards( final PhylogenyNode node )
            throws IllegalStateException {
        if ( !_is_directed ) {
            throw new IllegalStateException(
                    "Attempt to get direction of undirected branch." );
        }
        return ( node == _node_1 && _towards_1 );
    }

    public void setDirectionTowards( final PhylogenyNode node ) {
        _towards_1 = node == _node_1;
    }

    public PhylogenyNode getFirstNode() {
        return _node_1;
    }

    public PhylogenyNode getSecondNode() {
        return _node_2;
    }

    public PhylogenyData getData() {
        return _data;
    }

    private void setData( PhylogenyData data ) {
        _data = data;
    }

    public String toString() {
        return ( "PhylogenyNode 1:\n" + getFirstNode().toString() + "\n\nNode 2:\n" + getSecondNode()
                .toString() );
    }

    private final PhylogenyNode _node_1;
    private final PhylogenyNode _node_2;
    private PhylogenyData                _data;
    private boolean             _is_directed;
    private boolean             _towards_1;

}
