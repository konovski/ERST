/*
 * ATVnodeGlyphFrame.java Pop up box for displaying "glyphs" for a set of
 * sequences. Added to ATV by Ethy Cannon 7/9/04
 */

package erst.forester.java.src.org.forester.atv;


import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import erst.forester.java.src.org.forester.phylogeny.*;

public class ATVnodeGlyphFrame extends JFrame implements ActionListener {

    private String            class_name;

    private ATVnodeGlyphPanel atvnodeglyphpanel;

    private ATVtreePanel      atvtreepanel;

    // this instance's index in the array of ATVnodeGlyphFrames
    private int               frame_index;

    private PhylogenyNode     node;

    protected String          title        = "Glyphs for this node";

    protected JLabel          popup_title;

    protected JPanel          button_panel = new JPanel();

    protected JButton         close_button;


    ATVnodeGlyphFrame( String name, PhylogenyNode n, ATVtreePanel tp, int x ) {
        class_name = name;
        atvtreepanel = tp;
        frame_index = x;
        node = n;
    }


    public void actionPerformed( ActionEvent e ) {
        if ( e.getSource() == close_button ) {
            close();
        }
    }


    void close() {
        remove(); // release slot in array
        dispose();
    }


    ATVtreePanel getATVtreePanel() {
        return atvtreepanel;
    }


    public JPanel getButtonPanel() {
        return button_panel;
    }


    public void initGlyphFrame() {
        try {
            // create a glyph panel of the given class:
            Class c = getClass();
            ClassLoader cl = c.getClassLoader();
            Class newc = cl.loadClass( class_name );
            atvnodeglyphpanel = ( ATVnodeGlyphPanel ) newc.newInstance();
            atvnodeglyphpanel.init( this, node );

            // this frame should be this big.
            Dimension d = atvnodeglyphpanel.getSize();
            d.width += 80; // make plenty of room for the scrollbar if needed.
            if ( d.height < 250 ) {
                // add some breathing room, if there's room for it
                d.height += 60;
            }
            else if ( d.height > 400 ) {
                // don't let the popup get too long
                d.height = 400;
            }
            setSize( d );

            // add the glyph panel
            Container contentPane = getContentPane();
            contentPane.add( atvnodeglyphpanel, BorderLayout.CENTER );
            addWindowListener( new WindowAdapter() {

                public void windowClosing( WindowEvent e ) {
                    remove(); // to release slot in array
                    dispose();
                }
            } );

            // create a close button
            close_button = new JButton( "Close" );
            close_button.addActionListener( this );
            button_panel.add( close_button );
            contentPane.add( button_panel, "South" );

            // create a default title
            popup_title = new JLabel( title );
            popup_title.setHorizontalTextPosition( JLabel.CENTER );
            contentPane.add( popup_title, "North" );

            setVisible( true );
        }
        catch ( Exception e ) {
            System.out
                    .println( "Error encountered while creating glyph pop-up: "
                            + e.toString() );
            remove();
            dispose();
        }
    }


    void remove() {
        atvtreepanel.removeGlyphNodeFrame( frame_index ); // to release slot in
                                                          // array
    }
    

    public void setTitle( String new_title ) {
        title = new_title;
    }
}