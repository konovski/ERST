package erst.forester.java.src.org.forester.atv;

import java.awt.Color;

/**
 * Maintains the color schemes and a set of colors for drawing a tree.
 */
public class TreeColorSet
{
    // The drawing colors
    private Color               ext_node_seq_color;
    private Color               int_node_seq_color;
    private Color               species_name_color;
    private Color               bootstrap_color;
    private Color               ec_color;
    private Color               dub_spec_color;
    private Color               branch_length_color;
    private Color               branch_color;
    private Color               box_color;
    private Color               background_color;
    private Color               dup_box_color;
    private Color               seq_x_color;
    private Color               collapse_fill_color;
    private Color               custom_data_color;
    private Color               found_color;
    private Color               re_gain_color; //renata
    private Color               re_lost_color; // renata
    private Color               re_inherited_color; // renata
    
    // Color schemes:
    int                         color_scheme;                                                                    ; // the
    // current
    // color
    // scheme
    // (0-based)
    static final String         scheme_names[]             = { "Scheme 1",
        "Scheme 2", "Scheme 3", "Scheme 4"            };
    
    static final String         color_fields[]             = {
        "external node sequence name", "internal node sequence name",
        "species name", "bootstrap value", "ec value", "dub spec",
        "branch length", "branch", "box", "background", "duplication box",
        "sequence x", "collapesed fill", "found", "custom data", "spec hpf", "inh hpf" };
    
    // All the color sets; better be the same # of sets 
    //   as there are names!
    static final Color          color_schemes[][]          = {
        { new Color( 0, 0, 0 ), //ext_node_seq_name_color
            new Color( 255, 0, 0 ), //int_node_seq_name_color
            new Color( 40, 40, 40 ), // species_color
            new Color( 0, 125, 0 ), // bootstrap_color
            new Color( 255, 100, 0 ), // ec_color
            new Color( 255, 0, 0 ), // dub_spec_color
            new Color( 70, 70, 0 ), // branch_length_color
            new Color( 0, 20, 200 ), // branch_color
            new Color( 0, 20, 200 ), // box_color
            new Color( 250, 250, 250 ), // background_color
            new Color( 255, 0, 0 ), // duplication_box_color
            new Color( 0, 0, 255 ), // seq_x_color
            new Color( 255, 255, 0 ), // collapesed_fill_color
            new Color( 255, 0, 0 ), // found_color
            new Color( 0, 40, 40 ), // custom_data_color
            new Color( 0, 187, 0), //renata gain hpf
            // new Color( 0, 0, 0), // renata lost spec hpf - modified by Petar.
            new Color( 230, 190, 0), // lost spec hpf - to be orange (Petar).
            new Color( 0, 128, 255)}, // renata inherited spec hpf
        
        { new Color( 0, 0, 0 ), // ext_node_seq_name_color
            new Color( 0, 0, 0 ), // int_node_seq_name_color
            new Color( 0, 0, 150 ), // species_color
            new Color( 0, 0, 0 ), // bootstrap_color
            new Color( 150, 0, 0 ), // ec_color
            new Color( 150, 0, 150 ), // dub_spec_color
            new Color( 150, 0, 0 ), // branch_length_color
            new Color( 255, 255, 0 ), // branch_color
            new Color( 255, 255, 0 ), // box_color
            new Color( 180, 180, 180 ), // background_color
            new Color( 255, 0, 0 ), // duplication_box_color
            new Color( 0, 0, 255 ), // seq_x_color
            new Color( 0, 90, 0 ), // collapesed_fill_color
            new Color( 0, 180, 0 ), // found_color
            new Color( 0, 40, 40 ), // custom_data_color
            new Color( 0, 187, 0), //renata gain hpf
            new Color( 0, 0, 0), // renata lost spec hpf
            new Color( 0, 128, 255)}, // renata inherited spec hpf
        
        { new Color( 0, 0, 0 ), // ext_node_seq_name_color
            new Color( 0, 0, 0 ), // int_node_seq_name_color
            new Color( 50, 50, 50 ), // species_color
            new Color( 100, 100, 100 ), // bootstrap_color
            new Color( 0, 0, 0 ), // ec_color
            new Color( 0, 0, 0 ), // dub_spec_color
            new Color( 50, 50, 50 ), // branch_length_color
            new Color( 0, 0, 0 ), // branch_color
            new Color( 0, 0, 0 ), // box_color
            new Color( 255, 255, 255 ), // background_color
            new Color( 255, 0, 0 ), // duplication_box_color
            new Color( 0, 0, 255 ), // seq_x_color
            new Color( 255, 255, 0 ), // collapesed_fill_color
            new Color( 255, 0, 0 ), // found_color
            new Color( 10, 10, 10 ), // found_color
            new Color( 0, 187, 0), //renata gain hpf
            new Color( 0, 0, 0), // renata lost spec hpf
            new Color( 0, 128, 255)}, // renata inherited spec hpf
        
        { new Color( 255, 255, 255 ), // ext_node_seq_name_color
            new Color( 255, 255, 255 ), // int_node_seq_name_color
            new Color( 200, 200, 200 ), // species_color
            new Color( 255, 255, 255 ), // bootstrap_color
            new Color( 200, 200, 200 ), // ec_color
            new Color( 255, 255, 255 ), // dub_spec_color
            new Color( 200, 200, 200 ), // branch_length_color
            new Color( 0, 255, 255 ), // branch_color
            new Color( 0, 255, 255 ), // box_color
            new Color( 0, 0, 70 ), // background_color
            new Color( 255, 0, 0 ), // duplication_box_color
            new Color( 255, 255, 0 ), // seq_x_color
            new Color( 255, 255, 0 ), // collapesed_fill_color
            new Color( 255, 0, 0 ), // found_color
            new Color( 0, 255, 255 ),  // custom_data_color
            new Color( 0, 187, 0), //renata gain hpf
            new Color( 0, 0, 0), // renata lost spec hpf
            new Color( 0, 128, 255)}, // renata inherited spec hpf
    };
    
    /**
     * 
     */
    public TreeColorSet(boolean use_colors)
    {
        if (use_colors) {
            setColors(0);
        } else {
            setBW();
        }
    }
    
    /*
     * The colors are read-only. 
     */
    public Color get_ext_node_seq_color() { return ext_node_seq_color; }
    public Color get_int_node_seq_color() { return int_node_seq_color; }
    public Color get_species_name_color() { return species_name_color; }
    public Color get_bootstrap_color()    { return bootstrap_color; }
    public Color get_ec_color()           { return ec_color; }
    public Color get_dub_spec_color()     { return dub_spec_color; }
    public Color get_branch_length_color(){ return branch_length_color; }
    public Color get_branch_color()       { return branch_color; }
    public Color get_box_color()          { return box_color; }
    public Color get_background_color()   { return background_color; }
    public Color get_dup_box_color()      { return dup_box_color; }
    public Color get_seq_x_color()        { return seq_x_color; }
    public Color get_collapse_fill_color(){ return collapse_fill_color; }
    public Color get_custom_data_color()  { return custom_data_color; }
    public Color get_found_color()        { return found_color; }
    public Color get_re_gain_color()      { return re_gain_color; }
    public Color get_re_lost_color()      { return re_lost_color; }
    public Color get_re_inherited_color()  { return re_inherited_color; }

 
    public int getCurrentColorScheme() {
        return color_scheme;
    }
    
    
    void setBW() {
        ext_node_seq_color = new Color( 0, 0, 0 );
        int_node_seq_color = new Color( 0, 0, 0 );
        species_name_color = new Color( 0, 0, 0 );
        bootstrap_color = new Color( 0, 0, 0 );
        ec_color = new Color( 0, 0, 0 );
        dub_spec_color = new Color( 0, 0, 0 );
        branch_length_color = new Color( 0, 0, 0 );
        branch_color = new Color( 0, 0, 0 );
        box_color = new Color( 0, 0, 0 );
        dup_box_color = new Color( 0, 0, 0 );
        background_color = new Color( 255, 255, 255 );
        seq_x_color = new Color( 0, 0, 0 );
    }
    
    
    /**
     * Switches colors between different schemes.
     */
    void setColors( int scheme ) {
        color_scheme = scheme;
        
        ext_node_seq_color = color_schemes[ scheme ][ 0 ];
        int_node_seq_color = color_schemes[ scheme ][ 1 ];
        species_name_color = color_schemes[ scheme ][ 2 ];
        bootstrap_color = color_schemes[ scheme ][ 3 ];
        ec_color = color_schemes[ scheme ][ 4 ];
        dub_spec_color = color_schemes[ scheme ][ 5 ];
        branch_length_color = color_schemes[ scheme ][ 6 ];
        branch_color = color_schemes[ scheme ][ 7 ];
        box_color = color_schemes[ scheme ][ 8 ];
        background_color = color_schemes[ scheme ][ 9 ];
        dup_box_color = color_schemes[ scheme ][ 10 ];
        seq_x_color = color_schemes[ scheme ][ 11 ];
        collapse_fill_color = color_schemes[ scheme ][ 12 ];
        found_color = color_schemes[ scheme ][ 13 ];
        custom_data_color = color_schemes[ scheme ][ 14 ];
        re_gain_color = color_schemes[ scheme ][ 15 ];
        re_lost_color = color_schemes[ scheme ][ 16 ];
        re_inherited_color = color_schemes[ scheme ][17];
    }//switchColors
    
}
