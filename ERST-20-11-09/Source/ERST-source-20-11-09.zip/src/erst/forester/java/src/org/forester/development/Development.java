/*
 * Copyright 2005 Christian M. Zmasek, Ethalinda K.S. Cannon
 * 
 * Created on Oct 3, 2005. 
 * 
 * $Id: Development.java,v 1.1 2005/12/04 03:43:16 cmzmasek Exp $
 */
package erst.forester.java.src.org.forester.development;

/**
 * @author Christian M. Zmasek
 */
final public class Development {

    public static boolean isDebug() {
        return _debug;
    }

    public static void setDebug( boolean debug ) {
        _debug = debug;
    }

    public static boolean isTime() {
        return _time;
    }

    public static void setTime( boolean time ) {
        _time = time;
    }

    private Development() {
    }

    private static boolean _debug = false;
    private static boolean _time  = false;

}
