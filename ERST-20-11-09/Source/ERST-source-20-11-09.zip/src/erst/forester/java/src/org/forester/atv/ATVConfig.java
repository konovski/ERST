package erst.forester.java.src.org.forester.atv;

/*
 * Author:  Ethy Cannon
 *          ethy@a415software.com
 * 
 * Created: 11-26-05
 *
 * Purpose: Maintains the contents of the config file.
 *
 *          Settings may be overridden from outside class.
 *          
 *          Because of not supporting config file, render it useless (Petar).
 */


import java.awt.Color;
import java.util.*;
import java.io.*;
import java.net.*;


public class ATVConfig {
    //---------------------------------
    // Pertaining to the config itself
    //---------------------------------
    
    // Can config file be written?
    boolean config_writeable;
    
    // Full path to config (may be URL)
    String config_filename;
    String default_config_filename = "ATVConfig.conf";


    //---------------------------
    // Display options for trees
    //---------------------------

    // Is tree editable?
    boolean tree_editable = true;
    
    public final static int use_real_br_lengths       = 0;
    public final static int seq_name_internal_nodes   = 1;
    public final static int seq_name_ext_nodes        = 2;
    public final static int species_internal_nodes    = 3;
    public final static int species_ext_nodes         = 4;
    public final static int ec_internal_nodes         = 5;
    public final static int ec_ext_nodes              = 6;
    public final static int write_br_length_values    = 7;
    public final static int write_bootstrap_values    = 8;
    public final static int write_dup_spec            = 9;
    public final static int color_orthologous         = 10;
    public final static int color_super_orthologous   = 11;
    public final static int color_subtree_neighbors   = 12;
    public final static int color_according_to_species = 13;
    public final static int color_branches            = 14;
    public final static int width_branches            = 15;
    public final static int mark_nodes_with_box       = 16;
    
    String display_options[][] = {
      {"real branch lengths",     "display",   "no"},
      {"seq name int nodes",      "display",   "no"},
      {"species' names (leaves)",      "display",   "yes"}, // used to be {"seq name leaves",      "display",   "yes"},
      {"species int nodes",       "nodisplay", "no"},
      {"seq name leaves",       "display",   "no"}, //used to be {"species leaves",       "display",   "no"},
//      {"int EC names",            "display",  "yes"},
//      {"ext EC names",            "display",  "yes"},
      {"gains & losses int nodes",      "display",  "yes"},
      {"gains & losses leaves",      "display",  "yes"},
      {"branch length values",    "display",   "no"},
      {"bootstrap values",        "display",   "no"},
      {"write_dup_spec",          "nodisplay", "no"},
      {"display orthology",       "nodisplay", "no"},
      {"display s-orthology",     "nodisplay", "no"},
      {"display subtr-neighbors", "nodisplay", "no"},
      {"color species",           "display",   "no"},
      {"color branches",          "nodisplay", "no"},
      {"width branches",          "nodisplay", "no"},
      {"show node boxes",         "display",   "yes"}};
    public final static int display_genomes   = 0; //5;

    //added by Renata
    public final static int display_hpfs = 1;
    public final static int display_root_hpfs = 2;
//    
    String clickto_options[][] = {
      
    // added by Renata
      {"DISPLAY GENOMES",       "display"},
      {"DISPLAY GAINS/LOSSES",          "display"}
      // , {"DISPLAY GAINS/LOSSES AT ROOT",          "display"} Excluded by Petar.
      };
      
    
    // This option is selected in the drop-down
    int default_clickto = display_hpfs;// display_genomes;// edit_info; display_hpfs; // 
      
    
    
    //--------------
    // Colour set
    //--------------
    TreeColorSet tree_color_set;
    
    
    //-------
    // Fonts
    //-------
    TreeFontSet tree_font_set; 
    
    
    //----------------
    // Species colours
    //----------------
    Hashtable species_colors = new Hashtable();

    
    //---------------------------
    // applet-only pop-up options
    //---------------------------
    String node_popup_title;
    String node_popup_URL;
    String sequence_popup_URL;

    
    //------------
    // Glyph type
    //------------
    public final static int glyph_none  = 0;
    public final static int glyph_expression  = 1;
    public final static int glyph_chromosome  = 2;
    int glyph_type = glyph_none;
    
    
    
    
      public ATVConfig(String cf, boolean is_url, boolean is_applet) {
        if (cf == null || cf.length() == 0) {
            config_filename = default_config_filename;
        } else {
            config_filename = cf;
        }
        config_filename = config_filename.trim();
        
        // If URL, open accordingly
        URL u = null;
        if (is_url) {
            try {
                u = new URL(config_filename);
                try {
                    InputStreamReader isr = new InputStreamReader(u.openStream());
                    BufferedReader bf = new BufferedReader( isr );
                    readConfig(bf);
                    bf.close();
                } catch (Exception e) {
                    System.out.println("Exception encountered while opening read stream for config file, "+config_filename+": "+e.toString());
                }
            } catch (Exception e) {
                System.out.println("Cannot find or open config url, "+this.config_filename);
            }
          
        // Otherwise, open as a file
        } else { 
            File f = new File(config_filename);
            //String path = f.getAbsolutePath(); Not used (Petar)
            if (f.exists() && f.canRead()) {
                try {
                    BufferedReader bf = new BufferedReader(new FileReader(f));
                    readConfig(bf);
                    bf.close();
                } catch (Exception e) {
                    System.out.println("Exception encountered while opening read stream for config file, " + this.config_filename+": "+e.toString());
                }
            }
            /*  Because of not supporting config file, comment it off (Petar).
            else {
                System.out.println("Cannot find or read config file, "+f.getAbsolutePath());
            }
            */
        }
        
        // Make sure the settings don't contradict each other
//        sanityCheck(is_applet);
    } // End of public ATVConfig(String cf, boolean is_url, boolean is_applet)
    
    
    public boolean doCheckOption(int which) {
        return display_options[which][2].equals("yes");
    }
    

    public boolean doDisplayClickToOption(int which) {
        return clickto_options[which][1].equals("display");
    }
    
    
    public boolean doDisplayOption(int which) {
        return display_options[which][1].equals("display");
    }
    
    
    private int getClickToIndex(String name) {
        int index = -1;

        if (name.equals("display_genomes")) {
        	index = display_genomes;
        } 
        //added by Renata
        else if (name.equals("display_hpfs")) {
            index = display_hpfs;
        }
        else if (name.equals("display_root_hpfs")) {
            index = display_root_hpfs;
        }
     
        return index;
    }
    
    /* Commented off - not used (Petar).
    public int getClickToOptionsCount() {
        return clickto_options.length;
    }
    */
    
    public String getClickToTitle(int which) {
        return clickto_options[which][0];
    }
    
    
    public int getDefaultDisplayClicktoOption() { 
        return default_clickto;
    }
    
    
    public String getDisplayNodePopupTitle() {
        return node_popup_title;
    }
    
    
    public String getDisplayTitle(int which) {
        return display_options[which][0];
    }
    
    
    public int getGlyphType() {
        return glyph_type;
    }
    
    
    public String getNodePopupURL() {
        return node_popup_URL;
    }
    
    
    public String getSequencePopupURL() {
        return sequence_popup_URL;
    }
    
    //public Hashtable getSpeciesColors() {  An attempt to clear the warnings (Petar).
    public Hashtable<?,?> getSpeciesColors() { 
    	return species_colors; 
    }
    
    /* Not used. (Petar)
    public TreeColorSet getTreeColorSet() { return null; }
    public TreeFontSet getTreeFontSet() { return null; }
    */
    
    public boolean isTreeEditable() {
        return tree_editable;
    }
    
    
    /**
     * read each line of config file, process non-comment lines
     */
    private void readConfig(BufferedReader conf_in) {
        try {
            String line;
            do {
                line = conf_in.readLine();
                if (line != null) {
                    line = line.trim();
                    // skip comments and blank lines
                    if (!line.startsWith("#") && line.length() != 0) {
                        // convert runs of spaces to tabs
                        line = line.replaceAll("\\s+", "\t");
                        StringTokenizer st = new StringTokenizer(line, "\t");
                        setKeyValue(st);
                    }
                }
            } while (line != null);
        } catch (Exception e) {
            System.out.println("Exception while reading config file: "+e.toString());
        }
    } // End of private void readConfig(BufferedReader conf_in) 
    
    
    /**
     * Set a key-value(s) tuple
     */
    private void setKeyValue(StringTokenizer st) {
        String key = (String)st.nextElement();
        key = key.replace(':', ' ');
        key = key.trim();
     
        // Handle single value settings first:
        if (key.equals("editable")) {
            tree_editable = ((String)st.nextElement()).equals("yes");
        } else if (key.equals("sequence_popup_URL")) {
            if (st.hasMoreElements()) 
                sequence_popup_URL = (String)st.nextElement();
        } else if (key.equals("node_popup_URL")) {
            if (st.hasMoreElements()) 
                node_popup_URL = (String)st.nextElement();
        } else if (key.equals("node_popup_title")) {
            // A bit complicated: may have multiple words
            node_popup_title = "";
            while (st.hasMoreElements()) {
                node_popup_title += (String)st.nextElement()+" ";
            }
            node_popup_title = node_popup_title.replaceAll("\"", "");
            node_popup_title = node_popup_title.trim();
        
        } 
        else if (key.equals("default_click_to")) {
            String clickto_name = (String)st.nextElement();
            default_clickto = getClickToIndex(clickto_name);
            if (default_clickto == -1) {
                System.out.println("Invalid default clickto name: "+clickto_name);
                default_clickto = 0;
           }
        } 

        else if (st.countTokens() >= 2) {  // counts the tokens that are not yet retrieved!
            int key_index = -1;
            /* Commented off, because are not used. (Petar)
            if (key.equals("use_real_br_lengths")) {
                key_index = use_real_br_lengths;
            } else if (key.equals("color_according_to_species")) {
                key_index = color_according_to_species;
            } else if (key.equals("seq_name_ext_nodes")) {
                key_index = seq_name_ext_nodes;
            } else if (key.equals("seq_name_internal_nodes")) {
                key_index = seq_name_internal_nodes;
            } else if (key.equals("species_internal_nodes")) {
                key_index = species_internal_nodes;
            } else if (key.equals("write_br_length_values")) {
                key_index = write_br_length_values;
            } else if (key.equals("write_bootstrap_values")) {
                key_index = write_bootstrap_values;
            } else if (key.equals("write_dup_spec")) {
                key_index = write_dup_spec;
            } else if (key.equals("color_branches")) {
                key_index = color_branches;
            } else if (key.equals("width_branches")) {
                key_index = width_branches;
            } else if (key.equals("color_orthologous")) {
                key_index = color_orthologous;
            } else if (key.equals("color_subtree_neighbors")) {
                key_index = color_subtree_neighbors;
            } else if (key.equals("color_super_orthologous")) {
                key_index = color_super_orthologous;
            */
            if (key.equals("species_ext_nodes")) {
                key_index = species_ext_nodes;
            } else if (key.equals("width_branches")) {
                key_index = width_branches;
            } else if (key.equals("ec_ext_nodes")) {
                key_index = ec_ext_nodes;
            } else if (key.equals("ec_internal_nodes")) {
                key_index = ec_internal_nodes;
            } else if (key.equals("mark_nodes_with_box")) {
                key_index = mark_nodes_with_box;
            }
            
            // If we've found the key, set the values
            if (key_index >= 0) {
                display_options[key_index][1] = (String)st.nextElement();
                display_options[key_index][2] = (String)st.nextElement();
            
            // otherwise, keep looking
            } else {
                
                // Handle click-to options
                if (key.equals("click_to")) {
                    String click_to_name = (String)st.nextElement();
                    key_index = getClickToIndex(click_to_name);
                    if (key_index >= 0) {
                        clickto_options[key_index][1] = (String)st.nextElement();
                    } else {
                        System.out.println("Unknown click-to option: "+click_to_name);
                    }

                
                // Species colours
                } else if (key.equals("species_color")) {
                    species_colors.put(st.nextElement(), Color.decode((String)st.nextElement()));
                
                // Unknown config key
                } else {
                    System.out.println("Unknown config key: "+key);
                }
            }
        } else {
            System.out.println("Unknown config key: "+key);
        }
    }
} //End of public class ATVConfig.
