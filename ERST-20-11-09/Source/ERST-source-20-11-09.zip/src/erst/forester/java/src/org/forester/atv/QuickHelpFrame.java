package erst.forester.java.src.org.forester.atv;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Displays pop-up help. Useful for small help items.
 */
public class QuickHelpFrame extends JDialog
    implements ActionListener {
    JButton     closebtn;
    

    /**
     * Constructor
     * @param owner the Frame that owns this pop-up
     * @param help_name ID for the help string
     * @param help_title title for the id string 
     *                   (which may vary for the same control depending 
     *                    on configuration XML)
     */
    public QuickHelpFrame( Frame owner, String help_name, String help_title ) {
    super(owner,
          "Help", 
          true,             // dialog is modal
          owner.getGraphicsConfiguration());
        
        int width = 250;
        int height = 200;
        setSize( width, height );
        
        Container cp = getContentPane();
        cp.setLayout(new BorderLayout(4, 5));
        
        
        // The help item
        String help_str = getHelp(help_name);    // sets help_title and help_str
        JLabel help_item_title = new JLabel(help_title);
        //help_item_title.setFont(new Font("Sans Serif", Font.BOLD, 12)); Change the font size to 14. (Petar)
        help_item_title.setFont(new Font("Sans Serif", Font.BOLD, 14));
        help_item_title.setBackground(getBackground());
        help_item_title.setHorizontalAlignment(SwingConstants.CENTER);
        cp.add(help_item_title, "North");
       
        // The help text
        JTextPane tp = new JTextPane();
        //tp.setFont(new Font("Sans Serif", Font.PLAIN, 12)); Change the font size to 14. (Petar)
        tp.setFont(new Font("Sans Serif", Font.PLAIN, 14));
        tp.setBackground(getBackground());
        tp.setEnabled(false);
        tp.setText(help_str);
        cp.add(new JScrollPane( tp ), "Center");
        
        // The button panel
        JPanel btn_panel = new JPanel(); 
        closebtn = new JButton("Close");
        closebtn.addActionListener(this);
        btn_panel.add(closebtn);
        cp.add(btn_panel, "South");
    }

    /**
     * Handle the close button.
     * @param e the close-button action
     */
    public void actionPerformed( ActionEvent e ) {
        Object o = e.getSource();
        if (o == closebtn) {
            //hide(); Obsolete, replaced with setVisible(false). (Petar)
            setVisible(false);
            
        }
    }
    
    /**
     * Set the help string
     * @param help_name ID for help item
     */
    private String getHelp(String help_name) {
        String help_str = "";
        
        if ( help_name.equals("userealbl") ) {
            help_str = "If checked, display actual branch lengths. "
                     + "If unchecked, display all branches the same length.";
        } else if ( help_name.equals("color_branches") ) {
            help_str = "If checked, branch colors are displayed. These colors " 
                     + "must be included in the data."; 
        } else if ( help_name.equals("width_branches") ) {
            help_str = "If checked, branch widths are displayed. These widths "
                     + "must be included in data. If not clicked, all branches "
                     + "are the same width."; 
        } else if ( help_name.equals("writebl") ) {
            help_str = "If checked, branch distance values are displayed. Branch "
                     + "distance values must be included in the data.";
        } else if ( help_name.equals("seqnameextnodes") ) {
                help_str = "If checked, species' names are displayed on leaves. "
                     + "Species names must be included in the data.";
        } else if ( help_name.equals("seqnameintnodes") ) {
            help_str = "If checked, sequence names are displayed on internal nodes. " 
                     + "Internal sequence names must be included in the data.";
        } else if ( help_name.equals("speciesextnodes") ) {
            help_str = "If checked, sequence names are displayed on leaves.";
        } else if ( help_name.equals("speciesintnodes") ) {
            help_str = "If checked, species' names are displayed on internal nodes. "
                     + "Internal species' names must be included in the data.";
        } else if ( help_name.equals("color_acc_species") ) {
            help_str = "If checked, color text by species. Species data must be "
                     + "included in the data."; 
        } else if ( help_name.equals("ecintnodes") ) {
            help_str = "If checked, gains and losses are displayed on internal nodes. "
                     + "gains and losses are included in the data once"
                     + "the reconstruction algorithm is executed.";
        } else if ( help_name.equals("ecextnodes") ) {
            help_str = "If checked, gains and losses are displayed on leaves. "
                     + "gains and losses numbers are included in the data once "
                     + "reconstruction algorithm is executed.";
        } else if ( help_name.equals("writebootstrap") ) {
            help_str = "If checked, bootstrap values are displayed if found in "
                     + "the data.";
        } else if ( help_name.equals("writed_s") ) {
            help_str = "If checked, display duplication and speciation events.";
        } else if ( help_name.equals("color_orthos") ) {
            help_str = "If checked, highlight orthologous sequences."; 
        } else if ( help_name.equals("color_super_orthos") ) {
            help_str = "If checked, highlight sequences that are super-orthologous. "
                     + "Two sequences are super orthologous if, given a rooted "
                     + "tree with duplication or speciation events assigned to "
                     + "each of its internal nodes, two sequences are "
                     + "super-orthologous if and only if each internal node on "
                     + "their connecting path represents a speciation event. "; 
        } else if ( help_name.equals("color_sn") ) {
            help_str = "If checked, highlight sub-tree neighbors. Sub-tree neighbors "
                     + "are defined as follows: given a completely binary and "
                     + "rooted gene tree, the k-subtree-neighbors of a sequence "
                     + "q are defined as all sequences derived from the k-level "
                     + "parent node of q, except q itself (the level of q itself "
                     + "is 0, q's parent is 1, and so forth)."; 
        } else if ( help_name.equals("editable") ) {
            help_str = "If checked, node information is editable. Select "
                     + "\"display editable data\" from dropdown below \"click "
                     + "on node to:\""; 
        } else if ( help_name.equals("mark_nodes_with_box") ) {
            help_str = "If checked, nodes are indicated with a small box."; 
        } else {
            help_str = "No help available";
        }
        
        return help_str;
    }
    
}
