package erst.forester.java.src.org.forester.atv;
import java.awt.*;

import java.awt.*;

/**
 * Maintains the fonts for drawing a tree.
 */
public class TreeFontSet {
    // the owner (needed to get font metrics)
    public Component           owner;
    
    // The fonts
    public Font                small_font;
    public Font                large_font;
    public Font                small_italic_font;
    public Font                large_italic_font;
    
    // Handy holders for font metrics
    public FontMetrics         fm_small;
    public FontMetrics         fm_large;
    public FontMetrics         fm_small_italic;
    public FontMetrics         fm_large_italic;

    // hold font measurements
    public int                 small_maxDescent           = 0;
    public int                 small_maxAscent            = 0;

    public TreeFontSet(Component owner)
    {
        this.owner = owner;
        
        // default font set:
        mediumFonts();
    }

    /**
     * Large size.
     */
    public void largeFonts() {
    	/* Let us choose a little bigger fonts. (Petar)
        small_font = new Font( "Helvetica", Font.PLAIN, 13 );
        large_font = new Font( "Helvetica", Font.PLAIN, 13 );
        small_italic_font = new Font( "Helvetica", Font.ITALIC, 13 );
        large_italic_font = new Font( "Helvetica", Font.ITALIC, 13 );
        */
        small_font = new Font( "Helvetica", Font.PLAIN, 14 );
        large_font = new Font( "Helvetica", Font.PLAIN, 14 );
        small_italic_font = new Font( "Helvetica", Font.ITALIC, 14 );
        large_italic_font = new Font( "Helvetica", Font.ITALIC, 14 );
        
        fm_small = owner.getFontMetrics( small_font );
        fm_large = owner.getFontMetrics( large_font );
        fm_small_italic = owner.getFontMetrics( small_italic_font );
        fm_large_italic = owner.getFontMetrics( large_italic_font );
        
        small_maxDescent = fm_small.getMaxDescent();
        small_maxAscent = fm_small.getMaxAscent() + 2;
    }//largeFonts
    
    
     /**
     * Medium size.
     */
    public void mediumFonts() {
        small_font = new Font( "Helvetica", Font.PLAIN, 10 );
        large_font = new Font( "Helvetica", Font.PLAIN, 11 );
        small_italic_font = new Font( "Helvetica", Font.ITALIC, 10 );
        large_italic_font = new Font( "Helvetica", Font.ITALIC, 11 );
        
        fm_small = owner.getFontMetrics( small_font );
        fm_large = owner.getFontMetrics( large_font );
        fm_small_italic = owner.getFontMetrics( small_italic_font );
        fm_large_italic = owner.getFontMetrics( large_italic_font );
        
        small_maxDescent = fm_small.getMaxDescent();
        small_maxAscent = fm_small.getMaxAscent() + 2;
    }//mediumFonts
    
    
   /**
     * Small size.
     */
    public void smallFonts() {
        small_font = new Font( "Helvetica", Font.PLAIN, 9 );
        large_font = new Font( "Helvetica", Font.PLAIN, 10 );
        small_italic_font = new Font( "Helvetica", Font.ITALIC, 9 );
        large_italic_font = new Font( "Helvetica", Font.ITALIC, 10 );
        
        fm_small = owner.getFontMetrics( small_font );
        fm_large = owner.getFontMetrics( large_font );
        fm_small_italic = owner.getFontMetrics( small_italic_font );
        fm_large_italic = owner.getFontMetrics( large_italic_font );
        
        small_maxDescent = fm_small.getMaxDescent();
        small_maxAscent = fm_small.getMaxAscent() + 1;
    }//smallFonts
    
    
    /**
     * Tiny size.
     */
    public void tinyFonts() {
        small_font = new Font( "Helvetica", Font.PLAIN, 8 );
        large_font = new Font( "Helvetica", Font.PLAIN, 8 );
        small_italic_font = new Font( "Helvetica", Font.ITALIC, 8 );
        large_italic_font = new Font( "Helvetica", Font.ITALIC, 8 );
        
        fm_small = owner.getFontMetrics( small_font );
        fm_large = owner.getFontMetrics( large_font );
        fm_small_italic = owner.getFontMetrics( small_italic_font );
        fm_large_italic = owner.getFontMetrics( large_italic_font );
        
        small_maxDescent = fm_small.getMaxDescent();
        small_maxAscent = fm_small.getMaxAscent() + 1;
    }//tinyFonts

}
