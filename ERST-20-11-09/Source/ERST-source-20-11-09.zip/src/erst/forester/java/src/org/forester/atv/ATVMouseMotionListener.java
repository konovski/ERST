// ATVMouseMotionListener
//
// Created 2004 by eksc to help set cursors over "hot" areas.

package erst.forester.java.src.org.forester.atv;

import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseEvent;


class ATVMouseMotionListener extends MouseMotionAdapter {

    private ATVtreePanel atvtreepanel;

    public ATVMouseMotionListener( ATVtreePanel tp ) {
        atvtreepanel = tp;
    }

    public void mouseDragged( MouseEvent e ) {
    }

    public void mouseMoved( MouseEvent e ) {
        atvtreepanel.mouseMoved( e );
    }
}

