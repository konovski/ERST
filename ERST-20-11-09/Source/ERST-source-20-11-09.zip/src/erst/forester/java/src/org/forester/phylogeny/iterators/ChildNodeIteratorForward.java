/*
 * Created on Oct 23, 2005 TODO To change the template for this generated file
 * go to Window - Preferences - Java - Code Style - Code Templates
 */
package erst.forester.java.src.org.forester.phylogeny.iterators;

import java.util.NoSuchElementException;

import erst.forester.java.src.org.forester.phylogeny.PhylogenyNode;

/**
 * An iterator to forward iterate over child nodes of a PhylogenyNode. Created:
 * 10/23/2005 by Christian M. Zmasek. Last modified: 10/23/2005 by Christian M.
 * Zmasek.
 * 
 * @author Christian M. Zmasek
 * @version 1.000
 */
public class ChildNodeIteratorForward implements PhylogenyNodeIterator {

    // Constructor
    // -----------

    /**
     * Creates a new ChildNodeIteratorForward.
     * 
     * @param node
     *            the parent of the PhylogenyNodes to iterate over.
     * @throws IllegalArgumentException
     *             if node has no child nodes
     */
    public ChildNodeIteratorForward( final PhylogenyNode node )
            throws IllegalArgumentException {
        if ( node.getNumberOfChildNodes() < 1 ) {
            throw new IllegalArgumentException(
                    "Attempt to use ChildNodeIteratorForward on node with no child nodes." );
        }

        _node = node;
        reset();
    }

    // Public methods
    // --------------

    /**
     * Returns true is this iterator has at least one more element, false
     * otherwise.
     * 
     * @return true is this iterator has at least one more element, false
     *         otherwise
     */
    public boolean hasNext() {
        return ( getI() < getNode().getNumberOfChildNodes() );
    }

    /**
     * Returns the next PhylogenyNode.
     * 
     * @return the next PhylogenyNode
     * @throws NoSuchElementException
     *             if iteration is complete
     */
    public PhylogenyNode next() throws NoSuchElementException {
        if ( !hasNext() ) {
            throw new NoSuchElementException(
                    "Attempt to call \"next()\" on iterator which has no more next elements." );
        }

        final PhylogenyNode n = getNode().getChildNode( getI() );
        increaseI();

        return n;
    }

    /**
     * Resets the iterator.
     */
    public void reset() {
        setI( 0 );
    }

    // Private methods
    // ---------------

    /**
     * Returns the counter.
     */
    private int getI() {
        return _i;
    }

    /**
     * Sets the counter.
     */
    private void setI( int i ) {
        _i = i;
    }

    /**
     * Increases the counter by one.
     */
    private void increaseI() {
        ++_i;
    }

    /**
     * Returns the parent of the nodes to iterate over.
     * 
     * @return the parent of the nodes to iterate over.
     */
    private PhylogenyNode getNode() {
        return _node;
    }

    // Instance variables
    // ------------------
    private int                 _i;
    final private PhylogenyNode _node;

} // end of class ChildNodeIteratorForward.
