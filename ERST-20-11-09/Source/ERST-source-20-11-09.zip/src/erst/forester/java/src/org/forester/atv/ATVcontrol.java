// ATVcontrol.java
//
// Copyright (C) 1999-2002 Washington University School of Medicine
// and Howard Hughes Medical Institute
// All rights reserved
//
// Created: 1999
// Author: Christian M. Zmasek
// zmasek@genetics.wustl.edu
// http://www.genetics.wustl.edu/eddy/people/zmasek/
//
// Restructued: 2004
// Ethy Cannon
// ethy@a415software.com
// Modified by Renata and Petar:2008 - 2016

package erst.forester.java.src.org.forester.atv;
import java.util.Hashtable;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
//import javax.swing.event.*; Not used (Petar)

import erst.forester.java.src.org.forester.phylogeny.*;

//import javax.swing.JFrame; Not used (Petar)

//import PMCLASSES.readGL;
//import erst.windowtree; Not used (Petar)

/**
 * @author Christian M. Zmasek
 * @version 1.201 -- last modified: 02/05/04
 * @version 1.1 -- 8/9/04 -- eksc Controls are configurable. Removed
 *          redundancies in ATVcontrol and ATVcontrol_applet.
 * @version 1.2 -- 11/28/05 -- eksc changed from XML to key-value config file format,
 *                            new layout and controls.
 */

class ATVcontrol extends JPanel  implements ActionListener {
    
    ATVrootHPFPanel atvroothpfpanel; 
    // ATVtreePanel and ATVcontrol need peer pointers to each other
    ATVtreePanel      atvtreepanel;
    
    // Handy for communication back to parental components:
    ATVpanel          atvpanel;
    
    // The settings from the conf file
    ATVConfig         config_settings;

    // Tree checkboxes
    JCheckBox         userealbl, seqnameextnodes, seqnameintnodes,
            speciesextnodes, speciesintnodes, ecintnodes, ecextnodes, write_b_l,
            writebootstrap, write_d_s, color_orthos, color_super_orthos,
            color_s_n, color_acc_species, editable, color_branches,
            width_branches, mark_nodes_with_box; //, root_gains_losses; //, gainintnodes, gainextnodes, 
       //     lossintnodes, lossextnodes;

    // Help buttons for checkboxes
    JButton           userealbl_help, seqnameextnodes_help, seqnameintnodes_help,
            speciesextnodes_help, speciesintnodes_help, ecintnodes_help, 
            ecextnodes_help, writebl_help, writebootstrap_help, 
            writed_s_help, color_orthos_help, color_super_orthos_help,
            color_sn_help, color_acc_species_help, editable_help, 
            color_branches_help, width_branches_help,  
            mark_nodes_with_box_help; //, root_gains_losses_help; //, gainintnodes_help, gainextnodes_help, 
   //         lossintnodes_help, lossextnodes_help;
            
    // Custom data
    JButton           custom_data_btn;
    JPopupMenu        custom_data_menu;
    Hashtable         custom_tags = new Hashtable();

    // click on node to:
    boolean           multiselect = false;  // true if more than one node selected
    JLabel            click_to;
    JComboBox         click_to_list;
    // Hashes to associate menu titles with menu names (latter can be changed via XML)
    Hashtable         all_click_to_names;
    // Lists of option names allowed for single or multiple nodes
    Vector            single_click_to_names;
    Vector            multiple_click_to_names;
    // Indices for the click-to options in the combo box
//    int              edit_cb_item; 
    // added by Renata
    int              display_node_sequences_cb_item, display_node_hpfs_cb_item, display_root_hpfs_cb_item;
//     collapse_cb_item, reroot_cb_item, custom_option_cb_item, 
//                     display_node_glyph_info_cb_item, display_node_popup_cb_item, display_glyph_popup_cb_item
//            swap_cb_item, subtree_cb_item, , 
//            go_to_swissprot_cb_item, 

    int               num_click_to_opts;
    int               num_mult_click_to_opts;

    // zooming and quick tree manipulation buttons:
    JButton           zoom_in_x, zoom_in_y, zoom_out_x, zoom_out_y, show_whole, reload_tree;
//            order, uncollapse_all, collapse_to_deepest_annot, 

    boolean           order_of_appearance;

    //final static Font jcb_font      = new Font( "Helvetica", Font.PLAIN, 10 );
    //final static Font js_font       = new Font( "Helvetica", Font.PLAIN, 9 );
    //final static Font jcb_bold_font = new Font( "Helvetica", Font.BOLD, 10 );
    
    final static Font jcb_font      = new Font( "Helvetica", Font.PLAIN, 14 );
    final static Font js_font       = new Font( "Helvetica", Font.PLAIN, 13 );

    final static Font jcb_bold_font = new Font( "Helvetica", Font.BOLD, 14 );
    static Color      background_color, jcb_text_color, jcb_background_color,
            button_text_color, button_background_color;
            
    
    public void getRootGL() {
        atvroothpfpanel = new ATVrootHPFPanel();
        atvroothpfpanel.displayRootHPFInfo(0);
    }    
  

    /**
     * Default constructor.
     */
    ATVcontrol() {
    }
    

    /**
     * Constructor.
     */
    ATVcontrol( ATVpanel ap, ATVtreePanel atp, ATVConfig config_settings ) {
       
        this.atvpanel = ap;
        this.atvtreepanel = atp;
        this.config_settings = config_settings;

        setDefaultColors();

        setBackground( background_color );
        setBorder( BorderFactory.createRaisedBevelBorder() );

        setLayout( new GridLayout( 0, 1, 2, 2 ) );

        order_of_appearance = true;
        
        setupControls();
    }// constructor
    
      

    /**
     * Handle an action.
     */
    public void actionPerformed( ActionEvent e ) {
        
        ATVtreePanel tp = atvtreepanel;
        if (e.getSource() == click_to_list) {
            setClickToAction( click_to_list.getSelectedIndex() );        
            if ( click_to_list.getSelectedIndex() == 2 )
            {
                
//                 name_list.setText( list );
                //windowtree windT = new windowtree(); Not used anywhere (Petar)
                System.out.println(" ELEMENT NUMBER " + click_to_list.getSelectedIndex());
            }
        } else if ( e.getSource() == color_orthos ) {
            // turn off the other orthologous options
            setCheckbox( color_super_orthos, false );
            setCheckbox( color_s_n, false );
        } else if ( e.getSource() == color_super_orthos ) {
            setCheckbox( color_orthos, false );
            setCheckbox( color_s_n, false );
        } else if ( e.getSource() == color_s_n ) {
            setCheckbox( color_orthos, false );
            setCheckbox( color_super_orthos, false );
        } 
//        else if ( e.getSource() == root_gains_losses) { /// I put it here
////                atvroothpfpanel.displayRootHPFInfo(0);
//                  getRootGL();
//        }
        else if ( tp.getTree() != null ) {
            if ( e.getSource() == userealbl ) {
                // Fit tree into window if changing type of branch length display
                showWhole();
            }
            
            // Custom data tags
            if ( e.getSource() == custom_data_btn ) {
                custom_data_menu.show( this, custom_data_btn.getX(), 
                                             custom_data_btn.getY() );
            }
            
            // Zoom buttons
            else if ( e.getSource() == zoom_in_x ) {
                atvtreepanel.setXdistance(
                                ( int ) ( atvtreepanel.getXdistance() * 1.05 ) + 1 );

                atvtreepanel.setXcorrectionFactor(
                                atvtreepanel.getXcorrectionFactor() * 1.10 );
                atvtreepanel.resetPreferredSize();
            } else if ( e.getSource() == zoom_in_y ) {
                atvtreepanel.setYdistance(
                                ( int ) ( atvtreepanel.getYdistance() * 1.05 ) + 1 );
                atvtreepanel.resetPreferredSize();
            } else if ( e.getSource() == zoom_out_x ) {
                atvtreepanel.setXdistance(
                                ( int ) ( atvtreepanel.getXdistance() * 0.95 ) );
                atvtreepanel.setXcorrectionFactor(
                                atvtreepanel.getXcorrectionFactor() * 0.90 );
                atvtreepanel.resetPreferredSize();
            } else if ( e.getSource() == zoom_out_y ) {
                atvtreepanel.setYdistance(
                                ( int ) ( atvtreepanel.getYdistance() * 0.95 ) );
                atvtreepanel.resetPreferredSize();
            } else if ( e.getSource() == show_whole ) {
                showWhole();
                
            // Quick tree manipulation:
            } 
//            else if ( e.getSource() == order ) {
//                tp.getTree().orderAppearance( order_of_appearance );
//                order_of_appearance = !order_of_appearance;
//            } 
//            else if ( e.getSource() == uncollapse_all ) {
//                uncollapseAll( tp );
//            } 
//            else if ( e.getSource() == collapse_to_deepest_annot ) {
//                collapseToDeepestAnnot( tp );
//            } 
            
            else if ( e.getSource() == reload_tree ) {
                reloadTree();
            }
            
            // Help buttons:
            else if ( e.getSource() == userealbl_help) {
                showHelp( "userealbl", userealbl.getText() );
            }
            else if ( e.getSource() == writebl_help) {
                showHelp("writebl", write_b_l.getText());
            }
            else if ( e.getSource() == color_branches_help) {
                showHelp("color_branches", color_branches.getText());
            }
            else if ( e.getSource() == width_branches_help) {
                showHelp("width_branches", width_branches.getText());
            }
            else if ( e.getSource() == seqnameextnodes_help) {
                showHelp("seqnameextnodes", seqnameextnodes.getText());
            }
            else if ( e.getSource() == seqnameintnodes_help) {
                showHelp("seqnameintnodes", seqnameintnodes.getText());
            }
            else if ( e.getSource() == speciesextnodes_help) {
                showHelp("speciesextnodes", speciesextnodes.getText());
            }
            else if ( e.getSource() == speciesintnodes_help) {
                showHelp("speciesintnodes", speciesintnodes.getText());
            }
            else if ( e.getSource() == ecintnodes_help) {
                showHelp("ecintnodes", ecintnodes.getText());
            }
            else if ( e.getSource() == ecextnodes_help) {
                showHelp("ecextnodes", ecextnodes.getText());
            }
            else if ( e.getSource() == writebootstrap_help) { 
                showHelp("writebootstrap", writebootstrap.getText());
            }
            else if ( e.getSource() == writed_s_help) {
                showHelp("writed_s", write_d_s.getText());
            }
            else if ( e.getSource() == color_orthos_help) {
                showHelp("ecextnodes", color_orthos.getText());
            }
            else if ( e.getSource() == color_super_orthos_help) {
                showHelp("color_super_orthos", color_super_orthos.getText());
            }
            else if ( e.getSource() == color_sn_help) {
                showHelp("color_sn", color_s_n.getText());
            }
            else if ( e.getSource() == color_acc_species_help) {
                showHelp("color_acc_species", color_acc_species.getText());
            }
            else if ( e.getSource() == editable_help) {
                showHelp("ecexteditablenodes", editable.getText());
            }
            else if ( e.getSource() == mark_nodes_with_box_help) {
                showHelp("mark_nodes_with_box", mark_nodes_with_box.getText());
            }
//            else if ( e.getSource() == root_gains_losses_help) {
//                showHelp("root_gains_losses", root_gains_losses.getText());
//            }
//            // Start Renata's modification
//            else if ( e.getSource() == gainintnodes_help) {
//                showHelp("gainintnodes", gainintnodes.getText());
//            }
//            else if ( e.getSource() == gainextnodes_help) {
//                showHelp("gainextnodes", gainextnodes.getText());
//            }
//            else if ( e.getSource() == lossintnodes_help) {
//                showHelp("lossintnodes", lossintnodes.getText());
//            }
//            else if ( e.getSource() == lossextnodes_help) {
//                showHelp("lossextnodes", lossextnodes.getText());
//            }
//            // end Renata's modification
            atvpanel.adjustJScrollPane();
            atvtreepanel.repaint();
        }
    }//actionPerformed


    /**
     * add checkbox controls
     */
    protected void addCheckbox( int which, String title ) {
        JPanel ch_panel = new JPanel( new BorderLayout(0, 0) );
        switch (which) {
            case ATVConfig.use_real_br_lengths:
                userealbl = new JCheckBox( title );
                userealbl_help = new JButton("?");
                addJCB( userealbl, userealbl_help, ch_panel );
                add(ch_panel);
                break;
            case ATVConfig.color_according_to_species:
                color_acc_species = new JCheckBox( title );
                color_acc_species_help = new JButton("?");
                addJCB( color_acc_species, color_acc_species_help, ch_panel );
                add(ch_panel);
                break;
            case ATVConfig.seq_name_ext_nodes:
                seqnameextnodes = new JCheckBox( title );
                seqnameextnodes_help = new JButton("?");
                addJCB( seqnameextnodes, seqnameextnodes_help, ch_panel );
                add(ch_panel);
                break;
            case ATVConfig.seq_name_internal_nodes:
                seqnameintnodes = new JCheckBox( title );
                seqnameintnodes_help = new JButton("?");
                addJCB( seqnameintnodes, seqnameintnodes_help, ch_panel );
                add(ch_panel);
                break;
            case ATVConfig.species_ext_nodes:
                speciesextnodes = new JCheckBox( title );
                speciesextnodes_help = new JButton("?");
                addJCB( speciesextnodes, speciesextnodes_help, ch_panel );
                add(ch_panel);
                break;
            case ATVConfig.species_internal_nodes:
                speciesintnodes = new JCheckBox( title );
                speciesintnodes_help = new JButton("?");
                addJCB( speciesintnodes, speciesintnodes_help, ch_panel );
                add(ch_panel);
                break;
            case ATVConfig.ec_ext_nodes:
                ecextnodes = new JCheckBox( title );
                ecextnodes_help = new JButton("?");
                addJCB( ecextnodes, ecextnodes_help, ch_panel );
                add(ch_panel);
                break;
            case ATVConfig.ec_internal_nodes:
                ecintnodes = new JCheckBox( title );
                ecintnodes_help = new JButton("?");
                addJCB( ecintnodes, ecintnodes_help, ch_panel );
                add(ch_panel);
                break;
            case ATVConfig.write_br_length_values:
                write_b_l = new JCheckBox( title );
                writebl_help = new JButton("?");
                addJCB( write_b_l, writebl_help, ch_panel );
                add(ch_panel);
                break;
            case ATVConfig.write_bootstrap_values:
                writebootstrap = new JCheckBox( title );
                writebootstrap_help = new JButton("?");
                addJCB( writebootstrap, writebootstrap_help, ch_panel );
                add(ch_panel);
                break;
            case ATVConfig.write_dup_spec:
                write_d_s = new JCheckBox( title );
                writed_s_help = new JButton("?");
                addJCB( write_d_s, writed_s_help, ch_panel );
                add(ch_panel);
                break;
            case ATVConfig.color_branches:
                color_branches = new JCheckBox( title );
                color_branches_help = new JButton("?");
                addJCB( color_branches, color_branches_help, ch_panel );
                add(ch_panel);
                break;
            case ATVConfig.width_branches:
                width_branches = new JCheckBox( title );
                width_branches_help = new JButton("?");
                addJCB( width_branches, width_branches_help, ch_panel );
                add(ch_panel);
                break;
            case ATVConfig.color_orthologous:
                color_orthos = new JCheckBox( title );
                color_orthos_help = new JButton("?");
                addJCB( color_orthos, color_orthos_help, ch_panel );
                add(ch_panel);
                break;
            case ATVConfig.color_super_orthologous:
                color_super_orthos = new JCheckBox( title );
                color_super_orthos_help = new JButton("?");
                addJCB( color_super_orthos, color_super_orthos_help, ch_panel );
                add(ch_panel);
                break;
            case ATVConfig.color_subtree_neighbors:
                color_s_n = new JCheckBox( title );
                color_sn_help = new JButton("?");
                addJCB( color_s_n, color_sn_help, ch_panel );
                add(ch_panel);
                break;
            case ATVConfig.mark_nodes_with_box:
                mark_nodes_with_box = new JCheckBox( title );
                mark_nodes_with_box_help = new JButton("?");
                addJCB( mark_nodes_with_box, mark_nodes_with_box_help, ch_panel );
                add(ch_panel);
                break;

            default:
                System.out.println( "Unknown checkbox: " + which );
        }
    }//addCheckbox


    
    private void addClickToOption(int which, String title) {
        click_to_list.addItem(title);
        single_click_to_names.add(title);
        all_click_to_names.put(new Integer(which), title);
    }//addClickToOption
        

    /**
     * 
     */
    protected void addCustomControls() {
        custom_data_menu = new JPopupMenu();
        
        // Internal ActionListener class for handling menu checkboxes
        ActionListener customMenuItemListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JCheckBoxMenuItem cbmi = (JCheckBoxMenuItem)e.getSource();
                String cmd = cbmi.getActionCommand();
                custom_tags.put(cmd, new Boolean(cbmi.isSelected()));
                atvpanel.adjustJScrollPane();
                atvtreepanel.repaint();
            }
        };
        
        // Fill the pop-up menu from the custom tags (if any)
        Phylogeny tree = atvtreepanel.getTree();
        if (tree != null) {
            if (!tree.isEmpty()
                    && tree.getCustomTagNames() != null
                    && tree.getCustomTagNames().size() > 0) {
                // There is custom data for this tree, so tell 
                //   display options and enable button
//                display_options.setWriteCustomData(true);
                custom_data_btn.setEnabled(true);
                // Get all custom tags and add to popup menu
                for ( Enumeration e = tree.getCustomTagNames().keys(); 
                        e.hasMoreElements(); ) {
                    String tag_name = ( String ) e.nextElement();
                    JCheckBoxMenuItem custom_item 
                        = new JCheckBoxMenuItem( tag_name );
                    custom_item.addActionListener(customMenuItemListener);
                    custom_data_menu.add(custom_item);
                }
            }
        }
    }//addCustomControls
    
    
    /**
     * Set up and add this button
     */
    protected void addJB( JButton jb, JPanel p ) {
        jb.setBorder( BorderFactory.createRaisedBevelBorder() );
        jb.setBackground( button_background_color );
        jb.setForeground( button_text_color );
        jb.setFont( jcb_font );
        p.add( jb );
        jb.addActionListener( this );
    }//addJB
    
    
    /**
     * Set up and add this check box
     */
    protected void addJCB( JCheckBox jcb, JButton b, JPanel p ) {
        jcb.setBackground( jcb_background_color );
        jcb.setForeground( jcb_text_color );
        jcb.setFont( jcb_font );
        p.add( jcb, "Center" );
        b.setMargin( new Insets(1, 1, 1, 1) );
        b.addActionListener(this);
        b.setBounds(0, 0, 20, 20);
        b.setSize(new Dimension(20, 20));
        b.setPreferredSize(new Dimension(20, 20));
        b.setMinimumSize(new Dimension(20, 20));
        b.setMaximumSize(new Dimension(20, 20));
        p.add(b, "East");
        jcb.addActionListener( this );
    }//addJCB
    

    /**
     * Add zoom and quick edit buttons.
     * (Last modified 8/9/04)
     */
    protected void addButtons() {
//        JLabel spacer = new JLabel( "" );
//        spacer.setOpaque(false);
//        spacer.setFont( jcb_font );
//        add( spacer );

        JPanel x_panel = new JPanel( new GridLayout(1, 2, 0, 0) );
        JPanel y_panel = new JPanel( new GridLayout(1, 2, 0, 0) );
        x_panel.setBackground(getBackground());
        y_panel.setBackground(getBackground());
        add(x_panel);
        add(y_panel);
        
        zoom_in_x = new JButton( "zoom in X" );
        zoom_in_y = new JButton( "zoom in Y" );
        zoom_out_x = new JButton( "zoom out X" );
        zoom_out_y = new JButton( "zoom out Y" );
        show_whole = new JButton( "show whole" );
        
        
        //reload_tree = new JButton("reload tree"); Not useful (Petar)

        addJB( zoom_in_x, x_panel );
        addJB( zoom_out_x, x_panel );
        addJB( zoom_in_y, y_panel );
        addJB( zoom_out_y, y_panel );
        addJB( show_whole, this );
        //addJB( reload_tree, this ); Not useful (Petar)
    } // addButtons
    

    public boolean colorAccordingToSpecies() {
        return (color_acc_species != null && color_acc_species.isSelected());
    }//colorAccordingToSpecies

    
    public boolean colorOrthologous() {
        return (color_orthos != null && color_orthos.isSelected());
    }//colorOrthologous
    
    
    public boolean colorSubtreeNeighbors() {
        return (color_s_n != null && color_s_n.isSelected());
    }//colorSubtreeNeighbors
    
    
    public boolean colorSuperOrthologous() {
        return (color_super_orthos != null && color_super_orthos.isSelected());
    }//colorSuperOrthologous

    
    /**
     * 
     */
    protected void collapseToDeepestAnnot( ATVtreePanel tp ) {

        Phylogeny t = tp.getTree();
        if ( t != null && !t.isEmpty() ) {
            t.collapseToDeepestAnotNodes();
            showWhole();
        }
    } // End of collapseToDeepestAnnot
    

    /**
     * Finish off click-to dropdown list.
     */
    protected void endClickToOptions() {
        click_to_list.addActionListener(this);
        
        // Indicate which options are permitted when multiple nodes are selected
        multiple_click_to_names = new Vector();
        multiple_click_to_names.add( all_click_to_names.get(new Integer(ATVConfig.display_genomes)) );
    } // End of endClickToOptions
    
    
    /**
      *
      */
    public Hashtable getAllClickToItems() {
      return all_click_to_names;
    } // End of getAllClickToItems
    
    
    /**
      *
      */
    public Vector getMultipleClickToNames() {
      return multiple_click_to_names;
    }//getMultipleClickToNames
    
    
    /**
      *
      */
    public Vector getSingleClickToNames() {
      return single_click_to_names;
    }//getSingleClickToNames
    
    
    public boolean isColorBranches() {
        return (color_branches != null && color_branches.isSelected());
    }//isColorBranches
    
    
    public boolean isCustomTagChecked(String tag) {
        if (custom_tags.get(tag) != null) {
            return ((Boolean)custom_tags.get(tag)).booleanValue();
        } else {
            return false;
        }
    }//isCustomTagChecked
    
    
    public boolean isECExtNodes() {
        return (ecextnodes != null && ecextnodes.isSelected());
    }//isECExtNodes
    
    
    public boolean isECInternalNodes() {
        return (ecintnodes != null && ecintnodes.isSelected());
    }//isECInternalNodes
    
    
    public boolean isMarkNodesWithBox() {
        return (mark_nodes_with_box != null && mark_nodes_with_box.isSelected());
    }//isMarkNodesWithBox
    
    
    public boolean isTreeEditable() {
        return config_settings.isTreeEditable();
    }//isTreeEditable
    
    
    public boolean isWidthBranches() {
        return (width_branches != null && width_branches.isSelected());
    }//isWidthBranches

//    public boolean isRootGainsLosses() {
//        return (root_gains_losses != null && root_gains_losses.isSelected());
//    }//isRootGainsLosses
    
    
//    //Start Renata's modification
//    public boolean isGAINExtNodes() {
//        return (gainextnodes != null && gainextnodes.isSelected());
//    }//isGAINExtNodes
//    
//    
//    public boolean isGAINInternalNodes() {
//        return (gainintnodes != null && gainintnodes.isSelected());
//    }//isGAINInternalNodes
//    
//    public boolean isLOSSExtNodes() {
//        return (lossextnodes != null && lossextnodes.isSelected());
//    }//isLOSSExtNodes
//    
//    
//    public boolean isLOSSInternalNodes() {
//        return (lossintnodes != null && lossintnodes.isSelected());
//    }//isLOSSInternalNodes    
//    //end Renata's modification
    
    /**
     * Reload tree from file
     */
    protected void reloadTree() {
        atvpanel.atvframe.reLoad();
    }//reloadTree
    
    
    /**
     *
     */
    public void setClickToAction(int action) {
        // Set click-to action
//        if (action ==  edit_cb_item)
//            atvtreepanel.setActionWhenNodeClicked( ATVtreePanel.EDIT_INFO );
//        else if (action ==  collapse_cb_item)
//            atvtreepanel.setActionWhenNodeClicked( ATVtreePanel.COLLAPSE );
//        else if (action ==  reroot_cb_item)
//            atvtreepanel.setActionWhenNodeClicked( ATVtreePanel.REROOT );
//        else if (action ==  subtree_cb_item)
//            atvtreepanel.setActionWhenNodeClicked( ATVtreePanel.SUBTREE );
//        else if (action ==  swap_cb_item)
//            atvtreepanel.setActionWhenNodeClicked( ATVtreePanel.SWAP );
//        else
        if (action ==  display_node_sequences_cb_item) {
            //atvtreepanel.setActionWhenNodeClicked( ATVtreePanel_applet.SHOW_NODE_SEQUENCES );
            atvtreepanel.setActionWhenNodeClicked( ATVtreePanel.SHOW_NODE_SEQUENCES );
        }
            
        // added by Renata
        else if (action ==  display_node_hpfs_cb_item) {
            //atvtreepanel.setActionWhenNodeClicked( ATVtreePanel_applet.SHOW_NODE_HPFS ); 
            atvtreepanel.setActionWhenNodeClicked( ATVtreePanel.SHOW_NODE_HPFS ); 
        }
        else if (action ==  display_root_hpfs_cb_item) {
            //atvtreepanel.setActionWhenNodeClicked( ATVtreePanel_applet.SHOW_ROOT_HPFS );    
            atvtreepanel.setActionWhenNodeClicked( ATVtreePanel.SHOW_ROOT_HPFS );    
        }
    	/* Applets are deprecated. Comment off all their instances. (Petar)
        */
//        else if (action ==  display_node_popup_cb_item)
//            atvtreepanel.setActionWhenNodeClicked( ATVtreePanel_applet.DISPLAY_NODE_POPUP );
//        else if (action ==  display_node_glyph_info_cb_item)
//            atvtreepanel.setActionWhenNodeClicked( ATVtreePanel_applet.SHOW_NODE_GLYPH_INFO );
//        else if (action == custom_option_cb_item)
//            atvtreepanel.setActionWhenNodeClicked( ATVtreePanel_applet.CUSTOM_OPTION );
//        
//        // make sure drop down is displaying the correct action
//        // in case this was called from outside the class
        click_to_list.setSelectedIndex( action );
//        System.out.println ("&&&& ACTION &&&&&&&& " + action);
    }//setClickToAction
    
    
    /**
     * Set this checkbox state. Not all checkboxes have been
     * instantiated depending on the config.
     */
    protected void setCheckbox( JCheckBox cb, boolean state ) {
        if ( cb != null ) {
            cb.setSelected( state );
        }
    }//setCheckbox

    /**
     *
     */
    public void setCheckbox( int which, boolean state ) {
        switch (which) {
            case ATVConfig.use_real_br_lengths:
                userealbl.setSelected(state);
                break;
            case ATVConfig.color_according_to_species:
                color_acc_species.setSelected(state);
                break;
            case ATVConfig.seq_name_ext_nodes:
                seqnameextnodes.setSelected(state);
                break;
            case ATVConfig.seq_name_internal_nodes:
                seqnameintnodes.setSelected(state);
                break;
            case ATVConfig.species_ext_nodes:
                speciesextnodes.setSelected(state);
                break;
            case ATVConfig.species_internal_nodes:
                speciesintnodes.setSelected(state);
                break;
            case ATVConfig.ec_ext_nodes:
                ecextnodes.setSelected(state);
                break;
            case ATVConfig.ec_internal_nodes:
                ecintnodes.setSelected(state);
                break;
            case ATVConfig.write_br_length_values:
                write_b_l.setSelected(state);
                break;
            case ATVConfig.write_bootstrap_values:
                writebootstrap.setSelected(state);
                break;
            case ATVConfig.write_dup_spec:
                write_d_s.setSelected(state);
                break;
            case ATVConfig.color_branches:
                color_branches.setSelected(state);
                break;
            case ATVConfig.width_branches:
                width_branches.setSelected(state);
                break;
            case ATVConfig.color_orthologous:
                color_orthos.setSelected(state);
                break;
            case ATVConfig.color_super_orthologous:
                color_super_orthos.setSelected(state);
                break;
            case ATVConfig.color_subtree_neighbors:
                color_s_n.setSelected(state);
                break;
            case ATVConfig.mark_nodes_with_box:
                mark_nodes_with_box.setSelected(state);
                break;
//            case ATVConfig.root_gains_losses:
//                root_gains_losses.setSelected(state);
//                break;
//            //Start Renata's modification
//            case ATVConfig.gain_ext_nodes:
//                gainextnodes.setSelected(state);
//                break;
//            case ATVConfig.gain_internal_nodes:
//                gainintnodes.setSelected(state);
//                break; 
//            case ATVConfig.loss_ext_nodes:
//                lossextnodes.setSelected(state);
//                break;
//            case ATVConfig.loss_internal_nodes:
//                lossintnodes.setSelected(state);
//                break;          
//            //end Renata's modification                                  
            default:
                System.out.println( "Unknown checkbox: " + which );
        }
    }//setCheckbox
    

    /**
     * Sets the color to default values. Last updated: 05/15/05 by CMZ.
     */
    protected void setDefaultColors() {
        background_color = ATVconstants.GUI_BACKGROUND_DEFAULT;
        jcb_text_color = ATVconstants.CHECKBOX_TEXT_COLOR_DEFAULT;
        jcb_background_color = ATVconstants.CHECKBOX_BACKGROUND_COLOR_DEFAULT;
        button_text_color = ATVconstants.BUTTON_TEXT_COLOR_DEFAULT;
        button_background_color = ATVconstants.BUTTON_BACKGROUND_COLOR_DEFAULT;
    }//setDefaultColors
    
    

    /**
     *
     */
    
    protected void setMultipleSelect( boolean b ) {
        multiselect = b;
        
        // Clear existing click-to options and indices
        click_to_list.removeAllItems();
//        edit_cb_item = collapse_cb_item = reroot_cb_item = 
//              swap_cb_item = subtree_cb_item = display_node_sequences_cb_item = 
//              display_node_glyph_info_cb_item = -1;
//        edit_cb_item = 
        display_node_sequences_cb_item = display_node_hpfs_cb_item = display_root_hpfs_cb_item= -1;
              
        if (multiselect) {
            // set click-to options that are valid for sets of nodes
            int cb_index = 0;
            if (config_settings.doDisplayClickToOption(ATVConfig.display_genomes)) {//ATVConfig.edit_info)) {
                display_node_sequences_cb_item = cb_index;
//              edit_cb_item = cb_index;
                click_to_list.addItem(config_settings.getClickToTitle( ATVConfig.display_genomes)); //ATVConfig.edit_info));
                cb_index++;
           }
        } else {
            // restore full list of click-to options
            setupClickToOptions();           
        }
        repaint();
    }//setMultipleSelect
    
    
    public boolean seqNameExtNodes() {
        return (seqnameextnodes != null && seqnameextnodes.isSelected());
    }//seqNameExtNodes
    
    
    public boolean seqNameInternalNodes() {
        return (seqnameintnodes != null && seqnameintnodes.isSelected());
    }//seqNameInternalNodes
    
    
    /*
     * Set up the controls from the config settings.
     * 11/26/05
     */
    protected void setupControls() {
        // The tree display options:
        setupDisplayCheckboxes();
        
        // Click-to options
        startClickToOptions();
        setupClickToOptions();
        endClickToOptions();
        
        
        // Custom data controls (if any custom data in tree)
        // Commented out - We do not have proper proceedings for here. (Petar)
        //addCustomControls();
        
        // Zoom and quick edit buttons
        addButtons();
    } //end of setupControls
    
    
    private void setupClickToOptions() {
        int default_option = config_settings.getDefaultDisplayClicktoOption();
        int selected_index = 0;
        int cb_index = 0;

        if (config_settings.doDisplayClickToOption(ATVConfig.display_genomes)) {
            display_node_sequences_cb_item = cb_index;
            addClickToOption(ATVConfig.display_genomes, 
                  config_settings.getClickToTitle(ATVConfig.display_genomes));
            if (default_option == ATVConfig.display_genomes) selected_index = cb_index;
            cb_index++;
        }
        
        // added by Renata
         if (config_settings.doDisplayClickToOption(ATVConfig.display_hpfs)) {
            display_node_hpfs_cb_item = cb_index;
            addClickToOption(ATVConfig.display_hpfs, 
                  config_settings.getClickToTitle(ATVConfig.display_hpfs));
            if (default_option == ATVConfig.display_hpfs) selected_index = cb_index;
            cb_index++;           
        }
        
        /* Excluded by Petar
        if (config_settings.doDisplayClickToOption(ATVConfig.display_root_hpfs)) {
            display_root_hpfs_cb_item = cb_index;
            addClickToOption(ATVConfig.display_root_hpfs, 
                  config_settings.getClickToTitle(ATVConfig.display_root_hpfs));
            if (default_option == ATVConfig.display_root_hpfs) selected_index = cb_index;
            cb_index++;           
        }
        */

        click_to_list.setSelectedIndex(selected_index);
        setClickToAction(selected_index);
    } //setupClickToOptions
    
    
    private void setupDisplayCheckboxes() {
        // Set display checkboxes
    	/* Commented out: We do not show real branch lengths, sequence names,
    	 * species' names for internal nodes, branch length values, bootstrap values,
    	 * colouring options. (Petar)

        if (config_settings.doDisplayOption(ATVConfig.use_real_br_lengths)) {
            addCheckbox(ATVConfig.use_real_br_lengths, 
                config_settings.getDisplayTitle(ATVConfig.use_real_br_lengths));
            setCheckbox(ATVConfig.use_real_br_lengths, 
                config_settings.doCheckOption(ATVConfig.use_real_br_lengths));
        }
        if (config_settings.doDisplayOption(ATVConfig.seq_name_internal_nodes)) {
            addCheckbox(ATVConfig.seq_name_internal_nodes,
                config_settings.getDisplayTitle(ATVConfig.seq_name_internal_nodes));
            setCheckbox(ATVConfig.seq_name_internal_nodes, 
                config_settings.doCheckOption(ATVConfig.seq_name_internal_nodes));
        }
        */
        if (config_settings.doDisplayOption(ATVConfig.seq_name_ext_nodes)) {
            addCheckbox(ATVConfig.seq_name_ext_nodes,
                config_settings.getDisplayTitle(ATVConfig.seq_name_ext_nodes));
            setCheckbox(ATVConfig.seq_name_ext_nodes, 
                config_settings.doCheckOption(ATVConfig.seq_name_ext_nodes));
        }
        /* Commenting off - continued (Petar)
        if (config_settings.doDisplayOption(ATVConfig.species_internal_nodes)) {
            addCheckbox(ATVConfig.species_internal_nodes, 
                config_settings.getDisplayTitle(ATVConfig.species_internal_nodes));
            setCheckbox(ATVConfig.species_internal_nodes, 
                config_settings.doCheckOption(ATVConfig.species_internal_nodes));
        }
        if (config_settings.doDisplayOption(ATVConfig.species_ext_nodes)) {
            addCheckbox(ATVConfig.species_ext_nodes, 
                config_settings.getDisplayTitle(ATVConfig.species_ext_nodes));
            setCheckbox(ATVConfig.species_ext_nodes, 
                config_settings.doCheckOption(ATVConfig.species_ext_nodes));
        }
        */
        if (config_settings.doDisplayOption(ATVConfig.ec_internal_nodes)) {
            addCheckbox(ATVConfig.ec_internal_nodes, 
                config_settings.getDisplayTitle(ATVConfig.ec_internal_nodes));
            setCheckbox(ATVConfig.ec_internal_nodes, 
                config_settings.doCheckOption(ATVConfig.ec_internal_nodes));
        }
        if (config_settings.doDisplayOption(ATVConfig.ec_ext_nodes)) {
            addCheckbox(ATVConfig.ec_ext_nodes, 
                config_settings.getDisplayTitle(ATVConfig.ec_ext_nodes));
            setCheckbox(ATVConfig.ec_ext_nodes, 
                config_settings.doCheckOption(ATVConfig.ec_ext_nodes));
        }
        /* Commenting off - continued (Petar)
        if (config_settings.doDisplayOption(ATVConfig.write_br_length_values)) {
            addCheckbox(ATVConfig.write_br_length_values, 
                config_settings.getDisplayTitle(ATVConfig.write_br_length_values));
            setCheckbox(ATVConfig.write_br_length_values, 
                config_settings.doCheckOption(ATVConfig.write_br_length_values));
        }
        if (config_settings.doDisplayOption(ATVConfig.write_bootstrap_values)) {
            addCheckbox(ATVConfig.write_bootstrap_values, 
                config_settings.getDisplayTitle(ATVConfig.write_bootstrap_values));
            setCheckbox(ATVConfig.write_bootstrap_values, 
                config_settings.doCheckOption(ATVConfig.write_bootstrap_values));
        }
        if (config_settings.doDisplayOption(ATVConfig.write_dup_spec)) {
            addCheckbox(ATVConfig.write_dup_spec, 
                config_settings.getDisplayTitle(ATVConfig.write_dup_spec));
            setCheckbox(ATVConfig.write_dup_spec, 
                config_settings.doCheckOption(ATVConfig.write_dup_spec));
        }
        if (config_settings.doDisplayOption(ATVConfig.color_orthologous)) {
            addCheckbox(ATVConfig.color_orthologous, 
                config_settings.getDisplayTitle(ATVConfig.color_orthologous));
            setCheckbox(ATVConfig.color_orthologous, 
                config_settings.doCheckOption(ATVConfig.color_orthologous));
        }
        if (config_settings.doDisplayOption(ATVConfig.color_super_orthologous)) {
            addCheckbox(ATVConfig.color_super_orthologous, 
                config_settings.getDisplayTitle(ATVConfig.color_super_orthologous));
            setCheckbox(ATVConfig.color_super_orthologous, 
                config_settings.doCheckOption(ATVConfig.color_super_orthologous));
        }
        if (config_settings.doDisplayOption(ATVConfig.color_subtree_neighbors)) {
            addCheckbox(ATVConfig.color_subtree_neighbors, 
                config_settings.getDisplayTitle(ATVConfig.color_subtree_neighbors));
            setCheckbox(ATVConfig.color_subtree_neighbors, 
                config_settings.doCheckOption(ATVConfig.color_subtree_neighbors));
        }
        if (config_settings.doDisplayOption(ATVConfig.color_according_to_species)) {
            addCheckbox(ATVConfig.color_according_to_species, 
                config_settings.getDisplayTitle(ATVConfig.color_according_to_species));
            setCheckbox(ATVConfig.color_according_to_species, 
                config_settings.doCheckOption(ATVConfig.color_according_to_species));
        }
        if (config_settings.doDisplayOption(ATVConfig.color_branches)) {
            addCheckbox(ATVConfig.color_branches, 
                config_settings.getDisplayTitle(ATVConfig.color_branches));
            setCheckbox(ATVConfig.color_branches, 
                config_settings.doCheckOption(ATVConfig.color_branches));
        }
        */
        if (config_settings.doDisplayOption(ATVConfig.width_branches)) {
            addCheckbox(ATVConfig.width_branches, 
                config_settings.getDisplayTitle(ATVConfig.width_branches));
            setCheckbox(ATVConfig.width_branches, 
                config_settings.doCheckOption(ATVConfig.width_branches));
        }
        /*

        */
        if (config_settings.doDisplayOption(ATVConfig.mark_nodes_with_box)) {
            addCheckbox(ATVConfig.mark_nodes_with_box, 
                config_settings.getDisplayTitle(ATVConfig.mark_nodes_with_box));
            setCheckbox(ATVConfig.mark_nodes_with_box, 
                config_settings.doCheckOption(ATVConfig.mark_nodes_with_box));
        }
//        if (config_settings.doDisplayOption(ATVConfig.root_gains_losses)) {
//            addCheckbox(ATVConfig.root_gains_losses, 
//                config_settings.getDisplayTitle(ATVConfig.root_gains_losses));
//            setCheckbox(ATVConfig.root_gains_losses, 
//                config_settings.doCheckOption(ATVConfig.root_gains_losses));
//        }
//        // Start Renata's modification
//        if (config_settings.doDisplayOption(ATVConfig.gain_internal_nodes)) {
//            addCheckbox(ATVConfig.gain_internal_nodes, 
//                config_settings.getDisplayTitle(ATVConfig.gain_internal_nodes));
//            setCheckbox(ATVConfig.gain_internal_nodes, 
//                config_settings.doCheckOption(ATVConfig.gain_internal_nodes));
//        }
//        if (config_settings.doDisplayOption(ATVConfig.gain_ext_nodes)) {
//            addCheckbox(ATVConfig.gain_ext_nodes, 
//                config_settings.getDisplayTitle(ATVConfig.gain_ext_nodes));
//            setCheckbox(ATVConfig.gain_ext_nodes, 
//                config_settings.doCheckOption(ATVConfig.gain_ext_nodes));
//        }
//         if (config_settings.doDisplayOption(ATVConfig.loss_internal_nodes)) {
//            addCheckbox(ATVConfig.loss_internal_nodes, 
//                config_settings.getDisplayTitle(ATVConfig.loss_internal_nodes));
//            setCheckbox(ATVConfig.loss_internal_nodes, 
//                config_settings.doCheckOption(ATVConfig.loss_internal_nodes));
//        }
//        if (config_settings.doDisplayOption(ATVConfig.loss_ext_nodes)) {
//            addCheckbox(ATVConfig.loss_ext_nodes, 
//                config_settings.getDisplayTitle(ATVConfig.loss_ext_nodes));
//            setCheckbox(ATVConfig.loss_ext_nodes, 
//                config_settings.doCheckOption(ATVConfig.loss_ext_nodes));
//        }
//        //end Renata's modification
        
        
    }//setupDisplayCheckboxes

    
    
    /**
     * Pop up the help box.
     */
    //Hasty re-tailoring by Petar.
    protected void showHelp( String which, String title ) {
        //QuickHelpFrame qhf     = new QuickHelpFrame(atvpanel.atvframe, which, title);
        
        //An attempt to set the background color directly. (Petar) 
        //Color bgcolor = new Color(250,250,250);
        //dialog.getContentPane().setBackground( Color.red );
        //JOptionPane.showMessageDialog(atvpanel.atvframe, "Help here");
        //JOptionPane.showMessageDialog(atvpanel.atvframe, which, title, JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, getHelp(which), 
        		title, JOptionPane.INFORMATION_MESSAGE);

        //qhf.super.getContentPane().setBackground(  bgcolor );
        //qhf.setBackground(bgcolor);
        //qhf.show(); Obsolete, replaced with qhf.setVisible(true). (Petar)
        //qhf.setVisible(true);

    }//showHelp
    
    
    /**
     * 
     */
    public void showItemHelpButtons(boolean b) {
        if (userealbl_help != null) userealbl_help.setVisible(b);
        if (seqnameextnodes_help != null) seqnameextnodes_help.setVisible(b);
        if (seqnameintnodes_help != null) seqnameintnodes_help.setVisible(b);
        if (speciesextnodes_help != null) speciesextnodes_help.setVisible(b);
        if (speciesintnodes_help != null) speciesintnodes_help.setVisible(b);
        if (ecintnodes_help != null) ecintnodes_help.setVisible(b);
        if (ecextnodes_help != null) ecextnodes_help.setVisible(b);
        if (writebl_help != null) writebl_help.setVisible(b);
        if (writebootstrap_help != null) writebootstrap_help.setVisible(b); 
        if (writed_s_help != null) writed_s_help.setVisible(b);
        if (color_orthos_help != null) color_orthos_help.setVisible(b);
        if (color_super_orthos_help != null) color_super_orthos_help.setVisible(b);
        if (color_sn_help != null) color_sn_help.setVisible(b);
        if (color_acc_species_help != null) color_acc_species_help.setVisible(b);
        if (editable_help != null) editable_help.setVisible(b);
        if (color_branches_help != null) color_branches_help.setVisible(b);
        if (width_branches_help != null) width_branches_help.setVisible(b);
        if (mark_nodes_with_box_help != null) mark_nodes_with_box_help.setVisible(b);
//        if (root_gains_losses_help != null) root_gains_losses_help.setVisible(b);

//        //Start Renata's modification
//        if (gainintnodes_help != null) gainintnodes_help.setVisible(b);
//        if (gainextnodes_help != null) gainextnodes_help.setVisible(b);
//        if (lossintnodes_help != null) gainintnodes_help.setVisible(b);
//        if (lossextnodes_help != null) gainextnodes_help.setVisible(b);
//        //end Renata's modification
    }
    
    
    /**
     * Fit entire tree into window.
     * (Last modified: 10/04/01)
     */
    protected void showWhole() {
        atvtreepanel.setParametersForPainting(
                atvpanel.getSizeOfViewport().width,
                atvpanel.getSizeOfViewport().height );
        atvtreepanel.resetPreferredSize();
        atvpanel.adjustJScrollPane();
    }//showWhole


    public boolean speciesExtNodes() {
        return (speciesextnodes != null && speciesextnodes.isSelected());
    }//speciesExtNodes
    
    
    public boolean speciesInternalNodes() {
        return (speciesintnodes != null && speciesintnodes.isSelected());
    }//speciesInternalNodes
    
    
    /**
    * Create header for click-to radio buttons.
    */
    protected void startClickToOptions() {
        JLabel spacer = new JLabel( "" );
        spacer.setFont( jcb_font );
        add( spacer );
//        
//        click_to = new JLabel( "click on node to:" );
//        click_to.setFont( jcb_bold_font );
//        click_to.setForeground( jcb_text_color );
//        click_to.setBackground( background_color );
//        add( click_to );
//
        click_to_list = new JComboBox();
        click_to_list.setBackground(background_color);
        click_to_list.setFont( js_font );
//don't add listener until all items are set (or each one will trigger an event)
//        click_to_list.addActionListener(this);
        add(click_to_list);
//        
        // Correlates option names to titles
        all_click_to_names = new Hashtable();
//        
        // All options are valid for single nodes, so build this vector as we go
        single_click_to_names = new Vector();
    }//startClickToButtons


    /**
     * Uncollapse all nodes.
     */
//    void uncollapseAll( ATVtreePanel tp ) {
//        Phylogeny t = tp.getTree();
//        if ( t != null && !t.isEmpty() ) {
//            t.setAllNodesToNotCollapse();
//            t.adjustNodeCount( false );
////            t.recalculateAndReset();
//            showWhole();
//        }
//    }//uncollapseAll


    public boolean useRealBranchLengths() {
        return (userealbl != null && userealbl.isSelected());
    }//useRealBranchLengths
    
    
    public boolean writeBranchLengthValues() {
        return (write_b_l != null && write_b_l.isSelected());
    }//writeBranchLengthValues
    
    
    public boolean writeBootstrapValues() {
        return (writebootstrap != null && writebootstrap.isSelected());
    }//writeBootstrapValues

    
    public boolean writeDupSpec() {
        return (write_d_s != null && write_d_s.isSelected());
    }//writeDupSpec
    
    /**
     * Set the help string
     * @param help_name ID for help item
     */
    private String getHelp(String help_name) {
        String help_str = "";
        
        if ( help_name.equals("userealbl") ) {
            help_str = "If checked, display actual branch lengths. "
                     + "If unchecked, display all branches the same length.";
        } else if ( help_name.equals("color_branches") ) {
            help_str = "If checked, branch colors are displayed. These colors " 
                     + "must be included in the data."; 
        } else if ( help_name.equals("width_branches") ) {
            help_str = "If checked, branch widths are displayed. These widths "
                     + "must be included in data. If not clicked, all branches "
                     + "are the same width."; 
        } else if ( help_name.equals("writebl") ) {
            help_str = "If checked, branch distance values are displayed. Branch "
                     + "distance values must be included in the data.";
        } else if ( help_name.equals("seqnameextnodes") ) {
                help_str = "If checked, species' names are displayed on leaves. "
                     + "Species names must be included in the data.";
        } else if ( help_name.equals("seqnameintnodes") ) {
            help_str = "If checked, sequence names are displayed on internal nodes. " 
                     + "Internal sequence names must be included in the data.";
        } else if ( help_name.equals("speciesextnodes") ) {
            help_str = "If checked, sequence names are displayed on leaves.";
        } else if ( help_name.equals("speciesintnodes") ) {
            help_str = "If checked, species' names are displayed on internal nodes. "
                     + "Internal species' names must be included in the data.";
        } else if ( help_name.equals("color_acc_species") ) {
            help_str = "If checked, color text by species. Species data must be "
                     + "included in the data."; 
        } else if ( help_name.equals("ecintnodes") ) {
            help_str = "If checked, gains and losses are displayed on internal nodes. "
                     + "gains and losses are included in the data once"
                     + "the reconstruction algorithm is executed.";
        } else if ( help_name.equals("ecextnodes") ) {
            help_str = "If checked, gains and losses are displayed on leaves. "
                     + "gains and losses numbers are included in the data once "
                     + "reconstruction algorithm is executed.";
        } else if ( help_name.equals("writebootstrap") ) {
            help_str = "If checked, bootstrap values are displayed if found in "
                     + "the data.";
        } else if ( help_name.equals("writed_s") ) {
            help_str = "If checked, display duplication and speciation events.";
        } else if ( help_name.equals("color_orthos") ) {
            help_str = "If checked, highlight orthologous sequences."; 
        } else if ( help_name.equals("color_super_orthos") ) {
            help_str = "If checked, highlight sequences that are super-orthologous. "
                     + "Two sequences are super orthologous if, given a rooted "
                     + "tree with duplication or speciation events assigned to "
                     + "each of its internal nodes, two sequences are "
                     + "super-orthologous if and only if each internal node on "
                     + "their connecting path represents a speciation event. "; 
        } else if ( help_name.equals("color_sn") ) {
            help_str = "If checked, highlight sub-tree neighbors. Sub-tree neighbors "
                     + "are defined as follows: given a completely binary and "
                     + "rooted gene tree, the k-subtree-neighbors of a sequence "
                     + "q are defined as all sequences derived from the k-level "
                     + "parent node of q, except q itself (the level of q itself "
                     + "is 0, q's parent is 1, and so forth)."; 
        } else if ( help_name.equals("editable") ) {
            help_str = "If checked, node information is editable. Select "
                     + "\"display editable data\" from dropdown below \"click "
                     + "on node to:\""; 
        } else if ( help_name.equals("mark_nodes_with_box") ) {
            help_str = "If checked, nodes are indicated with a small box."; 
        } else {
            help_str = "No help available";
        }
        
        return help_str;
    }

} // End of class ATVcontrol.





