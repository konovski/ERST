/*
 * Created on Nov 13, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package erst.forester.java.src.org.forester.phylogeny;

import erst.forester.java.src.org.forester.phylogeny.data.PhylogenyData;

/**
 * @author Christian Zmasek
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface PhylogenyNodeData extends PhylogenyData {

  

}
