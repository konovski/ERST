package erst.forester.java.src.org.forester.phylogeny.data;

public class SequenceLocation implements PhylogenyData {

    private String _type;
    private String _unit;
    private String _value;
    
    public void init() {
        // TODO Auto-generated method stub
    }
    
    public StringBuffer toPhyloXML( int level ) {
        // TODO Auto-generated method stub
        return null;
    }

    public PhylogenyData copy() {
        // TODO Auto-generated method stub
        return null;
    }

    public boolean isEqual( PhylogenyData data ) {
        // TODO Auto-generated method stub
        return false;
    }

    public StringBuffer asText() {
        // TODO Auto-generated method stub
        return null;
    }

    public StringBuffer asSimpleText() {
        // TODO Auto-generated method stub
        return null;
    }

}
