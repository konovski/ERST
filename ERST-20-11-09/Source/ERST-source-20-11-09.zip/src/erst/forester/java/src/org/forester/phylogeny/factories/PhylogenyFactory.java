/*
 * Created on Jun 5.
 */
package erst.forester.java.src.org.forester.phylogeny.factories;

import java.io.IOException;

import java.util.List;

import erst.forester.java.src.org.forester.phylogeny.Phylogeny;

/**
 * Interface for Phylogeny factories.
 * 
 * @author Christian M. Zmasek
 */
public interface PhylogenyFactory {
    /**
     * This must be implemented in such a way that it returns an empty
     * Phylogeny.
     * 
     * @return an empty Phylogeny
     */
    public Phylogeny create();

    /**
     * This must create a Phylogeny from source (e.g. an XML file, an alignment,
     * pairwise distances) by using creator (e.g. an XML file parser, an
     * algorithm implementation) with parameters listed in parameters.
     * 
     * @param source
     *            a source to create a Phylogeny from
     * @param creator
     *            a means to create a Phylogeny
     * @param parameters
     *            a List of parameters for Phylogeny creation
     * @return a Phylogeny[] based on argument source
     * @throws IOException
     */
    public Phylogeny[] create( Object source, Object creator,
            List parameters ) throws IOException;

    /**
     * This must create a Phylogeny from source (e.g. an XML file, an alignment,
     * pairwise distances) by using creator (e.g. an XML file parser, an
     * algorithm implementation).
     * 
     * @param source
     *            a source to create a Phylogeny from
     * @param creator
     *            a means to create a Phylogeny
     * @return a Phylogeny[] based on argument source
     * @throws IOException
     */
    public Phylogeny[] create( Object source, Object creator )
            throws IOException;
} // PhylogenyFactory

