
package erst.forester.java.src.org.forester.phylogeny.parsers.xml;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;

import erst.forester.java.src.org.forester.phylogeny.Phylogeny;
import erst.forester.java.src.org.forester.phylogeny.parsers.PhylogenyParser;
import erst.forester.java.src.org.forester.phylogeny.parsers.PhylogenyParserException;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

/**
 * @author Christian Zmasek
 */
public class SimplePhyloXMLParser1 implements PhylogenyParser {

    /*
     * (non-Javadoc)
     * 
     * @see org.forester.phylogeny.parsers.PhylogenyParser#parse()
     */
    public Phylogeny[] parse() throws IOException, PhylogenyParserException {

        SimplePhyloXMLParser1Handler1 handler = new SimplePhyloXMLParser1Handler1();

        SAXParserFactory factory = SAXParserFactory.newInstance();
        factory.setValidating( true );
     //   factory.setErrorHandler(new BestSAXChecker());
                                 // ^^^^^^^^^^^^^^
                                 // From Chapter 7
        // turn on schema support
        
        
//        try {
//            factory.setFeature(  "c:\\WORK\\DAWN_WORKSPACE\\project_dawn\\forester-atv\\xml_schema\\phyloXML1.0.xsd", true );
//        }
//        catch ( SAXNotRecognizedException e ) {
//            throw new PhylogenyParserException( "Problem with schema (SAX not recognized): "
//                    + e.getMessage() );
//        }
//        catch ( SAXNotSupportedException e ) {
//            throw new PhylogenyParserException( "Problem with schema (SAX not supported): "
//                    + e.getMessage() );
//        }
//        catch ( ParserConfigurationException e ) {
//            throw new PhylogenyParserException( "Problem with schema (parser configuration exception): "
//                    + e.getMessage() );
//        }
        
       
        try {
           
            SAXParser parser = factory.newSAXParser();
         //   parser.setProperty(SCHEMA_LANGUAGE,XML_SCHEMA);
          //  parser.setProperty(SCHEMA_SOURCE,"c:\\WORK\\DAWN_WORKSPACE\\project_dawn\\forester-atv\\xml_schema\\phyloXML1.0.xsd");
          
                 
            if ( getSource() instanceof File ) {
                parser.parse( ( File ) getSource(), handler );
            }
            else if ( getSource() instanceof InputSource ) {
                parser.parse( ( InputSource ) getSource(), handler );
            }
            else if ( getSource() instanceof InputStream ) {
                parser.parse( ( InputStream ) getSource(), handler );
            }
            else if ( getSource() instanceof String ) {
                parser.parse( ( String ) getSource(), handler );
            }
            else {
                throw new PhylogenyParserException(
                        "Attempt to parse object of type \""
                                + getSource().getClass() + "\"" );
            }
        }
        catch ( SAXException sax_exception ) {
            throw new PhylogenyParserException( "Problem with parsing of XML file: "
                    + sax_exception.getMessage() );

        }
        catch ( ParserConfigurationException parser_config_exception ) {
            throw new PhylogenyParserException(
                    "Problem with SAX XML parser configuration: "
                            + parser_config_exception.getMessage() );
        }

        return new Phylogeny[] { handler.getPhylogeny() };
    }

    public void setSource( Object source ) {
        _source = source;
    }

    private Object getSource() {
        return _source;
    }

    private Object _source;
    
    public static String SCHEMA_LANGUAGE =
        "http://java.sun.com/xml/jaxp/properties/schemaLanguage",
                          XML_SCHEMA =
        "http://www.w3.org/2001/XMLSchema",
                          SCHEMA_SOURCE =
        "http://java.sun.com/xml/jaxp/properties/schemaSource";

}
