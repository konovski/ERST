// ATVpanel.java
//
// Copyright (C) 1999-2001 Washington University School of Medicine
// and Howard Hughes Medical Institute
// All rights reserved
//
// Created: 1999
// Author: Christian M. Zmasek
// zmasek@genetics.wustl.edu
// http://www.genetics.wustl.edu/eddy/people/zmasek/
//
// Restructued: 2004
// Ethy Cannon
// ethy@a415software.com

package erst.forester.java.src.org.forester.atv;


import java.awt.*;
import java.util.Vector;
import javax.swing.*;

import erst.forester.java.src.org.forester.phylogeny.*;

/**
 * @author Christian Zmasek
 * @version 1.06 -- 06/23/00
 * @version 1.1 -- 8/9/04 -- eksc Added configurable controls. Controls are now
 *          set up using an XML config file. Consolidated the ATVpanel and
 *          ATVpanel_applet to remove some redundancy.
 */
public class ATVpanel extends JPanel { //Iadded public
    ATVframe           atvframe;
    
    ATVtreePanel       atvtreepanel;

    ATVcontrol         atvcontrol;

    JScrollPane        treegraphic_jsp;

    JPanel             tree_panel        = new JPanel( new BorderLayout() );

    ATVnodeGlyphPanel  atvextension      = null;

    JScrollPane        extension_jsp     = null;

    final static Color background_color  = new Color( 0, 0, 0 );
    
    
    /**
     * Default constructor.
     *
     * Used by ATVpanel_applet, for example, since it needs to create
     *   a different atvtreepanel.
     */
    ATVpanel() { }
    
    
    /**
     * Main constructor
     */
    ATVpanel( Phylogeny t, ATVConfig config_settings, ATVframe parent ) {
        this.atvframe = parent;

        // Set up the extension panel (may not be one)
        setupExtensionPanel( config_settings, t );
        
        // Create the tree panel
        atvtreepanel = new ATVtreePanel( t, config_settings, this, atvextension );
        if ( atvtreepanel == null ) {
            System.out.println("atvtreepanel == null" );
        }
        
        // Create the control panel
        atvcontrol = new ATVcontrol( this, atvtreepanel, config_settings );
        
        // The tree panel and control panel need to "listen" to each other
        atvtreepanel.setControlPeer(atvcontrol);

        initialize();
        setupTreeGraphic( config_settings, atvtreepanel );
        
        getATVcontrol().showWhole();
    }// constructor
    

    /**
     * Helper method for constructor.
     * (last modified by eksc 7/8/04)
     */
    void initialize() {
        setBackground( background_color );

        treegraphic_jsp = new JScrollPane( atvtreepanel );
        treegraphic_jsp.getHorizontalScrollBar().setUnitIncrement( 20 );
        treegraphic_jsp.getHorizontalScrollBar().setBlockIncrement( 50 );
        treegraphic_jsp.getVerticalScrollBar().setUnitIncrement( 20 );
        treegraphic_jsp.getVerticalScrollBar().setBlockIncrement( 50 );

        if ( atvextension != null ) {
            atvextension.setGlyphWidth( 60 );
            Phylogeny t = atvtreepanel.getTree();
            if ( t != null ) {
                atvextension.init( this, t.getRoot() );
            }
            else {
                atvextension.init( this, null );
            }
            extension_jsp = new JScrollPane( atvextension );
            extension_jsp.getHorizontalScrollBar().setUnitIncrement( 20 );
            extension_jsp.getHorizontalScrollBar().setBlockIncrement( 50 );
            extension_jsp.getVerticalScrollBar().setUnitIncrement( 20 );
            extension_jsp.getVerticalScrollBar().setBlockIncrement( 50 );
        }

        setLayout( new BorderLayout() );

        tree_panel = new JPanel( new BorderLayout() );
        tree_panel.add( treegraphic_jsp, BorderLayout.CENTER );
        if ( extension_jsp != null ) {
            tree_panel.add( extension_jsp, BorderLayout.EAST );
        }
        add( tree_panel, BorderLayout.CENTER );
        add( atvcontrol, BorderLayout.WEST );
    }//initialize
    

    /**
     * 
     */
    Dimension getSizeOfViewport() {
        return treegraphic_jsp.getViewport().getExtentSize();
    }//getSizeOfViewport
    

    /**
     * 
     */
    void adjustJScrollPane() {
        tree_panel.remove( treegraphic_jsp );
        tree_panel.add( treegraphic_jsp, BorderLayout.CENTER );
        treegraphic_jsp.revalidate();
    }//adjustJScrollPane
    

    /**
     * 
     */
    ATVtreePanel getATVtreePanel() {
        return atvtreepanel;
    }//getATVtreePanel
    
    
    /**
     * 
     */
    ATVcontrol getATVcontrol() {
        return atvcontrol;
    }//getATVcontrol

    /**
     * Enables the extension panel to be turned on or off via XML.
     * (last modified by eksc 8/9/04)
     */
    void setupExtensionPanel( ATVConfig config_settings, Phylogeny t ) {
        int glyph_type = config_settings.getGlyphType();
        if (glyph_type != ATVConfig.glyph_none) {
            try {
                // get set up to load an arbitrary class
                Class newc;
                Class c = getClass();
                ClassLoader cl = c.getClassLoader();

                // determine class name from XML config
                if ( glyph_type == ATVConfig.glyph_expression ) {
                    newc = cl.loadClass( "org.forester.extensions.NodeExpressionPanel" );
                }
                else if ( glyph_type == ATVConfig.glyph_chromosome ) {
                    newc = cl.loadClass( "org.forester.extensions.NodeChromosomePanel" );
                }
                else {
                    System.out.println( "Unknown glyph type: " + glyph_type );
                    return;
                }

                // create the glyph class
                atvextension = ( ATVnodeGlyphPanel ) newc.newInstance();
            }
            catch ( Exception e ) {
                System.out
                        .println( "Error encountered while creating glyph frame; "
                                + e.toString() );
            }
        }
    }//setupExtensionPanel


    /**
     * 
     */
    void terminate() {
        atvtreepanel.removeAllEditNodeJFrames();
    }//terminate
    

    /**
     * Permit any action that may be needed in response to a 
     * change in tree structure.
     * (last modified by eksc 11/5/04)
     */
    void treeChanged( PhylogenyNode n ) {
        if ( atvextension != null ) {
            atvextension.treeChanged( n );
            atvextension.repaint();
        }
    }//

 
    /**
     * Load species colors.
     * (last modified by eksc 8/11/04)
     */
//    void setupTreeGraphic( XMLNode config_xml_root, ATVtreePanel atvtreepanel ) {
    void setupTreeGraphic( ATVConfig config_settings, ATVtreePanel atvtreepanel ) {
        atvtreepanel.setSpeciesColors( config_settings.getSpeciesColors() );
/*
        if ( config_xml_root != null ) {
            // get species colors, if any, from the XML config file and
            // pass the resulting vector to atvgraphic.
            Vector species_colors = new Vector();
            XMLNodeEnum e = config_xml_root
                    .getFirstLevelChildren( "species_color" );
            while ( e.hasMoreElements() ) {
                XMLNode xml_node = e.nextElement();
                String species_name = xml_node.getAttribute( "species" );
                String species_color = xml_node.getAttribute( "color" );
                String species_color_array[] = new String[2];
                species_color_array[ 0 ] = species_name;
                species_color_array[ 1 ] = species_color;
                species_colors.add( species_color_array );
            }
            atvtreepanel.setSpeciesColors( species_colors );
        }
        String graph_attr_value = getXMLAttr( config_xml_root,
                                              "glyph_panel",
                                              "graph" );
        // determine class name from XML config
        String graph_class_name = "";
        if ( graph_attr_value != null
                && graph_attr_value.equalsIgnoreCase( "expression" ) ) {
            graph_class_name = "org.forester.extensions.NodeExpressionPanel";
        }
        else if ( graph_attr_value != null
                && graph_attr_value.equalsIgnoreCase( "chromosome" ) ) {
            graph_class_name = "org.forester.extensions.NodeChromosomePanel";
        }
        else {
            System.out.println( "Unknown glyph type: " + graph_attr_value );
            return;
        }
        atvtreepanel.setGlyphClass( graph_class_name );
*/
    }//setupTreeGraphic
    

} // End of class ATVpanel.
