// ATVtextframe.java
//
// Copyright (C) 1999-2001 Washington University School of Medicine
// and Howard Hughes Medical Institute
// All rights reserved
//
// Created: 1999
// Author: Christian M. Zmasek
// zmasek@genetics.wustl.edu
// http://www.genetics.wustl.edu/eddy/people/zmasek/

package erst.forester.java.src.org.forester.atv;

import java.awt.*;
import java.awt.event.*;
import java.awt.datatransfer.*;

import javax.swing.*;

/**
 * @author Christian Zmasek
 * @version 1.02 last modified: 06/20/00
 */

class ATVtextframe extends JFrame 
    implements ActionListener, ClipboardOwner {

    private boolean   can_use_clipboard;
    
    private String    text;

    private JTextArea jtextarea;

    private JButton   close_button, copy_button;

    private JPanel    buttonjpanel;

    private static Color ta_text_color = new Color( 0, 0, 0 ),
            ta_background_color = new Color( 240, 240, 240 ),
            background_color = new Color( 215, 215, 215 ),
            button_background_color = new Color( 215, 215, 215 ),
            button_text_color = new Color( 0, 0, 0 );
    
    /* Change the font size to 14. (Petar)
    private final static Font button_font = new Font( "Helvetica",
                                                      Font.PLAIN,
                                                      10 ),
            ta_font = new Font( "Helvetica", Font.PLAIN, 10 );
    */
    private final static Font button_font = new Font( "Helvetica",
            Font.PLAIN,
            14 ),
ta_font = new Font( "Helvetica", Font.PLAIN, 14 );

    private Container         contentpane;

    ATVtextframe( String s ) {
        // first things first
        setTitle( "ATV - PARS" );
        text = s;

        // check to see if we have permission to use the clipboard:
        can_use_clipboard = true;
        /* Obsolete method used. Exclude for now. (Petar)
        SecurityManager sm = System.getSecurityManager();
        if (sm != null) {
            try {
                sm.checkSystemClipboardAccess();
            } catch (Exception e) {
                //nope!
                can_use_clipboard = false;
            }
        }
        /* Obsolete method used. Exclude for now. (Petar)
        */
        
        // set up the frame
        setBackground( background_color );
        
        buttonjpanel = new JPanel();
        buttonjpanel.setBackground( background_color );
        
        close_button = new JButton( "          Close          " );
        close_button.setBackground( button_background_color );
        close_button.setForeground( button_text_color );
        close_button.setFont( button_font );
        close_button.addActionListener( this );
        buttonjpanel.add( close_button );
        
        if (can_use_clipboard) {
            copy_button = new JButton( "Copy to clipboard" );
            copy_button.setBackground( button_background_color );
            copy_button.setForeground( button_text_color );
            copy_button.setFont( button_font );
            copy_button.addActionListener( this );
            buttonjpanel.add( copy_button );
        }

        contentpane = getContentPane();
        contentpane.setLayout( new BorderLayout() );

        jtextarea = new JTextArea( text );

        jtextarea.setBackground( ta_background_color );
        jtextarea.setForeground( ta_text_color );
        jtextarea.setFont( ta_font );
        jtextarea.setEditable( false );

        jtextarea.setWrapStyleWord( true );
        jtextarea.setLineWrap( true );

        contentpane.add( new JScrollPane( jtextarea ), BorderLayout.CENTER );


        buttonjpanel.setLayout( new FlowLayout( FlowLayout.CENTER, 20, 5 ) );

        contentpane.add( buttonjpanel, BorderLayout.SOUTH );

        setSize( 500, 400 );

        addWindowListener( new WindowAdapter() {

            public void windowClosing( WindowEvent e ) {
                close();
            }
        } );
        setVisible( true );
    }

    void close() {
        setVisible( false );
        dispose();
    }

    public void actionPerformed( ActionEvent e ) {
        Object o = e.getSource();

        if ( o == close_button ) {
            close();
        }
        else if ( o == copy_button ) {
            copy();
        }

    }
    
    private void copy() {
        if (!can_use_clipboard) {
            // can't do this!
            return;
        }
        
        Clipboard sys_clipboard = getToolkit().getSystemClipboard();
        StringSelection contents = new StringSelection(jtextarea.getText());
        sys_clipboard.setContents(contents, this); 
    }

    public void lostOwnership( Clipboard clipboard, Transferable contents ) { }
} // End of class ATVtexframe.

