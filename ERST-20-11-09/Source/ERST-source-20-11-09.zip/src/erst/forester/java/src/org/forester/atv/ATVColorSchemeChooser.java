package erst.forester.java.src.org.forester.atv;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.Vector;

public class ATVColorSchemeChooser extends JDialog
    implements ActionListener {

    TreeColorSet    colorset;
    
    JComboBox       selector;
    JPanel          color_panel;
    JPanel          color_labels[];
    int             selected_scheme;
    
    JButton         okbtn;
    JButton         cancelbtn;
    
    public ATVColorSchemeChooser(Frame parent, TreeColorSet colorset) {
        super(parent, "Choose Color Scheme", true);	// true = modal
        
        this.colorset = colorset;
        
        setSize(400, 350);
        
        Container contentpane = getContentPane();
        contentpane.setLayout(new BorderLayout(5, 15));
        
        // The scheme selection panel
        JPanel select_panel = new JPanel();
        JLabel l = new JLabel("Choose a color scheme:");
        select_panel.add(l);
        Vector list = new Vector();
        for (int i=0; i<colorset.scheme_names.length; i++) {
            list.add(colorset.scheme_names[i]);
        }
        selector = new JComboBox(list);
        selector.setPreferredSize(new Dimension(100, 20));
        selector.getModel().addListDataListener( 
            new ListDataListener() {
                public void intervalAdded(ListDataEvent e) {}
                public void intervalRemoved(ListDataEvent e) {}
                public void contentsChanged(ListDataEvent e) {
                    int selection = selector.getSelectedIndex();
                    changeDialogColors(selection); 
                }
        } );
        select_panel.add(selector);
        contentpane.add(select_panel, "North");
        
        // create color panel
        int num_colors = colorset.color_fields.length;
        color_panel = new JPanel( new GridLayout(num_colors, 2, 8, 0) );
        JLabel headings[] = new JLabel[num_colors];
        color_labels = new JPanel[num_colors];
        for (int i=0; i<num_colors; i++) {
            headings[i] = new JLabel(colorset.color_fields[i]);
            //headings[i].setFont(new Font("Sans Serif", Font.PLAIN, 9)); Change the font size to 14. (Petar)
            headings[i].setFont(new Font("Sans Serif", Font.PLAIN, 9));
            headings[i].setHorizontalAlignment(SwingConstants.RIGHT);
            color_panel.add(headings[i]);
            color_labels[i] = new JPanel();
            color_labels[i].setPreferredSize(new Dimension(15, 40));
            color_panel.add(color_labels[i]);
        }
        contentpane.add(color_panel, "Center");
        setColors(colorset.color_schemes[0]);
        
        // create button panel
        JPanel btn_panel = new JPanel();
        
        okbtn = new JButton("OK");
        okbtn.addActionListener( new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    ok();
                }
            } );
        btn_panel.add(okbtn);
        
        cancelbtn = new JButton("Cancel");
        cancelbtn.addActionListener( new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    ok();
                }
            } );
        btn_panel.add(cancelbtn);
        
        btn_panel.setPreferredSize(new Dimension(400, 30));
        getContentPane().add(btn_panel, "South");
        
        setCurrentColor(colorset.getCurrentColorScheme());
    }


    public void actionPerformed(ActionEvent e) {
    }
    
    
    public void cancel() {
        // close the window
        selected_scheme = -1;
        setVisible(false);
    }
    
    
    public void changeDialogColors(int scheme_index) {
        selected_scheme = scheme_index;
        setColors(colorset.color_schemes[scheme_index]);
    }
    
    
    public int getScheme() {
      return selected_scheme;
    }
    
    
    public void ok() {
        // set the new color
        colorset.setColors(selected_scheme);
        
        // close the window
        setVisible(false);
    }
    
    
    private void setColors(Color colors[]) {
        for (int i=0; i<colors.length; i++) {
            color_labels[i].setBackground(colors[i]);
        }
    }
    
    public void setCurrentColor(int color_index) {
        setColors(colorset.color_schemes[color_index]);
        selector.setSelectedIndex(color_index);
    }
}
