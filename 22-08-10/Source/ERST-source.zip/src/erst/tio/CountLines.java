package erst.tio;
/**
 * The class <code>CL</code> contains two methods:
 * The method <code>lineCount(String filename)</code>
 * with purpose is to count the lines in a text file.
 * 
 * * @author AFinkelstein (StackOverflow)
 * 
 * Wrapped in a class and included in the package erst.tio by Petar.
 */

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public abstract class CountLines {
	
	/**
	 * The method <code>lineCount(String filename)</code>
	 * which purpose is to count the lines in a text file.
	 * It counts both nonempty and empty lines.
	 * 
	 * * @author AFinkelstein (StackOverflow)
	 * 
	 */	
	public static int lineCount(String filename) throws IOException {
		InputStream is = new BufferedInputStream(new FileInputStream(filename));
		try {
			byte[] c = new byte[1024];
			int count = 0;
			int readChars = 0;
			boolean endsWithoutNewLine = false;
			while ((readChars = is.read(c)) != -1) { // We read the buffer, irrespectively of the number of lines inside.
				for (int i = 0; i < readChars; i++) {
					if (c[i] == '\n')
						count++;
				}
				endsWithoutNewLine = (c[readChars - 1] != '\n');
			}
			if(endsWithoutNewLine) {
				++count;
			} 
			return count;
		} finally {
			is.close();
		}
	} // End of public int lineCount(String filename) throws IOException
	
	
	/**
	 * The method <code>countMeaningfulLines(String filename)</code>
	 * count the lines in a text file which are non-white space and are not comments.
	 * A comment line is that with "#" in the first nonempty position.
	 * 
	 * * @author Petar
	 */	
	public static int countMeaningfulLines(String filename) throws IOException {
	
		int meaningfulLinesCounter = 0;
        ReadInput fileRead = new ReadInput (filename);
	
		try {
			while (fileRead.moreElements) { // Read until exception occurs.
				fileRead.readMeaningfulLine();
				meaningfulLinesCounter++;
			}
			
		}finally {
			//fileRead.close();
		}
		return meaningfulLinesCounter;
	}
	/*
	*/	
	

} // End of public class CountLines
	