/*
 * Created on Jun 5, 2005
 *
 */
package erst.forester.java.src.org.forester.phylogeny.parsers;

import java.io.IOException;

/**
 * @author Christian Zmasek
 *
 */
public class PhylogenyParserException extends IOException {

    /**
     * 
     */
    public PhylogenyParserException() {
        super();
    }

    /**
     * @param arg0
     */
    public PhylogenyParserException( String message ) {
        super( message );
    }

}
