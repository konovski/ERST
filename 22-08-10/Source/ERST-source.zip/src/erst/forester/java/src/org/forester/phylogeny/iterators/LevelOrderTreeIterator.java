/*
 * Created on Oct 23, 2005 TODO To change the template for this generated file
 * go to Window - Preferences - Java - Code Style - Code Templates
 */
package erst.forester.java.src.org.forester.phylogeny.iterators;

import java.util.NoSuchElementException;

import erst.forester.java.src.org.forester.datastructures.Queue;
import erst.forester.java.src.org.forester.phylogeny.Phylogeny;
import erst.forester.java.src.org.forester.phylogeny.PhylogenyNode;

/**
 * An iterator to iterate a Phylogeny in level order.
 * 
 * Created: 10/23/2005 by Christian M. Zmasek.
 * Last modified: 10/23/2005 by Christian M. Zmasek.
 * 
 * @author Christian M. Zmasek
 * @version 1.000
 */
public class LevelOrderTreeIterator implements PhylogenyNodeIterator {
    
    // Constructors
    // ------------
    
  
    /**
     * Creates a new LevelOrderTreeIterator for iterating
     * over all the nodes of Phylogeny phylogeny
     * 
     * @param phylogeny the Phylogeny to iterate over
     * @throws IllegalArgumentException if phylogeny is empty
     */
    public LevelOrderTreeIterator( final Phylogeny phylogeny ) throws IllegalArgumentException {
        this( phylogeny.getRoot() );
        if ( phylogeny.isEmpty() ) {
            throw new IllegalArgumentException(
                    "Attempt to use LevelOrderTreeIterator on an empty phylogeny." );
        }
        
       
    }
    
    /**
     * Creates a new LevelOrderTreeIterator for iterating
     * over all the child nodes of PhylogenyNode node (including 
     * node itself). 
     * 
     * @param node the parent of the nodes to iterate over
     */
    public LevelOrderTreeIterator( final PhylogenyNode node ) {
       
        _queue = new Queue();
        _root = node;
        reset();
    }

    // Public methods
    // --------------
    
    /**
     * Returns true is this iterator has at least one more element,
     * false otherwise.
     * 
     * @return true is this iterator has at least one more element,
     * false otherwise
     */
    public boolean hasNext() {
        return !getQueue().isEmpty();
    }

    /**
     * Returns the next PhylogenyNode.
     * 
     * @return the next PhylogenyNode
     * @throws NoSuchElementException if iteration is complete
     */
    public PhylogenyNode next() throws NoSuchElementException {
        if ( !hasNext() ) {
            throw new NoSuchElementException(
                    "Attempt to call \"next()\" on iterator which has no more next elements." );
        }

        final PhylogenyNode node = ( PhylogenyNode ) getQueue().dequeue();

        for ( int i = 0; i < node.getNumberOfChildNodes(); ++i ) {
            getQueue().enqueue( node.getChildNode( i ) );
        }

        return node;
    }

    /**
     * Resets the iterator.
     */
    public void reset() {
        getQueue().clear();
        getQueue().enqueue( getRoot() );
    }

    
    // Private methods
    // ---------------
    
    /**
     * Returns the queue upon which this iterator is based.
     * 
     */
    private Queue getQueue() {
        return _queue;
    }

    /**
     * Returns the root of the phylogeny this iterators parses over.
     * 
     * @return the root of the phylogeny this iterators parses over.
     */
    private PhylogenyNode getRoot() {
        return _root;
    }

    
    // Instance variables
    // ------------------
    
    private final Queue         _queue;
    private final PhylogenyNode _root;
    
} // enod of class LevelOrderTreeIterator
