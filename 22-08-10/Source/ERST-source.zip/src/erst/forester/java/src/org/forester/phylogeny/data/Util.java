package erst.forester.java.src.org.forester.phylogeny.data;

import java.util.ArrayList;

public final class Util {

    /**
     * Creates a deep copy of ArrayList of PhylogenyData objects.
     * 
     * @param list
     *            an ArrayList of PhylogenyData objects
     * @return a deep copy of ArrayList list
     */
    static ArrayList copy( final ArrayList list ) {
        ArrayList l = new ArrayList( list.size() );
        for ( int i = 0; i < list.size(); ++i ) {
            l.add( ( ( PhylogenyData ) list.get( i ) ).copy() );
        }
        return l;
    }
}
