// ATVprinter.java
//
// Copyright (C) 1999-2001 Washington University School of Medicine
// and Howard Hughes Medical Institute
// All rights reserved
//
// Created: 1999
// Author: Christian M. Zmasek
// zmasek@genetics.wustl.edu
// http://www.genetics.wustl.edu/eddy/people/zmasek/

package erst.forester.java.src.org.forester.atv;


import java.awt.*;

import erst.forester.java.src.org.forester.phylogeny.*;

/**
 * @author Christian Zmasek
 * @version 1.500 -- last modified: 02/17/02
 */
class ATVprinter extends Frame {

    private Phylogeny         tree;

    private String       title;

    private ATVtreePanel atvtreepanel;
    private ATVcontrol   atvcontrol;

    boolean              print_in_color;

    ATVprinter( ATVtreePanel atp, ATVcontrol ac, String s, boolean print_in_color ) {

        atvtreepanel = atp;
        atvcontrol = ac;
        tree = atvtreepanel.getTree();
        title = s;
        this.print_in_color = print_in_color;
        
        printTree();

        atvtreepanel = null;
        tree = null;

        dispose();

    }

    private void printTree() {

        if ( tree == null || tree.isEmpty() ) {
            return;
        }

        Graphics g;
        Toolkit tk = Toolkit.getDefaultToolkit();
        if ( tk != null ) {

            PrintJob pj = tk.getPrintJob( this, title, null );
            if ( pj != null ) {

                g = pj.getGraphics();
                

                if ( g != null ) {
                    boolean show_boxes = atvcontrol.isMarkNodesWithBox();
                    atvcontrol.setCheckbox( ATVConfig.mark_nodes_with_box, false);
                    atvtreepanel.paintTree( g, print_in_color );
                    atvcontrol.setCheckbox( ATVConfig.mark_nodes_with_box, show_boxes);
                    tree.setIndicatorsToZero();

                    g.dispose();

                }
                else {
                    System.out.println( "Failed to get Graphics for print job!" );
                }

                pj.end();

            }
            else {
                System.out.println( "Failed to start print job!" );
            }
        }

    } // end of method printTree.

} // End of class ATVprinter.
