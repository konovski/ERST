// ATVtreePanel.java
// Renamed from ATVgraphic
//
// Copyright (C) 1999-2002 Washington University School of Medicine
// and Howard Hughes Medical Institute
// All rights reserved
//
// Created: 1999
// Author: Christian M. Zmasek
// zmasek@genetics.wustl.edu
// http://www.genetics.wustl.edu/eddy/people/zmasek/
//
// Reorganized: August, 2005
// Ethy Cannon
// ethy@a415software.com
// Modified: 2006, Renata
// Modified: 2008-2021, Petar
package erst.forester.java.src.org.forester.atv;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;

import erst.forester.java.src.org.forester.phylogeny.Phylogeny;
import erst.forester.java.src.org.forester.phylogeny.PhylogenyNode;
import erst.forester.java.src.org.forester.phylogeny.TagValueUnit;
import erst.forester.java.src.org.forester.phylogeny.iterators.PhylogenyNodeIterator;
import erst.forester.java.src.org.forester.util.Util;
import erst.genalg.GetGL;
import erst.genalg.InnerData;


/**
 * @author Christian M. Zmasek
 * @version 1.420 -- last modified: 01/05/04
 */
class ATVtreePanel extends JPanel implements ActionListener {
    // ATVtreePanel and ATVcontrol need peer pointers to each other
    ATVcontrol atvcontrolpanel;
    
    // Need a pointer to the config settings
    ATVConfig  config_settings;
    
    // default max ortho value (max # a seq is expected to be 
    //     orthologous towards another, i.e. the number of 
    //     resampling steps.
    final static private int    MAX_ORTHO_DEFAULT          = 100;
    
    // For drawing boxes at nodes
    final static int            BOX_SIZE                   = 6;
    final static int            HALF_BOX_SIZE              = BOX_SIZE / 2;
    
    // Maximum # of subtrees
    final static int            MAX_SUBTREES               = 100;
    
    // Maximum # of popup frames that can be up at once
    final static int            MAX_POPUPFRAMES            = 10;
    
    // Space between ???
    final static int            MOVE                       = 30;
    
    // Click-on actions
    final static int            EDIT_INFO                  = 6;
    final static int            COLLAPSE                   = 7;
    final static int            REROOT                     = 8;
    final static int            SUBTREE                    = 9;
    final static int            SWAP                       = 10;
    final static int            SHOW_NODE_SEQUENCES        = 11;
    final static int            SHOW_NODE_GLYPH_INFO       = 12;
    final static int            CUSTOM_OPTION              = 13;
    // added by Renata
    final static int            SHOW_NODE_HPFS             = 14;
    final static int            SHOW_ROOT_HPFS             = 15;
    
    // Number format
    private NumberFormat        dist_nf                    = NumberFormat
                                                             .getNumberInstance();
    // Font set for drawing the tree:
    TreeFontSet                 fontset;
    
    // Color set for drawing the tree:
    TreeColorSet                colorset;
    
    // Support for species colors
    Hashtable                   species_colors             = null;
    int                         next_default_color         = 0; // used
    
    // to set species colors on the fly:
    String[]                    default_species_colors     = { 
        "0xff9999", "0x0000ff", "0xa52a2a", "0xff0000", "0x33a033",
        "0x803380", "0xcd3333", "0xd76400", "0x500000", "0x780078",
        "0x0000f5", "0x00007d", "0x00f500", "0x00af00", "0x00ff00" };
    
    //added by Renata
    ATVrootHPFFrame[]           atvroothpfframes           = new ATVrootHPFFrame[ MAX_POPUPFRAMES ];
    int                         roothpfframe_index             = 0;
     
        
    //added by Renata
    ATVnodeHPFFrame[]           atvnodehpfframes           = new ATVnodeHPFFrame[ MAX_POPUPFRAMES ];
    int                         hpfframe_index             = 0;
    
    //added by Petar
    private boolean if_drawLegend							= false; 

        
    // node seq names popup frames
    ATVnodeSeqFrame[]           atvnodeseqframes           = new ATVnodeSeqFrame[ MAX_POPUPFRAMES ];
    int                         seqframe_index             = 0;
    
    // Node glyph popup frames
    ATVnodeGlyphFrame[]         atvnodeglyphframes         = new ATVnodeGlyphFrame[ MAX_POPUPFRAMES ];
    int                         glyphframe_index           = 0;
    
    // Edit node popup frames
    ATVeditNodeFrame[]          atveditnodeframes          = new ATVeditNodeFrame[ MAX_POPUPFRAMES ];
    int                         editframe_index            = 0;
    
    // class-level pointer to the current node
    PhylogenyNode               node                       = null;
    
    // The TREE
    Phylogeny                   tree                       = null;
    
    // Temporary storage for sub trees
    Phylogeny[]                 trees                      = new Phylogeny[ MAX_SUBTREES ];
    int                         subtree_index              = 0;
    
    // Pointer back to the ATVpanel owner of this component
    ATVpanel                    atvpanel                   = null;
    
    // Pointer to peer extension panel (may be null)
    ATVnodeGlyphPanel           atvextension               = null;
    
    // Name of the glyph class to use
    String                      glyph_class_name;
    
    // List of nodes found on search
    Hashtable                   _found_nodes               = null;
    
    // Highlighted node (probably because it was clicked)
    PhylogenyNode               _highlight_node            = null;
    
    // External node which extends farthest to the right?
    private int                 longest_ext_node_info      = 0;
    
    // maximum ortho value
    private int                 max_ortho                  = MAX_ORTHO_DEFAULT;
    
    // Indicates what should happen when user clicks on a node
    int                         action_when_node_clicked   = 0;
    
    // Drawing parameters
    private double              x_correction_factor        = 0.0;
    private double              x_distance                 = 0.0;
    private double              y_distance                 = 0.0;
    
    // Set and used by tree-drawing code; defined here to avoid
    //    even more parameter passing.
    double                      x_current;
    int                         y_current;
    
    // Cursors we'll need
    protected Cursor            arrow_cursor               = Cursor
        .getPredefinedCursor( Cursor.DEFAULT_CURSOR );
    protected Cursor            hand_cursor                = Cursor
        .getPredefinedCursor( Cursor.HAND_CURSOR );
    
    JPopupMenu                  clickto_single_menu = null;
    JPopupMenu                  clickto_multiple_menu = null;
    JMenuItem                   clickto_single_items[];
    JMenuItem                   clickto_multiple_items[];
    
    //public long paintCounter = 0; // For testing purposes (Petar)
    
    /**
     * Default constructor.
     */
   /* Excluded by Petar
    ATVtreePanel() {
    	// The constructor without parameter list.
    }
   */
   int specHPF;
   public void setKeySpec(int p) { specHPF = p; }
   public int getKeySpec() { return specHPF; }

   /**
    * Constructor. 
    * Last modified: 8/5/05
    */
   ATVtreePanel( Phylogeny t, ATVConfig config_settings,
                  ATVpanel tjp, ATVnodeGlyphPanel atvextension ) {
       this.tree = t;
       this.config_settings = config_settings;
       this.atvextension = atvextension;
        
       if ( ( tree != null ) && !tree.isEmpty() ) {
            tree.adjustNodeCount( true );
//            tree.recalculateAndReset();
       }
//        if (atvtp.getKeySpec() > 0)
//            System.out.println("������������������������������������ " + atvtp.getKeySpec());
       atvpanel = tjp;

       // The set of colors used for drawing trees
       colorset = new TreeColorSet(true);   // true = use colors
        
       // The set of fonts used for drawing trees
       fontset = new TreeFontSet(this);
       fontset.mediumFonts();
        
       setBackground( colorset.get_background_color() );
       addMouseListener( new ATVmouseListener( this ) );
        
       addMouseMotionListener( new ATVMouseMotionListener( this ) );
        
       calculateLongestExtNodeInfo();
        
       max_ortho = MAX_ORTHO_DEFAULT;
        
       dist_nf.setMaximumFractionDigits( 6 );
       dist_nf.setMinimumFractionDigits( 1 );
        
       // CZ added, to prevent null pointer exception 12/29/04
//        species_colors = new Vector();
       species_colors = new Hashtable();
 
// Keep this idea: turn off branch lengths and bootstraps if no data for them?
//        if ( ( tree != null ) && !tree.isEmpty() ) {
//            // Checks whether bootstrap, branch lengths have been assigned.
//            //    Careful about over-riding existing display options (turn off, but not on)
//            if ( tree.getFirstExternalNode() != null ) {
//                if ( tree.getFirstExternalNode().getDistanceToParent() == PhylogenyNode.DISTANCE_DEFAULT ) {
//                    display_options.setUseRealBranchLengths( false );
//                }
//                
//                if ( tree.getFirstExternalNode().getParent() != null ) {
//                    if ( tree.getFirstExternalNode().getParent().getBootstrap() == PhylogenyNode.BOOTSTRAP_DEFAULT ) {
//                        display_options.setWriteBootstrapValues( false );
//                    }
//                }
//            }
//        }
        
    }//constructor


    /**
     *
     */
    public void actionPerformed( ActionEvent e ) {
        int index;
        boolean done = false;
        // String cmd = e.getActionCommand(); - Excluded by Petar (never read).
      JMenuItem mi = (JMenuItem)e.getSource();
      
      // associated node is stored as client property of the popup menu
      // item selected from multiple-node popup menu?
      for (index=0; index<clickto_multiple_items.length&&!done; index++) {
        // NOTE: index corresponds to the indices of click-to options
        //       in the control panel.
        if ( mi == clickto_multiple_items[index] ) {
          // Set this as the new default click-to action
          atvpanel.getATVcontrol().setClickToAction( index );
          handleClickToAction( action_when_node_clicked, null );
          done = true;
        }
      }
      
      if (!done) {
        // maybe item is from single-node popup menu
        for (index=0; index<clickto_single_items.length&&!done; index++) {
          // NOTE: index corresponds to the indices of click-to options
          //       in the control panel.
          if ( mi == clickto_single_items[index] ) {
            // Set this as the new default click-to action
            atvpanel.getATVcontrol().setClickToAction( index );
            
            // The variable name node was changed to clickedNode  by Petar.
            PhylogenyNode clickedNode = (PhylogenyNode)clickto_single_menu.getClientProperty("node");
            handleClickToAction( action_when_node_clicked, clickedNode );
            done = true;
          }
        }
      }
    }
    
    
    /**
     * DOCUMENT ME!
     * @param phNode
     * @param is_vertical
     * @param g
     */
    void assignGraphicsForBranchWithColorForParentBranch( PhylogenyNode phNode,
                                                          boolean is_vertical, 
                                                          Graphics g ) {
        if ( atvcontrolpanel.isColorBranches()
            && phNode.isParentBranchColorAssigned()
            && ( !is_vertical || ( phNode.isRoot() || ( !phNode.getParent()
                        .isPseudoNode()
                        && !phNode.getParent().getChildNode1().isPseudoNode() && !phNode
                        .getParent().getChildNode2().isPseudoNode() ) ) ) ) {
            g.setColor( phNode.getColor() );
        }
        else {
            g.setColor( colorset.get_branch_color() );
        }
    }//assignGraphicsForBranchWithColorForParentBranch
    
    
    /**
     * DOCUMENT ME!
     * @param phNode
     * @param g
     */
    void assignGraphicsForNodeBoxWithColorForParentBranch( PhylogenyNode phNode,
        Graphics g ) {
        if ( atvcontrolpanel.isColorBranches() && phNode.isParentBranchColorAssigned() ) {
            g.setColor( phNode.getColor() );
        }
        else {
            g.setColor( colorset.get_branch_color() );
        }
    }//assignGraphicsForNodeBoxWithColorForParentBranch
    

    /**
     * Calculate the length of the distance between the given node and
     * its parent.
     * @param phNode 
     * @param ext_node_x
     * @factor
     * @return the distance value
     */
    private double calculateBranchLength(PhylogenyNode phNode, int ext_nodes_x,
        int factor ) {
        double x2double;
        
        if ( atvcontrolpanel.useRealBranchLengths() ) {
            double d = phNode.getDistanceToParent();
            if ( d < 0.0 ) d = 0.0;
                x2double = x_current + ( x_correction_factor * d );
        }
        else if ( phNode.isExternal()
            || phNode.isCollapse() ) {
            x2double = ext_nodes_x;
        }
        else if ( phNode.isPseudoNode() ) {
            x2double = x_current;
        }
        else {
            x2double = x_current + ( x_distance * factor );
        }
        
        if ( !atvcontrolpanel.useRealBranchLengths() && phNode.isPseudoNode()
            && !phNode.isPseudoNode()
            && !phNode.isExternal()
            && !phNode.isCollapse() ) {
            PhylogenyNode n = phNode.getParent();
            
            while ( n.isPseudoNode() ) {
                n = n.getParent();
            }
            
            x2double += ( ( n.getSumExtNodes() - phNode
                    .getSumExtNodes() ) * x_distance );
        }
        
        return x2double;
    }//calculateBranchLength
    
    
    /**
     * (Last modified: 06/13/01)
     */
    private Color calculateColorForOrthologous( PhylogenyNode n ) {
        int o = n.getOrthologous();
        
        if ( o == PhylogenyNode.SEQ_X ) {
            return colorset.get_seq_x_color();
        }
        // else { - Excluded by Petar - "if" finishes with "return".
            if ( o > getMaxOrtho() ) {
                o = getMaxOrtho();
            }
            else if ( o < 0 ) {
                o = 0;
            }
            
            int green = ( o * 200 ) / getMaxOrtho();
            
            return new Color( colorset.get_ext_node_seq_color().getRed(), 
                              green, 
                              colorset.get_ext_node_seq_color().getBlue() );
        // }
    }//calculateColorForOrthologous
    
    
    /**
     * (Last modified: 06/13/01)
     */
    private Color calculateColorForSuperOrthologous( PhylogenyNode n ) {
        int o = n.getSuperOrthologous();
        
        if ( o == PhylogenyNode.SEQ_X ) {
            return colorset.get_seq_x_color();
        }
        
        if ( o > getMaxOrtho() ) {
            o = getMaxOrtho();
        }
        else if ( o < 0 ) {
            o = 0;
        }
        
        int red = ( o * 255 ) / getMaxOrtho();
        
        return new Color( red, 
                          colorset.get_ext_node_seq_color().getGreen(),
                          colorset.get_ext_node_seq_color().getBlue() );
    }//calculateColorForSuperOrthologous
    
    
    /**
     * (Last modified: 02/16/02)
     */
    private Color calculateColorForSubtreeNeighbors( PhylogenyNode n ) {
        int o = n.getSubtreeNeighborings();
        
        if ( o == PhylogenyNode.SEQ_X ) {
            return colorset.get_seq_x_color();
        }
        // else { - Excluded by Petar - "if" finishes with "return".
            if ( o > getMaxOrtho() ) {
                o = getMaxOrtho();
            }
            else if ( o < 0 ) {
                o = 0;
            }
            
            int c = ( o * 255 ) / getMaxOrtho();
            
            return new Color( colorset.get_ext_node_seq_color().getRed(), 
                              c, c );
        // }
    }//calculateColorForSubtreeNeighbors
    
    
    /**
     * DOCUMENT ME!
     */
    void calculateLongestExtNodeInfo() {
        if ( ( tree == null ) || tree.isEmpty() ) {
            return;
        }
        
        int longest = 0;
        int sum = 0;
        
        for ( PhylogenyNodeIterator iter = tree.iteratorExternalForward(); iter
            .hasNext(); ) {
            PhylogenyNode phNode = iter.next();
            sum = fontset.fm_large_italic.stringWidth( phNode.getTaxonomy() + " " )
            + fontset.fm_large.stringWidth( phNode.getSeqName() + " " )
            + fontset.fm_large.stringWidth( phNode.getECnumber() );
          
          // Check length of custom data string, if any
          String s = customDataAsString( phNode );
          if ( s != null ) {
              sum += fontset.fm_large.stringWidth( "  " + s );
          }
            
          if ( sum > longest ) {
              longest = sum;
          }
            
            sum = 0;
        }
        
        setLongestExtNodeInfo( longest );
    }//calculateLongestExtNodeInfo
    
    
    /**
     * Collapse the tree from the given node
     * @param phNode a PhylogenyNode
     */
    void collapse( PhylogenyNode phNode ) {
        if ( !phNode.isExternal() ) {
            phNode.setCollapse( !phNode.isCollapse() );
            tree.adjustNodeCount( true );
//            tree.recalculateAndReset();
            resetPreferredSize();
            atvpanel.adjustJScrollPane();
            atvpanel.treeChanged( tree.getRoot() );
            repaint();
        }
    }//collapse
    

    /**
     * Build the custom data string for this node.
     * (last modified by eksc 8/17/05)
     * @param phNode
     * @return string
     */
    String customDataAsString( PhylogenyNode phNode ) {
        TagValueUnit[] tvu = phNode.getCustomTagValueUnitsAsArray();
        
        if ( tvu.length > 0 ) {
            StringBuffer sb = new StringBuffer( 100 );
            for ( int i = 0; i < tvu.length; ++i ) {
                String tag = tvu[ i ].getTag();
                if (atvcontrolpanel != null && atvcontrolpanel.isCustomTagChecked(tag)) {
                    Object value = tvu[ i ].getValue();
                    String unit = tvu[ i ].getUnit();
                    sb.append( tag );
                    sb.append( ": " );
                    sb.append( value.toString() );
                    sb.append( unit );
                    sb.append( " | " );
                }
            }
            if ( sb.length() > 0 ) {
                return "| " + sb.toString();
            }
        }
        return null;
    }//customDataAsString
    
    
    /**
     * customOption()
     * This notifies the parent app/applet that the custom click-to action
     * happened on this node
     */
    private void customOption( PhylogenyNode n ) {
        // See if this is one or multiple nodes
        if (_found_nodes != null && _found_nodes.containsKey(n)) {
            atvpanel.atvframe.customOption(_found_nodes);
        } else {
            atvpanel.atvframe.customOption(n);
        }
    }
    
    
    /**
     * 
     */
    void drawCollapsedNode( int x, int y, Graphics g, PhylogenyNode phNode,
        boolean found, boolean in_color ) {
        int offset = 0;
        g.setColor( colorset.get_branch_color() );
        g.drawRect( x - HALF_BOX_SIZE, y - HALF_BOX_SIZE, BOX_SIZE, BOX_SIZE );
        
        if ( found ) {
            g.setColor( colorset.get_background_color() );
        }
        else {
            g.setColor( colorset.get_collapse_fill_color() );
        }
        
        g.fillRect( x - HALF_BOX_SIZE + 1, y - HALF_BOX_SIZE + 1, BOX_SIZE - 1,
            BOX_SIZE - 1 );
        
        if ( atvcontrolpanel.speciesExtNodes() && ( phNode.getTaxonomy().length() > 0 ) ) {
            g.setFont( fontset.large_italic_font );
            g.setColor( colorset.get_species_name_color() );
            int start_x = x + 3 + HALF_BOX_SIZE;
            int start_y = y + ( fontset.fm_large_italic.getAscent() / 2 ); 
            String label = phNode.getTaxonomy();
            if ( atvcontrolpanel.seqNameExtNodes() && ( phNode.getSeqName().length() > 0 ) ) {
                label += ":";
                g.drawString( label, start_x, start_y );
                offset = fontset.fm_large_italic.stringWidth( label );
            }
            else {
                g.drawString( label, start_x, start_y );
            }
            
            // draw a box around the text if in _found_nodes
            if ( ( _found_nodes != null ) && _found_nodes.containsKey( phNode ) ) {
                g.setColor( colorset.get_found_color() );
                int height = g.getFontMetrics().getAscent();
                g.drawRect(start_x,
                           start_y - height, 
                           g.getFontMetrics().stringWidth(label),
                           height);
           }
        }
        
        if ( atvcontrolpanel.seqNameExtNodes() && ( phNode.getSeqName().length() > 0 ) ) {
            g.setFont( fontset.large_font );
            g.setColor( colorset.get_int_node_seq_color() );
            
            int start_x = x + 3 + HALF_BOX_SIZE + offset;
            int start_y =  y + fontset.fm_large.getAscent() / 2;
            String label = phNode.getSeqName();
            g.drawString( label , start_x, start_y );
                
            // draw a box around the text if in _found_nodes
            if ( ( _found_nodes != null ) && _found_nodes.containsKey( phNode ) ) {
                g.setColor( colorset.get_found_color() );
                int height = g.getFontMetrics().getAscent();
                g.drawRect(start_x,
                           start_y - height, 
                           g.getFontMetrics().stringWidth(label),
                           height);
           }
        }
    }//drawCollapsedNode
    
    
    /**
     * (Last modified: 08/13/01)
     */
    void drawFoundNode( int x, int y, Graphics g, boolean duplication, boolean in_color ) {
        if ( duplication ) { 
            g.setColor( colorset.get_dup_box_color() ); 
        } else {
            g.setColor( colorset.get_box_color() ); 
        } 
        g.drawRect( x - HALF_BOX_SIZE, y -
                        HALF_BOX_SIZE, BOX_SIZE, BOX_SIZE ); 
        g.setColor( colorset.get_found_color() );
        g.fillRect( x - HALF_BOX_SIZE + 1, y - HALF_BOX_SIZE + 1, 
                        BOX_SIZE - 1, BOX_SIZE - 1 );
        
    } // drawFoundNode( int, int, Graphics, boolean )
    
    
    /**
     * DOCUMENT ME!
     * @param x1
     * @param y1
     * @param x2
     * @param y2
     * @param phNode
     * @param is_vertical
     * @param g
     */
    /* Redesign drawLine in order to allow drawing thicker branches,
     * without elaboration. The original source commented off is below. (Petar)
     */
    void drawLine( int x1, int y1, int x2, int y2, PhylogenyNode phNode,
        boolean is_vertical, Graphics g, boolean in_color ) {
    	
        int w = 2; //Rough approach for setting the width of the branches (Petar).
            
           
        if ( !is_vertical ) {
            g.fillRect( x1, y1 - ( w / 2 ), x2 - x1, w );
        }
        else {
            if ( y2 > y1 ) {
                g.fillRect( x1, y1, w, y2 - y1 + ( w / 2 ) );
            }
            else {
                int w2 = w / 2;
                g.fillRect( x1, y2 - w2, w, y1 - y2 + w2 + 1 );
            }
        }

    }//drawLine


    /*
    void drawLine( int x1, int y1, int x2, int y2, PhylogenyNode phNode,
        boolean is_vertical, Graphics g, boolean in_color ) {
        if ( atvcontrolpanel.isWidthBranches()
            && phNode.isParentBranchWidthAssigned()
            && ( !is_vertical || ( !phNode.getParent().getChildNode1()
                    .isPseudoNode() && !phNode.getParent().getChildNode2()
                    .isPseudoNode() ) ) ) {
            int w = phNode.getParentBranchWidth();
            
            if ( w < 1 ) {
                return;
            }
            
            if ( !is_vertical ) {
                g.fillRect( x1, y1 - ( w / 2 ), x2 - x1, w );
            }
            else {
                if ( y2 > y1 ) {
                    g.fillRect( x1, y1, w, y2 - y1 + ( w / 2 ) );
                }
                else {
                    int w2 = w / 2;
                    g.fillRect( x1, y2 - w2, w, y1 - y2 + w2 + 1 );
                }
            }
        }
        else {
            g.drawLine( x1, y1, x2, y2 );
        }
    }//drawLine 
    */
    
    
    /* Drawing a circle around a node (Petar)
       The circle is three lines thick and its drawing is with empirical approach.
       The radius is fixed to 14 pixels, which suits us for marking the nodes, where
       genes are gained, lost or inherited.
       The colour for the graphics is preset.
    */
       
    private void drawNodeCircle(int x, int y, Graphics g, Color col) {
    	
    	g.setColor(col);
        g.drawOval(x-8, y-7, 13, 13);
        g.drawOval(x-9, y-7, 14, 14);
        g.drawOval(x-9, y-8, 15, 15);
    } 
    /*
    */

    
    
    /**
     * Draw a box at the indicated node.
     * @param x
     * @param y
     * @param node
     * @param g
     */
    void drawNodeBox( int x, int y, PhylogenyNode node, Graphics g, boolean in_color) {
        /* Commented off to switch to InnerData approach (Petar).
        // boolean keyHPF = GraphTabPanel.key; - Never read (Petar).
        int indexInToHash = atvpanel.hashCode();
        Integer index = (Integer)GraphTabPanel.indexLookup.get(new Integer (indexInToHash)); // look for context first
        String str;
        if (index != null)
            str = "Found " + index;
        else {
            index = (Integer)GraphTabPanel.indexLookup.get(null); // find if place reserved?
            if(index != null) {
                str = "HERE " + index;
                GraphTabPanel.indexLookup.remove(null);
                GraphTabPanel.indexLookup.put(new Integer (indexInToHash), index);
          } else
                str = "Not found"; //error should't happen
        }
        //int indexHPF = index.intValue(); //GraphTabPanel.index; //
        */
        int indexHPF = InnerData.chosenHPF;
        
        if (indexHPF >= 0) { // We must accept the first index as well (Petar).
        	// We replaced the usage of readGLatv methods with the corresponding
        	// methods from GetGL. The call of execute is redundant (Petar).
			// Replacement of the original segment, which is commented out:
			ArrayList<Integer> gains = GetGL.getHPFGains(indexHPF);
			ArrayList<Integer> losses = GetGL.getHPFLosses(indexHPF);
			ArrayList<Integer> inherited = GetGL.getHPFInherited(indexHPF);
			
            /*
            readGLatv readgainslosses = new readGLatv(); 
            readgainslosses.execute();
            // Iterator iteratorGain = readgainslosses.getHPFGain(indexHPF-1).iterator(); - Modified by Petar.
            Iterator iteratorGain = readgainslosses.getHPFGain(indexHPF).iterator();
            */
            Iterator<Integer> iteratorGain = gains.iterator();
            while (iteratorGain.hasNext()) {
                Integer elementGain = (Integer)iteratorGain.next();
                if (elementGain.intValue() == node.getID()) {
                    /* 
                    g.setColor(colorset.get_re_gain_color()); //.get_found_color());
                    g.drawOval(x-8, y-8, 16, 16);
                    g.drawOval(x-9, y-8, 17, 17);
                    g.drawOval(x-9, y-9, 18, 18);
                    Decrease the radius, organise with a function. (Petar)
                    */
                    drawNodeCircle(x, y, g, colorset.get_re_gain_color());
                    if_drawLegend = true;
                }
            }
            // Iterator iteratorLoss = readgainslosses.getHPFLoss(indexHPF-1).iterator(); - Modified by Petar.
            //Iterator iteratorLoss = readgainslosses.getHPFLoss(indexHPF).iterator();
            Iterator<Integer> iteratorLoss = losses.iterator();
            while (iteratorLoss.hasNext()) {
                Integer elementLoss = (Integer)iteratorLoss.next();
                if (elementLoss.intValue() == node.getID()) {
                    /*
                    g.setColor(colorset.get_re_lost_color()); //.get_found_color());
                    g.drawOval(x-8, y-8, 16, 16);
                    g.drawOval(x-9, y-8, 17, 17);
                    g.drawOval(x-9, y-9, 18, 18);
                    Decrease the radius, organise with a function. (Petar)
                    */
                    drawNodeCircle(x, y, g, colorset.get_re_lost_color()); 
                    if_drawLegend = true;
                }
            }
            
            // Iterator iteratorInherited = readgainslosses.getHPFInherited(indexHPF-1).iterator(); - Modified by Petar.
            //Iterator iteratorInherited = readgainslosses.getHPFInherited(indexHPF).iterator();
            Iterator<Integer> iteratorInherited = inherited.iterator();
            while (iteratorInherited.hasNext()) {
                Integer elementInherited = (Integer)iteratorInherited.next();
                if (elementInherited.intValue() == node.getID()) {
                    /* Decrease the radius, organise with a function. (Petar)
                    g.setColor(colorset.get_re_inherited_color()); //.get_found_color());
                    g.drawOval(x-8, y-8, 16, 16);
                    g.drawOval(x-9, y-8, 17, 17);
                    g.drawOval(x-9, y-9, 18, 18);
                    */
                    drawNodeCircle(x, y, g, colorset.get_re_inherited_color()); 
                    if_drawLegend = true;
                }
            }
        }
        
        if (_highlight_node == node) {
            drawNodeCircle(x, y, g, colorset.get_found_color()); 
        }
        
        if ( !node.isPseudoNode() && atvcontrolpanel.isMarkNodesWithBox() ) {
            if ( node.isCollapse() ) {
                drawCollapsedNode( x, y, g, node,
                    ( ( _found_nodes != null ) && 
                        _found_nodes.containsKey( node ) ), in_color );
            }
            else if ( ( _found_nodes != null ) &&
                        _found_nodes.containsKey( node ) ) {
                if ( !atvcontrolpanel.writeDupSpec() && node.isDuplicationOrSpecAssigned()
                    && node.isDuplication() ) {
                    drawFoundNode( x, y, g, true, in_color );
                }
                else {
                    drawFoundNode( x, y, g, false, in_color );
                }
            }
            else {
                if ( atvcontrolpanel.writeDupSpec() && node.isDuplicationOrSpecAssigned()
                    && node.isDuplication() ) {
                    g.setColor( colorset.get_dup_box_color() );
                }
                else {
                    assignGraphicsForNodeBoxWithColorForParentBranch( node, g );
                }
                
                // draw a box so there's something to click for the nodes
                g.fillRect( x - HALF_BOX_SIZE, y - HALF_BOX_SIZE, BOX_SIZE, BOX_SIZE );
            }
        }
    } // End of void drawNodeBox( int x, int y, PhylogenyNode node, Graphics g, boolean in_color)
    
    
    /**
     * Find the node, if any, at the given location
     * @param x
     * @param y
     * @return pointer to the node at x,y, null if not found
     */
    PhylogenyNode findNode( int x, int y ) {
        int wiggle = 3; // a few extra pixels of "wiggle" room
        
        if ( ( tree == null ) || tree.isEmpty() ) {
            return null;
        }
        
        for ( PhylogenyNodeIterator iter = tree.iteratorPostorder(); iter
            .hasNext(); ) {
            PhylogenyNode node = iter.next();
            
            if ( !node.isPseudoNode() && ( tree.isRooted() || !node.isRoot() )
                && ( ( node.getXcoord() - HALF_BOX_SIZE - wiggle ) <= x )
                && ( ( node.getXcoord() + HALF_BOX_SIZE + wiggle ) >= x )
                && ( ( node.getYcoord() - HALF_BOX_SIZE - wiggle ) <= y )
                && ( ( node.getYcoord() + HALF_BOX_SIZE + wiggle ) >= y ) ) {
                return node;
            }
        }
        
        return null; // not found
    }//findNode
    

    /**
     * Find the sequence name, if any, at the given x,y location
     * @param x 
     * @param y
     * @return squence name or null if not found
     */
    String findSequenceName( int x, int y ) {
        if ( ( tree == null ) || tree.isEmpty() ) {
            return null;
        }
        
        for ( PhylogenyNodeIterator iter = tree.iteratorPostorder(); iter
            .hasNext(); ) {
            PhylogenyNode node = iter.next();
            
            if ( !node.isPseudoNode() && ( tree.isRooted() || !node.isRoot() )
                && node.isInSeqNameRect( x, y ) ) {
                return node.getSeqName();
            }
        }
        
        return null; // not found
    }//findSequenceName
    
    
    /**
     * Indicates what action should be execute when a node is clicked
     * @return the click-on action
     */
    int getActionWhenNodeClicked() {
        return action_when_node_clicked;
    }
    

    /**
     * get a pointer to the ATVpanel
     * 
     * @return pointer to ATVpanel
     */
    ATVpanel getATVpanel() {
        return atvpanel;
    }
    

    /**
     * DOCUMENT ME!
     * @return DOCUMENT ME!
     */
/*    Hashtable getCustomTagCheckBoxes() {
        return _custom_tag_check_boxes;
    }
*/    

    public Hashtable getFoundNodes() {
      return _found_nodes;
    }
    
    
    /**
     * DOCUMENT ME!
     * 
     * @return DOCUMENT ME!
     */
    int getLengthOfRootSpecies() {
        if ( ( tree == null ) || tree.isEmpty() ) {
            return 0;
        }
        
        return fontset.fm_small_italic.stringWidth( tree.getRoot().getTaxonomy() );
    }
    

    /**
     * DOCUMENT ME!
     * 
     * @return DOCUMENT ME!
     */
    int getLongestExtNodeInfo() {
        return longest_ext_node_info;
    }
    
    /**
     * Gets the maximal number a sequence is expected to be orthologous 
     * toward another, i.e. the number of resampling steps. 
     * (Last modified: 12/05/00)
     * @return max ortho number
     */
    int getMaxOrtho() {
        return max_ortho;
    }
    
    
    /**
     * Get a pointer to the phylogeny tree
     * 
     * @return a pointer to a Phylogeny
     */
    Phylogeny getTree() {
        return tree;
    }
    

    /**
     * @return pointer to colorset for tree drawing
     */
    public TreeColorSet getTreeColorSet() {
        return colorset;
    }
    
    
    /**
     * DOCUMENT ME!
     * 
     * @return DOCUMENT ME!
     */
    double getXcorrectionFactor() {
        return x_correction_factor;
    }
    

    /**
     * DOCUMENT ME!
     * @return DOCUMENT ME!
     */
    double getXdistance() {
        return x_distance;
    }
    
    
    /**
     * DOCUMENT ME!
     * @return DOCUMENT ME!
     */
    double getYdistance() {
        return y_distance;
    }
    

    /**
     *
     */
    private void handleClickToAction( int action, PhylogenyNode node ) {
        if ( action == EDIT_INFO ) {
            popupEditFrame( node );
        }
        else if ( action == COLLAPSE ) {
            collapse( node );
        }
        else if ( action == REROOT ) {
            reRoot( node );
        }
        else if ( action == SUBTREE ) {
            subTree( node );
        }
        else if ( action == SWAP ) {
            swap( node );
        }
        else if ( action == SHOW_NODE_SEQUENCES ) {
            popupNodeSeqFrame( node );
        }
        else if ( action == SHOW_NODE_GLYPH_INFO ) {
            popupGlyphFrame( node );
        }
        else if ( action == CUSTOM_OPTION ) {
            customOption( node );
        }
        //added by Renata
        else if (action == SHOW_NODE_HPFS ) {
            popupNodeHPFFrame( node );
        }
        else if (action == SHOW_ROOT_HPFS ) {
            popupRootHPFFrame(0); //root information is on index zero
        }
    }
    
    
    /**
     * Label an external node.
     */
    private void labelExtNode(Graphics g, int x1, PhylogenyNode node, boolean in_color) {
        if ( atvcontrolpanel.speciesExtNodes() && 
                ( node.getTaxonomy().length() > 0 ) ) {
            paintSpeciesExtNode(g, x1, node, in_color);
        }
        
        // Sequence label on external node
        if ( atvcontrolpanel.seqNameExtNodes() && 
            node.getSeqName().length() > 0 ) {
            paintSeqExtName(g, x1, node, in_color);
        }
        
        if ( atvcontrolpanel.isECExtNodes() && ( node.getECnumber().length() > 0 ) ) {
            paintECExtNode(g, x1, node, in_color);
        }
        
        if ( ( atvcontrolpanel.colorOrthologous() && ( node.getOrthologous() != PhylogenyNode.ORTHOLOGOUS_DEFAULT ) )
            || ( atvcontrolpanel.colorSuperOrthologous() && ( node
                    .getSuperOrthologous() != PhylogenyNode.ORTHOLOGOUS_DEFAULT ) )
            || ( atvcontrolpanel.colorSubtreeNeighbors() && ( node
                    .getSubtreeNeighborings() != PhylogenyNode.ORTHOLOGOUS_DEFAULT ) ) ) {
            paintOrthologous(g, x1, node, in_color);
        }
        
        paintCustomExtData(g, x1, node, in_color);
        
        if ( atvcontrolpanel.writeBranchLengthValues() && !node.isRoot()
            && ( node.getDistanceToParent() >= 0.0 ) ) {
            paintBranchLength(g, node, in_color);
        }
    }//labelExtNode
    
    
    /**
     *
     */
    private void makePopupMenus() {
        // The menu to pop up if a single node is selected
        clickto_single_menu = new JPopupMenu();
        Hashtable clickto_hash = atvpanel.getATVcontrol().getAllClickToItems();
        Vector clickto_names = atvpanel.getATVcontrol().getSingleClickToNames();
        clickto_single_items = new JMenuItem[clickto_names.size()];
        
        for (int i=0; i<clickto_names.size(); i++) {
          String title = (String)clickto_names.elementAt(i);
          clickto_single_items[i] = new JMenuItem( title );
          clickto_single_items[i].addActionListener( this );
          clickto_single_menu.add( clickto_single_items[i] );
        }
        
        // the menu to pop up if multiple nodes are selected
        clickto_multiple_menu = new JPopupMenu();
        clickto_names = atvpanel.getATVcontrol().getMultipleClickToNames();
        clickto_multiple_items = new JMenuItem[clickto_names.size()];
        
        for (int i=0; i<clickto_names.size(); i++) {
          String title = (String)clickto_names.elementAt(i);
          clickto_multiple_items[i] = new JMenuItem( title );
          clickto_multiple_items[i].addActionListener( this );
          clickto_multiple_menu.add( clickto_multiple_items[i] );
        }
    }
        

    /**
     * Handle mouse clicked event.
     * (Last modified: 9/27/05)
     * @param e the mouse event
     */
    public void MouseClicked( MouseEvent e ) {
      
        int x = e.getX();
        int y = e.getY();
        PhylogenyNode node = findNode( x, y );
        
        if ( node != null ) {
            _highlight_node = node;
            
            // Check if shift key is down
            //if ( (e.getModifiers() & MouseEvent.SHIFT_MASK) != 0 ) { Deprecated elements corrected (Petar).
            if ( (e.getModifiersEx() & MouseEvent.SHIFT_DOWN_MASK) != 0 ) {
                // Yes, so add to _found_nodes
                if ( _found_nodes == null ) _found_nodes = new Hashtable();
                _found_nodes.put( node, "" );
                
                if (_found_nodes.size() > 1) {
                    atvpanel.getATVcontrol().setMultipleSelect(true);
                }
                
            
            // Check if control key is down
            } else if ( (e.getModifiers() & MouseEvent.CTRL_MASK) != 0 ) {
                // Yes, so pop-up menu
                popupClickToMenu( node, e.getX(), e.getY() );
                
            // Handle unadorned click
            } else {
            
                // Check for right mouse button
                int m = e.getModifiers();
                if ( e.getModifiers() == 4 ) {
//                    popupEditFrame( node );
                    popupClickToMenu( node, e.getX(), e.getY() );
                }
                
                // Must be the left mouse button.
                else {
                    // if not in _found_nodes, clear _found_nodes
                    if ( _found_nodes != null && !_found_nodes.containsKey(node) ) {
                      _found_nodes.clear();
                      atvpanel.getATVcontrol().setMultipleSelect(false);
                    }
                    handleClickToAction( action_when_node_clicked, node );
                }
            }
            
        } else {
          // no node was clicked
          _highlight_node = null;
          atvpanel.getATVcontrol().setMultipleSelect(false);
          _found_nodes = null;
        }
        
        repaint();
    }//MouseClicked
    
    
    /**
     * Handle mouse moved event.
     * @param e the mouse event
     */
    // Modified by Petar to show tool tips.
    public void mouseMoved( MouseEvent e ) {
        int x = e.getX();
        int y = e.getY();
        PhylogenyNode node = findNode( x, y );
        
        if ( node != null ) {
            // cursor is over a tree node
            setCursor( hand_cursor );
            int nodeNumber = node.getID();
            this.setToolTipText("Node " + nodeNumber);
            /*
            
            */
        }
        else {
            setCursor( arrow_cursor );
    		this.setToolTipText(null);

        }
    }//mouseMoved
    
    
    /** 
    drawLegend - Draws the legend in the low left corner of the graphics (Petar).
    */
    private void drawLegend(Graphics g) {
    	
    Rectangle bounds = g.getClipBounds();
    Color red = new Color(255,0,0);
	//int legend_widht = 100;
	int legend_widht = 130;
	int legend_height = 80;
	int legend_x = 0;
	int legend_y = bounds.y + bounds.height - legend_height - 1;
	// Draw rectangle with suitable size as a frame of the legend.
	g.setColor(red);
	g.drawRect(legend_x, legend_y, legend_widht, legend_height);
	
	int x = legend_x + 11;
	// Draw four squares representing nodes.
	g.setColor( colorset.get_branch_color() );
	
	int y = legend_y + 11;
    g.fillRect( x - HALF_BOX_SIZE, y - HALF_BOX_SIZE, BOX_SIZE, BOX_SIZE );
    
	y += 18;
    g.fillRect( x - HALF_BOX_SIZE, y - HALF_BOX_SIZE, BOX_SIZE, BOX_SIZE );
    
	y += 18;
    g.fillRect( x - HALF_BOX_SIZE, y - HALF_BOX_SIZE, BOX_SIZE, BOX_SIZE );

	y += 18;
    g.fillRect( x - HALF_BOX_SIZE, y - HALF_BOX_SIZE, BOX_SIZE, BOX_SIZE );
	g.drawString(" - Not inherited", x+15, y+3); // Explains the meaning of a square without circle.

	y = legend_y + 11;
	// Draw three ovals with the colours for 'gained', 'lost' and 'inherited'.
	// Draw the explanation strings.
	
	drawNodeCircle(x, y, g, colorset.get_re_gain_color());
	g.drawString(" - Gained", x+15, y+3);
 
	y += 18;
	drawNodeCircle(x, y, g, colorset.get_re_lost_color());
	g.drawString(" - Lost", x+15, y+3);
	
	y += 18;
	drawNodeCircle(x, y, g, colorset.get_re_inherited_color());
	g.drawString(" - Inherited", x+15, y+3);
	
    } // End of private void drawLegend(Graphics g) 
    
    
    /**
     * Paints the phylogenic tree.
     */
    @Override // Added by Petar.
	public void paintComponent( Graphics g ) {
        super.paintComponent( g );
        paintTree( g, true); // true --> in color
        // System.out.println(" = " + paintCounter);
    }
    
    /**
     * Paint bootstrap value on the tree
     */
    private void paintBootstrapValue(Graphics g, boolean in_color) {
        String bs = "" + node.getBootstrap();
        int parent_x = node.getParent().getXcoord();
        g.setFont( fontset.small_font );
        g.setColor( colorset.get_bootstrap_color() );
        g.drawString( bs, Util.roundToInt( parent_x
                + ( ( x_current - parent_x - fontset.fm_small
                        .stringWidth( bs ) ) / 2 ) ),
            ( y_current + fontset.small_maxAscent ) - 1 );
    }//paintBootstrapValue
    
    
    /**
     * Paint a branch which consists of a vertical and a horizontal bar
     */
    private void paintBranch(Graphics g, int x1, int x2, int y1, int y2,
                             PhylogenyNode node, boolean in_color) {
        // draw the vertical line
        assignGraphicsForBranchWithColorForParentBranch( node, true, g );
        if ( !node.isPseudoNode()
            && !( node.isRoot() && !tree.isRooted() ) ) {
            drawLine( x1, y1, x1, y2, node,
                true, g, in_color );
        }
        else {
            g.drawLine( x1, y1, x1, y2 );
        }
        
        // draw the horizontal line
        assignGraphicsForBranchWithColorForParentBranch( node, false, g );
        drawLine( x1, y2, x2, y2, node, false, g, in_color );
        drawNodeBox( x2, y2, node, g, in_color );
    }//paintBranch

 
    /**
     * Paint a length on a branch
     */
    private void paintBranchLength(Graphics g, PhylogenyNode node, boolean in_color) {
        g.setFont( fontset.small_font );
        g.setColor( colorset.get_branch_length_color() );
        
        if ( !node.isRoot() ) {
            g.drawString( dist_nf.format( node
                    .getDistanceToParent() ), node.getParent()
                .getXcoord() + 3, y_current - fontset.small_maxDescent );
        }
        else {
            // Deepest node (=root):
            g.drawString( dist_nf.format( node
                    .getDistanceToParent() ), 3, y_current
                - fontset.small_maxDescent );
        }
    }//paintBranchLength
    
    
    /**
     * 
     */
    private void paintECExtNode(Graphics g, int x1, PhylogenyNode node, boolean in_color) {
        int x;
        
        g.setFont( fontset.large_font );
        g.setColor( colorset.get_ec_color() );
        
        if ( atvcontrolpanel.speciesExtNodes() && ( node.getTaxonomy().length() > 0 ) ) {
            x = fontset.fm_large_italic.stringWidth( node.getTaxonomy()
                + " " );
        }
        else {
            x = 0;
        }
        
        if ( atvcontrolpanel.seqNameExtNodes() && ( node.getSeqName().length() > 0 ) ) {
            x += fontset.fm_large.stringWidth( node.getSeqName() + " " );
        }
        
        int start_x = x1 + x + 3 + HALF_BOX_SIZE;
        int start_y = y_current + fontset.fm_large.getAscent() / 2;
        String label = node.getECnumber();
        g.drawString( label, start_x, start_y );
        
        // draw a box around the text if in _found_nodes
        if ( ( _found_nodes != null ) && _found_nodes.containsKey( node ) ) {
            g.setColor( colorset.get_found_color() );
            int height = g.getFontMetrics().getAscent();
            g.drawRect(start_x,
                       start_y - height, 
                       g.getFontMetrics().stringWidth(label),
                       height);
       }
    }//paintExtECNode
    

    /**
     * DOCUMENT ME!
     * @param x
     * @param y
     * @param node
     * @param g
     */
    void paintCustomData( int x, int y, PhylogenyNode node, Graphics g, boolean in_color ) {
        String s = customDataAsString( node );
        
        if ( s != null ) {
            g.setColor( colorset.get_custom_data_color() );
            
            if ( node.isExternal() ) {
                g.setFont( fontset.large_font );
            }
            else {
                g.setFont( fontset.small_font );
            }
            
            g.drawString( s, x, y );
        }
    }//paintCustomData
    
    
    /**
     * 
     */
    private void paintCustomExtData(Graphics g, int x1, PhylogenyNode node, boolean in_color) {
        int x;
        
        if ( atvcontrolpanel.speciesExtNodes() && ( node.getTaxonomy().length() > 0 ) ) {
            x = fontset.fm_large_italic.stringWidth( node.getTaxonomy()
                + " " );
        }
        else {
            x = 0;
        }
        
        if ( atvcontrolpanel.seqNameExtNodes() && ( node.getSeqName().length() > 0 ) ) {
            x += fontset.fm_large.stringWidth( node.getSeqName() + " " );
        }
        
        if ( atvcontrolpanel.isECExtNodes() && ( node.getECnumber().length() > 0 ) ) {
            x += fontset.fm_large.stringWidth( node.getECnumber() + " " );
        }
        
        if ( ( atvcontrolpanel.colorOrthologous() && ( node.getOrthologous() != PhylogenyNode.ORTHOLOGOUS_DEFAULT ) )
            || ( atvcontrolpanel.colorSuperOrthologous() && ( node
                    .getSuperOrthologous() != PhylogenyNode.ORTHOLOGOUS_DEFAULT ) )
            || ( atvcontrolpanel.colorSubtreeNeighbors() && ( node
                    .getSubtreeNeighborings() != PhylogenyNode.ORTHOLOGOUS_DEFAULT ) ) ) {
            x += fontset.fm_large.stringWidth( " [     ] " );
        }
        
        paintCustomData( x1 + x + 3 + HALF_BOX_SIZE, y_current
            + ( fontset.fm_large.getAscent() / 2 ), node, g, in_color );
    }//paintCustomExtData
    
    
    /**
     * 
     */
    private void paintECIntNode(Graphics g, int x1, PhylogenyNode node, boolean in_color) {
        int x;
        g.setColor( colorset.get_ec_color() );
        
        g.setFont( fontset.large_font );
        
        if ( atvcontrolpanel.seqNameInternalNodes()
            && ( node.getSeqName().length() > 0 ) ) {
            x = fontset.fm_large.stringWidth( node.getSeqName() + " " );
        }
        else {
            x = 0;
        }
        
        int start_x = x1 - x
                        - fontset.fm_large.stringWidth( node.getECnumber() )
                        - 4 - HALF_BOX_SIZE;
        int start_y =  y_current - fontset.fm_large.getMaxDescent();
        String label = node.getECnumber();
        g.drawString( label, start_x, start_y );
        
        // draw a box around the text if in _found_nodes
        if ( ( _found_nodes != null ) && _found_nodes.containsKey( node ) ) {
            g.setColor( colorset.get_found_color() );
            int height = g.getFontMetrics().getAscent();
            g.drawRect(start_x,
                       start_y - height, 
                       g.getFontMetrics().stringWidth(label),
                       height);
       }
    }
    
    
    /**
     * Paint one node.
     */
    private boolean paintNode(Graphics g, int ext_nodes_x, boolean in_color) {
        boolean done = false;
        int     x1=0, y1=0, x2=0, y2=0;
        double  x2double;
        int     factor;
       
        // Internal node labels that appear at beginning of branch:
        //   lengths and bootstrap values.
        if ( !node.isPseudoNode() ) {
            // Branch lengths
            if ( atvcontrolpanel.writeBranchLengthValues()
                && ( node.getIndicator() == 0 )
                && ( node.getDistanceToParent() != PhylogenyNode.DISTANCE_DEFAULT ) ) {
                paintBranchLength(g, node, in_color);
            }
            
            // Bootstrap values
            if ( atvcontrolpanel.writeBootstrapValues() && ( node.getIndicator() == 0 )
                && ( !node.isRoot() )
                && ( node.getBootstrap() != PhylogenyNode.BOOTSTRAP_DEFAULT )
                && ( tree.getNumberOfExternalNodes() >= 2 ) ) {
                paintBootstrapValue(g, in_color);
            }
        }
        
        // Draw a line to root:
        if ( node.isRoot() && tree.isRooted()
            && ( node.getIndicator() == 0 ) ) {
            x1 = Util.roundToInt( x_current );
            paintRootBranch(g, x1, y1, tree.getRoot(), in_color);
        }
        
        //               
        // Paint branch and internal node labels for child1:
        //  _
        // |
        if ( ( node.getIndicator() == 0 ) && !node.isExternal() ) {
            node.setIndicator( 1 );
            
            factor = node.getSumExtNodes()
            - node.getChildNode1().getSumExtNodes();
            x1 = Util.roundToInt( x_current );
            y1 = y_current;
            y2 = y_current - Util.roundToInt( y_distance * factor );
            node.setXcoord( x1 );
            node.setYcoord( y1 );
            
            // Label internal nodes for child1
            if ( !node.isPseudoNode() ) {
                // Species internal node:
                if ( atvcontrolpanel.speciesInternalNodes() && !node.isCollapse()
                    && ( node.getTaxonomy().length() > 0 ) ) {
                    paintSpeciesIntNode(g, x1, in_color);
                }
                
                // Custom data internal node:
                int x;
                if ( atvcontrolpanel.speciesInternalNodes()
                    && ( node.getTaxonomy().length() > 0 ) ) {
                    x = fontset.fm_small_italic.stringWidth( node.getTaxonomy()
                        + " " );
                }
                else {
                    x = 0;
                }
                paintCustomData( x1 + x + 3 + HALF_BOX_SIZE, y_current
                    + ( fontset.fm_small.getAscent() / 2 ), node, g, in_color );
                
                // Sequence name int node:
                if ( atvcontrolpanel.seqNameInternalNodes()
                    && ( node.getSeqName().length() > 0 )
                    && !node.isCollapse() ) {
                    paintSeqIntNode(g, x1, node, in_color);
                }
                
                // EC int node:
                if ( atvcontrolpanel.isECInternalNodes()
                    && ( node.getECnumber().length() > 0 )
                    && !node.isCollapse() ) {
                    paintECIntNode(g, x1, node, in_color);
                }
                
                // Indicate whether D or S if assigned:
                if ( atvcontrolpanel.writeDupSpec() && node.isDuplicationOrSpecAssigned()
                    && !node.isCollapse() ) {
                    paintSpecEvent(g, x1, in_color);
                }
            }// !psuedo node
            
            // Draw branch for child1
            if ( !node.isCollapse() ) {
                x2double = calculateBranchLength( node.getChildNode1(), 
                    ext_nodes_x, factor );
                x2 = Util.roundToInt( x2double );
                paintBranch(g, x1, x2, y1, y2, node.getChildNode1(), in_color);
                
                x_current = x2double;
                y_current = y2;
                
                node = node.getChildNode1();
            }//!node.isCollapse
            
        }// child1
        
        // Paint branch for child2: |_
        if ( ( node.getIndicator() == 1 ) && !node.isExternal() ) {
            node.setIndicator( 2 );
            
            // draw branch for child 2
            if ( !node.isCollapse() ) {
                factor = node.getSumExtNodes()
                - node.getChildNode2().getSumExtNodes();
                x1 = Util.roundToInt( x_current );
                y1 = y_current;
                y2 = y_current + Util.roundToInt( y_distance * factor );
                
                x2double = calculateBranchLength( node.getChildNode2(), 
                    ext_nodes_x, factor );
                x2 = Util.roundToInt( x2double );
                paintBranch(g, x1, x2, y1, y2, node.getChildNode2(), in_color);

                x_current = x2double;
                y_current = y2;
             
                node = node.getChildNode2();
            }
        }
        
        // In case of collapsed root or collapsed root.child2:
        if ( node.isRoot() ) {
            done = true;
        }
        // Moving towards the root:
        else if ( ( node.getIndicator() == 2 ) && !node.isExternal() ) {
            node = node.getParent();
            x_current = node.getXcoord();
            y_current = node.getYcoord();
        }
        
        // Handle external node
        if ( node.isExternal() ) {
            
            // Label it
            x1 = Util.roundToInt( x_current );
            labelExtNode(g, x1, node, in_color);
            
            // Set its position
            node.setXcoord( x1 );
            node.setYcoord( y_current );
            
            // Check if finished
            if ( node.isLastExternalNode() ) {
                done = true;
            }
            
            // Need to check whether parent is null in case the tree 
            // is only one node:
            if ( !node.isRoot() ) {
                node = node.getParent();
                x_current = node.getXcoord();
                y_current = node.getYcoord();
            }
        } // if ( node.isExternal() )
        return !done;
    } // End of private boolean paintNode(Graphics g, int ext_nodes_x, boolean in_color)
    
    
    /**
     * 
     */
    private void paintOrthologous(Graphics g, int x1, PhylogenyNode node, boolean in_color) {
        int x;
        g.setColor( calculateColorForOrthologous( node ) );
        g.setFont( fontset.large_font );
        
        if ( atvcontrolpanel.speciesExtNodes() && ( node.getTaxonomy().length() > 0 ) ) {
            x = fontset.fm_large_italic.stringWidth( node.getTaxonomy()
                + " " );
        }
        else {
            x = 0;
        }
        
        if ( atvcontrolpanel.seqNameExtNodes() && ( node.getSeqName().length() > 0 ) ) {
            x += fontset.fm_large.stringWidth( node.getSeqName() + " " );
        }
        
        if ( atvcontrolpanel.isECExtNodes() && ( node.getECnumber().length() > 0 ) ) {
            x += fontset.fm_large.stringWidth( node.getECnumber() + " " );
        }
        
        // orthologous
        if ( atvcontrolpanel.colorOrthologous() ) {
            g.setColor( calculateColorForOrthologous( node ) );
            
            if ( node.getOrthologous() == PhylogenyNode.SEQ_X ) {
                g.drawString( " [ Q ]", x1 + x + 3 + HALF_BOX_SIZE,
                    y_current + ( fontset.fm_large.getAscent() / 2 ) );
            }
            else {
                g.drawString( " [ " + node.getOrthologous() + " ]",
                    x1 + x + 3 + HALF_BOX_SIZE, y_current
                    + ( fontset.fm_large.getAscent() / 2 ) );
            }
        }
        // super orthologous
        else if ( atvcontrolpanel.colorSuperOrthologous() ) {
            g.setColor( calculateColorForSuperOrthologous( node ) );
            
            if ( node.getSuperOrthologous() == PhylogenyNode.SEQ_X ) {
                g.drawString( " [ Q ]", x1 + x + 3 + HALF_BOX_SIZE,
                    y_current + ( fontset.fm_large.getAscent() / 2 ) );
            }
            else {
                g.drawString( " [ " + node.getSuperOrthologous()
                    + " ]", x1 + x + 3 + HALF_BOX_SIZE,
                    y_current + ( fontset.fm_large.getAscent() / 2 ) );
            }
        }
        // subtree neighbors
        else if ( atvcontrolpanel.colorSubtreeNeighbors() ) {
            g.setColor( calculateColorForSubtreeNeighbors( node ) );
            
            if ( node.getSubtreeNeighborings() == PhylogenyNode.SEQ_X ) {
                g.drawString( " [ Q ]", x1 + x + 3 + HALF_BOX_SIZE,
                    y_current + ( fontset.fm_large.getAscent() / 2 ) );
            }
            else {
                g.drawString( " [ " + node.getSubtreeNeighborings()
                    + " ]", x1 + x + 3 + HALF_BOX_SIZE,
                    y_current + ( fontset.fm_large.getAscent() / 2 ) );
            }
        }
    }//paintOrthologous
    
    
    /**
     * Paint the root branch. (Differs from others because it will
     * always be a single horizontal line).
     * @return new x1 value
     */
    private void paintRootBranch(Graphics g, int x1, int y1, 
        PhylogenyNode to_node, boolean in_color ) {
        assignGraphicsForBranchWithColorForParentBranch( node, false, g );
        
        if ( atvcontrolpanel.useRealBranchLengths()
            && ( to_node.getDistanceToParent() > 0.0 ) ) {
            double d = x_correction_factor
            * to_node.getDistanceToParent();
            
            drawLine( x1 - Util.roundToInt( d ), y_current, x1,
                y_current, node, false, g, in_color );
        }
        else {
            drawLine( x1 - Util.roundToInt( x_distance ),
                y_current, x1, y_current, node, false, g, in_color );
        }
        
        drawNodeBox( x1, y_current, node, g, in_color );
    }//paintRootBranch
    
    
    /**
     * 
     */
    private void paintSeqExtName(Graphics g, int x1, PhylogenyNode node, boolean in_color) {
        int x;
        
        g.setFont( fontset.large_font );
        
        if ( atvcontrolpanel.colorOrthologous()
            && ( node.getOrthologous() != PhylogenyNode.ORTHOLOGOUS_DEFAULT ) ) {
            g.setColor( calculateColorForOrthologous( node ) );
        }
        else if ( atvcontrolpanel.colorSuperOrthologous()
            && ( node.getSuperOrthologous() != PhylogenyNode.ORTHOLOGOUS_DEFAULT ) ) {
            g.setColor( calculateColorForSuperOrthologous( node ) );
        }
        else if ( atvcontrolpanel.colorSubtreeNeighbors()
            && ( node.getSubtreeNeighborings() != PhylogenyNode.ORTHOLOGOUS_DEFAULT ) ) {
            g.setColor( calculateColorForSubtreeNeighbors( node ) );
        }
        else if ( in_color && atvcontrolpanel.colorAccordingToSpecies() ) {
            g.setColor( speciesStringToColor(node.getTaxonomy()) );
        }
        else {
            g.setColor( colorset.get_ext_node_seq_color() );
        }
        
        if ( atvcontrolpanel.speciesExtNodes() && ( node.getTaxonomy().length() > 0 ) ) {
            x = fontset.fm_large_italic.stringWidth( node.getTaxonomy()
                + " " );
        }
        else {
            x = 0;
        }
        
        g.drawString( node.getSeqName(),
            x1 + x + 3 + HALF_BOX_SIZE, y_current
            + ( fontset.fm_large.getAscent() / 2 ) );
            
        Rectangle seq_rec =
            new Rectangle( x1 + x + 3 + HALF_BOX_SIZE, 
                           y_current - ( ( int ) fontset.fm_large.getAscent() / 2 ), 
                           fontset.fm_large.stringWidth( node.getSeqName() ),
                           fontset.fm_large.getHeight() );
                           
        if ( ( _found_nodes != null )
            && _found_nodes.containsKey( node ) ) {
            g.setColor( colorset.get_found_color() );
            g.drawRect(seq_rec.x, seq_rec.y, seq_rec.width, seq_rec.height);
        }
        
        node.setSeqNameRect( seq_rec.x, seq_rec.y, 
                             seq_rec.width, seq_rec.height );
    }//paintSeqExtName
    
    
    /**
     * 
     */
    private void paintSeqIntNode(Graphics g, int x1, PhylogenyNode node, boolean in_color) {
        g.setColor( colorset.get_int_node_seq_color() );
        g.setFont( fontset.large_font );
        
        int start_x =  x1 - fontset.fm_large.stringWidth( node.getSeqName() ) 
                          - 3
                          - HALF_BOX_SIZE;
        int start_y = y_current - fontset.fm_large.getMaxDescent();
        String label = node.getSeqName();
        g.drawString( label, start_x, start_y  );
        
        node.setSeqNameRect( start_x, y_current,
                             fontset.fm_large.stringWidth( label ),
                             fontset.fm_large.getHeight() );
                             
        // draw a box around the text if in _found_nodes
        if ( ( _found_nodes != null ) && _found_nodes.containsKey( node ) ) {
            g.setColor( colorset.get_found_color() );
            int height = g.getFontMetrics().getAscent();
            g.drawRect(start_x,
                       start_y - height, 
                       g.getFontMetrics().stringWidth(label),
                       height);
       }
    }//paintSeqIntNode
    
    
    /**
     * 
     */
    private void paintSpeciesExtNode( Graphics g, int x1, 
        PhylogenyNode node, boolean in_color ) {
        g.setFont( fontset.large_italic_font );
        
        if ( atvcontrolpanel.colorOrthologous()
            && ( node.getOrthologous() != PhylogenyNode.ORTHOLOGOUS_DEFAULT ) ) {
            g.setColor( calculateColorForOrthologous( node ) );
        }
        else if ( atvcontrolpanel.colorSuperOrthologous()
            && ( node.getSuperOrthologous() != PhylogenyNode.ORTHOLOGOUS_DEFAULT ) ) {
            g.setColor( calculateColorForSuperOrthologous( node ) );
        }
        else if ( atvcontrolpanel.colorSubtreeNeighbors()
            && ( node.getSubtreeNeighborings() != PhylogenyNode.ORTHOLOGOUS_DEFAULT ) ) {
            g.setColor( calculateColorForSubtreeNeighbors( node ) );
        }
        else if ( in_color && atvcontrolpanel.colorAccordingToSpecies() ) {
            g.setColor( speciesStringToColor(node.getTaxonomy()) );
        }
        else {
            g.setColor( colorset.get_species_name_color() );
        }
        
        int start_x = x1 + 3 + HALF_BOX_SIZE;
        int start_y = y_current + ( fontset.fm_large.getAscent() / 2 );
        String label = node.getTaxonomy() + " ";
        g.drawString( label, start_x, start_y );
        
        // draw a box around the text if in _found_nodes
        if ( ( _found_nodes != null ) && _found_nodes.containsKey( node ) ) {
            g.setColor( colorset.get_found_color() );
            int height = g.getFontMetrics().getAscent();
            g.drawRect(start_x,
                       start_y - height, 
                       g.getFontMetrics().stringWidth(label),
                       height);
       }
    }//paintSpeciesExtNode
    
    
    /**
     * 
     */
    private void paintSpeciesIntNode(Graphics g, int x1, boolean in_color) {
        g.setFont( fontset.small_italic_font );
        
        if ( in_color && atvcontrolpanel.colorAccordingToSpecies() ) {
            g.setColor( speciesStringToColor(node.getTaxonomy()) );
        }
        else {
            g.setColor( colorset.get_species_name_color() );
        }
        
        int start_x = x1 + 3 + HALF_BOX_SIZE;
        int start_y = y_current + ( fontset.fm_small_italic.getAscent() / 2 );
        String label = node.getTaxonomy();
        g.drawString( label, start_x, start_y );
        
        // draw a box around the text if in _found_nodes
        if ( ( _found_nodes != null ) && _found_nodes.containsKey( node ) ) {
            g.setColor( colorset.get_found_color() );
            int height = g.getFontMetrics().getAscent();
            g.drawRect(start_x,
                       start_y - height, 
                       g.getFontMetrics().stringWidth(label),
                       height);
       }
    }//paintIntSpeciesNode
    
    
    /**
     * 
     */
    private void paintSpecEvent(Graphics g, int x1, boolean in_color) {
        int x;
        
        g.setColor( colorset.get_dub_spec_color() );
        g.setFont( fontset.large_font );
        
        if ( atvcontrolpanel.speciesInternalNodes() ) {
            x = fontset.fm_large.getMaxAscent();
        }
        else {
          x = 0;
        }
        
        if ( node.isDuplication() ) {
            g.drawString( "D", x1 + 3 + HALF_BOX_SIZE,
                y_current + ( fontset.fm_large.getAscent() / 2 )
                + x );
        }
        else {
            g.drawString( "S", x1 + 3 + HALF_BOX_SIZE,
                y_current + ( fontset.fm_large.getAscent() / 2 )
                + x );
        }
    }//paintSpecEvent
    

    /**
     * The main method for drawing a tree
     * 
     * @param g Graphics to draw on
     * @param print_in_color indicates if tree should be painted in color
     */
    public void paintTree( Graphics g, boolean print_in_color ) {
        // boolean done = false; - never read (Petar)
        
        int     ext_nodes_x;
        
        // Can't draw anything if there's no tree!
        if ( ( tree == null ) || tree.isEmpty() ) {
            return;
        }
        node = tree.getRoot();
        tree.setIndicatorsToZero();
        
        // Save colors in case we're drawing in B&W
        TreeColorSet old_colorset = colorset;
        
        // Set BW colors if not painting in color
        if ( !print_in_color ) {
            // temporarily set colors to black and white.
            colorset = new TreeColorSet(false);
        }
        
        // Position starting X of tree
        if ( !tree.isRooted() ) {
            x_current = MOVE;
        }
        else if ( ( tree.getRoot().getDistanceToParent() > 0.0 )
            && atvcontrolpanel.useRealBranchLengths() ) {
            x_current = MOVE
            + ( tree.getRoot().getDistanceToParent() * x_correction_factor );
        }
        else {
            x_current = MOVE + getXdistance();
        }
        
        // Position starting Y of tree
        y_current = Util.roundToInt( ( getYdistance() * tree
                .getNumberOfExternalNodes() )
            + ( MOVE / 2.0 ) );
        
        // Position external nodes
        ext_nodes_x = MOVE
        + Util.roundToInt( x_distance
            * tree.getNumberOfExternalNodes() );
        
        // Color the background
        g.setColor( colorset.get_background_color() );
        g.fillRect( getX(), getY(), getWidth(), getHeight() );
        
        // Draw the tree
        while (paintNode(g, ext_nodes_x, print_in_color)) { 
        	// paintCounter++;
        }
            
        // reset colors if needed
        if ( !print_in_color ) {
            colorset = old_colorset;
        }
        if (atvextension != null) {
          atvextension.update( tree.getRoot() );
        }
        
        // Draw the legend for gained, lost or inherited genes.
        if(if_drawLegend) {
        	drawLegend (g);
        	if_drawLegend = false;
        }
        
    } // End of public void paintTree(Graphics g, boolean print_in_color).
    

    /**
     *
     */
    private void popupClickToMenu( PhylogenyNode node, int x, int y ) {
      // if menu doesn't exist, create it
      if ( clickto_single_menu == null ) {
          makePopupMenus();
      }
      
      // a single node or set?
      if (_found_nodes == null || !_found_nodes.containsKey( node ) ) {
        // save the node as a client property for the popup menu
        clickto_single_menu.putClientProperty( "node", node );
        // show the menu for a single node
        clickto_single_menu.show( this, x, y );
        
      } else {
        // show the menu for a set of nodes
        clickto_multiple_menu.show( this, x, y );
      }
    }//popupClickToMenu
    
    
    /**
     * pop up the node-edit box 
     */ 
    private void popupEditFrame( PhylogenyNode n ) {
        if (editframe_index < MAX_POPUPFRAMES) {
            if (_found_nodes != null && _found_nodes.containsKey(n)) {
                // Popup edit box for a collection
                atveditnodeframes[ editframe_index ]
                    = new ATVeditNodeFrame( atvpanel.getATVtreePanel().getFoundNodes(),
                                            tree,
                                            atvcontrolpanel.isTreeEditable(),
                                            atvpanel.getATVtreePanel(),
                                            editframe_index);
            } else {
                // pop up edit box for single node
                atveditnodeframes[ editframe_index ] 
                    = new ATVeditNodeFrame( n, tree, atvcontrolpanel.isTreeEditable(),
                                            this, editframe_index );
            }
            editframe_index++;
        } else {
            JOptionPane.showMessageDialog(this, "Too many edit popups are open");
        }
    }//popupEditFrame
    
    
    /**
     * pop up the glyph box
     */
    private void popupGlyphFrame( PhylogenyNode n ) {
        if (glyphframe_index < MAX_POPUPFRAMES) {
            atvnodeglyphframes[ glyphframe_index ] 
            = new ATVnodeGlyphFrame( glyph_class_name, 
                n, 
                this, 
                glyphframe_index );
            atvnodeglyphframes[ glyphframe_index ].setTitle( "Graphs" );
            atvnodeglyphframes[ glyphframe_index ].initGlyphFrame();
            glyphframe_index++;
        } else {
            JOptionPane.showMessageDialog(this, "Too many graph popups are open");
        }
    }//popupGlyphFrame
    
    
    /**
     * Remove all edit-node frames
     */
    void removeAllEditNodeJFrames() {
        for (int i = 0; i <= ( MAX_POPUPFRAMES - 1 ); i++ ) {
            if ( atveditnodeframes[ i ] != null ) {
                atveditnodeframes[ i ].dispose();
                atveditnodeframes[ i ] = null;
            }
        }
        
        editframe_index = 0;
    }//removeAllEditNodeJFrames
    

    /**
     * pop up the sequence list for this node.
     */
    private void popupNodeSeqFrame( PhylogenyNode n ) {
        if (seqframe_index < MAX_POPUPFRAMES) {
            atvnodeseqframes[ seqframe_index ] = new ATVnodeSeqFrame( n, this, seqframe_index );
            seqframe_index++;
        } else {
            JOptionPane.showMessageDialog(this, "Too many sequence list popups are open");
        }
    }//popupNodeSeqFrame
    
    //added by Renata
     private void popupNodeHPFFrame( PhylogenyNode n ) {
        if (hpfframe_index < MAX_POPUPFRAMES) {
            atvnodehpfframes[ hpfframe_index ] = new ATVnodeHPFFrame( n, this, hpfframe_index );
            hpfframe_index++;
        } else {
            JOptionPane.showMessageDialog(this, "Too many hpf list popups are open");
        }
    }//popupNodeHPFFrame

     
    private void popupRootHPFFrame( int nroot ) { //( int nroot ) {
//        System.out.println("TTTTTTTTTTTTTTTTTTTTTTTTT + AAAAAAAAAAAAAAAAAAA");
        if (roothpfframe_index < MAX_POPUPFRAMES) {
            atvroothpfframes[roothpfframe_index] = new ATVrootHPFFrame();// n, this, roothpfframe_index );
            roothpfframe_index++;
        } else {
            JOptionPane.showMessageDialog(this, "Too many hpf list popups are open");
        }
    }//popupNodeHPFFrame
 
    /**
     * Remove a node-edit frame.
     */
    void removeEditNodeFrame( int i ) {
        editframe_index--;
        atveditnodeframes[ i ] = null;
        if (i < editframe_index) {
            for (int j=0; j<editframe_index-1; j++) {
                atveditnodeframes[ j ] = atveditnodeframes[ j+1 ];
            }
            atveditnodeframes[editframe_index] = null;
        }
    }//removeEditNodeFrame
    
    
    /**
     * Remove a glyph frame.
     */
    void removeGlyphNodeFrame( int i ) {
        glyphframe_index--;
        atvnodeglyphframes[ i ] = null;
        if (i < glyphframe_index) {
            for (int j=0; j<glyphframe_index-1; j++) {
                atvnodeglyphframes[ j ] = atvnodeglyphframes[ j+1 ];
            }
            atvnodeglyphframes[glyphframe_index] = null;
        }
    }//removeGlyphNodeFrame
    
    
    /**
     * Remove a sequence list frame
     */
    void removeNodeSeqFrame( int i ) {
        seqframe_index--;
        atvnodeseqframes[ i ] = null;
        if (i < seqframe_index) {
            for (int j=0; j<seqframe_index-1; j++) {
                atvnodeseqframes[ j ] = atvnodeseqframes[ j+1 ];
            }
            atvnodeseqframes[seqframe_index] = null;
        }
    }//removeNodeSeqFrame
    
    // added by Renata
    /**
     * Remove a hpf list frame
     */
    void removeNodeHPFFrame( int i ) {
        hpfframe_index--;
        atvnodehpfframes[ i ] = null;
        if (i < hpfframe_index) {
            for (int j=0; j<hpfframe_index-1; j++) {
                atvnodehpfframes[ j ] = atvnodehpfframes[ j+1 ];
            }
            atvnodehpfframes[hpfframe_index] = null;
        }
    }//removeNodeHPFFrame
    
    void removeRootHPFFrame( int i ) {
        roothpfframe_index--;
        atvroothpfframes[ i ] = null;
        if (i < roothpfframe_index) {
            for (int j = 0; j < roothpfframe_index-1; j++) {
                atvroothpfframes[ j ] = atvroothpfframes[ j+1 ];
            }
            atvroothpfframes[roothpfframe_index] = null;
        }
    }//removeNodeHPFFrame
    
    /**
     * DOCUMENT ME!
     */
    void removeRoot() {
        if ( tree == null ) {
            return;
        }
        
        if ( tree.isEmpty() ) {
            return;
        }
        
        tree.unRoot();
        atvpanel.treeChanged( tree.getRoot() );
        repaint();
    }//removeRoot
    

    /**
     * DOCUMENT ME!
     */
    void removeRootTri() {
        if ( tree == null ) {
            return;
        }
        
        if ( tree.isEmpty() ) {
            return;
        }
        
        tree.unRootAndTrifurcate();
        atvpanel.treeChanged( tree.getRoot() );
        repaint();
    }//removeRootTri
    
    
    /**
     * DOCUMENT ME!
     * @param node a PhylogenyNode
     */
    void reRoot( PhylogenyNode node ) {
        if ( !( ( node.isRoot() || node.getParent().isRoot() ) && tree
                .isRooted() ) ) {
            try {
                tree.reRoot( node );
                tree.adjustNodeCount( true );
//                tree.recalculateAndReset();
            }
            catch ( Exception e ) {
                System.err.println( "ATVtreePanel: reRoot( node ): " + e );
            }
            
            resetPreferredSize();
            atvpanel.adjustJScrollPane();
            atvpanel.treeChanged( tree.getRoot() );
            repaint();
        }
    }//reRoot
    

    /**
     * DOCUMENT ME!
     */
    void resetPreferredSize() {
        if ( ( tree == null ) || tree.isEmpty() ) {
            return;
        }
        
        int x = 0;
        int y = 0;
        
        y = MOVE
        + Util.roundToInt( getYdistance()
            * tree.getNumberOfExternalNodes() * 2 );
        
        if ( atvcontrolpanel.useRealBranchLengths() ) {
            x = MOVE
            + getLongestExtNodeInfo()
            + getLengthOfRootSpecies()
            + Util.roundToInt( ( getXcorrectionFactor() * tree
//                    .getRealHeight() )
                    .getHeight() )
                + getXdistance() );
        }
        else {
            x = MOVE
            + getLongestExtNodeInfo()
            + getLengthOfRootSpecies()
            + Util.roundToInt( getXdistance()
                * ( tree.getNumberOfExternalNodes() + 2 ) );
        }
        
        setPreferredSize( new Dimension( x, y ) );
    }//resetPreferredSize
    

    /**
     * Set what action should occur when a node is clicked
     * @param i the new click-on action
     */
    void setActionWhenNodeClicked( int i ) {
        action_when_node_clicked = i;
    }
    

    /**
     * ATVtreePanel and ATVcontrol need to communicate closely.
     */
    public void setControlPeer(ATVcontrol peer) {
         atvcontrolpanel = peer;
    }
    
   
    /**
     * DOCUMENT ME!
     * 
     * @param found_nodes
     *            DOCUMENT ME!
     */
    void setFoundNodes( Hashtable found_nodes ) {
        _found_nodes = found_nodes;
    }
    

    /**
     * Set the name of the glyph class to be displayed by this instance
     * of the tree panel.
     * 
     * @param new_class name of a glyph class.
     */
    void setGlyphClass( String new_class ) {
        glyph_class_name = new_class;
    }
    
    
    /**
     * Sets the maximal number a sequence is expected to be orthologous 
     * towards another, i.e. the number of resampling steps. 
     * (Last modified: 12/05/00)
     * @param m new max orth number
     */
    void setMaxOrtho( int m ) {
        max_ortho = m;
    }
    

    /**
     * 
     */
    public void setLargeFonts() {
        fontset.largeFonts();
    }
    

    /**
     * DOCUMENT ME!
     * 
     * @param i
     *            DOCUMENT ME!
     */
    void setLongestExtNodeInfo( int i ) {
        longest_ext_node_info = i;
    }
    
    
    /**
     * 
     */
    public void setMediumFonts() {
        fontset.mediumFonts();
    }
    

    /**
     * Set parameters for printing the displayed tree
     * @param x
     * @param y
     */
    void setParametersForPainting( int x, int y ) {
        if ( ( tree != null ) && !tree.isEmpty() ) {
            calculateLongestExtNodeInfo();
            
            double xdist = ( double ) ( x - getLongestExtNodeInfo() - MOVE - getLengthOfRootSpecies() )
            / ( tree.getNumberOfExternalNodes() + 2.0 );
            
            double ydist = ( double ) ( y - MOVE )
            / ( tree.getNumberOfExternalNodes() * 2.0 );
            
            if ( xdist < 0.0 ) {
                xdist = 0.0;
            }
            
            if ( ydist < 0.0 ) {
                ydist = 0.0;
            }
            
            setXdistance( xdist );
            setYdistance( ydist );
            
            if ( tree.getHeight() > Double.MIN_VALUE ) {
                double corr = ( x - MOVE - getLongestExtNodeInfo()
                    - getXdistance() - getLengthOfRootSpecies() )
                / tree.getHeight();
                
                if ( corr < 0.0 ) {
                    corr = 0.0;
                }
                
                setXcorrectionFactor( corr );
            }
            else {
                setXcorrectionFactor( 0.0 );
            }
        }
    }//setParametersForPainting.
    
    
    /**
     * 
     */
    public void setSmallFonts() {
        fontset.smallFonts();
    }
    
    
    /**
     * set the species colors Vector
     * @param colors a vector containing species colors
     */
//    void setSpeciesColors( Vector colors ) {
//        species_colors = colors;
//    }
    void setSpeciesColors( Hashtable colors ) {
        species_colors = colors;
    }
    
    
    /**
     * 
     */
    public void setTinyFonts() {
        fontset.tinyFonts();
    }
    
    /**
     * Set a phylogeny tree.
     * 
     * @param t an instance of a Phylogeny
     */
    void setTree( Phylogeny t ) {
        tree = t;
    }
    
    
    /**
     * Set a mew tree color set, probably from an options dialog.
     */
    void setTreeColorSet( TreeColorSet colorset ) {
        this. colorset = colorset;       
        setBackground( colorset.get_background_color() );
        repaint();
    }//setTreeColorSet
    
    
    /**
     * DOCUMENT ME!
     * @param i
     */
    void setXdistance( double i ) {
        x_distance = i;
    }
    

    /**
     * DOCUMENT ME!
     * @param i
     */
    void setXcorrectionFactor( double i ) {
        x_correction_factor = i;
    }
    
    /**
     * DOCUMENT ME!
     * 
     * @param i
     *            DOCUMENT ME!
     */
    void setYdistance( double i ) {
        y_distance = i;
    }

    
    /**
     * Find a color for this species name.
     * @param species
     * @return the species color
     */
    public Color speciesStringToColor( final String species ) {
        if ( ( species == null ) || ( species.length() < 1 ) ) {
            // return non-colorized color
            return colorset.get_species_name_color();
        }
        
        // Start with non-colorized color
        Color c = colorset.get_species_name_color();
        
        // Look in species hash
        if (species_colors.get(species) != null) {
            c = (Color)species_colors.get(species);
        
        // Not there: pick the next color from the default set;
        } else {
            if (next_default_color < default_species_colors.length) {
                String color_str = default_species_colors[ next_default_color ];
                c = Color.decode( color_str );
                next_default_color++;
                species_colors.put(species, c);
            } else {
                // issue a non-fatal warning
                System.out.println( "Out of colors for species " + species );
            }
        }
          
        return c;
    }//speciesStringToColor
    

    /**
     * DOCUMENT ME!
     * @param node
     */
    void subTree( PhylogenyNode node ) {
        if ( !node.isExternal() && !node.isRoot()
            && ( subtree_index <= ( MAX_SUBTREES - 1 ) ) ) {
            trees[ subtree_index++ ] = tree;
            tree = tree.subTree( node.getID() );
        }
        else if ( node.isRoot() && ( subtree_index >= 1 ) ) {
            trees[ subtree_index ] = null;
            tree = trees[ --subtree_index ];
        }
        
        atvpanel.getATVcontrol().showWhole();
        atvpanel.treeChanged( tree.getRoot() );
        repaint();
    }//subTree
    
    
    /**
     * DOCUMENT ME!
     * @param node
     */
    void swap( PhylogenyNode node ) {
        if ( !node.isExternal() ) {
            tree.swapChildren( node );
        }
        
        repaint();
        atvpanel.treeChanged( tree.getRoot() );
    }//swap
    
} // End of ATVtreePanel.
