/*
 * Created on Jun 12, 2005 TODO To change the template for this generated file
 * go to Window - Preferences - Java - Code Style - Code Templates
 */
package erst.forester.java.src.org.forester.phylogeny;

/**
 * @author Christian Zmasek TODO To change the template for this generated type
 *         comment go to Window - Preferences - Java - Code Style - Code
 *         Templates
 */
public final class PhyloXMLmapping {
    
    
    

    public static final String PHYLOGENY = "phylogeny";
    public static final String PHYLOGENY_OPEN = "<" + PHYLOGENY + ">";
    public static final String PHYLOGENY_CLOSE = "</" + PHYLOGENY + ">";
    
    public static final String PHYLOGENY_NAME = "name";
    public static final String PHYLOGENY_NAME_OPEN = "<" + PHYLOGENY_NAME + ">";
    public static final String PHYLOGENY_NAME_CLOSE = "</" + PHYLOGENY_NAME + ">";
    
    public static final String PHYLOGENY_DESCRIPTION = "description";
    public static final String PHYLOGENY_DESCRIPTION_OPEN  = "<" + PHYLOGENY_DESCRIPTION + ">";
    public static final String PHYLOGENY_DESCRIPTION_CLOSE = "</" + PHYLOGENY_DESCRIPTION + ">";
    
    
    public static final String CLADE = "clade";
    public static final String CLADE_OPEN = "<" + CLADE + ">";
    public static final String CLADE_CLOSE = "</" + CLADE + ">";

    public static final String SEQUENCE_NAME = "sequence_name";
    public static final String SEQUENCE_NAME_OPEN = "<" + SEQUENCE_NAME + ">";
    public static final String SEQUENCE_NAME_CLOSE = "</" + SEQUENCE_NAME + ">";

    public static final String TAXONOMY_ID = "taxonomy_id";
    public static final String TAXONOMY_ID_OPEN = "<" + TAXONOMY_ID + ">";
    public static final String TAXONOMY_ID_CLOSE = "</" + TAXONOMY_ID + ">";
    
    public static final String TAXONOMY = "taxonomy";
    public static final String TAXONOMY_OPEN = "<" + TAXONOMY + ">";
    public static final String TAXONOMY_CLOSE = "</" + TAXONOMY + ">";

    public static final String DISTANCE = "distance";
    public static final String DISTANCE_OPEN = "<" + DISTANCE + ">";
    public static final String DISTANCE_CLOSE = "</" + DISTANCE + ">";

    public static final String DUPLICATION = "is_duplication";
    public static final String DUPLICATION_OPEN = "<" + DUPLICATION + ">";
    public static final String DUPLICATION_CLOSE = "</" + DUPLICATION + ">";

    public static final String CONFIDENCE = "confidence";
    public static final String CONFIDENCE_OPEN = "<" + CONFIDENCE + ">";
    public static final String CONFIDENCE_CLOSE = "</" + CONFIDENCE + ">";
    public static final String CONFIDENCE_ATTRIBUTE_TYPE = "type";
    public static final String CONFIDENCE_BOOTSTRAP_TYPE = "bootstrap";
    
    public static final String COLOR = "color";
    public static final String COLOR_OPEN = "<" + COLOR + ">";
    public static final String COLOR_CLOSE = "</" + COLOR + ">";
    public static final String COLOR_ATTRIBUTE_TYPE = "type";
    public static final String COLOR_RGB_TYPE = "rgb";
    
    public static final String COLOR_RED = "red";
    public static final String COLOR_RED_OPEN = "<" + COLOR_RED + ">";
    public static final String COLOR_RED_CLOSE = "</" + COLOR_RED + ">";
    
    public static final String COLOR_GREEN = "green";
    public static final String COLOR_GREEN_OPEN = "<" + COLOR_GREEN + ">";
    public static final String COLOR_GREEN_CLOSE = "</" + COLOR_GREEN + ">";
    
    public static final String COLOR_BLUE = "blue";
    public static final String COLOR_BLUE_OPEN = "<" + COLOR_BLUE + ">";
    public static final String COLOR_BLUE_CLOSE = "</" + COLOR_BLUE + ">";
    
    
    public static final String CUSTOM_ATTRIBUTE_UNIT = "unit";
    public static final String CUSTOM_ATTRIBUTE_TYPE = "type";
    public static final String CUSTOM_ATTRIBUTE_PROPERTY = "property";
    public static final String CUSTOM_STRING_TYPE = "string";
    public static final String CUSTOM_DOUBLE_TYPE = "double";
    public static final String CUSTOM_LONG_TYPE = "long";
    public static final String CUSTOM_BOOLEAN_TYPE = "boolean";
    public static final String CUSTOM_URL_TYPE = "url";
    public static final String CUSTOM_NODE_PROPERTY = "node";
    public static final String CUSTOM_CLADE_PROPERTY = "clade";
    public static final String CUSTOM_PARENT_BRANCH_PROPERTY = "parent_branch";
    
    public static final String NL = "\n";

    public static final String IND = "  ";

    /**
     *  
     */
    private PhyloXMLmapping() {
    }

}
