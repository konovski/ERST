/*
 * ATVnodeHPFFrame.java Added to ATV by Ethy Cannon 7/8/04
 */

package erst.forester.java.src.org.forester.atv;


import java.awt.*;
import java.awt.event.*;

import javax.swing.JFrame;

import erst.forester.java.src.org.forester.phylogeny.*;

public class ATVnodeHPFFrame extends JFrame {

    private ATVnodeHPFPanel atvnodehpfpanel;

    private ATVtreePanel    atvtreepanel;

    private int             i;

    ATVnodeHPFFrame( PhylogenyNode n, ATVtreePanel tp, int x ) {
        atvtreepanel = tp;
        i = x;
        atvnodehpfpanel = new ATVnodeHPFPanel( n, this );
        setSize( 360, 320 );

        Container contentPane = getContentPane();
        contentPane.add( atvnodehpfpanel, BorderLayout.CENTER );
        addWindowListener( new WindowAdapter() {

            public void windowClosing( WindowEvent e ) {
                remove(); // to release slot in array
                dispose();
            }
        } );

        setVisible( true );
    }

    ATVtreePanel getATVtreePanel() {
        return atvtreepanel;
    }

    void remove() {
        atvtreepanel.removeNodeHPFFrame( i ); // to release slot in array
    }
}