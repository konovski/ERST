package erst.forester.java.src.org.forester.phylogeny.data;

public class Custom implements PhylogenyData {

   
    
    
    private String _name;
    private String _unit;
    private String _type;
    private String _property;
    private double _interval;
    private Support _support;
    private String _value;
    
    
    public Custom( final String name, final String type, final String value ) {
        
    }
    
    public void init() {
        // TODO Auto-generated method stub
    }
    
    public StringBuffer toPhyloXML( int level ) {
        // TODO Auto-generated method stub
        return null;
    }

    public PhylogenyData copy() {
        // TODO Auto-generated method stub
        return null;
    }

    public boolean isEqual( PhylogenyData data ) {
        // TODO Auto-generated method stub
        return false;
    }

    public StringBuffer asText() {
        // TODO Auto-generated method stub
        return null;
    }

    public StringBuffer asSimpleText() {
        // TODO Auto-generated method stub
        return null;
    }

 

}
