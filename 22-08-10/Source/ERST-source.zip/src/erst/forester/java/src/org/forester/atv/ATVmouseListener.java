
// ATVmouseListener.java
//
// Copyright (C) 1999-2002 Washington University School of Medicine
// and Howard Hughes Medical Institute
// All rights reserved
//
// Created: 1999
// Author: Christian M. Zmasek
// zmasek@genetics.wustl.edu
// http://www.genetics.wustl.edu/eddy/people/zmasek/

package erst.forester.java.src.org.forester.atv;

import java.awt.event.*;

/**
 * @author Christian Zmasek
 * @version 1.030 -- last modified: 10/04/01
 */
class ATVmouseListener extends MouseAdapter {

    private ATVtreePanel atvtreepanel;

    /**
     * Constructor.
     */
    ATVmouseListener( ATVtreePanel tp ) {
        atvtreepanel = tp;
    }

    /**
     * Mouse clicked.
     */
    public void mouseClicked( MouseEvent e ) {
        atvtreepanel.MouseClicked( e );
    }
}