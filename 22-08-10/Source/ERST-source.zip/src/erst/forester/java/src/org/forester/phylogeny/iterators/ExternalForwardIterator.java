// Copyright (C) 2005 Christian M. Zmasek
// All rights reserved
//
// Created: 2005
// Author: Christian M. Zmasek
// cmzmasek@yahoo.com
// http://www.phylogenonimcs.us
package erst.forester.java.src.org.forester.phylogeny.iterators;

import java.util.NoSuchElementException;

import erst.forester.java.src.org.forester.phylogeny.Phylogeny;
import erst.forester.java.src.org.forester.phylogeny.PhylogenyNode;

/**
 * @author Christian Zmasek
 */
public class ExternalForwardIterator implements PhylogenyNodeIterator {
    /**
     * Constructor for ExternalForwardIterator.
     * 
     * @param tree
     *            the tree on which to iterate over all external nodes.
     */
    public ExternalForwardIterator( final Phylogeny phylogeny )
            throws IllegalArgumentException {
        if ( phylogeny.isEmpty() ) {
            throw new IllegalArgumentException(
                    "Attempt to use ExternalForwardIterator on an empty phylogeny." );
        }

        PhylogenyNode n = phylogeny.getRoot();

        while ( !n.isExternal() ) {
            n = n.getLastChildNode();
        }

        _last_ext_node = n;
        _first_ext_node = phylogeny.getFirstExternalNode();
        reset();
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.util.Iterator#hasNext()
     */
    public boolean hasNext() {
        return getCurrentNode() != null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.util.Iterator#next()
     */
    public PhylogenyNode next() throws NoSuchElementException {
        if ( !hasNext() ) {
            throw new NoSuchElementException(
                    "Attempt to call \"next()\" on iterator which has no more next elements." );
        }

        final PhylogenyNode n = getCurrentNode();

        if ( n == getLastExtNode() ) {
            setCurrentNode( null );
        }
        else {
            setCurrentNode( n.getNextExternalNode() );
        }

        return n;
    }

    /**
     * DOCUMENT ME!
     */
    public void reset() {
        setCurrentNode( getFirstExtNode() );
    }

    private PhylogenyNode getCurrentNode() {
        return _current_node;
    }

    private void setCurrentNode( final PhylogenyNode current_node ) {
        _current_node = current_node;
    }

    private PhylogenyNode getFirstExtNode() {
        return _first_ext_node;
    }

    private PhylogenyNode getLastExtNode() {
        return _last_ext_node;
    }

    private PhylogenyNode       _current_node;
    private final PhylogenyNode _last_ext_node;
    private final PhylogenyNode _first_ext_node;
} // end of class ExternalForwardIterator
