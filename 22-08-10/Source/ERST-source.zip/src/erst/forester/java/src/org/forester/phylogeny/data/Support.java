package erst.forester.java.src.org.forester.phylogeny.data;

public class Support implements PhylogenyData {

    public final static double INTERVALL_DEFAULT = Double.MIN_VALUE;
    
    private double _value;

    private String _type;

    private double _interval;
    
    

    public Support() {
        init();
    }

    public Support( double value, String type ) {
        this( value, type, INTERVALL_DEFAULT);
    }
    
    public Support( double value, String type, double interval ) {
        setValue( value );
        setType( type );
        setInterval( interval );
    }

    public void init() {
        setValue( 0.0 );
        setType( "" );
        setInterval( INTERVALL_DEFAULT );
    }
    
    public PhylogenyData copy() {
        return new Support( getValue(), getType(), getInterval() );
    }

    public boolean isEqual( PhylogenyData support ) {
        if ( support == null ) {
            throw new IllegalArgumentException( "Attempt to compare a "
                    + "Support object to null." );
        }
        if ( ! ( support instanceof Support ) ) {
            throw new IllegalArgumentException( "Attempt to compare a "
                    + "Support object to a object of type ["
                    + support.getClass() + "]." );
        }
        final Support s = ( Support ) support;
        if ( s.getValue() != getValue() ) {

            return false;
        }
        if ( !s.getType().equals( getType() ) ) {
            return false;
        }
        if ( s.getInterval() != getInterval() ) {
            return false;
        }
        return true;
    }

    public StringBuffer toPhyloXML( int level ) {
        StringBuffer sb = new StringBuffer();
        sb.append( "<support type=\"" );
        sb.append( getType() );
        sb.append( "\"" );
        if ( getInterval() != INTERVALL_DEFAULT ) {
            sb.append( " interval=\"" );
            sb.append( getInterval() );
            sb.append( "\"" );
        }
        sb.append( ">" );
        sb.append( getValue() );
        sb.append( "</support>");
        return sb;
    }

    public StringBuffer asText() {
        StringBuffer sb = new StringBuffer();
        sb.append( getType() );
        sb.append( ": " );
        sb.append( getValue() );
       
        if ( getInterval() != INTERVALL_DEFAULT ) {
            sb.append( " [" );
            sb.append( getInterval() );
            sb.append( "]" );
        }
        return sb;
    }

    public StringBuffer asSimpleText() {
        return new StringBuffer().append( getValue() );
    }

    public double getInterval() {
        return _interval;
    }

    public void setInterval( double interval ) {
        _interval = interval;
    }

    public double getValue() {
        return _value;
    }

    public void setValue( double value ) {
        _value = value;
    }

    public String getType() {
        return _type;
    }

    public void setType( String type ) {
        _type = type;
    }

}
