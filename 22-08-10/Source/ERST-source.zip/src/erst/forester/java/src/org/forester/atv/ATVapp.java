// ATVapp.java
// Copyright (C) 1999-2000 Washington University School of Medicine
// and Howard Hughes Medical Institute
// All rights reserved

package erst.forester.java.src.org.forester.atv;
/**
 * @author Christian Zmasek
 * @version 1.00 -- last modified: 07/18/00
 * Probably modified by Renata in 2006.
 * Modified by Petar in 2008 - 2021.
 */

import java.io.*;
// import java.util.Map; - Excluded by Petar - never used.
// import java.util.HashMap; - Excluded by Petar - never used.
// import java.util.AbstractMap; - Excluded by Petar - never used.

import erst.forester.java.src.org.forester.phylogeny.Phylogeny;
import erst.forester.java.src.org.forester.phylogeny.factories.ParserBasedPhylogenyFactory;
import erst.forester.java.src.org.forester.phylogeny.factories.PhylogenyFactory;
import erst.forester.java.src.org.forester.phylogeny.parsers.nhx.NHXParser;
import erst.forester.java.src.org.forester.phylogeny.parsers.xml.SimplePhyloXMLParser1;

public class ATVapp {
    public int indexMM;
    public int keyMM;
//     public static Map indexGraphicsMap;
	@SuppressWarnings("unused")
	private ATVapplicationFrame atvframe;
     
//   private int index = GraphTabPanel.getIndex();
////     static {
////         indexGraphicsMap = new HashMap();
////     }
//     
//    public static AbstractMap indexLookup; 
//    
//    static {
//        indexLookup = new HashMap();
//    }
//
//   //     indexLookup.put(null, index);

     
     
     public ATVapp(){
    	 // Nothing special for the construction of an object is needed - the class is created simply as
    	 // a container for the programme execute.
     }
     
//     public ATVapp(int index){
//        this.index = index;
//     }
//    public static void main( String args[] ) {
    public void execute( String args[]) {
        Phylogeny p = null;
        Phylogeny tree = null; 
        String config_filename = null;
//        String pathRE = "";// = "H:\\2006-results\\TREEEU.txt"; //me

        try {
            int filename_index = 0;
//            if (pathRE.length() > 0) { // start me
//                File f = new File(pathRE);
//                PhylogenyFactory factory = ParserBasedPhylogenyFactory.getInstance();
//                System.out.println("printing path ***" + f + "****");
//                p = factory.create( f, new NHXParser() )[ 0 ];
//            } //finish me 
//            else
            if ( args.length > 0 ) { // me added the word else
                // check for a config file
                if ( args[ 0 ].startsWith( "-c" ) ) {
                    config_filename = args[ 1 ];
                    filename_index += 2;
                }
                if ( args.length > filename_index ) {
                    File f = new File( args[ filename_index ] );
                    PhylogenyFactory factory = ParserBasedPhylogenyFactory.getInstance();
                    //System.out.println("startup file: "+f.getName()+" exists: "+f.exists()); Diagnostic print.
                    if ( f.getName().toLowerCase().endsWith( ".xml" ) ) {
                        p = factory.create( f, new SimplePhyloXMLParser1() )[ 0 ];
                    }
                    else {
                        p = factory.create( f, new NHXParser() )[ 0 ];
                    }
                    //Close the file. (Petar)
                    //f.close();
                }
            }
        }
        catch ( Exception e ) {
            System.out.println();
            System.out.println( "Failure during startup of PARS - ATVapp:" );
            System.out.println( e.getMessage() );
            System.out.println();
            System.exit( -1 );
        }
        
        if (p != null) tree = p; 

        //String curDir = System.getProperty( "user.dir" ); Not used (Petar).
        //System.out.println( "working directory: " + curDir );

        //        System.err.println("g atvframe " + atvframe.getGraphics().toString());
//        indexGraphicsMap.put(atvframe.getGraphics(), new Integer(index));
		atvframe = new ATVapplicationFrame(tree, config_filename);
    } // End of public void execute( String args[]).
    
//    public void HPFNumber(int hpfN, String arg[], int keySpec){
//        
//        System.out.println("Printing HPF Number " + hpfN + " Key " + keySpec);
//       
//        
//        indexMM =  hpfN;
//        keyMM = keySpec;
//        
//        if (arg.length > 0) 
//            execute( arg );
//    }
}