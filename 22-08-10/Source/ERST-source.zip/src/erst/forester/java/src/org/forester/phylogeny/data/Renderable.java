// An interface which might to be used to render phylogeny data in ATV.

package erst.forester.java.src.org.forester.phylogeny.data;

public interface Renderable {
	
	public StringBuffer asText();
	
	public StringBuffer asSimpleText();

}
