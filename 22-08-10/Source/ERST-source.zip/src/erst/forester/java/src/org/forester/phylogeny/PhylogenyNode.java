// PhylogenyNode.java
//
// Copyright (C) 1999-2002 Washington University School of Medicine
// and Howard Hughes Medical Institute
// All rights reserved
//
// Created: 1999
// Author: Christian M. Zmasek
// zmasek@genetics.wustl.edu
// http://www.genetics.wustl.edu/eddy/people/zmasek/
package erst.forester.java.src.org.forester.phylogeny;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Stack;
import java.util.StringTokenizer;
import java.util.Vector;

import erst.forester.java.src.org.forester.phylogeny.iterators.ChildNodeIteratorForward;
import erst.forester.java.src.org.forester.phylogeny.iterators.PhylogenyNodeIterator;
import erst.forester.java.src.org.forester.phylogeny.parsers.PhylogenyParserException;

/**
 * @author Christian M. Zmasek
 * @version 1.700 -- last modified: 11/13/05
 */
public class PhylogenyNode extends Object {
    /** Value of -99.0 is used as default value. */
    public final static double DISTANCE_DEFAULT            = -99.0;

    /** Value of -99 is used as default value. */
    public final static double    BOOTSTRAP_DEFAULT           = -99.0;
    
//    //Start Renata's modification
//    public final static double GAIN_DEFAULT                 = -99.0;
//    
//    public final static double LOSS_DEFAULT                 = -99.0;
//    // end Renata's modification

    /**
     * Value of -100 is used to indicate that the branch does not exist. I.e. to
     * simulate nodes with more than two children.
     */
    public final static double DISTANCE_NULL               = -100.0;

    /**
     * Value of getOrthologous == -11 is used to indicate that this
     * PhylogenyNode is sequence X in the context of _orthologous relationships.
     */
    public final static int    SEQ_X                       = -11;

    public final static int    ORTHOLOGOUS_DEFAULT         = -99;

    //public final static int    PARENT_BRANCH_WIDTH_DEFAULT = -99;
    public final static int    PARENT_BRANCH_WIDTH_DEFAULT = 2; 
    // We will try this parameter with some meaningful values. 
    

    public final static Color  PARENT_BRANCH_COLOR_DEFAULT = null;

    private static int         _node_count                 = 0;     // Used to

    private int                _indicator;

    private int                _id;

    private String             _taxo_id;

    private double             _bootstrap;

    private int                _sum_ext_nodes;

    private int                _orthologous;

    private int                _super_orthologous;

    private int                _subtree_neighborings;

    private int                _parent_branch_width;

    private int                _x;

    private int                _y;

    private String             _seq_name;

    private String             _ec_number;

    private String             _taxonomy;

    //eksc 7/6/04 sequence popup suppprt
    private int                _seq_name_x;

    //eksc 7/6/04 sequence popup suppprt
    private int                _seq_name_y;

    //eksc 7/6/04 sequence popup suppprt
    private int                _seq_name_width;

    //eksc 7/6/04 sequence popup suppprt
    private int                _seq_name_height;

    //---------
    private double             _distance_parent;

    private boolean            _duplication_or_spec_assigned;

    private boolean            _duplication;

    private boolean            _possible_duplication;

    private boolean            _collapse;

    private PhylogenyNode      _parent;

    private PhylogenyNode      _link;

    private ArrayList          _connected_edges;

    private Color              _color;

    private Vector             _vector;
    //  Used in Eulenstein's algorithm.

    private Hashtable          _tag_value_units_node;

    private Hashtable          _tag_value_units_parent_branch;
    
//   // begin Renata's modification
//    private double              _gain;
//    
//    private double              _loss;
//    // end Renata's modification

//    private String             _gain;
//    private String             _loss;
    
    // ---------------------------------------------------------
    // Constructors
    // ---------------------------------------------------------

    /**
     * Constructor for PhylogenyNode.
     * <p>
     * (Last modified: 12/20/03)
     * 
     * @param s
     *            String representing one PhylogenyNode in New Hampshire (NH) or
     *            New Hampshire X (NHX) format.
     */
    public PhylogenyNode( String s ) throws PhylogenyParserException {

        init();
        parseNHX( s );

        setID( getNodeCount() );
        increaseNodeCount();

        setSumExtNodes( 1 ); // For ext node, this number is 1 (not 0!!)
    } // PhylogenyNode( String s )

    /**
     * Default constructor for PhylogenyNode.
     * <p>
     * (Last modified: 06/12/01)
     */
    public PhylogenyNode() {

        init();

        setID( getNodeCount() );
        increaseNodeCount();
        setSumExtNodes( 1 ); // For ext node, this number is 1 (not 0!!)
    } // PhylogenyNode()

    private void init() {
        setConnectedEdges( new ArrayList() );
        _parent = null;
        _id = 0;
        initializeData();

    }

    public void parseNHX( String s ) throws PhylogenyParserException {
        if ( s != null && s.length() > 0 ) {
            int ob = 0;
            int cb = 0;
            String a = "";
            String b = "";
            StringTokenizer t = null;

            ob = s.indexOf( "[" );
            cb = s.indexOf( "]" );

            if ( ob > -1 ) {
                a = "";
                b = "";

                if ( cb < 0 ) {
                    throw new PhylogenyParserException(
                            "Error in NHX format: No closing ]" );
                }

                if ( s.indexOf( "&&NHX" ) == ( ob + 1 ) ) {
                    a = s.substring( 0, ob );
                    b = s.substring( ob + 6, cb );
                }
                else {
                    a = s.substring( 0, ob );
                }

                s = a + b;

                if ( ( s.indexOf( "[" ) > -1 ) || ( s.indexOf( "]" ) > -1 ) ) {
                    throw new PhylogenyParserException(
                            "Error in NHX format: More than one ] or [" );
                }
            }
            t = new StringTokenizer( s, ":" );

            if ( t.countTokens() >= 1 ) {
                if ( !s.startsWith( ":" ) ) {
                    setSeqName( t.nextToken() );
                }

                while ( t.hasMoreTokens() ) {
                    s = t.nextToken();

                    if ( s.startsWith( "S=" ) ) {
                        setTaxonomy( s.substring( 2 ) );
                    }
                    else if ( s.startsWith( "E=" ) ) {
                        setECnumber( s.substring( 2 ) );
                    }
                    else if ( s.startsWith( "D=" ) ) {
                        if ( s.charAt( 2 ) == 'Y' ) {
                            setDuplication( true );
                        }
                        else if ( s.charAt( 2 ) == 'N' ) {
                            setDuplication( false );
                        }
                        else {
                            throw new PhylogenyParserException(
                                    "Error in NHX format: :D=Y or :D=N" );
                        }
                    }
                    else if ( s.startsWith( "Co=" ) ) {
                        if ( s.charAt( 3 ) == 'Y' ) {
                            setCollapse( true );
                        }
                        else if ( s.charAt( 3 ) == 'N' ) {
                            setCollapse( false );
                        }
                        else {
                            throw new PhylogenyParserException(
                                    "Error in NHX format: :Co=Y or :Co=N" );
                        }
                    }
                    else if ( s.startsWith( "B=" ) ) {
                        setBootstrap( Integer.parseInt( s.substring( 2 ) ) );
                    }
                    else if ( s.startsWith( "T=" ) ) {
                        setTaxonomyID( s.substring( 2 ) );
                    }
                    else if ( s.startsWith( "O=" ) ) {
                        setOrthologous( Integer.parseInt( s.substring( 2 ) ) );
                    }
                    else if ( s.startsWith( "SO=" ) ) {
                        setSuperOrthologous( Integer
                                .parseInt( s.substring( 3 ) ) );
                    }
                    else if ( s.startsWith( "SN=" ) ) {
                        setSubtreeNeighborings( Integer.parseInt( s
                                .substring( 3 ) ) );
                    }
                    else if ( s.startsWith( "W=" ) ) {
                        setParentBranchWidth( Integer
                                .parseInt( s.substring( 2 ) ) );
                    }
                    else if ( s.startsWith( "C=" ) ) {
                        Color c = null;

                        c = stringToColor( s.substring( 2 ) );

                        if ( c != null ) {
                            setColor( c );
                        }
                    }
                    else if ( s.startsWith( "XN=" ) ) {
                        TagValueUnit tvu = TagValueUnit.createInstance( s );
                        addCustomTagValue( tvu, true );
                    }
                    else if ( s.startsWith( "XB=" ) ) {
                        TagValueUnit tvu = TagValueUnit.createInstance( s );
                        addCustomTagValue( tvu, false );
                    }
//                    // Start Renata's modification
//                    else if ( s.startsWith( "GN=" ) ) {
//                        setNumberOfGains( Integer.parseInt( s.substring( 2 ) ) );
//                    }
//                    else if ( s.startsWith( "LS=" ) ) {
//                        setNumberOfLosses( Integer.parseInt( s.substring( 2 ) ) );
//                    }
//                    // end Renata's modification
                    
//                    else if ( s.startsWith( "GN=" ) ) {
//                        setGNnumber( s.substring( 2 ) );
//                    }
//                    else if ( s.startsWith( "LS=" ) ) {
//                        setLSnumber( s.substring( 2 ) );
//                    }
                    else {
                        //                        if ( _distance_parent != DISTANCE_DEFAULT ) {
                        //                            throw new PhylogenyParserException(
                        //                                    "Error in NHX format: More than one distance to
                        // _parent\n"
                        //                                            + "or non existing tag used: "
                        //                                            + "\"" + s + "\"" );
                        //                        }

                        setDistanceToParent( Double.valueOf( s ).doubleValue() );
                    }
                } // end of while loop
            }
        }

    }

    // ---------------------------------------------------------
    // Copy and delete Nodes, copy subtress
    // ---------------------------------------------------------

    /**
     * Returns a new PhylogenyNode which has its data copied from this
     * PhylogenyNode. Links to the other Nodes in the same Phylogeny are NOT
     * copied (e.g. _link to _parent). Field "_link" IS copied.
     * 
     * @see #getLink() (Last modified: 12/20/03)
     */
    public PhylogenyNode copyNodeData() {
        PhylogenyNode node = new PhylogenyNode();

        decreaseNodeCount();

        node._id = _id;
        node._bootstrap = _bootstrap;
        node._sum_ext_nodes = _sum_ext_nodes;
        node._indicator = _indicator;
        node._x = _x;
        node._y = _y;
        node._duplication = _duplication;
        node._seq_name = new String( _seq_name );
        node._ec_number = new String( _ec_number );
        node._taxonomy = new String( _taxonomy );
        node._taxo_id = _taxo_id;
        node._orthologous = _orthologous;
        node._super_orthologous = _super_orthologous;
        node._subtree_neighborings = _subtree_neighborings;
        node._distance_parent = _distance_parent;
        node._duplication_or_spec_assigned = _duplication_or_spec_assigned;
        node._collapse = _collapse;
        node._link = _link;
        node._vector = _vector;
        node._parent_branch_width = _parent_branch_width;
        node._color = _color;
        node._possible_duplication = _possible_duplication;

//        // Start Renata's modification
//         node._gain = _gain;
//         node._loss = _loss;
//        //end Renata's modification
//        node._gain = new String( _gain );
//        node._loss = new String( _loss );
        
        if ( _tag_value_units_node != null ) {
            node._tag_value_units_node = ( Hashtable ) _tag_value_units_node
                    .clone();
        }

        if ( _tag_value_units_parent_branch != null ) {
            node._tag_value_units_parent_branch = ( Hashtable ) _tag_value_units_parent_branch
                    .clone();
        }

        return node;
    } // copyNodeData()

    /**
     * Deletes data of this PhylogenyNode. Links to the other Nodes in the
     * Phylogeny, the ID and the sum of external nodes are NOT deleted. Field
     * "_link" (_link to Nodes in other Phylogeny) IS deleted.
     * 
     * @see #getLink() (Last modified: 12/20/03)
     */
    public void initializeData() {
        _indicator = 0;
        _taxo_id = "";
        _bootstrap = BOOTSTRAP_DEFAULT;
        _orthologous = ORTHOLOGOUS_DEFAULT;
        _super_orthologous = ORTHOLOGOUS_DEFAULT;
        _subtree_neighborings = ORTHOLOGOUS_DEFAULT;
        _x = 0;
        _y = 0;
        _seq_name = "";
        _ec_number = "";
        _taxonomy = "";
        _distance_parent = DISTANCE_DEFAULT;
        _duplication_or_spec_assigned = false;
        _duplication = false;
        _collapse = false;
        _link = null;
        _vector = null;
        _parent_branch_width = PARENT_BRANCH_WIDTH_DEFAULT;
        _color = PARENT_BRANCH_COLOR_DEFAULT;
        _tag_value_units_node = null;
        _tag_value_units_parent_branch = null;
        _possible_duplication = false;
        
//        //Start Renata's modification  
//        _gain = GAIN_DEFAULT;
//        _loss = LOSS_DEFAULT;
//        // end Renata's modification
//        _gain = "";
//        _loss = "";
        
    } // initializeData()

    /**
     * Deep copies the Phylogeny originating from this PhylogenyNode.
     */
    static PhylogenyNode copyTree( PhylogenyNode source ) {
        if ( source == null ) {
            return null;
        }
        else {
            PhylogenyNode newnode = source.copyNodeData();

            if ( !source.isExternal() ) {
                newnode.setChild1( copyTree( source.getChildNode1() ) );
                newnode.setChild2( copyTree( source.getChildNode2() ) );
            }

            return newnode;
        }
    } // copyTree( PhylogenyNode )

    // ---------------------------------------------------------
    // Static set and get methods for PhylogenyNode class
    // ---------------------------------------------------------

    /**
     * Returns the total number of all Nodes created so far.
     * 
     * @return total number of Nodes (int)
     */
    public static int getNodeCount() {
        return _node_count;
    }

    /**
     * Sets the total number of all Nodes created so far to i (int).
     */
    public static void setNodeCount( int i ) {
        _node_count = i;
    }

    /**
     * Increases the total number of all Nodes created so far by one.
     */
    public static void increaseNodeCount() {
        ++_node_count;
    }

    /**
     * Decreases the total number of all Nodes created so far by one.
     */
    static void decreaseNodeCount() {
        --_node_count;
    }

    // ---------------------------------------------------------
    // Set and get methods for Nodes
    // ---------------------------------------------------------

    /**
     * Returns the ID (int) of this PhylogenyNode.
     */
    public int getID() {
        return _id;
    }

    /**
     * Sets the ID of this PhylogenyNode to i (int). In most cases, this number
     * should not be set to values lower than getNodeCount().
     */
    public void setID( int i ) {
        _id = i;
    }

    /**
     * Returns the _bootstrap value (double) of this PhylogenyNode.
     */
    public double getBootstrap() {
        return _bootstrap;
    }

    /**
     * Sets the _bootstrap value of this PhylogenyNode to d (double).
     */
    public void setBootstrap( double d ) {
        if ( ( d < 0 ) && ( d != BOOTSTRAP_DEFAULT ) ) {
            _bootstrap = 0;
            System.err
                    .print( "PhylogenyNode: setBootstrap( int ): WARNING: Negative " );
            System.err
                    .println( "_bootstrap has been replaced by _bootstrap 0!\n" );
        }
        else {
            _bootstrap = d;
        }
    }
    
    
   
//    //Start Renata's modification
//    public double getNumberOfGains() {
//        return _gain;
//    }   
//    public double getNumberOfLosses() {
//        return _loss;
//    }
//    public void setNumberOfGains( double d ) {
//        if ( ( d < 0 ) && ( d != GAIN_DEFAULT ) ) {
//            _gain = 0;
//            System.err.print( "PhylogenyNode: setNumberOfGains( int ): WARNING: Negative " );
//            System.err.println( "_gain has been replaced by _gain 0!\n" );
//        }
//        else {
//            _gain = d;
//        }
//    }
//    public void setNumberOfLosses( double d ) {
//        if ( ( d < 0 ) && ( d != LOSS_DEFAULT ) ) {
//            _loss = 0;
//            System.err.print( "PhylogenyNode: setNumberOfLosses( int ): WARNING: Negative " );
//            System.err.println( "_loss has been replaced by _loss 0!\n" );
//        }
//        else {
//            _loss = d;
//        }
//    }
//    // end Renata's modification

    /**
     * Sets the NCBI Taxonomy ID of this PhylogenyNode to i (int). TODO: Should
     * be a String... or specialized object (with namespace, -> XML )
     */
    public void setTaxonomyID( String id ) {
        _taxo_id = id;
    }

    /**
     * Returns the NCBI Taxonomy ID (int) of this PhylogenyNode.
     */
    public String getTaxonomyID() {
        return _taxo_id;
    }

    /**
     * Checks whether this PhylogenyNode is a pseudo PhylogenyNode, i.e. used to
     * simulate nodes with more than two childrem. A pseudo node has no distance
     * to its _parent.
     * 
     * @return true if this PhylogenyNode is a pseudo node, false otherwise
     */
    public boolean isPseudoNode() {
        return ( getDistanceToParent() == DISTANCE_NULL );
    }

    /**
     * Checks whether this PhylogenyNode is external (tip).
     * 
     * @return true if this PhylogenyNode is external, false otherwise
     */
    public boolean isExternal() {
        return ( getNumberOfChildNodes() < 1 );
    }

    /**
     * Checks whether this PhylogenyNode is internal (tip).
     * 
     * @return true if this PhylogenyNode is external, false otherwise
     */
    public boolean isInternal() {
        return ( !isExternal() );
    }

    /**
     * Checks whether this PhylogenyNode is a root.
     * 
     * @return true if this PhylogenyNode is the root, false otherwise
     */
    public boolean isRoot() {
        return _parent == null;
    }

    /**
     * Returns the total number of external Nodes originating from this
     * PhylogenyNode (int).
     */
    public int getSumExtNodes() {
        return _sum_ext_nodes;
    }

    /**
     * Sets the total number of external Nodes originating from this
     * PhylogenyNode to i (int).
     */
    public void setSumExtNodes( int i ) {
        _sum_ext_nodes = i;
    }

    /**
     * Returns the _indicator value of this PhylogenyNode (int).
     */
    public int getIndicator() {
        return _indicator;
    }

    /**
     * Sets the _indicator value of this PhylogenyNode to i (int).
     */
    public void setIndicator( int i ) {
        _indicator = i;
    }

    /**
     * Used for drawing of Trees.
     */
    public int getXcoord() {
        return _x;
    }

    /**
     * Used for drawing of Trees.
     */
    public void setXcoord( int i ) {
        _x = i;
    }

    /**
     * Used for drawing of Trees.
     */
    public int getYcoord() {
        return _y;
    }

    //eksc 7/6/04 for sequence popup support
    public void setSeqNameRect( int x, int y, int width, int height ) {
        _seq_name_x = x;
        _seq_name_y = y;
        _seq_name_width = width;
        _seq_name_height = height;
    }

    //-----------
    //eksc 7/6/04 for sequence popup support
    public boolean isInSeqNameRect( int x, int y ) {
        return ( ( x > _seq_name_x )
                && ( x < ( _seq_name_x + _seq_name_width ) )
                && ( y > _seq_name_y ) && ( y < ( _seq_name_y + _seq_name_height ) ) );
    }

    //-----------

    /**
     * Used for drawing of Trees.
     */
    public void setYcoord( int i ) {
        _y = i;
    }

    /**
     * Returns true if this PhylogenyNode represents a _duplication event, false
     * otherwise.
     */
    public boolean isDuplication() {
        return _duplication;
    }

    /**
     * Sets whether this PhylogenyNode represents a _duplication event or not.
     */
    public void setDuplication( boolean b ) {
        _duplication = b;
        setDuplicationOrSpecAssigned( true );
    }

    /**
     * Sets the name of the sequence associated with this PhylogenyNode to
     * String s.
     */
    public void setSeqName( String s ) {
        _seq_name = s.trim();
    }

    /**
     * Returns the name of the sequence associated with this PhylogenyNode
     * (String).
     */
    public String getSeqName() {
        return _seq_name;
    }

    /**
     * Sets the EC number associated with this PhylogenyNode to String s.
     */
    public void setECnumber( String s ) {
        _ec_number = s.trim();
    }

//    public void setGNnumber( String s ) {
//        _gain = s.trim();
//    }
//
//     public String getGNnumber() {
//        return _gain;
//    }
//    public void setLSnumber( String s ) {
//        _loss = s.trim();
//    }
//
//     public String getLSnumber() {
//        return _loss;
//    }
    /**
     * Returns the EC number associated with this PhylogenyNode (as String).
     */
    public String getECnumber() {
        return _ec_number;
    }

    /**
     * Sets the name of the _taxonomy associated with this PhylogenyNode to
     * String s.
     */
    public void setTaxonomy( String s ) {
        _taxonomy = s.trim();
    }

    /**
     * Returns the name of the _taxonomy associated with this PhylogenyNode
     * (String).
     */
    public String getTaxonomy() {
        return _taxonomy;
    }

    /**
     * Returns the length of the branch leading to the _parent of this
     * PhylogenyNode (double).
     */
    public double getDistanceToParent() {
        return _distance_parent;
    }

    /**
     * Sets the length of the branch leading to the _parent of this
     * PhylogenyNode to double d.
     */
    public void setDistanceToParent( double d ) {
        if ( ( d < 0.0 ) && ( d != DISTANCE_DEFAULT ) && ( d != DISTANCE_NULL ) ) {
            _distance_parent = 0.0;
        }
        else {
            _distance_parent = d;
        }
    }

    /**
     * Returns whether a _duplication or speciation event has been assigned for
     * this PhylogenyNode.
     */
    public boolean isDuplicationOrSpecAssigned() {
        return _duplication_or_spec_assigned;
    }

    /**
     * Sets whether a _duplication or speciation event has been assigned for
     * this PhylogenyNode.
     */
    public void setDuplicationOrSpecAssigned( boolean b ) {
        _duplication_or_spec_assigned = b;
    }

    /**
     * Sets whether this PhylogenyNode should be drawn as collapsed.
     */
    public void setCollapse( boolean b ) {
        _collapse = b;
    }

    /**
     * Returns whether this PhylogenyNode should be drawn as collapsed.
     */
    public boolean isCollapse() {
        return _collapse;
    }

    /**
     * Returns a refernce to the next external PhylogenyNode of this
     * PhylogenyNode. TODO should be in Phylogeny. Returns null if no next
     * external node is available.
     */
    public PhylogenyNode getPreviousExternalNode() {
        if ( isInternal() ) {
            throw new UnsupportedOperationException(
                    "Cannot get the previous external node for an internal node." );
        }
        else if ( isRoot() /* TODO && tree is rooted */) {
            throw new UnsupportedOperationException(
                    "Cannot get the previous external node for a root node." );
        }
        else if ( isFirstExternalNode() ) {
            throw new UnsupportedOperationException(
                    "Attempt to get previous external node of the first external node." );
        }

        int index = getChildNodeIndex();
        PhylogenyNode previous_node = this;
        PhylogenyNode current_node = getParent();

        while ( !current_node.isRoot()
                && ( ( current_node.getNumberOfChildNodes() == 1 ) || previous_node
                        .isFirstChildNode() ) ) {
            index = current_node.getChildNodeIndex();
            previous_node = current_node;
            current_node = current_node.getParent();
        }

        current_node = current_node.getChildNode( index - 1 );

        while ( current_node.isInternal() ) {
            current_node = current_node.getLastChildNode();
        }

        return current_node;
    }

    /**
     * Returns a refernce to the next external PhylogenyNode of this
     * PhylogenyNode. TODO should be in Phylogeny. Returns null if no next
     * external node is available.
     */
    public PhylogenyNode getNextExternalNode() {
        if ( isInternal() ) {
            throw new UnsupportedOperationException(
                    "Cannot get the next external node for an internal node." );
        }
        else if ( isRoot() /* TODO && tree is rooted */) {
            throw new UnsupportedOperationException(
                    "Cannot get the next external node for a root node." );
        }
        else if ( isLastExternalNode() ) {
            throw new UnsupportedOperationException(
                    "Attempt to get next external node of tha last external node." );
        }

        int index = getChildNodeIndex();
        PhylogenyNode previous_node = this;
        PhylogenyNode current_node = getParent();

        while ( !current_node.isRoot()
                && ( ( current_node.getNumberOfChildNodes() == 1 ) || previous_node
                        .isLastChildNode() ) ) {
            index = current_node.getChildNodeIndex();
            previous_node = current_node;
            current_node = current_node.getParent();
        }

        current_node = current_node.getChildNode( index + 1 );

        while ( current_node.isInternal() ) {
            current_node = current_node.getFirstChildNode();
        }

        return current_node;
    }

    /**
     * DOCUMENT ME!
     * 
     * @return DOCUMENT ME!
     */
    public boolean isFirstExternalNode() {
        if ( isInternal() ) {
            return false;
        }

        PhylogenyNode node = this;

        while ( !node.isRoot() ) {
            if ( !node.isFirstChildNode() ) {
                return false;
            }

            node = node.getParent();
        }

        return true;
    }

    /**
     * DOCUMENT ME!
     * 
     * @return DOCUMENT ME!
     */
    public boolean isLastExternalNode() {
        if ( isInternal() ) {
            return false;
        }

        PhylogenyNode node = this;

        while ( !node.isRoot() ) {
            if ( !node.isLastChildNode() ) {
                return false;
            }

            node = node.getParent();
        }

        return true;
    }

    public int getNumberOfChildNodes() {
        int counter = 0;
        if ( getConnectedEdges() != null ) {

            for ( int i = 0; i < getConnectedEdges().size(); ++i ) {
                final Edge edge = ( Edge ) getConnectedEdges().get( i );
                if ( !( edge instanceof PhylogenyBranch && ( ( PhylogenyBranch ) edge )
                        .isDirectionTowards( this ) ) ) {
                    ++counter;
                }
            }
        }
        return counter;
    }

    public int getNumberOfParents() {
        int counter = 0;
        if ( getConnectedEdges() != null ) {

            for ( int i = 0; i < getConnectedEdges().size(); ++i ) {
                final Edge edge = ( Edge ) getConnectedEdges().get( i );
                if ( edge instanceof PhylogenyBranch
                        && ( ( PhylogenyBranch ) edge )
                                .isDirectionTowards( this ) ) {
                    ++counter;
                }
            }
        }
        return counter;
    }

    /**
     * Convenience method. Returns the first child PhylogenyNode of this
     * PhylogenyNode.
     */
    public PhylogenyNode getChildNode1() {
        return getFirstChildNode();
    }

    /**
     * Convenience method. Returns the second child PhylogenyNode of this
     * PhylogenyNode.
     * <p>
     * [last modified May 18, 2005 by CMZ]
     */
    public PhylogenyNode getChildNode2() {
        return getChildNode( 1 );
    }

    /**
     * Convenience method. Returns the first child node of this node.
     * <p>
     * [last modified May 18, 2005 by CMZ]
     * 
     * @return the first child node of this node
     */
    public PhylogenyNode getFirstChildNode() {
        return getChildNode( 0 );
    }

    /**
     * Convenience method. Returns the last child node of this node.
     * <p>
     * [last modified May 18, 2005 by CMZ]
     * 
     * @return the last child node of this node
     */
    public PhylogenyNode getLastChildNode() {
        return getChildNode( getNumberOfChildNodes() - 1 );
    }

    /**
     * Returns true if this node is the last child node of its _parent.
     * <p>
     * [last modified June 01, 2005 by CMZ]
     * 
     * @return true if this node is the last child node of its _parent, false
     *         otherwise
     */
    public boolean isLastChildNode() {
        if ( isRoot() /* and tree is rooted TODO */) {
            throw new UnsupportedOperationException(
                    "Cannot determine whether the root is the last child node of its _parent." );
        }

        return ( getChildNodeIndex() == ( getParent().getNumberOfChildNodes() - 1 ) );
    }

    /**
     * DOCUMENT ME!
     * 
     * @return DOCUMENT ME!
     */
    public boolean isFirstChildNode() {
        if ( isRoot() /* and tree is rooted TODO */) {
            throw new UnsupportedOperationException(
                    "Cannot determine whether the root is the first child node of its _parent." );
        }

        return ( getChildNodeIndex() == 0 );
    }

    /**
     * This return child node n of this node.
     * 
     * @param n
     *            the index of the child to get
     * @return the child node with index n
     * @throws IllegalArgumentException
     *             if n is out of bounds
     */
    public PhylogenyNode getChildNode( int i ) {
        if ( isExternal() ) {
            throw new UnsupportedOperationException(
                    "Cannot get the child node for a external node." );
        }

        if ( ( i >= getNumberOfChildNodes() ) || ( i < 0 ) ) {
            throw new IllegalArgumentException( "Attempt to get child node "
                    + i + " of a node with " + getNumberOfChildNodes()
                    + " child nodes." );
        }

        return ( ( PhylogenyBranch ) getConnectedEdges().get( i ) )
                .getConnectedNode( this );
    }

    /**
     * This gets the child node index of this node.
     * <p>
     * [last modified May 18, 2005 by CMZ]
     * 
     * @return the child node index of this node
     * @throws UnsupportedOperationException
     *             if this node is a root node
     */
    public int getChildNodeIndex() {
        if ( isRoot() ) {
            throw new UnsupportedOperationException(
                    "Cannot get the child index for a root node." );
        }

        for ( int i = 0; i < getParent().getNumberOfChildNodes(); ++i ) {
            if ( getParent().getChildNode( i ) == this ) {
                return i;
            }
        }

        throw new RuntimeException(
                "Unexpected exception: Could not determine the child index for node:\n"
                        + this );
    }

    /**
     * Sets the first child PhylogenyNode of this PhylogenyNode to n. But does
     * NOT set the _parent of n to this.
     */
    public void setChild1( PhylogenyNode n ) {
        setChildNode( 0, n );
    }

    /**
     * Sets the second child PhylogenyNode of this PhylogenyNode to n. But does
     * NOT set the _parent of n to this.
     */
    public void setChild2( PhylogenyNode n ) {
        setChildNode( 1, n );
    }

    /**
     * Inserts PhylogenyNode n at the specified position i into the list of
     * child nodes. This does not allow null slots in the list of child nodes:
     * If i is larger than the number of child nodes, n is just added to the
     * list, not place at index i. But does NOT set the _parent of n to this.
     * 
     * @param i
     *            the index of position where to add the child
     * @param n
     *            the PhylogenyNode to add
     */
    public void setChildNode( int i, PhylogenyNode node ) {

        if ( getNumberOfChildNodes() <= i ) {
            addChildNode( node );
        }
        else {
            PhylogenyBranch b = new PhylogenyBranch( node, this, true );
            getConnectedEdges().set( i, b );
        }
    }

    /**
     * Adds PhylogenyNode n to the list of child nodes. But does NOT set the
     * _parent of n to this.
     * 
     * @see addAsChild( PhylogenyNode n )
     * @param n
     *            the PhylogenyNode to add
     */
    private void addChildNode( PhylogenyNode node ) {
        PhylogenyBranch b = new PhylogenyBranch( node, this, true );
        getConnectedEdges().add( b );
    }

    /**
     * Adds PhylogenyNode n to the list of child nodes and sets the _parent of n
     * to this.
     * 
     * @param n
     *            the PhylogenyNode to add
     */
    public void addAsChild( PhylogenyNode node ) {
        addChildNode( node );
        node.setParent( this );
    }

    /**
     * Returns a refernce to the _parent PhylogenyNode of this PhylogenyNode.
     */
    public PhylogenyNode getParent() {
        if ( isRoot() ) {
            throw new UnsupportedOperationException(
                    "Cannot get the _parent of a root node." );
        }

        return _parent;
    }

    /**
     * Sets the _parent PhylogenyNode of this PhylogenyNode to n.
     */
    public void setParent( PhylogenyNode n ) {
        _parent = n;
    }

    /**
     * Sets the linked PhylogenyNode of this PhylogenyNode to n. Currently, this
     * method is only used for the speciation-_duplication assignment
     * algorithms.
     */
    public void setLink( PhylogenyNode n ) {
        _link = n;
    }

    /**
     * Returns a refernce to the linked PhylogenyNode of this PhylogenyNode.
     * Currently, this method is only used for the speciation-_duplication
     * assignment algorithms.
     */
    public PhylogenyNode getLink() {
        return _link;
    }

    /**
     * Sets the Vector associated with this PhylogenyNode to v. Currently, this
     * method is only used for Eulenstein's speciation-_duplication assignment
     * algorithm. TODO: this should go into a subclass of this.... and should be
     * a List....
     */
    public void setVector( Vector v ) {
        _vector = v;
    }

    /**
     * Returns a refernce to the Vector associated with this PhylogenyNode.
     * Currently, this method is only used for Eulenstein's
     * speciation-_duplication assignment algorithm.
     */
    public Vector getVector() {
        return _vector;
    }

    /**
     * Returns how many times this PhylogenyNode is _orthologous to another one.
     * (Last modified: 12/05/00 )
     */
    public int getOrthologous() {
        return _orthologous;
    }

    /**
     * Sets how many times this PhylogenyNode is _orthologous to another one.
     * (Last modified: 12/05/00 )
     */
    public void setOrthologous( int i ) {
        _orthologous = i;
    }

    /**
     * Returns how many times this PhylogenyNode is super _orthologous to
     * another one. (Last modified: 12/05/00 )
     */
    public int getSuperOrthologous() {
        return _super_orthologous;
    }

    /**
     * Sets how many times this PhylogenyNode is super _orthologous to another
     * one. (Last modified: 12/05/00 )
     */
    public void setSuperOrthologous( int i ) {
        _super_orthologous = i;
    }

    /**
     * Returns how many times this PhylogenyNode is a subtree-neighbor to
     * another one. (Last modified: 02/16/02 )
     */
    public int getSubtreeNeighborings() {
        return _subtree_neighborings;
    }

    /**
     * Sets how many times this PhylogenyNode is a subtree-neighbor to another
     * one. (Last modified: 02/16/02 )
     */
    public void setSubtreeNeighborings( int i ) {
        _subtree_neighborings = i;
    }

    /**
     * Returns whether the width of the _parent branch has been assigned. (Last
     * modified: 01/02/04)
     */
    public boolean isParentBranchWidthAssigned() {
        return getParentBranchWidth() != PARENT_BRANCH_WIDTH_DEFAULT;
    }

    /**
     * Returns the width of the _parent branch. (Last modified: 12/20/03)
     */
    public int getParentBranchWidth() {
        return _parent_branch_width;
    }

    /**
     * Sets the width of the _parent branch. (Last modified: 12/20/03)
     */
    public void setParentBranchWidth( int parent_branch_width ) {
        _parent_branch_width = parent_branch_width;
    }

    /**
     * Returns whether the width of the _parent branch has been assigned. (Last
     * modified: 01/02/04)
     */
    public boolean isParentBranchColorAssigned() {
        return getColor() != PARENT_BRANCH_COLOR_DEFAULT;
    }

    /**
     * Returns the color of this node. (Last modified: 06/20/05)
     */
    public Color getColor() {
        return _color;
    }

    /**
     * Sets the color of the this node. (Last modified: 06/20/05)
     */
    public void setColor( final Color color ) {
        _color = color;
    }

    /**
     * Sets the color of the this node. (Last modified: 06/20/05)
     */
    public void setColor( int red, int green, int blue ) {
        setColor( new Color( red, green, blue ) );
    }

    // ---------------------------------------------------------
    // Custom data
    // ---------------------------------------------------------

    /**
     * Sets the reference to the Hashtable containing the custom
     * tag/values/units for this node. (Last modified: 05/05/03 )
     */
    void setNodeCustomTagValueUnits( final Hashtable custom_tag_value_units ) {
        _tag_value_units_node = custom_tag_value_units;
    }

    /**
     * Returns the reference to the Hashtable containing the custom
     * tag/values/units for this node. (Last modified: 05/05/03 )
     */
    Hashtable getNodeCustomTagValueUnits() {
        return _tag_value_units_node;
    }

    /**
     * Sets the reference to the Hashtable containing the custom
     * tag/values/units for the _parent branch of this node. (Last modified:
     * 05/05/03 )
     */
    void setParentBranchCustomTagValueUnits(
            final Hashtable custom_tag_value_units ) {
        _tag_value_units_parent_branch = custom_tag_value_units;
    }

    /**
     * Returns the reference to the Hashtable containing the custom
     * tag/values/units for the _parent branch of this node. (Last modified:
     * 05/05/03 )
     */
    Hashtable getParentBranchCustomTagValueUnits() {
        return _tag_value_units_parent_branch;
    }

    /**
     * Sets a TagValueUnit. The tag is used as key in the hashtable. (Last
     * modified: 05/05/03 )
     */
    public void addCustomTagValue( final TagValueUnit tag_value_unit,
            boolean for_node ) throws IllegalArgumentException {
        if ( getNodeCustomTagValueUnits() == null ) {
            setNodeCustomTagValueUnits( new Hashtable() );
        }

        if ( getParentBranchCustomTagValueUnits() == null ) {
            setParentBranchCustomTagValueUnits( new Hashtable() );
        }

        if ( getNodeCustomTagValueUnits().containsKey( tag_value_unit.getTag() )
                || getParentBranchCustomTagValueUnits().containsKey(
                        tag_value_unit.getTag() ) ) {
            throw new IllegalArgumentException( "Tag \""
                    + tag_value_unit.getTag() + "\" is already present" );
        }

        if ( for_node ) {
            getNodeCustomTagValueUnits().put( tag_value_unit.getTag(),
                    tag_value_unit );
        }
        else {
            getParentBranchCustomTagValueUnits().put( tag_value_unit.getTag(),
                    tag_value_unit );
        }
    }

    /**
     * Returns a TagValueUnit. (throws exception if not present.) Repaired to
     * throw a descriptive IllegalArgumentException rather than a nondescriptive
     * NullpointerException. (Last modified: 07/29/04 )
     */
    public TagValueUnit getCustomTagValue( final String tag )
            throws IllegalArgumentException {
        TagValueUnit tvu = null;

        if ( getNodeCustomTagValueUnits() != null ) {
            tvu = ( TagValueUnit ) getNodeCustomTagValueUnits().get( tag );
        }

        if ( tvu != null ) {
            return tvu;
        }
        else {
            if ( getParentBranchCustomTagValueUnits() != null ) {
                tvu = ( TagValueUnit ) getParentBranchCustomTagValueUnits()
                        .get( tag );
            }
        }

        if ( tvu != null ) {
            return tvu;
        }
        else {
            throw new IllegalArgumentException( "Tag \"" + tag
                    + "\" is not present" );
        }
    }

    /**
     * DOCUMENT ME!
     * 
     * @return DOCUMENT ME!
     */
    public TagValueUnit[] getCustomTagValueUnitsAsArray() {
        if ( ( getParentBranchCustomTagValueUnits() == null )
                && ( getNodeCustomTagValueUnits() == null ) ) {
            return new TagValueUnit[ 0 ];
        }

        Enumeration e1 = null;
        Enumeration e2 = null;
        int size = 0;

        if ( getNodeCustomTagValueUnits() != null ) {
            e1 = getNodeCustomTagValueUnits().elements();
            size += getNodeCustomTagValueUnits().size();
        }

        if ( getParentBranchCustomTagValueUnits() != null ) {
            e2 = getParentBranchCustomTagValueUnits().elements();
            size += getParentBranchCustomTagValueUnits().size();
        }

        TagValueUnit[] a = new TagValueUnit[ size ];
        int i = 0;

        while ( ( e1 != null ) && e1.hasMoreElements() ) {
            a[ i++ ] = ( TagValueUnit ) e1.nextElement();
        }

        while ( ( e2 != null ) && e2.hasMoreElements() ) {
            a[ i++ ] = ( TagValueUnit ) e2.nextElement();
        }

        return a;
    }

    /**
     * DOCUMENT ME!
     * 
     * @return DOCUMENT ME!
     */
    public TagValueUnit[] getParentBranchCustomTagValueUnitsAsArray() {
        if ( getParentBranchCustomTagValueUnits() == null ) {
            return new TagValueUnit[ 0 ];
        }

        Enumeration e = getParentBranchCustomTagValueUnits().elements();
        TagValueUnit[] a = new TagValueUnit[ getParentBranchCustomTagValueUnits()
                .size() ];
        int i = 0;

        while ( e.hasMoreElements() ) {
            a[ i++ ] = ( TagValueUnit ) e.nextElement();
        }

        return a;
    }

    /**
     * DOCUMENT ME!
     * 
     * @return DOCUMENT ME!
     */
    public TagValueUnit[] getNodeCustomTagValueUnitsAsArray() {
        if ( getNodeCustomTagValueUnits() == null ) {
            return new TagValueUnit[ 0 ];
        }

        Enumeration e = getNodeCustomTagValueUnits().elements();
        TagValueUnit[] a = new TagValueUnit[ getNodeCustomTagValueUnits()
                .size() ];
        int i = 0;

        while ( e.hasMoreElements() ) {
            a[ i++ ] = ( TagValueUnit ) e.nextElement();
        }

        return a;
    }

    /**
     * Returns all custom data tag names of this PhylogenyNode as String array.
     */
    public String[] getCustomTagNames() {
        if ( ( getNodeCustomTagValueUnits() == null )
                && ( getParentBranchCustomTagValueUnits() == null ) ) {
            return new String[ 0 ];
        }

        TagValueUnit[] tvu = getCustomTagValueUnitsAsArray();
        String[] tags = new String[ tvu.length ];

        for ( int i = 0; i < tvu.length; ++i ) {
            tags[ i ] = tvu[ i ].getTag();
        }

        return tags;
    }

    //eksc 8/9/04 added for convenience
    public boolean customTagExists( String tag ) {
        boolean exists = false;

        if ( getNodeCustomTagValueUnits() != null ) {
            Enumeration e = getNodeCustomTagValueUnits().elements();

            while ( e.hasMoreElements() && !exists ) {
                TagValueUnit tvu = ( TagValueUnit ) e.nextElement();

                if ( tvu.getTag().equalsIgnoreCase( tag ) ) {
                    exists = true;
                }
            }
        }

        return exists;
    }

    //-----------------
    // ---------------------------------------------------------
    // Inquiery of PhylogenyNode properties
    // ---------------------------------------------------------

    /**
     * Returns true if this PhylogenyNode is the first child of its _parent
     * PhylogenyNode. Returns false if this PhylogenyNode is the second child of
     * its _parent or if this PhylogenyNode has no _parent.
     */
    //    public boolean isChild1() {
    //        if ( (getParent() == null) || (getParent().getChildNode2() == this) ) {
    //            return false;
    //        }
    //
    //        return true;
    //    } // isChild1()
    // ---------------------------------------------------------
    // Obtaining of Nodes
    // ---------------------------------------------------------
    /**
     * Returns a Vector containing references to all external children of this
     * PhylogenyNode. The order is the same as in the Phylogeny.
     * 
     * @return Vector of references to external Nodes, null if this node is
     *         external
     */
    public Vector getAllExternalChildren() {
        Vector nodes = new Vector();
        PhylogenyNode node1 = null;
        PhylogenyNode node2 = null;

        if ( isExternal() ) {
            nodes.addElement( this );
            nodes.trimToSize();

            return nodes;
        }

        node1 = this;

        while ( !node1.isExternal() ) {
            node1 = node1.getChildNode1();
        }

        node2 = this;

        while ( !node2.isExternal() ) {
            node2 = node2.getChildNode2();
        }

        do {
            nodes.addElement( node1 );
            node1 = node1.getNextExternalNode();
        }
        while ( node1 != node2 );

        nodes.addElement( node1 );

        nodes.trimToSize();

        return nodes;
    } // getAllExternalChildren()

    /**
     * Returns a Vector containing references to all (both internal and
     * external) children of this PhylogenyNode. Does not return pseudo Nodes
     * (which are used to simulate nodes with more than two children).
     * 
     * @return Vector of references to Nodes, null if this node is external
     */
    public Vector getAllChildren() {
        Vector nodes = new Vector();

        if ( isExternal() ) {
            return null;
        }

        PhylogenyNode node1;
        PhylogenyNode node2;
        PhylogenyNode node3;

        node1 = this;

        while ( !node1.isExternal() ) {
            node1 = node1.getChildNode1();
        }

        node3 = this;

        while ( !node3.isExternal() ) {
            node3 = node3.getChildNode2();
        }

        setIndicatorsToZero();

        do {
            node2 = node1;

            do {
                if ( node2.getIndicator() == 0 ) {
                    node2.setIndicator( 1 );

                    if ( !node2.isPseudoNode() && ( node2 != this ) ) {
                        //                                nec.???
                        nodes.addElement( node2 );
                    }
                }

                node2 = node2.getParent();
            }
            while ( node2 != this );

            node1 = node1.getNextExternalNode();
        }
        while ( ( node1 != null )
                && ( node1.getPreviousExternalNode() != node3 ) );

        nodes.trimToSize();

        return nodes;
    } // getAllChildren()

    /**
     * Returns a array containing copies all external children of this
     * PhylogenyNode.
     */
    public PhylogenyNode[] copyAllExtChildren() {
        int i = 1;
        PhylogenyNode node;
        PhylogenyNode first = this;
        PhylogenyNode last = this;
        PhylogenyNode[] nodes;

        if ( isExternal() ) {
            nodes = new PhylogenyNode[ 1 ];
            nodes[ 0 ] = copyNodeData();
        }
        else {
            while ( !first.isExternal() ) {
                first = first.getChildNode1();
            }

            while ( !last.isExternal() ) {
                last = last.getChildNode2();
            }

            node = first;

            do {
                node = node.getNextExternalNode();
                i++;
            }
            while ( node != last );

            nodes = new PhylogenyNode[ i ];
            node = first;

            for ( i = 0; i < nodes.length; i++ ) {
                nodes[ i ] = node.copyNodeData();
                node = node.getNextExternalNode();
            }
        }

        return nodes;
    } // copyAllExtChildren()

    // ---------------------------------------------------------
    // Writing of Nodes to Strings
    // ---------------------------------------------------------

    public String toNewHampshire( boolean simple_nh ) {
        StringBuffer sb = new StringBuffer( 40 );
        if ( getSeqName().length() > 0 ) {
            if ( simple_nh ) {
                String tmp = getSeqName();
                if ( tmp.length() > 10 ) {
                    tmp = tmp.substring( 0, 11 );
                }
                if ( tmp.indexOf( '/' ) > 0 ) {
                    tmp = tmp.substring( 0, tmp.indexOf( '/' ) );
                }
                sb.append( tmp );
            }
            else {
                sb.append( getSeqName() );
            }
        }
        if ( getDistanceToParent() != DISTANCE_DEFAULT ) {
            sb.append( ":" );
            sb.append( getDistanceToParent() );
        }
        return sb.toString();
    }

    /**
     * Converts this PhylogenyNode to a New Hampshire X (NHX) String
     * representation.
     */
    public String toNewHampshireX() {
        StringBuffer s = new StringBuffer( 200 );
        StringBuffer s_nhx = new StringBuffer( 200 );

        if ( !getSeqName().equals( "" ) ) {
            s.append( getSeqName() );
        }

        if ( getDistanceToParent() != DISTANCE_DEFAULT ) {
            s.append( ":" );
            s.append( getDistanceToParent() );
        }

        if ( !getTaxonomy().equals( "" ) ) {
            s_nhx.append( ":S=" );
            s_nhx.append( getTaxonomy() );
        }

        if ( !getTaxonomyID().equals( "" ) ) {
            s_nhx.append( ":T=" );
            s_nhx.append( getTaxonomyID() );
        }

        if ( !getECnumber().equals( "" ) ) {
            s_nhx.append( ":E=" );
            s_nhx.append( getECnumber() );
        }
//        if ( !getGNnumber().equals( "" ) ) {
//            s_nhx.append( ":GN=" );
//            s_nhx.append( getGNnumber() );
//        }
//
//        if ( !getLSnumber().equals( "" ) ) {
//            s_nhx.append( ":LS=" );
//            s_nhx.append( getLSnumber() );
//        }
//        //Start Renata's modification
//        if ( getNumberOfGains() != GAIN_DEFAULT ) {
//            s_nhx.append( ":GN=" );
//            s_nhx.append( getNumberOfGains() );
//        }           
//        
//        if ( getNumberOfLosses() != LOSS_DEFAULT ) {
//            s_nhx.append( ":LS=" );
//            s_nhx.append( getNumberOfLosses() );
//        }
//        //end Renata's modification
        
        if ( !isExternal() ) {
            if ( isDuplicationOrSpecAssigned() ) {
                if ( isDuplication() ) {
                    s_nhx.append( ":D=Y" );
                }
                else {
                    s_nhx.append( ":D=N" );
                }
            }

            if ( getBootstrap() != BOOTSTRAP_DEFAULT ) {
                s_nhx.append( ":B=" );
                s_nhx.append( getBootstrap() );
            }
//            //Start Renata's modification
//            if ( getNumberOfGains() != GAIN_DEFAULT ) {
//                s_nhx.append( ":GN=" );
//                s_nhx.append( getNumberOfGains() );
//            }
//            
//             if ( getNumberOfLosses() != LOSS_DEFAULT ) {
//                s_nhx.append( ":LS=" );
//                s_nhx.append( getNumberOfLosses() );
//            }
//            //end Renata's modification

            if ( isCollapse() ) {
                s_nhx.append( ":Co=Y" );
            }
        }
        else {
            if ( getOrthologous() != ORTHOLOGOUS_DEFAULT ) {
                s_nhx.append( ":O=" );
                s_nhx.append( getOrthologous() );
            }

            if ( getSuperOrthologous() != ORTHOLOGOUS_DEFAULT ) {
                s_nhx.append( ":SO=" );
                s_nhx.append( getSuperOrthologous() );
            }

            if ( getSubtreeNeighborings() != ORTHOLOGOUS_DEFAULT ) {
                s_nhx.append( ":SN=" );
                s_nhx.append( getSubtreeNeighborings() );
            }
        }

        if ( getParentBranchWidth() != PARENT_BRANCH_WIDTH_DEFAULT ) {
            s_nhx.append( ":W=" );
            s_nhx.append( getParentBranchWidth() );
        }

        if ( getColor() != PARENT_BRANCH_COLOR_DEFAULT ) {
            Color c = getColor();
            s_nhx.append( ":C=" );
            s_nhx.append( c.getRed() );
            s_nhx.append( "." );
            s_nhx.append( c.getGreen() );
            s_nhx.append( "." );
            s_nhx.append( c.getBlue() );
        }

        if ( getNodeCustomTagValueUnits() != null ) {
            TagValueUnit[] a = getNodeCustomTagValueUnitsAsArray();

            for ( int i = 0; i < a.length; ++i ) {
                s_nhx.append( a[ i ].toNHX( true ) );
            }
        }

        if ( getParentBranchCustomTagValueUnits() != null ) {
            TagValueUnit[] a = getParentBranchCustomTagValueUnitsAsArray();

            for ( int i = 0; i < a.length; ++i ) {
                s_nhx.append( a[ i ].toNHX( false ) );
            }
        }

        if ( s_nhx.length() > 0 ) {
            s.append( "[&&NHX" );
            s.append( s_nhx );
            s.append( "]" );
        }

        return s.toString();
    } // toNewHampshireX()

    /**
     * Converts this PhylogenyNode to a String, which looks "pretty" when
     * printed to the console.
     */
    public String toString() {
        String s = "";

        if ( !isPseudoNode() ) {
            s = "\nSeq name                : " + getSeqName();
        }
        else {
            s = "\nSeq name                :  *pseudo node*";
        }

        s += ( "\nEC number               : " + getECnumber() );
        s += ( "\nSpecies                 : " + getTaxonomy() );
//        s += ( "\nGN number               : " + getGNnumber() );
//        s += ( "\nLS number               : " + getLSnumber() );

        if ( !getTaxonomyID().equals( "" ) ) {
            s += ( "\nTaxonomy ID             : " + getTaxonomyID() );
        }
        else {
            s += "\nTaxonomy ID             : n/a";
        }

        if ( !isPseudoNode() && ( getDistanceToParent() != DISTANCE_DEFAULT ) ) {
            s += ( "\nDistance to _parent      : " + getDistanceToParent() );
        }
        else {
            s += "\nDistance to _parent      : n/a";
        }

        if ( getBootstrap() != BOOTSTRAP_DEFAULT ) {
            s += ( "\nBootstrap value         : " + getBootstrap() );
        }
        else {
            s += "\nBootstrap value         : n/a";
        }

//        //Start Renata's modification
//        if ( getNumberOfGains() != GAIN_DEFAULT ) {
//            s += ( "\nNumber of Gains         : " + getNumberOfGains() );
//        }
//        else {
//            s += "\nNumber of Gains         : n/a";
//        }
//        
//        if ( getNumberOfLosses() != LOSS_DEFAULT ) {
//            s += ( "\nNumber of Losses         : " + getNumberOfLosses() );
//        }
//        else {
//            s += "\nNumber of Losses         : n/a";
//        }
//        //end Renata's modification
        
        if ( isDuplicationOrSpecAssigned() ) {
            s += ( "\nDuplication             : " + isDuplication() );
        }
        else {
            s += "\nDuplication             : n/a";
        }

        if ( getParentBranchWidth() != PARENT_BRANCH_WIDTH_DEFAULT ) {
            s += ( "\nParent branch width     : " + getParentBranchWidth() );
        }
        else {
            s += "\nParent branch width     : n/a";
        }

        if ( getColor() != PARENT_BRANCH_COLOR_DEFAULT ) {
            Color c = getColor();
            s += ( "\nParent branch color     : " + c.getRed() + "."
                    + c.getGreen() + "." + c.getBlue() );
        }
        else {
            s += "\nParent branch color     : n/a";
        }

        if ( isExternal() ) {
            if ( getOrthologous() != ORTHOLOGOUS_DEFAULT ) {
                s += ( "\nOrthologous             : " + getOrthologous() );
            }

            if ( getSuperOrthologous() != ORTHOLOGOUS_DEFAULT ) {
                s += ( "\nSuper _orthologous       : " + getSuperOrthologous() );
            }

            if ( getSubtreeNeighborings() != ORTHOLOGOUS_DEFAULT ) {
                s += ( "\nSubtree-neighborings    : " + getSubtreeNeighborings() );
            }
        }

        s += ( "\nSum of ext nodes	: " + getSumExtNodes() );
        s += ( "\nID                      : " + getID() );

        if ( !isRoot() ) {
            s += ( "\nID of _parent            : " + getParent().getID() );
        }
        else {
            s += "\nID of _parent            : n/a (root or pseudo root)";
        }

        if ( isInternal() ) {
            for ( int i = 0; i < getNumberOfChildNodes(); ++i ) {
                s += ( "\nID of child " + i + "           : " + getChildNode( i )
                        .getID() );
            }
        }
        else {
            s += "\nID of child             : n/a (external node)";
        }

        TagValueUnit[] tvu = getCustomTagValueUnitsAsArray();

        if ( tvu.length > 0 ) {
            for ( int i = 0; i < tvu.length; ++i ) {
                s += ( "\nCustom Tag/Value/Unit #" + i + "\n" );
                s += tvu[ i ];
            }
        }

        return s;
    } // toString()

    // should go into Phylogeny Helper
    // <~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ and use
    // for toNHX etc...
    boolean isEmpty( final String s ) {
        return ( ( s == null ) || ( s.length() < 1 ) );
    }

    /**
     * Converts this PhylogenyNode to a XML representation. TODO: should not be
     * in this class.
     */
    public String toXML() {
        if ( isPseudoNode() ) {
            return null;
        }

        StringBuffer sb = new StringBuffer();

        if ( !isEmpty( getSeqName() ) ) {
            sb.append( PhyloXMLmapping.SEQUENCE_NAME_OPEN );
            sb.append( getSeqName() );
            sb.append( PhyloXMLmapping.SEQUENCE_NAME_CLOSE );
        }

        if ( getDistanceToParent() != DISTANCE_DEFAULT ) {
            sb.append( PhyloXMLmapping.DISTANCE_OPEN );
            sb.append( getDistanceToParent() );
            sb.append( PhyloXMLmapping.DISTANCE_CLOSE );
        }

        if ( !isEmpty( getTaxonomy() ) ) {
            sb.append( PhyloXMLmapping.TAXONOMY_OPEN );
            sb.append( getTaxonomy() );
            sb.append( PhyloXMLmapping.TAXONOMY_CLOSE );
        }

        if ( !isEmpty( getTaxonomyID() ) ) {
            sb.append( PhyloXMLmapping.TAXONOMY_ID_OPEN );
            sb.append( getTaxonomyID() );
            sb.append( PhyloXMLmapping.TAXONOMY_ID_CLOSE );
        }

        if ( !isEmpty( getECnumber() ) ) {
            sb.append( "<_ec_number>" );
            sb.append( getECnumber() );
            sb.append( "</_ec_number>" );
        }
//        if ( !isEmpty( getGNnumber() ) ) {
//            sb.append( "<_gain>" );
//            sb.append( getGNnumber() );
//            sb.append( "</_gain>" );
//        }
//        if ( !isEmpty( getLSnumber() ) ) {
//            sb.append( "<_loss>" );
//            sb.append( getLSnumber() );
//            sb.append( "</_loss>" );
//        }
//        // start Renata's modification
//        if ( getNumberOfGains() != GAIN_DEFAULT ) {
//            sb.append( "<_gain>" );
//            sb.append( getNumberOfGains() );
//            sb.append( "</_gain>" );
//        }
//        
//        if ( getNumberOfLosses() != LOSS_DEFAULT ) {
//            sb.append( "<_loss>" );
//            sb.append( getNumberOfLosses() );
//            sb.append( "</_loss>" );
//        }
//        // end Renata's modification
        if ( isInternal() ) {
            if ( getBootstrap() != BOOTSTRAP_DEFAULT ) {
                sb.append( "<" );
                sb.append( PhyloXMLmapping.CONFIDENCE );
                sb.append( " " );
                sb.append( PhyloXMLmapping.CONFIDENCE_ATTRIBUTE_TYPE );
                sb.append( "=\"" );
                sb.append( PhyloXMLmapping.CONFIDENCE_BOOTSTRAP_TYPE );
                sb.append( "\">" );
                sb.append( getBootstrap() );
                sb.append( PhyloXMLmapping.CONFIDENCE_CLOSE );
            }
//           // start Renata's modification
//            if ( getNumberOfGains() != GAIN_DEFAULT ) {
//                sb.append( "<_gain>" );
//                sb.append( getNumberOfGains() );
//                sb.append( "</_gain>" );
//            }
//        
//            if ( getNumberOfLosses() != LOSS_DEFAULT ) {
//                sb.append( "<_loss>" );
//                sb.append( getNumberOfLosses() );
//                sb.append( "</_loss>" );
//            }
//            // end Renata's
            
            
            if ( isDuplicationOrSpecAssigned() ) {
                sb.append( PhyloXMLmapping.DUPLICATION_OPEN );
                if ( isDuplication() ) {
                    sb.append( "true" );
                }
                if ( !isDuplication() ) {
                    sb.append( "false" );
                }
                sb.append( PhyloXMLmapping.DUPLICATION_CLOSE );
            }
        }

        if ( getParentBranchWidth() != PARENT_BRANCH_WIDTH_DEFAULT ) {
            sb.append( "<parent_branch_width>" );
            sb.append( getParentBranchWidth() );
            sb.append( "</parent_branch_width>" );
        }

        if ( getColor() != PARENT_BRANCH_COLOR_DEFAULT ) {
            Color c = getColor();
            sb.append( "<" );
            sb.append( PhyloXMLmapping.COLOR );
            sb.append( " " );
            sb.append( PhyloXMLmapping.COLOR_ATTRIBUTE_TYPE );
            sb.append( "=\"" );
            sb.append( PhyloXMLmapping.COLOR_RGB_TYPE );
            sb.append( "\">" );
            sb.append( PhyloXMLmapping.COLOR_RED_OPEN );
            sb.append( c.getRed() );
            sb.append( PhyloXMLmapping.COLOR_RED_CLOSE );
            sb.append( PhyloXMLmapping.COLOR_GREEN_OPEN );
            sb.append( c.getGreen() );
            sb.append( PhyloXMLmapping.COLOR_GREEN_CLOSE );
            sb.append( PhyloXMLmapping.COLOR_BLUE_OPEN );
            sb.append( c.getBlue() );
            sb.append( PhyloXMLmapping.COLOR_BLUE_CLOSE );
            sb.append( PhyloXMLmapping.COLOR_CLOSE );
        }

        if ( isExternal() ) {
            if ( getOrthologous() != ORTHOLOGOUS_DEFAULT ) {
                sb.append( "<orthologous_to_query_count>" );
                sb.append( getOrthologous() );
                sb.append( "</orthologous_to_query_count>" );
            }

            if ( getSuperOrthologous() != ORTHOLOGOUS_DEFAULT ) {
                sb.append( "<superorthologous_to_query_count>" );
                sb.append( getSuperOrthologous() );
                sb.append( "</superorthologous_to_query_count>" );
            }

            if ( getSubtreeNeighborings() != ORTHOLOGOUS_DEFAULT ) {
                sb.append( "<subtreeneighborings_to_query_count>" );
                sb.append( getSubtreeNeighborings() );
                sb.append( "</subtreeneighborings_to_query_count>" );
            }
        }

        if ( getNodeCustomTagValueUnits() != null ) {
            TagValueUnit[] a = getNodeCustomTagValueUnitsAsArray();

            for ( int i = 0; i < a.length; ++i ) {
                sb.append( a[ i ].toXML( true, false, false ) );
            }
        }

        if ( getParentBranchCustomTagValueUnits() != null ) {
            TagValueUnit[] a = getParentBranchCustomTagValueUnitsAsArray();

            for ( int i = 0; i < a.length; ++i ) {
                sb.append( a[ i ].toXML( false, true, false ) );
            }
        }

        return sb.toString();
    } // toXML()

    // ---------------------------------------------------------
    // Comparison
    // ---------------------------------------------------------

    /**
     * Compares this PhylogenyNode with PhylogenyNode node. Nodes are considered
     * equal if their sequence name, _taxonomy name, taxonomy ID, and EC number
     * are exactly the same. Case sensitive.
     * 
     * @return true if equal, false otherwise
     */
    public boolean equals( PhylogenyNode node ) {
        return ( ( node != null ) && getSeqName().equals( node.getSeqName() )
                && getTaxonomy().equals( node.getTaxonomy() )
                && getECnumber().equals( node.getECnumber() ) && ( getTaxonomyID()
                .equals( node.getTaxonomyID() ) ));// && getGNnumber().equals( node.getGNnumber() ) && getLSnumber().equals( node.getLSnumber() ) );
    } // equals( PhylogenyNode )

    /**
     * sould go into helper
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ < < < < <
     * Returns true if PhylogenyNode arrays nodes1 and nodes2 are equal, false
     * otherwise. Uses sequence names, _taxonomy names, taxonomy IDs, and EC
     * numbers for comparison.
     */
    public static boolean compareArraysOfNodes( PhylogenyNode[] nodes1,
            PhylogenyNode[] nodes2 ) {
        int i = 0;
        int j = 0;
        PhylogenyNode[] n2 = null;

        if ( nodes1.length != nodes2.length ) {
            return false;
        }

        // copy nodes2 since it will be destroyed:
        n2 = new PhylogenyNode[ nodes2.length ];

        for ( i = 0; i < nodes2.length; i++ ) {
            n2[ i ] = nodes2[ i ].copyNodeData();
        }

        I: for ( i = 0; i < nodes1.length; i++ ) {
            for ( j = 0; j < n2.length; j++ ) {
                if ( nodes1[ i ].equals( nodes2[ j ] ) ) {
                    n2[ j ] = null;

                    continue I;
                }
            }

            return false;
        }

        return true;
    } // compareArraysOfNodes( PhylogenyNode[], PhylogenyNode[] )

    // ---------------------------------------------------------
    // Basic printing
    // ---------------------------------------------------------

    /**
     * Prints to the console the subtree originating from this PhylogenyNode in
     * preorder.
     */
    public void preorderPrint() {
        System.out.println( this + "\n" );

        if ( isInternal() ) {
            for ( int i = 0; i < getNumberOfChildNodes(); ++i ) {
                getChildNode( i ).preorderPrint();
            }
        }
    } // preorderPrint()

    // --------------------------------------------------------------------
    // Adjust methods (related to Phylogeny construcation and
    // Phylogeny modification)
    // --------------------------------------------------------------------

    /**
     * Sets the indicators of all the children of this PhylogenyNode to zero.
     */
    void setIndicatorsToZero() {
        Stack stack = new Stack();
        PhylogenyNode n = this;

        stack.push( n );

        while ( !stack.empty() ) {
            n = ( PhylogenyNode ) stack.pop();
            n.setIndicator( 0 );

            if ( !n.isExternal() ) {
                stack.push( n.getChildNode1() );
            }

            if ( !n.isExternal() ) {
                stack.push( n.getChildNode2() );
            }
        }
    } // setIndicatorsToZero()

    /**
     * Resets the parents of all Nodes of the subtree originating from this
     * PhylogenyNode, given that child1 and child2 are correctly set.
     */
    void setParents() {
        PhylogenyNode start = this;
        PhylogenyNode node = this;
        PhylogenyNode prev = null;
        boolean done = false;

        if ( isExternal() ) {
            return;
        }

        start.setIndicatorsToZero();

        while ( !done ) {
            if ( ( node == start ) && ( start.getIndicator() == 2 ) ) {
                done = true;
            }
            else if ( ( node.getIndicator() == 0 ) && !node.isExternal() ) {
                node.setParent( prev );
                prev = node;
                node.setIndicator( 1 );
                node = node.getChildNode1();
            }
            else if ( ( node.getIndicator() == 1 ) && !node.isExternal() ) {
                prev = node;
                node.setIndicator( 2 );
                node = node.getChildNode2();
            }
            else if ( ( node.getIndicator() == 2 ) && !node.isExternal() ) {
                node = node.getParent();
            }
            else if ( node.isExternal() ) {
                node.setParent( prev );
                node = prev;
            }
        }
    } // setParents()

    /**
     * Returns the root PhylogenyNode of the tree of which this PhylogenyNode is
     * member.
     */
    public PhylogenyNode getRoot() {
        PhylogenyNode node = this;

        while ( !node.isRoot() ) {
            node = node.getParent();
        }

        return node;
    } // getRoot()

    /**
     * @return Returns the possible_duplication.
     */
    public boolean isPossibleDuplication() {
        return _possible_duplication;
    }

    /**
     * @param possible_duplication
     *            The possible_duplication to set.
     */
    public void setPossibleDuplication( boolean possible_duplication ) {
        _possible_duplication = possible_duplication;
        setDuplicationOrSpecAssigned( true );
    }

    // ---------------------------------------------------------
    // Iterator
    // ---------------------------------------------------------

    public PhylogenyNodeIterator iterateChildNodesForward() {
        return new ChildNodeIteratorForward( this );
    }

    /**
     * Parses String s in the format r.g.b (e.g. "12.34.234" ) into red, green,
     * and blue and returns the corresponding Color.
     * <p>
     * (Last modified: 12/20/03)
     */
    public static Color stringToColor( final String s ) {

        StringTokenizer st = new StringTokenizer( s, "." );
        if ( st.countTokens() != 3 ) {
            throw new IllegalArgumentException(
                    "Argument to stringToColor must contain three \".\"." );
        }
        int red = limitRangeForColor( Integer.parseInt( st.nextToken() ) );
        int green = limitRangeForColor( Integer.parseInt( st.nextToken() ) );
        int blu = limitRangeForColor( Integer.parseInt( st.nextToken() ) );
        return new Color( red, green, blu );

    }

    /**
     * Helper for method "stringToColor".
     * <p>
     * (Last modified: 12/20/03)
     */
    private static int limitRangeForColor( int i ) {
        if ( i > 255 ) {
            i = 255;
        }
        else if ( i < 0 ) {
            i = 0;
        }
        return i;
    }

    public ArrayList getConnectedEdges() {
        return _connected_edges;
    }

    public void setConnectedEdges( ArrayList connected_edges ) {
        _connected_edges = connected_edges;
    }
} // End of class PhylogenyNode.
