/*
 * Petar - minor corrections (2016)
 */

package erst.forester.java.src.org.forester.atv;

//import java.io.*; Never used (Petar).
import java.awt.*;
import java.util.*;
import javax.swing.*;

import erst.forester.java.src.org.forester.phylogeny.*;

import java.awt.event.*;

/**
 * @author christian TODO To change the template for this generated type comment
 *         go to Window - Preferences - Java - Code Style - Code Templates
 */

public abstract class ATVframe extends JFrame implements ActionListener {

    // The original tree
    protected Phylogeny     reload_tree_  = null;
    // 
    protected Phylogeny     species_tree_ = null;
    
    // Menubar
    protected JMenuBar      jmenubar;
    protected  JMenu        file_jmenu, edit_jmenu, 
                             view_jmenu, options_jmenu, help_jmenu; //SDI_jmenu, genomics_jmenu,
    protected  JMenuItem    // file menu
                            open_item, open_url_item, save_item,
                            saveas_item, close_item, reload_item,
                            // edit menu
//                            remove_root_item, remove_root_tri_item, 
                            find_item, find_reset_item, highlight_item, 
//                            selectall_item,
//                            edit_selection_item,
                            // options menu
                            tiny_fonts_item,
                            small_fonts_item, medium_fonts_item, 
                            large_fonts_item, 
                            // switch_colors_item, We will not switch colours.  (Petar)
//                            preferences_item,
                            // view as text menu
//                            view_as_NH_item, view_as_NHX_item,
//                            view_as_XML_item, 
                            // help menu
                            about_item, help_item, hide_show_item; //,
//                            // SDI menu
//                            load_species_tree_item,
//                            infer_dups_item, root_min_dups_height_item, 
//                            root_min_L_height_item, root_min_height_item;
    
    // Handy pointers to child components:
    protected  ATVpanel     atvpanel;
    protected  Container    contentpane;
    protected  ATVtextframe atvtextframe;
    
/*
    protected  JSlider      x_slider, y_slider;
    protected  final static int
                                SLIDER_MIN  = 0, 
                                SLIDER_MAX = 200,
                                SLIDER_VAL = 100, 
                                SLIDER_MAJS = 50, 
                                SLIDER_MINS = 10;
 */   
    protected  JLabel       xs_label, ys_label;
 
    /* Choose a little bigger font. (Petar)
    protected  final static Font      menu_font     = new Font( "Helvetica",
                                                                Font.PLAIN,
                                                                10 );
    */
    protected  final static Font      menu_font     = new Font( "Helvetica",
            Font.PLAIN,
            12 );
    
    protected String        config_filename;
    ATVConfig               config_settings;
    
    
    /**
     * Constructor
     */
    public ATVframe( ) { }
    
     
    /**
     * Display the about box.
     */
    protected void about() {
        String about = "ATV (A Phylogeny Viewer)\nVersion 3.00 BETA\n";
        about += "Copyright (C) 1999-2005 Washington University School of Medicine\n";
        about += "and Howard Hughes Medical Institute\n";
        about += "All Rights Reserved\n";
        about += "Authors: Christian M. Zmasek, Ethy Cannon\n";
        about += "Last modified: 11/7/05\n";
        about += "Reference: Zmasek C.M. and Eddy S.R. Bioinformatics, 17, 383 (2001)\n";
        about += "For more information & download:\n";
        about += "http://www.phylogenomics.us/atv/\n";
        about += "Comments: cmzmasek@yahoo.com";

        JOptionPane.showMessageDialog( this,
                                       about,
                                       "ATV Applet (Java 1.4 or greater)",
                                       JOptionPane.PLAIN_MESSAGE );
    }//about
    

    /**
    * Action performed.
    */
    public void actionPerformed( ActionEvent e ) {
    
      Object o = e.getSource();
      
      if ( o == reload_item ) {
          reLoad();
      }
      else if ( o == open_url_item ) {
          openURL();
      }
      else if ( o == close_item ) {
          close();
      }
//      else if ( o == remove_root_item ) {
//          removeRoot();
//      }
//      else if ( o == remove_root_tri_item ) {
//          removeRootTri();
//      }
      /* We will not switch colours.  (Petar)
      else if ( o == switch_colors_item ) {
          switchColors();
      }
      */
// Not sure how best to handle preferences, wait
//      else if ( o == preferences_item ) {
//          preferences();
//      }
//        else if ( o == view_as_NH_item ) {
//            viewAsNH();
//        }
//        else if ( o == view_as_NHX_item ) {
//            viewAsNHX();
//        }
//        else if ( o == view_as_XML_item ) {
//            viewAsXML();
//        }
        else if ( o == tiny_fonts_item ) {
            atvpanel.getATVtreePanel().setTinyFonts();
            atvpanel.getATVtreePanel().repaint();
        }
        else if ( o == small_fonts_item ) {
            atvpanel.getATVtreePanel().setSmallFonts();
            atvpanel.getATVtreePanel().repaint();
        }
        else if ( o == medium_fonts_item ) {
            atvpanel.getATVtreePanel().setMediumFonts();
            atvpanel.getATVtreePanel().repaint();
        }
        else if ( o == large_fonts_item ) {
            atvpanel.getATVtreePanel().setLargeFonts();
            atvpanel.getATVtreePanel().repaint();
        }
        else if ( o == about_item ) {
                about();
        }
        else if ( o == help_item ) {
            help();
        }
        else if ( o == hide_show_item ) {
            hideShowItemHelp();
        } else if ( o == find_item ) {
            find();
        }
        else if ( o == highlight_item) {
            highlightSequences();
        }
        else if ( o == find_reset_item ) {
            findReset();
        }
//remove until implemented in phylogeny
//        else if ( o == selectall_item ) {
//            selectAll();
//        }
//not sure if this should be a menu item???
//        else if ( o == edit_selection_item ) {
//            editSelection();
//        }
        contentpane.repaint();
    }//actionPerformed
    

    /**
     * 
     */
    protected void buildEditMenu() {
       // edit_jmenu = createMenu( "Edit" );
         edit_jmenu = createMenu( "Search" );
//        edit_jmenu.add( remove_root_item = 
//                       new JMenuItem( "Remove root" ) );
//        edit_jmenu.add( remove_root_tri_item = 
//                       new JMenuItem( "Remove root and trifurcate" ) );
//        edit_jmenu.addSeparator();
        edit_jmenu.add( find_item = 
                       new JMenuItem( "Search..." ) );
        edit_jmenu.add( highlight_item = 
                       new JMenuItem( "Select Sequences..." ) );
//        edit_jmenu.add( selectall_item =
//                       new JMenuItem( "Select All" ) );
        edit_jmenu.add( find_reset_item = 
                       new JMenuItem( "Unselect All" ) );
//        edit_jmenu.addSeparator();
//        edit_jmenu.add( edit_selection_item = 
//                       new JMenuItem( "Edit Selection" ) );
        
//        customizeJMenuItem( remove_root_item );
//        customizeJMenuItem( remove_root_tri_item );
        customizeJMenuItem( find_item );
        customizeJMenuItem( highlight_item );
//        customizeJMenuItem( selectall_item );
        customizeJMenuItem( find_reset_item );
//        customizeJMenuItem( edit_selection_item );
        jmenubar.add( edit_jmenu );
    }//buildEditMenu
    
        
    /**
     * 
     */
    protected void buildFileMenu() {
        file_jmenu = createMenu( "File" );
        file_jmenu.add( reload_item = new JMenuItem( "Reload" ) );
        file_jmenu.addSeparator();
        file_jmenu.add( open_url_item = 
                       new JMenuItem( "Open tree URL..." ) );
        file_jmenu.addSeparator();
        file_jmenu.add( close_item = new JMenuItem( "Close" ) );
        
        customizeJMenuItem( reload_item );
        customizeJMenuItem( open_url_item );
        customizeJMenuItem( close_item );
        jmenubar.add( file_jmenu );
    }//buildFileMenu
    

    /**
    * 
    */
    protected void buildHelpMenu() {
        help_jmenu = createMenu( "Help" );
        help_jmenu.add( help_item = new JMenuItem( "Help" ) );
        help_jmenu.add( hide_show_item = new JMenuItem( "Hide item help" ) );
        help_jmenu.addSeparator();
        help_jmenu.add( about_item = new JMenuItem( "About" ) );
        
        customizeJMenuItem( help_item );
        customizeJMenuItem( hide_show_item );
        customizeJMenuItem( about_item );
        jmenubar.add( help_jmenu );
    }//buildHelpMenu
    
        
    /**
     * 
     */
    protected void buildOptionsMenu() {
        options_jmenu = new JMenu( "Display Options" );
        options_jmenu.setFont( menu_font );
        options_jmenu.setBackground( ATVconstants.MENU_BACKGROUND_COLOR_DEFAULT );
        options_jmenu.setForeground( ATVconstants.MENU_TEXT_COLOR_DEFAULT );
        
        //options_jmenu.add( switch_colors_item = new JMenuItem( "Switch colors..." ) ); We will not switch colours.  (Petar)
        options_jmenu.addSeparator();
        options_jmenu.add( tiny_fonts_item = new JMenuItem( "Tiny fonts" ) );
        options_jmenu.add( small_fonts_item = new JMenuItem( "Small fonts" ) );
        options_jmenu.add( medium_fonts_item = new JMenuItem( "Medium fonts" ) );
        options_jmenu.add( large_fonts_item = new JMenuItem( "Large fonts" ) );
        options_jmenu.addSeparator();
// Not sure how best to handle preferences, wait
//        options_jmenu.add( preferences_item = new JMenuItem( "Preferences..." ) );
        
        //customizeJMenuItem( switch_colors_item ); We will not switch colours.  (Petar)
        customizeJMenuItem( tiny_fonts_item );
        customizeJMenuItem( small_fonts_item );
        customizeJMenuItem( medium_fonts_item );
        customizeJMenuItem( large_fonts_item );
// Not sure how best to handle preferences, wait
//        customizeJMenuItem( preferences_item );
        jmenubar.add( options_jmenu );
    }//buildOptionsMenu
    
        
    /**
     * 
     */
//    protected void buildViewMenu() {
//        view_jmenu = createMenu( "View as Text" );
//        view_jmenu.add( view_as_XML_item = new JMenuItem( "View as PhyloXML..." ) );
//        view_jmenu.add( view_as_NH_item = new JMenuItem( "View as NH..." ) );
//        view_jmenu.add( view_as_NHX_item = new JMenuItem( "View as NHX..." ) );
//        
//        customizeJMenuItem( view_as_NH_item );
//        customizeJMenuItem( view_as_NHX_item );
//        customizeJMenuItem( view_as_XML_item );
//        jmenubar.add( view_jmenu );
//    }//buildViewMenu
    

    /**
     * 
     */
    protected void close() {
        removeatvtextframe();
        atvpanel.terminate();
        contentpane.removeAll();
        setVisible( false );
        dispose();
    }//close
    
    
    /**
     * 
     */
    protected JMenu createMenu( String title ) {
        JMenu jmenu = new JMenu( title );
        jmenu.setFont( menu_font );
        jmenu.setBackground( ATVconstants.MENU_BACKGROUND_COLOR_DEFAULT );
        jmenu.setForeground( ATVconstants.MENU_TEXT_COLOR_DEFAULT );
        return jmenu;
    }//createMenu
    
        
    /**
     * Sets font, background, and foreground, adds ActionListener
     * to a JMenuItem:
     */
    protected void customizeJMenuItem( JMenuItem jmi ) {
        jmi.setFont( menu_font );
        jmi.setBackground( ATVconstants.MENU_BACKGROUND_COLOR_DEFAULT );
        jmi.setForeground( ATVconstants.MENU_TEXT_COLOR_DEFAULT );
        jmi.addActionListener( this );
    }//customizeJMenuItem
    

    // A customized implementation of ATV should
    // override these methods.
    public void customOption( PhylogenyNode node ) {
    }
    public void customOption( Hashtable node_hash ) {
    }
    
    
/*not sure if this should be a menu option
    protected void editSelection() {
        if (atvpanel != null && atvpanel.getATVtreePanel() != null) {
          ATVeditNodeFrame aenf = 
              new ATVeditNodeFrame( atvpanel.getATVtreePanel().getFoundNodes(),
                                    display_options, atvpanel.getATVtreePanel() );
        }
    }
*/

    /**
     * 
     */
    protected void exceptionOccuredDuringOpenFile( Exception e ) {
        JOptionPane.showMessageDialog( this,
                                       "Exception: " + e,
                                       "Error during File|Open",
                                       JOptionPane.ERROR_MESSAGE );
    }//exceptionOccuredDuringOpenFile
    

    /**
     * 
     */
    protected void exceptionOccuredDuringSaveAs( Exception e ) {
        JOptionPane.showMessageDialog( this,
                                       "Exception" + e,
                                       "Error during File|SaveAs",
                                       JOptionPane.ERROR_MESSAGE );
    }//exceptionOccuredDuringSaveAs
    

    /**
     * (Last modified: 07/30/01)
     */
    protected void find() {
        if ( atvpanel.getATVtreePanel().getTree() == null
                || atvpanel.getATVtreePanel().getTree().isEmpty() ) {
            return;
        }
        //    ~~~~~~~~~~~~~~~~~~~~~search custom data
        // TODO: <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<~~~~~~~~~~~~~~~~~~~~~~~~~<<<<<<<<<<<<,
        String message = "String to search for in sequence and species' names,\nEC numbers; or integer for taxonomy IDs:";
        
        String query = JOptionPane
        .showInputDialog( this,
                          message,
                          "Search",
                          JOptionPane.QUESTION_MESSAGE );
        
        if ( query != null ) {
        
            query = query.trim();
            
            if ( !query.equals( "" ) ) {
                Hashtable nodes = null;
                try {
                    nodes = atvpanel.getATVtreePanel().getTree().findInNameSpecECid( query );
                }
                catch ( Exception e ) {
                    System.err.println( "Unexpected exception: " + e );
                }
                if ( nodes != null && nodes.size() > 0 ) {
                    atvpanel.getATVtreePanel().setFoundNodes( nodes );
                }
                else {
                    JOptionPane.showMessageDialog( this,
                                                   "Could not find \"" + query
                                                   + "\"",
                                                   "Search",
                                                   JOptionPane.ERROR_MESSAGE );
                }
            }
        }
        contentpane.repaint();
        
    } // find()
    

    /**
     * (Last modified: 07/30/01)
     */
    protected void findReset() {
        if ( atvpanel.getATVtreePanel().getTree() == null
                || atvpanel.getATVtreePanel().getTree().isEmpty() ) {
            return;
        }
        atvpanel.getATVtreePanel().setFoundNodes( null );
        contentpane.repaint();
    } // findReset()

    /**
     * Last modifed 05/26/01
     */
//    protected boolean GAndSDoHaveMoreThanOneSpeciesInComman( Phylogeny gene_tree ) {
//        if ( gene_tree == null || gene_tree.isEmpty() ) {
//            JOptionPane
//                    .showMessageDialog( this,
//                                        "Gene tree and species tree have no species in common.",
//                                        "Error during SDI",
//                                        JOptionPane.ERROR_MESSAGE );
//            return false;
//        }
//        else if ( gene_tree.getNumberOfExternalNodes() < 2 ) {
//            JOptionPane
//                    .showMessageDialog( this,
//                                        "Gene tree and species tree have only one species in common.",
//                                        "Error during SDI",
//                                        JOptionPane.ERROR_MESSAGE );
//            return false;
//        }
//        else {
//            return true;
//        }
//    }//GAndSDoHaveMoreThanOneSpeciesInComman
    

    protected void help() {
        String help = 
              "Display options\n"
            + "-------------------\n"
            + "Use the checkboxes to select types of information to display on the tree.\n\n"
            + "Clickable Tree nodes\n"
            + "----------\n"
            + "All nodes are active and can be clicked. Select the action by clicking a radio button:\n"
            + "o  display editable info -- display and edit information of a node.\n"
            + "    To edit information, box \"Editable\" needs to be checked.\n"
            + "o  collapse/uncollapse -- collapse and uncollapse subtree from clicked node.\n"
            + "o  root/reroot -- change tree root to clicked node.\n"
            + "o  swap children -- switch children on either side of clicked node.\n"
            + "o  subtree/parent tree -- toggle between subtree from clicked node and whole tree.\n"
            + "o  display sequences -- pop up a list of all sequences in subtree at clicked node.\n"
            + "-  there may be additional choices depending on this particular setup\n\n"
            + "Applet-only click-to options:\n"
            + "o  SWISS-PROT -- go to SWISS-PROT and display its entry for the corresponding sequence.\n"
            + "    Only available in JApplet version.\n"
            + "    Seq names need to be proper SWISS-PROT names for this to work.\n\n"
            + "Right clicking on a node always displays the information of a node.\n\n"
            + "Zooming:\n"
            + "--------\n"
            + "Use the buttons on the control panel to zoom the tree in and out, both horizontally and vertically.\n"
            + "The entire tree can be fitted into the window by clicking the \"show whole\" button.\n\n"
            + "Quick tree manipulation:\n"
            + "------------------------\n"
            + "Order Subtrees -- order the tree by branch length\n"
            + "Uncollapse All -- uncollapse any and all collapsed branches\n"
            + "Collapse to Deepest Annotation Level -- Collapse tree to deepest onnotation level.\n"
            + "Reload tree -- Restore the tree from its file\n\n"
            + "Menus\n"
            + "-----\n"
            + "File/Reload -- Restore tree to original data.\n"
            + "File/Open -- Open a new tree file; not available in applet.\n"
            + "File/Open URL -- Open a new tree from URL.\n"
            + "File/Save, Save As -- Save tree; not available in applet.\n"
            + "File/Print -- prints the tree as displayed; not available in applet.\n\n"
//            + "Edit/Remove root -- remove the root from the tree.\n"
//            + "Edit/Remove root and trifurcurate -- Remove root and put three branches at the lowest level.\n"
            + "Edit/Search -- Find all occurrences of a string in any node.\n"
            + "Edit/Highlight Sequences -- Highlight a set of sequence names.\n"
            + "Edit/Remove Highlighting -- Clear all selected and hightlighted text.\n\n"
//            + "View As Text/XML, NH, NHX -- view tree in its current state in any of three formats.\n"
//            + "   NOTE: some information can't be represented in NH and NHX.\n\n"
            + "Display Options/Switch colors -- choose new colors for the tree.\n"
            + "Display Options/Tiny fonts, Small fonts, Medium fonts, Large fonts -- change font size.\n"
// Not sure how best to handle preferences, wait
//            + "Display Options/Preferences -- set display preferences for ATV.\n\n"
            + "Help/About -- information about ATV.\n"
            + "Help/Help -- this popup.\n\n"
            + "General remarks:\n"
            + "----------------\n"                    
            + "o  ATV can deal with trees with an arbitrary number of \n"
            + "    children per parent (except for SDI).\n"
            + "o  The application version permits copying to the clipboard \n"
            + "    in the \"View\"|\"View as ...\" frame (either by control-c or button press).\n"
            + "o  Changes made to a subtree affect this subtree and its subtrees,\n"
            + "    but not any of its parent tree(s).\n"
            + "o  ATV tries to detect whether the numerical values in a NH tree\n"
            + "    are likely to be bootstrap values instead of branch length values.\n\n"
//            + " Remarks regarding SDI (Speciation Duplication Inference):\n"
//            + "o  Each external node of the gene tree (in display) needs to be associated with\n"
//            + "    a species: either directly through the \"Species\" field, or the species\n"
//            + "    is part of the sequence name in the form \"XXXX_SPECIES\"\n"
//            + "    (e.g. \"ACON_DROME\" or \"ACON_DROME/123-4489\" which is also acceptable).\n"
//            + "o  A species tree for each species of the gene tree needs to be loaded with\n"
//            + "   \"SDI\"|\"Load species tree\" prior the SDI execution.\n"
//            + "o  !External nodes of the gene tree associated with species not present in\n"
//            + "    the species tree are REMOVED prior to SDI execution!\n"
//            + "o  Both the gene tree and the species tree must be completely binary.\n"
//            + "o  Duplications and speciations are a function of the position of the root.\n"
//            + "    Hence, after each manual \"Root/Reroot\"ing some duplications will be\n"
//            + "    incorrect and need to be inferred again\n"
//            + "    with: \"SDI\"|\"SDI (Speciation Duplication Inference)\n\n"
            + "For more information: http://www.phylogenomics.us/atv/\n"
            + "Email: cmzmasek@yahoo.com, ethy@a415software.com\n\n";

        ATVtextframe atf = new ATVtextframe( help );
    }//help


    /**
     * 
     */
    protected void hideShowItemHelp() {
        String s = hide_show_item.getLabel();
        if (s.startsWith("Hide")) {
            atvpanel.getATVcontrol().showItemHelpButtons(false);
            hide_show_item.setLabel("Show item help");
        } else {
            atvpanel.getATVcontrol().showItemHelpButtons(true);
            hide_show_item.setLabel("Hide item help");
        }
    }
    
    
    /**
     * 
     */
    protected void highlightSequences() {
        HighlightSeqFrame hsf = new HighlightSeqFrame(this);
        hsf.show();
        ArrayList namelist = hsf.getSequenceNames();
        if (namelist != null) {
            Hashtable found_nodes = new Hashtable();
            for (int i=0; i<namelist.size(); i++) {
            String seqname = (String)namelist.get(i);
            Hashtable nodes = atvpanel.getATVtreePanel().
            getTree().findInNameSpecECid( seqname );
            if (nodes != null && nodes.keys().hasMoreElements()) {
                PhylogenyNode pn = (PhylogenyNode)(nodes.keys().nextElement());
                found_nodes.put(pn, "");
            }
        }
        atvpanel.atvtreepanel.setFoundNodes(found_nodes);
        contentpane.repaint();
        }
    }//highlightSequences
    
    
    /**
     * 
     */
    public void highlightSequences(Vector seq_list) {
System.out.println("ATVframe.highlightSequences()");
System.out.println("seq_list: "+seq_list+" has "+seq_list.size()+" members");
        Hashtable found_nodes = new Hashtable();
        Phylogeny tree = atvpanel.getATVtreePanel().getTree();
        if (tree != null) {
            if (seq_list != null && tree != null) {
                for (int i=0; i<seq_list.size(); i++) {
                    String seqname = (String)seq_list.get(i);
System.out.println("Found seq name "+seqname);
                    Hashtable nodes = tree.findInNameSpecECid( seqname );
                    if (nodes != null && nodes.keys().hasMoreElements()) {
                        PhylogenyNode pn = (PhylogenyNode)(nodes.keys().nextElement());
System.out.println("Add node to highlight list");
                        found_nodes.put(pn, "");
                    }
                }
System.out.println("Set found nodes: "+found_nodes+" with "+found_nodes.size()+" nodes");
                atvpanel.atvtreepanel.setFoundNodes(found_nodes);
            } else {
System.out.println("Clear list of found nodes");
                atvpanel.atvtreepanel.setFoundNodes(null);
            }
            contentpane.repaint();
        }
System.out.println("All done with ATVframe.highlightSequences()");
    }
    
    
    protected abstract void openURL();
    
    
    protected abstract void reLoad();
    
    
    /**
     * 
     */
    protected void removeatvtextframe() {
        if ( atvtextframe != null ) {
            atvtextframe.close();
            atvtextframe = null;
        }
    }//removeatvtextframe
    

    
    /**
    * Sets the maximal number a sequence is expected to be orthologous towards
    * another, i.e. the number of resampling steps. (Last modified: 12/05/00)
    */
    protected void setMaxOrtho( int m ) {
        atvpanel.getATVtreePanel().setMaxOrtho( m );
    }//setMaxOrtho
    
    
    /**
    * Resizes the Phylogeny, so that it is displayed in its entirety. It is
    * recommended to call this method after the constructor ATVframe(Phylogeny t)
    * has been called.
    * 
    * @see #ATVjframe(Phylogeny)
    */
    public void showWhole() {
        atvpanel.getATVcontrol().showWhole();
    }//showWhole
    
    
    /**
     * 
     */
    protected void switchColors() {
        TreeColorSet colorset = atvpanel.getATVtreePanel().getTreeColorSet();   
        ATVColorSchemeChooser csc = new ATVColorSchemeChooser(this, colorset);
        csc.setVisible(true);
        atvpanel.getATVtreePanel().setTreeColorSet(colorset);
    }//switchColors
    
    
    /**
     * 
     */
    protected void viewAsNH() {
        removeatvtextframe();
        if ( atvpanel.getATVtreePanel().getTree() == null ) {
            return;
        }
        if ( atvpanel.getATVtreePanel().getTree().isEmpty() ) {
            return;
        }
        atvtextframe = new ATVtextframe( atvpanel.getATVtreePanel().getTree()
                            .toNewHampshire( false ) );
    }//viewAsNH
    
    
    /**
     * 
     */
    protected void viewAsNHX() {
        removeatvtextframe();
        if ( atvpanel.getATVtreePanel().getTree() == null ) {
            return;
        }
        if ( atvpanel.getATVtreePanel().getTree().isEmpty() ) {
            return;
        }
        atvtextframe = new ATVtextframe( atvpanel.getATVtreePanel().getTree()
                            .toNewHampshireX() );
    }//viewAsNHX
    
    
    /**
     * 
     */
    protected void viewAsXML() {
        removeatvtextframe();
        if ( atvpanel.getATVtreePanel().getTree() == null ) {
            return;
        }
        if ( atvpanel.getATVtreePanel().getTree().isEmpty() ) {
            return;
        }
        atvtextframe = new ATVtextframe( atvpanel.getATVtreePanel().getTree()
                            .toPhyloXML(0) );
//                            .toXML() );
    }//viewAsXML

} // End of class ATVframe.


