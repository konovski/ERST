package erst.forester.java.src.org.forester.atv;
import java.util.StringTokenizer;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList;

/**
 * Popup box for pasting a set of sequence names to be highlighted
 * on the tree.
 */
public class HighlightSeqFrame extends JDialog
    implements ActionListener
{
    JTextArea   sequencenames;
    JButton     highlightbtn;
    JButton     cancelbtn;
    
    ArrayList   sequencelist;
    
    String instructions = "Type or paste one or more sequence names in the box below:";
    public HighlightSeqFrame(Frame owner) {
        super(owner,
              "Highlight Sequences", 
              true,             // dialog is modal
              owner.getGraphicsConfiguration());
        
        setSize( 360, 320 );
        
        Container cp = getContentPane();
        cp.setLayout(new BorderLayout());
        
        // The instructions
        JTextPane tp = new JTextPane();
        //tp.setFont(new Font("Sans Serif", Font.BOLD, 12)); Change the font size to 14. (Petar)
        tp.setFont(new Font("Sans Serif", Font.BOLD, 14));
        tp.setSize(new Dimension(360, 40));
        tp.setBackground(getBackground());
        tp.setEnabled(false);
        tp.setText(instructions);
        cp.add(tp, "North");
        
        // The list of sequence names
        sequencenames = new JTextArea();
        cp.add(sequencenames, "Center");
        
        // The button panel
        JPanel btn_panel = new JPanel(); 
        
        highlightbtn = new JButton("Select");
        highlightbtn.addActionListener(this);
        btn_panel.add(highlightbtn);
        
        cancelbtn = new JButton("Cancel");
        cancelbtn.addActionListener(this);
        btn_panel.add(cancelbtn);
        
        cp.add(btn_panel, "South");
    }
    
    
    public void actionPerformed( ActionEvent e ) {
        Object o = e.getSource();
        if (o == cancelbtn) {
            sequencelist = null;
            hide();
        } else if (o == highlightbtn) {
            String name_str = sequencenames.getText();
            if (name_str.length() > 0) {
                sequencelist = parseSequenceNames(name_str);
            } else {
                sequencelist = null;
            }
            hide();
        }
    }
    
    public ArrayList getSequenceNames() {
        return sequencelist;
    }
    
    private ArrayList parseSequenceNames(String name_str) {
        ArrayList list = null;
        
        // clean up the string and convert any (reasonable) sort
        //    of delineators into single spaces.
        name_str = name_str.trim();
        name_str = name_str.replaceAll("\\n", " ");
        name_str = name_str.replaceAll("\\t", " ");
        name_str = name_str.replaceAll(",", " ");
        name_str = name_str.replaceAll(":", " ");
        name_str = name_str.replaceAll(";", " ");
        name_str = name_str.replaceAll("\\s+", " ");
        StringTokenizer st = new StringTokenizer(name_str, " ");
        if (st.countTokens() > 0) {
            list = new ArrayList();
            while (st.hasMoreElements()) {
                list.add(st.nextElement());
            }
        }
        
        return list;
    }
    
}
