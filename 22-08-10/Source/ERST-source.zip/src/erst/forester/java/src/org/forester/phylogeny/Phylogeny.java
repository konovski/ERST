// Phylogeny.java
// 
// Copyright (C) 1999-2002 Washington University School of Medicine
// and Howard Hughes Medical Institute
// All rights reserved
//
// Created: 1999
// Author: Christian M. Zmasek
// zmasek@genetics.wustl.edu
// http://www.genetics.wustl.edu/eddy/people/zmasek/
//

package erst.forester.java.src.org.forester.phylogeny;

import java.util.HashMap;
import java.util.NoSuchElementException;
import java.util.Vector;

import erst.forester.java.src.org.forester.io.PhylogenyWriter;
import erst.forester.java.src.org.forester.phylogeny.iterators.ExternalForwardIterator;
import erst.forester.java.src.org.forester.phylogeny.iterators.LevelOrderTreeIterator;
import erst.forester.java.src.org.forester.phylogeny.iterators.PhylogenyNodeIterator;
import erst.forester.java.src.org.forester.phylogeny.iterators.PostorderTreeIterator;
import erst.forester.java.src.org.forester.phylogeny.iterators.PreorderTreeIterator;
import erst.forester.java.src.org.forester.util.Util;

import java.util.Hashtable;
import java.awt.Color;

/**
 * @author Christian M. Zmasek
 * @version 1.930 -- last modified: 01/05/04
 * Modified by Petar in 2008.
 */
public class Phylogeny {

    public static final int MAX_LENGTH = 10;

    // Max length for seq names, when printing out "clean" NH.

    private PhylogenyNode   _root;

    private int             _external_nodes;

    private boolean         _rooted;
    
    private String          _name;
    private String          _description;

    private HashMap         _idhash;

    // ---------------------------------------------------------
    // Constructors
    // ---------------------------------------------------------

    /**
     * Default Phylogeny constructor. Constructs an empty Phylogeny.
     */
    public Phylogeny() {
        delete();
    } // Phylogeny()

    /**
     * Comments from old constructor. Phylogeny constructor which constructs a
     * Phylogeny from String nh_sb. The tree is considered unrooted if the
     * deepest node has more than two children, otherwise it is considered
     * rooted.
     * 
     * @param nh_sb
     *            String in New Hampshire (NH) or New Hampshire X (NHX) format
     */

    // ---------------------------------------------------------
    // Copy and delete Trees
    // ---------------------------------------------------------
    /**
     * Returns a deep copy of this Phylogeny.
     * <p>
     * (The resulting Phylogeny has its references in the external nodes
     * corrected, if they are lacking/ obsolete in this.)
     * <p>
     * (Last modified: 06/11/01)
     */
    public Phylogeny copy() {

        Phylogeny tree = new Phylogeny();

        if ( isEmpty() ) {
            tree.delete();
            return tree;
        }

        tree._rooted = _rooted;
        tree._external_nodes = _external_nodes;
        tree._name = new String( _name );
        tree._description = new String( _description );
        tree._idhash = _idhash;

        tree._root = PhylogenyNode.copyTree( _root );

        tree.getRoot().setParents();

        return tree;

    } // copyTree()

    /**
     * Deletes this Phylogeny.
     */
    public void delete() {
        _root = null;
        // _rooted = false; - Modified by Petar.
        _rooted = true; // An attempt for solving the problem with the 
        				// non-displayed root (Petar).
        _external_nodes = 0;
        _name = "";
        _description = "";
        _idhash = null;

    } // delete()

    /**
     * Returns the subtree of this Phylogeny which has the PhylogenyNode with ID
     * id as its root PhylogenyNode.
     * 
     * @param id
     *            ID (int) of PhylogenyNode
     */
    public Phylogeny subTree( int id ) throws IllegalStateException {

        if ( !isTree() ) {
            throw new IllegalStateException(
                    "Attempt to get sub tree on phylogeny which is not tree-like." );
        }

        Phylogeny tree = null;
        PhylogenyNode node = null;

        if ( isEmpty() ) {
            return null;
        }
        tree = copy();
        node = tree.getNode( id );
        if ( node == null || node.isExternal() ) {
            return null;
        }
        node.setParent( null );
        node.setDistanceToParent( PhylogenyNode.DISTANCE_DEFAULT );
        tree.setRooted( true );
        tree.setRoot( node );
        tree.adjustNodeCount( true );
        return tree;

    } // subTree( int )

    // ---------------------------------------------------------
    // Modification of Phylogeny topology and Phylogeny appearance
    // ---------------------------------------------------------

    /**
     * Removes the root PhylogenyNode of this Phylogeny and makes at least a
     * trifurcation at its basal node.
     */
    public void unRootAndTrifurcate() throws IllegalStateException {

        if ( !isTree() ) {
            throw new IllegalStateException(
                    "Attempt to unroot a phylogeny which is not tree-like." );
        }

        double sum = 0.0;

        if ( isEmpty() ) {
            return;
        }
        unRoot();
        if ( getNumberOfExternalNodes() <= 2 ) {
            return;
        }

        sum = getRoot().getChildNode2().getDistanceToParent()
                + getRoot().getChildNode1().getDistanceToParent();
        if ( getRoot().getChildNode2().isExternal()
                || getRoot().getChildNode2().isCollapse() ) {
            if ( sum >= 0.0 ) {
                getRoot().getChildNode2().setDistanceToParent( sum );
            }
            else {
                getRoot().getChildNode2().setDistanceToParent(
                        PhylogenyNode.DISTANCE_DEFAULT );
            }
            getRoot().getChildNode1().setDistanceToParent(
                    PhylogenyNode.DISTANCE_NULL );
        }
        else {
            if ( sum >= 0.0 ) {
                getRoot().getChildNode1().setDistanceToParent( sum );
            }
            else {
                getRoot().getChildNode1().setDistanceToParent(
                        PhylogenyNode.DISTANCE_DEFAULT );
            }
            getRoot().getChildNode2().setDistanceToParent(
                    PhylogenyNode.DISTANCE_NULL );
        }
        return;

    } // unRootAndTrifurcate()

    /**
     * Removes the root PhylogenyNode this Phylogeny.
     */
    public void unRoot() throws IllegalStateException {

        if ( !isTree() ) {
            throw new IllegalStateException(
                    "Attempt to unroot a phylogeny which is not tree-like." );
        }

        if ( isEmpty() ) {
            return;
        }

        setIndicatorsToZero();
        if ( !isRooted() || getNumberOfExternalNodes() <= 1 ) {
            return;
        }
        setRooted( false );
        return;

    } // unRoot()

    /**
     * Removes external PhylogenyNode n from this Phylogeny. If this tree has
     * only one node, a empty tree will be returned.
     * 
     * @param n
     *            PhylogenyNode to remove
     */
    public void removeExtNode( PhylogenyNode n ) {

        PhylogenyNode removed_node = null, p = null, pp = null;

        if ( isEmpty() ) {
            return;
        }

        // Returns an empty tree.
        if ( getNumberOfExternalNodes() == 1 && n == getFirstExternalNode() ) {
            delete();
            return;
        }

        removed_node = n;

        //        if ( removed_node == getFirstExternalNode() ) {
        //            setFirstExternalNode( removed_node.getNextExternalNode() );
        //            removed_node.getNextExternalNode().setPrevExtNode( null );
        //        }
        //        else if ( removed_node.getNextExternalNode() == null ) {
        //            removed_node.getPreviousExternalNode(). null );
        //        }

        p = removed_node.getParent();

        if ( p.isRoot() ) {
            if ( removed_node.isFirstChildNode() ) {
                setRoot( getRoot().getChildNode2() );
                getRoot().setParent( null );
            }
            else {
                setRoot( getRoot().getChildNode1() );
                getRoot().setParent( null );
            }
        }
        else {
            pp = removed_node.getParent().getParent();
            if ( p.isFirstChildNode() ) {
                if ( removed_node.isFirstChildNode() ) {
                    p.getChildNode2().setDistanceToParent(
                            addDist( p.getDistanceToParent(), p.getChildNode2()
                                    .getDistanceToParent() ) );
                    pp.setChild1( p.getChildNode2() );
                    p.getChildNode2().setParent( pp );
                }
                else {
                    p.getChildNode1().setDistanceToParent(
                            addDist( p.getDistanceToParent(), p.getChildNode1()
                                    .getDistanceToParent() ) );
                    pp.setChild1( p.getChildNode1() );
                    p.getChildNode1().setParent( pp );
                }

            }
            else {
                if ( removed_node.isFirstChildNode() ) {
                    p.getChildNode2().setDistanceToParent(
                            addDist( p.getDistanceToParent(), p.getChildNode2()
                                    .getDistanceToParent() ) );
                    pp.setChild2( p.getChildNode2() );
                    p.getChildNode2().setParent( pp );
                }
                else {
                    p.getChildNode1().setDistanceToParent(
                            addDist( p.getDistanceToParent(), p.getChildNode1()
                                    .getDistanceToParent() ) );
                    pp.setChild2( p.getChildNode1() );
                    p.getChildNode1().setParent( pp );
                }
            }

            while ( pp != getRoot() ) {
                pp.setSumExtNodes( pp.getSumExtNodes() - 1 );
                pp = pp.getParent();
            }

            pp.setSumExtNodes( pp.getSumExtNodes() - 1 );

        }
        _idhash = null;
        return;

    } // removeExtNode( PhylogenyNode )

    // Helper method for removeExtNode( PhylogenyNode ).
    private double addDist( double a, double b ) {
        if ( a >= 0.0 && b >= 0.0 ) {
            return a + b;
        }
        else if ( a >= 0.0 ) {
            return a;
        }
        else if ( b >= 0.0 ) {
            return b;
        }
        else if ( a == PhylogenyNode.DISTANCE_NULL
                && b == PhylogenyNode.DISTANCE_NULL ) {
            return PhylogenyNode.DISTANCE_NULL;
        }
        return PhylogenyNode.DISTANCE_DEFAULT;

    } // addDist( double, double )

    /**
     * Swaps the the two childern of a PhylogenyNode with ID id of this
     * Phylogeny.
     * 
     * @param id
     *            ID (int) of PhylogenyNode
     */
    public void swapChildren( int id ) throws IllegalStateException {
        swapChildren( getNode( id ) );
    } // swapChildren( int )

    /**
     * Swaps the the two childern of a PhylogenyNode node of this Phylogeny.
     * <p>
     * (Last modified: 06/13/01)
     * 
     * @param node
     *            a PhylogenyNode of this Phylogeny
     */
    public void swapChildren( final PhylogenyNode node )
            throws IllegalStateException {
        
        if ( !isTree() ) {
            throw new IllegalStateException(
                    "Attempt to swap children on phylogeny which is not tree-like." );
        }
        if ( isEmpty() || node.isExternal() || node.getNumberOfChildNodes() < 2 ) {
            return;
        }

        final PhylogenyNode first = node.getFirstChildNode();

        for ( int i = 1; i < node.getNumberOfChildNodes(); ++i ) {
            node.setChildNode( i - 1, node.getChildNode( i ) );
        }
        node.setChildNode( node.getNumberOfChildNodes() - 1, first );
      
    } // swapChildren( PhylogenyNode )

    /**
     * Arranges the order of childern for each node of this Phylogeny in such a
     * way that either the branch with more children is on top (right) or on
     * bottom (left), dependent on the value of boolean order.
     * <p>
     * (Last modified: 06/13/01)
     * 
     * @param order
     *            decides in which direction to order
     */
    public void orderAppearance( boolean order ) throws IllegalStateException {

        if ( !isTree() ) {
            throw new IllegalStateException(
                    "Attempt to order appearance on phylogeny which is not tree-like." );
        }

        if ( isEmpty() ) {
            return;
        }

        orderAppearanceHelper( getRoot(), order );

    } // void orderAppearance( boolean )

    // Helper method for "orderAppearance(boolean)".
    // Traverses this Phylogeny recusively.
    // (Last modified: 06/13/00)
    private void orderAppearanceHelper( PhylogenyNode n, boolean order ) {

        if ( n.isExternal() ) {
            return;
        }
        // else { - Unnecessary else clause (Petar).
        PhylogenyNode temp = null;
        //          FIXME
        if ( ( n.getChildNode1().getSumExtNodes() != n.getChildNode2()
                .getSumExtNodes() )
                && ( ( n.getChildNode1().getSumExtNodes() < n
                        .getChildNode2().getSumExtNodes() ) == order ) ) {
            temp = n.getChildNode1();
            n.setChild1( n.getChildNode2() );
            n.setChild2( temp );

        }
        for ( int i = 0; i < n.getNumberOfChildNodes(); ++i ) {
            orderAppearanceHelper( n.getChildNode( i ), order );
        }
        // }

    } // orderAppearanceHelper( PhylogenyNode, boolean )

    /**
     * Sets all Nodes of this Phylogeny to not-collapsed.
     * <p>
     * In most cases methods adjustNodeCount(false) and recalculateAndReset()
     * need to be called after this method has been called.
     */
    public void setAllNodesToNotCollapse() {
        if ( isEmpty() ) {
            return;
        }
        for ( PhylogenyNodeIterator iter = iteratorPreorder(); iter.hasNext(); ) {
            PhylogenyNode node = iter.next();
            node.setCollapse( false );
        }
    } // setAllNodesToNotCollapse()

    /**
     * Collapses this Phylogeny's deepest Nodes anotated with either a sequence
     * name or a species name. All other Nodes are uncollapsed.
     * <p>
     * (Last modified: 07/03/01)
     */
    public void collapseToDeepestAnotNodes() {
        if ( isEmpty() ) {
            return;
        }
        setAllNodesToNotCollapse();
        collapseToDeepestAnotNodesHelper( getRoot() );
        adjustNodeCount( true );

    } // collapseToDeepestAnotNodes()

    // Helper for collapseToDeepestAnotNodes()
    // (Last modified: 07/03/01)
    private void collapseToDeepestAnotNodesHelper( PhylogenyNode n ) {
        if ( n.isExternal() ) {
            return;
        }
        else {
            if ( !n.isPseudoNode()
                    && ( !n.getTaxonomy().equals( "" ) || !n.getSeqName()
                            .equals( "" ) ) ) {
                n.setCollapse( true );
                return;
            }
            else {
                for ( int i = 0; i < n.getNumberOfChildNodes(); ++i ) {
                    collapseToDeepestAnotNodesHelper( n.getChildNode( i ) );
                }
            }
        }
    } // collapseToDeepestAnotNodesHelper( PhylogenyNode )

    // ---------------------------------------------------------
    // Rerooting
    // ---------------------------------------------------------

    /**
     * Places the root of this Phylogeny on the parent branch of the
     * PhylogenyNode with a corresponding ID. The new root is always placed on
     * the middle of the branch. If the resulting reRooted Phylogeny is to be
     * used any further, in most cases the following methods have to be called
     * on the resulting Phylogeny:
     * <p>
     * <li>adjustNodeCount(boolean)
     * <li>recalculateAndReset()
     * <p>
     * (Last modified: 10/01/01)
     * 
     * @param id
     *            ID (int) of PhylogenyNode of this Phylogeny
     */
    public void reRoot( int id ) {
        reRoot( getNode( id ) );
    } // reRoot( int )

    /**
     * Places the root of this Phylogeny on the parent branch PhylogenyNode n.
     * The new root is always placed on the middle of the branch.
     * <p>
     * If the resulting reRooted Phylogeny is to be used any further, in most
     * cases the following three methods have to be called on the resulting
     * Phylogeny:
     * <ul>
     * <li>adjustNodeCount(boolean)
     * <li>recalculateAndReset()
     * </ul>
     * <p>
     * (Last modified: 10/01/01)
     * 
     * @param n
     *            PhylogenyNode of this Phylogeny\
     */
    public void reRoot( PhylogenyNode n ) {
        PhylogenyNode nodeA = n;
        PhylogenyNode node = null;
        PhylogenyNode nodeB = null;
        PhylogenyNode nodeC = null;
        PhylogenyNode new_root = null;
        double distance1 = 0.0;
        double distance2 = 0.0;
        double bootstrap1 = 0;
        double bootstrap2 = 0;
        int width1 = 0;
        int width2 = 0;
        Color color1 = null;
        Color color2 = null;
        Hashtable hash1 = null, hash2 = null;

        if ( isEmpty() || getNumberOfExternalNodes() < 2 ) {
            return;
        }

        if ( nodeA.isPseudoNode() ) {
            throw new IllegalArgumentException(
                    "Phylogeny: reRoot(PhylogenyNode): Can not place root on parent branch of pseudo node." );
        }

        setRooted( true );

        if ( nodeA.isRoot() ) {
            moveRootToMiddle();
            return;
        }

        if ( nodeA.getParent().isRoot() ) {
            if ( getRoot().getChildNode1().isPseudoNode()
                    || getRoot().getChildNode2().isPseudoNode() ) {
                if ( getRoot().getChildNode1() == nodeA
                        && getRoot().getChildNode2().isPseudoNode() ) {
                    node = getRoot().getChildNode2();
                }
                if ( getRoot().getChildNode2() == nodeA
                        && getRoot().getChildNode1().isPseudoNode() ) {
                    node = getRoot().getChildNode1();
                }
                if ( nodeA.getDistanceToParent() == PhylogenyNode.DISTANCE_DEFAULT ) {
                    node.setDistanceToParent( PhylogenyNode.DISTANCE_DEFAULT );
                }
                else {
                    double d = nodeA.getDistanceToParent() / 2;
                    node.setDistanceToParent( d );
                    nodeA.setDistanceToParent( d );
                }

                node.setParentBranchCustomTagValueUnits( nodeA
                        .getParentBranchCustomTagValueUnits() );
                node.setParentBranchWidth( nodeA.getParentBranchWidth() );
                node.setColor( nodeA.getColor() );
                node.setBootstrap( nodeA.getBootstrap() );
            }
            else {
                moveRootToMiddle();
            }
            return;
        }

        nodeB = nodeA.getParent();
        nodeC = nodeB.getParent();

        // New Root.
        new_root = new PhylogenyNode();
        if ( nodeB.getChildNode2() == nodeA ) {
            new_root.setChild1( nodeA );
            new_root.setChild2( nodeB );
        }
        else {
            new_root.setChild1( nodeB );
            new_root.setChild2( nodeA );
        }

        distance1 = nodeC.getDistanceToParent();
        hash1 = nodeC.getParentBranchCustomTagValueUnits();
        width1 = nodeC.getParentBranchWidth();
        color1 = nodeC.getColor();
        bootstrap1 = nodeC.getBootstrap();

        nodeC.setDistanceToParent( nodeB.getDistanceToParent() );
        nodeC.setParentBranchCustomTagValueUnits( nodeB
                .getParentBranchCustomTagValueUnits() );
        nodeC.setParentBranchWidth( nodeB.getParentBranchWidth() );
        nodeC.setColor( nodeB.getColor() );
        nodeC.setBootstrap( nodeB.getBootstrap() );

        nodeB.setParentBranchCustomTagValueUnits( nodeA
                .getParentBranchCustomTagValueUnits() );
        nodeB.setParentBranchWidth( nodeA.getParentBranchWidth() );
        nodeB.setColor( nodeA.getColor() );
        nodeB.setBootstrap( nodeA.getBootstrap() );

        // New root is always placed in the middle of the branch:
        if ( nodeA.getDistanceToParent() == PhylogenyNode.DISTANCE_DEFAULT ) {
            nodeB.setDistanceToParent( PhylogenyNode.DISTANCE_DEFAULT );
        }
        else {
            double d = nodeA.getDistanceToParent() / 2;
            nodeB.setDistanceToParent( d );
            nodeA.setDistanceToParent( d );
        }

        // nodeA:
        nodeA.setParent( new_root );

        // nodeB:
        if ( nodeB.getChildNode1() == nodeA ) {
            nodeB.setChild1( nodeC );
        }
        else {
            nodeB.setChild2( nodeC );
        }
        nodeB.setParent( new_root );

        // moving to the old root, swapping references:
        while ( !nodeC.isRoot() ) {
            nodeA = nodeB;
            nodeB = nodeC;
            nodeC = nodeC.getParent();

            if ( nodeB.getChildNode1() == nodeA ) {
                nodeB.setChild1( nodeC );
            }
            else {
                nodeB.setChild2( nodeC );
            }
            nodeB.setParent( nodeA );

            distance2 = nodeC.getDistanceToParent();
            hash2 = nodeC.getParentBranchCustomTagValueUnits();
            width2 = nodeC.getParentBranchWidth();
            color2 = nodeC.getColor();
            bootstrap2 = nodeC.getBootstrap();

            nodeC.setDistanceToParent( distance1 );
            nodeC.setParentBranchCustomTagValueUnits( hash1 );
            nodeC.setParentBranchWidth( width1 );
            nodeC.setColor( color1 );
            nodeC.setBootstrap( bootstrap1 );

            distance1 = distance2;
            hash1 = hash2;
            width1 = width2;
            color1 = color2;
            bootstrap1 = bootstrap2;
        }

        // removing the old root:
        if ( nodeC.getChildNode1() == nodeB ) {
            node = nodeC.getChildNode2();
        }
        else {
            node = nodeC.getChildNode1();
        }
        node.setParent( nodeB );

        if ( nodeC.getDistanceToParent() == PhylogenyNode.DISTANCE_NULL
                && node.getDistanceToParent() == PhylogenyNode.DISTANCE_NULL ) {
            node.setDistanceToParent( PhylogenyNode.DISTANCE_NULL );
        }
        else if ( ( nodeC.getDistanceToParent() == PhylogenyNode.DISTANCE_DEFAULT || nodeC
                .getDistanceToParent() == PhylogenyNode.DISTANCE_NULL )
                && ( node.getDistanceToParent() == PhylogenyNode.DISTANCE_DEFAULT || node
                        .getDistanceToParent() == PhylogenyNode.DISTANCE_NULL ) ) {
            node.setDistanceToParent( PhylogenyNode.DISTANCE_DEFAULT );
        }
        else {
            node
                    .setDistanceToParent( ( nodeC.getDistanceToParent() >= 0.0 ? nodeC
                            .getDistanceToParent()
                            : 0.0 )
                            + ( node.getDistanceToParent() >= 0.0 ? node
                                    .getDistanceToParent() : 0.0 ) );
        }

        if ( nodeC.getDistanceToParent() != PhylogenyNode.DISTANCE_NULL ) {
            node.setParentBranchCustomTagValueUnits( nodeC
                    .getParentBranchCustomTagValueUnits() );
            node.setParentBranchWidth( nodeC.getParentBranchWidth() );
            node.setColor( nodeC.getColor() );
        }

        node.setBootstrap( nodeC.getBootstrap() );

        if ( nodeB.getChildNode1() != nodeC ) {
            nodeB.setChild2( node );
        }
        else {
            nodeB.setChild1( node );
        }

        setRoot( new_root );
        return;

    } // reRoot( PhylogenyNode )

    /**
     * Places the root of this Phylogeny on Branch b. The new root is always
     * placed on the middle of the branch b.
     * <p>
     * (Last modified: 10/01/01)
     * 
     * @param n1
     *            PhylogenyNode of PhylogenyNode of this Phylogeny n2
     *            PhylogenyNode of PhylogenyNode of this Phylogeny
     */
    public void reRoot( PhylogenyBranch b ) {

        PhylogenyNode n1 = b.getFirstNode(), n2 = b.getSecondNode();

        if ( n2 == n1.getChildNode1() || n2 == n1.getChildNode2() ) {
            reRoot( n2 );
        }
        else if ( n1 == n2.getChildNode1() || n1 == n2.getChildNode2() ) {
            reRoot( n1 );
        }
        else if ( n1.getParent() != null
                && n1.getParent().isRoot()
                && ( n1.getParent().getChildNode1() == n2 || n1.getParent()
                        .getChildNode2() == n2 ) ) {
            reRoot( n1 );
        }
        else {
            throw new IllegalArgumentException(
                    "reRoot( Branch b ): b is not a branch." );
        }

    } // reRoot( Branch )

    /**
     * Places the root of this Phylogeny on the parent branch PhylogenyNode n.
     * The new root is always placed on the middle of the branch.
     * <p>
     * This method only considers the "skeleton" of the Phylogeny: It ignores
     * everything except the topology and branch lenghts. It also does not deal
     * properly with multifurcated tree! DO NOT USE. <pPhylogenyBranch * This is
     * ONLY to be used by methods in class SDIunrooted PhylogenyBranch *
     * forester/tools)!
     * <p>
     * (Last modified: 10/01/01)
     * 
     * @param n
     *            PhylogenyNode of this Phylogeny
     */
    public void reRootSkeleton( PhylogenyNode n ) {

        PhylogenyNode nodeA = n, node = null, nodeB = null, nodeC = null, new_root = null;
        double distance1 = 0.0, distance2 = 0.0;

        if ( isEmpty() || getNumberOfExternalNodes() < 2 ) {
            return;
        }

        setRooted( true );

        if ( nodeA.isRoot() || nodeA.getParent().isRoot() ) {
            moveRootToMiddle();
            return;
        }

        nodeB = nodeA.getParent();
        nodeC = nodeB.getParent();

        // New Root.
        new_root = new PhylogenyNode();
        if ( nodeB.getChildNode2() == nodeA ) {
            new_root.setChild1( nodeA );
            new_root.setChild2( nodeB );
        }
        else {
            new_root.setChild1( nodeB );
            new_root.setChild2( nodeA );
        }

        distance1 = nodeC.getDistanceToParent();

        nodeC.setDistanceToParent( nodeB.getDistanceToParent() );

        // New root is always placed in the middle of the branch:
        if ( nodeA.getDistanceToParent() == PhylogenyNode.DISTANCE_DEFAULT ) {
            nodeB.setDistanceToParent( PhylogenyNode.DISTANCE_DEFAULT );
        }
        else {
            double d = nodeA.getDistanceToParent() / 2;
            nodeB.setDistanceToParent( d );
            nodeA.setDistanceToParent( d );
        }

        // nodeA:
        nodeA.setParent( new_root );

        // nodeB:
        if ( nodeB.getChildNode1() == nodeA ) {
            nodeB.setChild1( nodeC );
        }
        else {
            nodeB.setChild2( nodeC );
        }
        nodeB.setParent( new_root );

        // moving to the old root, swapping references:
        while ( !nodeC.isRoot() ) {

            nodeA = nodeB;
            nodeB = nodeC;
            nodeC = nodeC.getParent();

            if ( nodeB.getChildNode1() == nodeA ) {
                nodeB.setChild1( nodeC );
            }
            else {
                nodeB.setChild2( nodeC );
            }
            nodeB.setParent( nodeA );
            distance2 = nodeC.getDistanceToParent();
            nodeC.setDistanceToParent( distance1 );
            distance1 = distance2;
        }

        // removing the old root:
        if ( nodeC.getChildNode1() == nodeB ) {
            node = nodeC.getChildNode2();
        }
        else {
            node = nodeC.getChildNode1();
        }
        node.setParent( nodeB );

        if ( nodeC.getDistanceToParent() == PhylogenyNode.DISTANCE_DEFAULT
                && node.getDistanceToParent() == PhylogenyNode.DISTANCE_DEFAULT ) {
            node.setDistanceToParent( PhylogenyNode.DISTANCE_DEFAULT );
        }
        else {
            node
                    .setDistanceToParent( ( nodeC.getDistanceToParent() >= 0.0 ? nodeC
                            .getDistanceToParent()
                            : 0.0 )
                            + ( node.getDistanceToParent() >= 0.0 ? node
                                    .getDistanceToParent() : 0.0 ) );
        }

        if ( nodeB.getChildNode1() != nodeC ) {
            nodeB.setChild2( node );
        }
        else {
            nodeB.setChild1( node );
        }
        setRoot( new_root );

        return;

    } // reRootSkeleton( PhylogenyNode )

    /**
     * Places the root of this Phylogeny on Branch b. The new root is always
     * placed on the middle of the branch b.
     * <p>
     * This method only considers the "skeleton" of the Phylogeny: It ignores
     * everything except the topology and branch lenghts. It also does not deal
     * properly with multifurcated tree! DO NOT USE.
     * <p>
     * This is ONLY to be used by methods in class SDIunrooted (in
     * forester/tools)!
     * <p>
     * (Last modified: 10/01/01)
     * 
     * @param n1
     *            PhylogenyNode of PhylogenyNode of this PhyloPhylogenyBranch2
     *            PhylogenyNode of PhylogenyNode of this Phylogeny
     */
    public void reRootSkeleton( PhylogenyBranch b ) {

        PhylogenyNode n1 = b.getFirstNode(), n2 = b.getSecondNode();

        if ( n2 == n1.getChildNode1() || n2 == n1.getChildNode2() ) {
            reRootSkeleton( n2 );
        }
        else if ( n1 == n2.getChildNode1() || n1 == n2.getChildNode2() ) {
            reRootSkeleton( n1 );
        }
        else if ( n1.getParent() != null
                && n1.getParent().isRoot()
                && ( n1.getParent().getChildNode1() == n2 || n1.getParent()
                        .getChildNode2() == n2 ) ) {
            reRootSkeleton( n1 );
        }
        else {
            throw new IllegalArgumentException(
                    "reRootSkeleton( Branch b ): b is not a branch." );
        }

    } // reRootSkeleton( Branch )

    // (Last modified: 10/01/01)
    private void moveRootToMiddle() {
        if ( getRoot().getChildNode1() != null
                && getRoot().getChildNode2() != null ) {
            double d1 = getRoot().getChildNode1().getDistanceToParent(), d2 = getRoot()
                    .getChildNode2().getDistanceToParent(), d = 0.0;
            if ( d1 < 0.0 ) {
                d1 = 0.0;
            }
            if ( d2 < 0.0 ) {
                d2 = 0.0;
            }
            d = ( d1 + d2 ) / 2.0;
            getRoot().getChildNode1().setDistanceToParent( d );
            getRoot().getChildNode2().setDistanceToParent( d );
        }
    } // moveRootToMiddle()

    // ----------------------------------------------------------------------------
    // Orthologs, Super Orthologs, Ultra Paralogs, Subtree Neighbors,
    // "X-Orthologs"
    // ----------------------------------------------------------------------------

    /**
     * Returns all orthologs of the external PhylogenyNode n of this Phylogeny.
     * Orthologs are returned as Vector of references to Nodes.
     * <p>
     * PRECONDITION: This tree must be binary and rooted, and speciation -
     * duplication need to be assigned for each of its internal Nodes.
     * <p>
     * Returns null if this Phylogeny is empty or if n is internal.
     * <p>
     * (Last modified: 11/22/00)
     * 
     * @param n
     *            external PhylogenyNode whose orthologs are to be returned
     * @return Vector of references to all orthologous Nodes of PhylogenyNode n
     *         of this Phylogeny, null if this Phylogeny is empty or if n is
     *         internal
     */
    public Vector getOrthologousNodes( PhylogenyNode n ) {

        PhylogenyNode node = n, prev = null;
        Vector v = new Vector();

        if ( !node.isExternal() || isEmpty() ) {
            return null;
        }

        //FIXME
        while ( !node.isRoot() ) {
            prev = node;
            node = node.getParent();
            if ( !node.isDuplication() ) {
                if ( node.getChildNode1() == prev ) {
                    Util.addIntoVector( node.getChildNode2()
                            .getAllExternalChildren(), v );
                }
                else {
                    Util.addIntoVector( node.getChildNode1()
                            .getAllExternalChildren(), v );
                }
            }
        }

        v.trimToSize();

        return v;
    } // getOrthologousNodes( PhylogenyNode )

    /**
     * Returns all Nodes which are connected to external PhylogenyNode n of this
     * Phylogeny by a path containing only speciation events. We call these
     * "super orthologs". Nodes are returned as Vector of references to Nodes.
     * <p>
     * PRECONDITION: This tree must be binary and rooted, and speciation -
     * duplication need to be assigned for each of its internal Nodes.
     * <p>
     * Returns null if this Phylogeny is empty or if n is internal.
     * <p>
     * (Last modified: 11/22/00)
     * 
     * @param n
     *            external PhylogenyNode whose strictly speciation related Nodes
     *            are to be returned
     * @return Vector of references to all strictly speciation related Nodes of
     *         PhylogenyNode n of this Phylogeny, null if this Phylogeny is
     *         empty or if n is internal
     */
    public Vector getSuperOrthologousNodes( PhylogenyNode n ) {
        //FIXME
        PhylogenyNode node = n, deepest = null;
        Vector v = new Vector();

        if ( !node.isExternal() || isEmpty() ) {
            return null;
        }

        while ( !node.isRoot() && !node.getParent().isDuplication() ) {
            node = node.getParent();
        }

        deepest = node;
        deepest.setIndicatorsToZero();

        do {
            if ( !node.isExternal() ) {
                if ( node.getIndicator() == 0 ) {
                    node.setIndicator( 1 );
                    if ( !node.isDuplication() ) {
                        node = node.getChildNode1();
                    }
                }
                if ( node.getIndicator() == 1 ) {
                    node.setIndicator( 2 );
                    if ( !node.isDuplication() ) {
                        node = node.getChildNode2();
                    }
                }
                if ( node != deepest && node.getIndicator() == 2 ) {
                    node = node.getParent();
                }
            }
            else {
                if ( node != n ) {
                    v.addElement( node );
                }
                if ( node != deepest ) {
                    node = node.getParent();
                }
                else {
                    node.setIndicator( 2 );
                }
            }
        }
        while ( node != deepest || deepest.getIndicator() != 2 );

        v.trimToSize();

        return v;

    } // getSuperOrthologousNodes( PhylogenyNode )

    /**
     * Returns all Nodes which are connected to external PhylogenyNode n of this
     * Phylogeny by a path containing, and leading to, only duplication events.
     * We call these "ultra paralogs". Nodes are returned as Vector of
     * references to Nodes.
     * <p>
     * PRECONDITION: This tree must be binary and rooted, and speciation -
     * duplication need to be assigned for each of its internal Nodes.
     * <p>
     * Returns null if this Phylogeny is empty or if n is internal.
     * <p>
     * (Last modified: 10/06/01)
     * 
     * @param n
     *            external PhylogenyNode whose ultra paralogs are to be returned
     * @return Vector of references to all ultra paralogs of PhylogenyNode n of
     *         this Phylogeny, null if this Phylogeny is empty or if n is
     *         internal
     */
    public Vector getUltraParalogousNodes( PhylogenyNode n ) {
        //FIXME
        PhylogenyNode node = n;
        Vector v = new Vector();

        if ( !node.isExternal() || isEmpty() ) {
            return null;
        }

        while ( !node.isRoot() && node.getParent().isDuplication()
                && areAllChildrenDuplications( node.getParent() ) ) {
            node = node.getParent();
        }

        v = node.getAllExternalChildren();

        v.removeElement( n );

        v.trimToSize();

        return v;

    } // getUltraParalogousNodes( PhylogenyNode )

    // Helper for getUltraParalogousNodes( PhylogenyNode ).
    //(Last modified: 11/22/00)
    public boolean areAllChildrenDuplications( PhylogenyNode n ) {
        if ( n.isExternal() ) {
            return true;
        }
        else {
            //FIXME
            if ( n.isDuplication() ) {
                return ( areAllChildrenDuplications( n.getChildNode1() ) && areAllChildrenDuplications( n
                        .getChildNode2() ) );
            }
            else {
                return false;
            }
        }
    }

    /**
     * Returns all external nodes (except n) which are members of the 2nd
     * smallest subtree containing PhylogenyNode n. In other words, this method
     * returns all external descendants (except n itself) of n's parent's parent
     * node (n.getParent().getParent()). We call these "subtree neighbors". This
     * concept is not dependent on duplications and speciations. Nodes are
     * returned as Vector of references to Nodes.
     * <p>
     * PRECONDITION: This tree must be binary and rooted.
     * <p>
     * Returns null if this Phylogeny is empty or if n is internal.
     * <p>
     * (Last modified: 12/26/01)
     * 
     * @param n
     *            external PhylogenyNode whose "subtree neighbors" are to be
     *            returned
     * @return Vector of references to all "subtree neighbors" of PhylogenyNode
     *         n of this Phylogeny, null if this Phylogeny is empty or if n is
     *         internal
     */
    public Vector getSubtreeNeighbors( PhylogenyNode n ) {
        //FIXME
        PhylogenyNode node = n;
        Vector v = new Vector();

        if ( !node.isExternal() || isEmpty() ) {
            return null;
        }

        if ( !node.isRoot() ) {
            node = node.getParent();
        }
        if ( !node.isRoot() ) {
            node = node.getParent();
        }

        v = node.getAllExternalChildren();

        v.removeElement( n );

        v.trimToSize();

        return v;

    } // getSubtreeNeighbors( PhylogenyNode )

    // ---------------------------------------------------------
    // Getting and finding of Nodes and Names
    // ---------------------------------------------------------

    /**
     * Returns a PhylogenyNode of this Phylogeny which has a matching name.
     * Throws an Exception if seqname is not present in this or not unique.
     * <p>
     * (Last modifed: 12/03/00)
     * 
     * @param name
     *            name (String) of PhylogenyNode to find
     * @return PhylogenyNode with matchin name
     */
    public PhylogenyNode getNode( String name ) {

        Vector nodes = getNodes( name );

        if ( isEmpty() ) {
            return null;
        }

        if ( nodes == null || nodes.size() < 1 ) {
            throw new IllegalArgumentException( name + " not found" );
        }
        if ( nodes.size() > 1 ) {
            throw new IllegalArgumentException( name + " not unique" );
        }
        return ( PhylogenyNode ) nodes.elementAt( 0 );

    } // getNode( String )

    /**
     * Finds the PhylogenyNode of this Phylogeny which has a matching ID number.
     * Takes O(n) time. After method hashIDs() has been called it runs in
     * constant time.
     * 
     * @param id
     *            ID number (int) of the PhylogenyNode to find
     * @return PhylogenyNode with matching ID, null if PhylogenyNode not found
     */
    public PhylogenyNode getNode( int id ) throws NoSuchElementException {

        if ( isEmpty() ) {
            throw new NoSuchElementException(
                    "Attempt to find node in an empty phlyogeny." );
        }

        if ( _idhash != null ) {
            return ( PhylogenyNode ) _idhash.get( new Integer( id ) );
        }
        else {
            for ( PhylogenyNodeIterator iter = iteratorPreorder(); iter
                    .hasNext(); ) {
                final PhylogenyNode node = iter.next();
                if ( node.getID() == id ) {
                    return node;
                }
            }
        }
        throw new NoSuchElementException( "Node for which id=" + id
                + " not found." );

    } // getNode( int id )

    /**
     * Returns a Vector of references to Nodes which match in sequence name AND
     * species AND EC number AND taxonomy ID. To not use a parameter set it to
     * "", or to PhylogenyNode.TAXO_ID_DEFAULT for taxonomy_id. Is case
     * insensitive.
     * <p>
     * (Last modified: 07/30/01)
     * 
     * @param name
     *            sequence name to match species species name to match ec EC
     *            number to match taxonomy_id taxonomy ID to match
     * @return Vecotor of references to matching Nodes
     */
    public Vector find( final String name, final String species,
            final String ec, String taxonomy_id ) {
        if ( isEmpty() ) {
            return null;
        }
        Vector nodes = new Vector();
        boolean failed = false;

        final String my_name = Util.sanitize( name ).toLowerCase();
        final String my_species = Util.sanitize( species ).toLowerCase();
        final String my_ec = Util.sanitize( ec ).toLowerCase();
        final String my_taxo_id = Util.sanitize( taxonomy_id ).toLowerCase();

        for ( PhylogenyNodeIterator iter = iteratorPreorder(); iter.hasNext(); ) {
            PhylogenyNode current = iter.next();
            PhylogenyNode n = null;
            if ( !Util.isEmpty( my_name ) ) {
                if ( current.getSeqName().toLowerCase().equals( my_name ) ) {
                    n = current;
                }
                else {
                    failed = true;
                }
            }
            if ( !failed && !Util.isEmpty( my_species ) ) {
                if ( current.getTaxonomy().toLowerCase().equals( my_species ) ) {
                    n = current;
                }
                else {
                    failed = true;
                }
            }
            if ( !failed && !Util.isEmpty( my_ec ) ) {
                if ( current.getECnumber().toLowerCase().equals( my_ec ) ) {
                    n = current;
                }
                else {
                    failed = true;
                }
            }
            if ( !failed && !Util.isEmpty( my_taxo_id ) ) {
                if ( current.getTaxonomyID().toLowerCase().equals( my_taxo_id ) ) {
                    n = current;
                }
                else {
                    failed = true;
                }
            }

            if ( !failed ) {
                nodes.addElement( n );
            }
            // i.next();
        }

        nodes.trimToSize();
        return nodes;

    } // find( String, String, String, int )

    /**
     * Returns a Hashtable of references to Nodes which match in sequence name
     * OR species OR EC number OR taxonomy ID. Matches are substring matches. Is
     * case insensitive.
     * <p>
     * (Last modified: 01/02/04)
     * 
     * @param query
     *            to String to match
     * @return Hashtable of references to matching Nodes
     */
    public Hashtable findInNameSpecECid( String query ) {

        Hashtable nodes = new Hashtable();

        if ( isEmpty() ) {
            return nodes;
        }

        query = query.toLowerCase().trim();

        if ( query.equals( "" ) ) {
            return nodes;
        }

        for ( PhylogenyNodeIterator iter = iteratorPreorder(); iter.hasNext(); ) {
            PhylogenyNode current = iter.next();
            if ( current.getSeqName().toLowerCase().indexOf( query ) >= 0 ) {
                nodes.put( current, "" );
            }
            else if ( current.getTaxonomy().toLowerCase().indexOf( query ) >= 0 ) {
                nodes.put( current, "" );
            }
            else if ( current.getECnumber().toLowerCase().indexOf( query ) >= 0 ) {
                nodes.put( current, "" );
            }
            else if ( current.getTaxonomyID().toLowerCase().indexOf( query ) >= 0 ) {
                nodes.put( current, "" );
            }

            //need to search all the custom data!!!
            // FIXME<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~<<<<<<<<<<
            //i.next();
        }

        return nodes;

    } // findInNameSpecECid( String )

    /**
     * Returns a Vector with references to all Nodes of this Phylogeny which
     * have a matching name.
     * <p>
     * (Last modified: 07/29/01)
     * 
     * @param name
     *            name (String) of Nodes to find
     * @return Vector of references to Nodes of this Phylogeny with matching
     *         names
     * @see #getNodesWithMatchingSpecies(String)
     */
    public Vector getNodes( String name ) {

        if ( isEmpty() ) {
            return null;
        }
        Vector nodes = new Vector();

        for ( PhylogenyNodeIterator iter = iteratorPreorder(); iter.hasNext(); ) {
            PhylogenyNode n = iter.next();
            if ( n.getSeqName().equals( name ) ) {
                nodes.addElement( n );
            }
        }
        nodes.trimToSize();
        return nodes;

    } // getNodes( String )

    /**
     * Returns a Vector with references to all Nodes of this Phylogeny which
     * have a matching species name.
     * 
     * @param specname
     *            species name (String) of Nodes to find
     * @return Vector of references to Nodes of this Phylogeny with matching
     *         species' names.
     * @see #getNodes(String)
     */
    public Vector getNodesWithMatchingSpecies( String specname ) {

        if ( isEmpty() ) {
            return null;
        }
        Vector nodes = new Vector();
        for ( PhylogenyNodeIterator iter = iteratorPreorder(); iter.hasNext(); ) {
            PhylogenyNode n = iter.next();
            if ( n.getTaxonomy().equals( specname ) ) {
                nodes.addElement( n );
            }
        }

        nodes.trimToSize();
        return nodes;

    } // getNodesWithMatchingSpecies( String )

    /**
     * Returns the sequence names of all external Nodes of this Phylogeny as
     * array of Strings.
     * <p>
     * (Last modified: 11/13/00)
     * 
     * @return all external sequence names as String[]
     */
    public String[] getAllExternalSeqNames() {

        int i = 0;

        if ( isEmpty() ) {
            return null;
        }

        String[] names = new String[ getNumberOfExternalNodes() ];
        for ( PhylogenyNodeIterator iter = iteratorExternalForward(); iter
                .hasNext(); ) {
            names[ i++ ] = new String( iter.next().getSeqName() );
        }
        return names;

    } // getAllExternalSeqNames()

    // ---------------------------------------------------------
    // Calculation of simple numerical values
    // ---------------------------------------------------------

    /**
     * This calculates the height for rooted, tree-shaped phylogenies. The
     * height is the longest distance from the root to an external node. Please
     * note. Child nodes of collapsed nodes are ignored -- which is useful for
     * display purposes but might be misleading for other applications.
     * 
     * @return the height for rooted, tree-shaped phylogenies
     */
    public double getHeight() {
        if ( isEmpty() ) {
            return 0.0;
        }
        return calculateSubtreelHeight( getRoot() );

    } // getHeight()

    /**
     * This calculates the difference between the longest and shortest subtree
     * emanating at the root for rooted, tree-shaped phylogenies. Please note.
     * Child nodes of collapsed nodes are ignored.
     * 
     * @return the difference between the longest and shortest subtree emanating
     *         at the root for rooted, tree-shaped phylogenies
     */
    public double getLargestSubtreeHeightDifference() {
        if ( isEmpty() || getRoot().getNumberOfChildNodes() < 1 ) {
            return 0.0;
        }
        double max = Double.MIN_VALUE;
        double min = Double.MAX_VALUE;
        for ( int i = 0; i < getRoot().getNumberOfChildNodes(); ++i ) {
            double l = calculateSubtreelHeight( getRoot().getChildNode( i ) );
            if ( l > max ) {
                max = l;
            }
            if ( l < min ) {
                min = l;
            }
        }
        return max - min;
    } // getLargestSubtreeHeightDifference()

    /**
     * This calculates the height of the subtree emanating at n for rooted,
     * tree-shaped phylogenies
     * 
     * @param n
     *            the root-node of a subtree
     * @return the height of the subtree emanating at n
     */
    private double calculateSubtreelHeight( final PhylogenyNode n ) {
        if ( n.isExternal() || n.isCollapse() ) {
            return Util.atLeastZero( n.getDistanceToParent() );
        }
        else {
            double max = Double.MIN_VALUE;
            for ( int i = 0; i < n.getNumberOfChildNodes(); ++i ) {
                double l = calculateSubtreelHeight( n.getChildNode( i ) );
                if ( l > max ) {
                    max = l;
                }
            }
            return max + Util.atLeastZero( n.getDistanceToParent() );
        }
    } // double calculateSubtreelHeight( final PhylogenyNode n )

    // ---------------------------------------------------------
    // Various methods to modify Phylogeny (PhylogenyNode) values
    // ---------------------------------------------------------

    /**
     * Normalizes the bootstrap values to max_normalized_value. Assumptions:
     * minimal bootstrap value is 0.
     */
    public void normalizeBootstrapValues( double max_bootstrap_value,
            double max_normalized_value ) {
        normalizeBootstrapValuesHelper( getRoot(), max_bootstrap_value,
                max_normalized_value );

    } // normalizeBootstrapValues( int, int )

    private void normalizeBootstrapValuesHelper( final PhylogenyNode n,
            double max_bootstrap_value, double max_normalized_value ) {
        if ( n == null ) {
            return;
        }
        else {
            if ( !n.isPseudoNode()
                    && n.getBootstrap() != PhylogenyNode.BOOTSTRAP_DEFAULT ) {
                if ( n.getBootstrap() >= max_bootstrap_value ) {
                    n.setBootstrap( max_normalized_value );
                }
                else {
                    n
                            .setBootstrap( ( int ) ( ( ( n.getBootstrap() * max_normalized_value ) / max_bootstrap_value ) + 0.5 ) );
                }
            }
            normalizeBootstrapValuesHelper( n.getChildNode1(),
                    max_bootstrap_value, max_normalized_value );
            normalizeBootstrapValuesHelper( n.getChildNode2(),
                    max_bootstrap_value, max_normalized_value );

        }

    } // normalizeBootstrapValuesHelper( final PhylogenyNode, int, int )

    // ---------------------------------------------------------
    // Inquiery of Phylogeny properties
    // ---------------------------------------------------------

    /**
     * Checks whether a Phylogeny object is deleted (or empty).
     * 
     * @return true if the tree is deleted (or empty), false otherwise
     */
    public boolean isEmpty() {
        return ( getRoot() == null );
    }

    public boolean isTree() {
        return true;
    }

    /**
     * Returns whether this is a completely binary tree (i.e. all internal nodes
     * are bifurcations).
     * <p>
     * (Last modifed: 05/26/01)
     */
    public boolean isCompletelyBinary() {
        if ( isEmpty() ) {
            return false;
        }
        for ( PhylogenyNodeIterator iter = iteratorPreorder(); iter.hasNext(); ) {
            PhylogenyNode node = iter.next();
            if ( node.isInternal() && node.getNumberOfChildNodes() != 2 ) {
                return false;
            }
        }
        return true;

    } // isCompletelyBinary()

    /**
     * Returns the largest bootstrap value found on this tree.
     */
    public double getMaximumBootstrapValue() {
        double max_bootstrap = Double.MIN_VALUE;
        for ( PhylogenyNodeIterator iter = iteratorPreorder(); iter.hasNext(); ) {
            PhylogenyNode node = iter.next();
            if ( node.getBootstrap() != PhylogenyNode.BOOTSTRAP_DEFAULT
                    && node.getBootstrap() > max_bootstrap ) {
                max_bootstrap = node.getBootstrap();
            }
        }
        return max_bootstrap;
    } // getMaximumBootstrapValue()

    /**
     * Resets the ID numbers of the nodes of this Phylogeny in level order,
     * starting with start_label (for the root). <br>
     * WARNING. After this method has been called, node IDs are no longer
     * unique. <br>
     * WARNING. Afterwards static method getNodeCount of PhylogenyNode is might
     * not be correct anymore (depending on what start_label was used). Returns
     * the maximum used ID number which is used for the child nodes furthest
     * away from the root.
     * 
     * @param start_label
     *            the starting value for the ID numbers
     * @return the maximum used ID number
     */
    public int levelOrderReID( int start_label ) {

        if ( isEmpty() ) {
            return start_label;
        }

        _idhash = null;

        int max = Integer.MIN_VALUE;

        for ( final PhylogenyNodeIterator it = iteratorPreorder(); it.hasNext(); ) {
            final PhylogenyNode node = it.next();
            if ( node.isRoot() ) {
                node.setID( start_label );
            }
            else {
                node.setID( node.getParent().getID() + 1 );
                if ( node.getID() > max ) {
                    max = node.getID();
                }
            }
        }
        return max;

    } // levelOrderReID( int )

    /**
     * Resets the ID numbers of the Nodes of this Phylogeny in preorder,
     * starting with i.<br>
     * WARNING. Afterwards static method getNodeCount of PhylogenyNode is might
     * not be correct anymore (depending on what start_label was used).
     * 
     * @param start_label
     *            the starting value (int)
     * @return start_label plus the total number of Nodes of this Phylogeny
     *         (int)
     */
    public int preorderReID( int start_label ) {
        if ( isEmpty() ) {
            return start_label;
        }
        _idhash = null;
        for ( PhylogenyNodeIterator it = iteratorPreorder(); it.hasNext(); ) {
            it.next().setID( start_label++ );
        }

        return start_label;

    } // preorderReID( int )

    // ---------------------------------------------------------
    // Set and get methods
    // ---------------------------------------------------------

    /**
     * Returns the root PhylogenyNode of this Phylogeny.
     */
    public PhylogenyNode getRoot() {
        return _root;
    } // getRoot()

    public void setRoot( PhylogenyNode n ) {
        _root = n;
    } // setRoot( PhylogenyNode )

    /**
     * Returns true is this Phylogeny is rooted.
     */
    public boolean isRooted() {
        return _rooted;
    } // isRooted()

    /**
     * Sets whether this Phylogeny is rooted or not.
     */
    public void setRooted( boolean b ) {
        _rooted = b;
    } // setRooted( boolean )

    /**
     * Returns the number of duplications of this Phylogeny (int). A return
     * value of -1 indicates that the number of duplications is unknown.
     */
    //    public int getNumberOfDuplications() {
    //        return _number_of_duplications;
    //    } // getNumberOfDuplications()
    /**
     * Sets the number of duplications of this Phylogeny (int). A value of -1
     * indicates that the number of duplications is unknown.
     * 
     * @param clean_nh
     *            set to true for clean NH format
     */
    //    public void setNumberOfDuplications( int i ) {
    //        if ( i < 0 ) {
    //            _number_of_duplications = -1;
    //        }
    //        else {
    //            _number_of_duplications = i;
    //        }
    //    } // setNumberOfDuplications( int )
    /**
     * Returns the first external PhylogenyNode.
     */
    public PhylogenyNode getFirstExternalNode() {
        if ( isEmpty() ) {
            throw new IllegalStateException(
                    "Attempt to obtain first external node of empty Phylogeney." );
        }
        PhylogenyNode node = getRoot();
        while ( node.isInternal() ) {
            node = node.getFirstChildNode();
        }
        return node;
    } // getExtNode0()

    /**
     * Returns the sum of external Nodes of this Phylogeny (int).
     */
    public int getNumberOfExternalNodes() {
        int i = 0;
        for ( PhylogenyNodeIterator iter = iteratorExternalForward(); iter
                .hasNext(); iter.next() ) {
            i++;
        }
        return i;
    } // getNumberOfExtNodes()

    /**
     * Returns the name of this Phylogeny.
     */
    public String getName() {
        return _name;
    } // getName()

    /**
     * Sets the name of this Phylogeny to s.
     */
    public void setName( final String s ) {
        _name = s;
    }

    public String getDescription() {
        return _description;
    }

    public void setDescription( final String description ) {
        _description = description;
    }

    private HashMap getIdHash() {
        return _idhash;
    }

    private void setIdHash( final HashMap idhash ) {
        _idhash = idhash;
    }

    // ---------------------------------------------------------
    // Writing of Phylogeny to Strings
    // ---------------------------------------------------------

    /**
     * Converts this Phylogeny to a New Hampshire X (String) representation.
     * 
     * @return New Hampshire X (String) representation of this
     * @see #toNewHampshireX()
     */
    public String toString() {
        return toNewHampshireX();
    }

    public String toPhyloXML( int level ) {
        return new PhylogenyWriter().toPhyloXML( this ).toString();
    }

    public String toNewHampshire( boolean simple_nh ) {
        return new PhylogenyWriter().toNewHampshire( this, simple_nh )
                .toString();
    }

    public String toNewHampshireX() {
        return new PhylogenyWriter().toNewHampshireX( this ).toString();
    }

    // ---------------------------------------------------------
    // Basic printing
    // ---------------------------------------------------------

    /**
     * Prints descriptions of all external Nodes of this Phylogeny to
     * System.out.
     */
    public void printExtNodes() {

        if ( isEmpty() ) {
            return;
        }

        for ( PhylogenyNodeIterator iter = iteratorExternalForward(); iter
                .hasNext(); ) {
            System.out.println( iter.next() + "\n" );
        }

    } // printExtNodes()

    /**
     * Prints descriptions of all Nodes of this Phylogeny to the console.
     */
    public void printAllNodes() {
        if ( isEmpty() ) {
            return;
        }
        getRoot().preorderPrint();
    } // printAllNodes()

    // --------------------------------------------------------------------
    // Adjust methods (related to Phylogeny construcation and Phylogeny
    // modification)
    // --------------------------------------------------------------------

    /**
     * Sets the indicators of all Nodes of this Phylogeny to 0.
     */
    public void setIndicatorsToZero() {

        if ( isEmpty() ) {
            return;
        }
        for ( PhylogenyNodeIterator iter = iteratorPreorder(); iter.hasNext(); ) {
            iter.next().setIndicator( 0 );
        }

    } // setIndicatorsToZero()

    /**
     * Hashes the ID number of each PhylogenyNode of this Phylogeny to its
     * corresonding PhylogenyNode, in order to make method getNode( id ) run in
     * constant time. Important: The user is responsible for calling this method
     * (again) after this Phylogeny has been changed/created/renumbered.
     */
    public void hashIDs() {

        if ( isEmpty() ) {
            return;
        }

        setIdHash( new HashMap() );

        for ( PhylogenyNodeIterator iter = iteratorPreorder(); iter.hasNext(); ) {
            final PhylogenyNode node = iter.next();
            getIdHash().put( new Integer( node.getID() ), node );
        }

    } // hashIDs()

    /**
     * (Re)counts the number of children for each PhylogenyNode of this
     * Phylogeny. As an example, this method needs to be called after a
     * Phylogeny has been reRooted and it is to be displayed.
     * <p>
     * [Last modified Jun 5, 2005 by CMZ]
     * 
     * @param considerCollapsedNodes
     *            set to true to take into account collapsed nodes (collapsed
     *            nodes have 1 child).
     */
    public void adjustNodeCount( boolean considerCollapsedNodes ) {

        if ( isEmpty() ) {
            return;
        }

        for ( PhylogenyNodeIterator iter = iteratorPostorder(); iter.hasNext(); ) {
            PhylogenyNode node = iter.next();
            if ( node.isExternal()
                    || ( considerCollapsedNodes && node.isCollapse() ) ) {
                node.setSumExtNodes( 1 );
            }
            else {
                int sum = 0;
                for ( int i = 0; i < node.getNumberOfChildNodes(); ++i ) {
                    sum += node.getChildNode( i ).getSumExtNodes();
                }
                node.setSumExtNodes( sum );
            }
        }

    } // adjustNodeCount

    // ---------------------------------------------------------
    // Custom data
    // ---------------------------------------------------------

    /**
     * Returns all custom data tag names of this Phylogeny as Hashtable. Tag
     * names are keys, values are Boolean set to false.
     */
    public Hashtable getCustomTagNames() {

        Hashtable ht = new Hashtable();

        if ( isEmpty() ) {
            return ht;
        }

        for ( PhylogenyNodeIterator iter = iteratorPreorder(); iter.hasNext(); ) {
            PhylogenyNode current_node = iter.next();
            String[] tags = current_node.getCustomTagNames();
            for ( int i = 0; i < tags.length; ++i ) {
                ht.put( tags[ i ], new Boolean( false ) );
            }
        }

        return ht;
    }

    //  ---------------------------------------------------------
    //  Tree modification
    //  ---------------------------------------------------------

    /**
     * Adds this Phylogeny to the list of child nodes of PhylogenyNode parent
     * and sets the parent of this to parent.
     * 
     * @param n
     *            the PhylogenyNode to add
     */
    public void addAsChild( final PhylogenyNode parent ) {

        if ( isEmpty() ) {
            throw new IllegalArgumentException( "Attempt to add an empty tree." );
        }
        if ( !isRooted() ) {
            throw new IllegalArgumentException(
                    "Attempt to add an unrooted tree." );
        }
        parent.addAsChild( getRoot() );
    } // addAsChild( final PhylogenyNode parent )

    // ---------------------------------------------------------
    // Iterators
    // ---------------------------------------------------------

    public PhylogenyNodeIterator iteratorExternalForward() {
        return new ExternalForwardIterator( this );
    }

    public PhylogenyNodeIterator iteratorPostorder() {
        return new PostorderTreeIterator( this );
    }

    public PhylogenyNodeIterator iteratorPreorder() {
        return new PreorderTreeIterator( this );
    }

    public PhylogenyNodeIterator iteratorLevelOrder() {
        return new LevelOrderTreeIterator( this );
    }

} // End of class Phylogeny.

