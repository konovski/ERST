// ATVeditNodeFrame.java
//
// Copyright (C) 1999-2001 Washington University School of Medicine
// and Howard Hughes Medical Institute
// All rights reserved
//
// Created: 1999
// Author: Christian M. Zmasek
// zmasek@genetics.wustl.edu
// http://www.genetics.wustl.edu/eddy/people/zmasek/

package erst.forester.java.src.org.forester.atv;


import java.awt.*;
import java.awt.event.*;
import java.util.Hashtable;

import erst.forester.java.src.org.forester.phylogeny.*;

/**
 * @author Christian Zmasek
 * @version 1.01 -- last modified: 11/04/00
 */
class ATVeditNodeFrame extends javax.swing.JFrame {

    private ATVeditNodePanel atveditnodepanel;

    private ATVtreePanel     atvtreepanel;

    private int              index = -1;


    /**
     *
     */
    ATVeditNodeFrame( Hashtable nodes, Phylogeny tree, boolean editable,
                      ATVtreePanel tp, int x ) {
        super( "ATV - PARS" );
        this.atvtreepanel = tp;
        setSize( 372, 300 );
        
        index = x;
        Container contentPane = getContentPane();
        atveditnodepanel = new ATVeditNodePanel( nodes, tree, editable, this );
        contentPane.add( atveditnodepanel, BorderLayout.CENTER );

        addWindowListener( new WindowAdapter() {

            public void windowClosing( WindowEvent e ) {
                remove(); // to release slot in array
                dispose();
            }
        } );

        setVisible( true );
    }//multi-select constructor
    
    
    /**
     *
     */
    ATVeditNodeFrame( PhylogenyNode n, Phylogeny tree, boolean editable,
                      ATVtreePanel tp, int x ) {
        super( "ATV - PARS" );
        this.atvtreepanel = tp;
        setSize( 372, 380 );
        
        index = x;
        Container contentPane = getContentPane();
        atveditnodepanel = new ATVeditNodePanel( n, tree, editable, this );
        contentPane.add( atveditnodepanel, BorderLayout.CENTER );

        addWindowListener( new WindowAdapter() {

            public void windowClosing( WindowEvent e ) {
                remove(); // to release slot in array
                dispose();
            }
        } );

        setVisible( true );
    }//single node constructor
    
    
    /**
     * 
     */
    ATVtreePanel getATVtreePanel() {
        return atvtreepanel;
    }

    /**
     *
     */
    void remove() {
        if ( index > -1 ) {
            atvtreepanel.removeEditNodeFrame( index ); // to release slot in array
       }
    }//remove

} // End of class ATVnodeFrame.

