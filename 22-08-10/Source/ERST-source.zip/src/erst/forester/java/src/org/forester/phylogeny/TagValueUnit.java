/*
 * ValueUnitType.java
 *
 * Created on May 24, 2003, 3:19 PM
 * 
 * Last modified: 12/31/04
 * CHANGE LOG:
 * 12/31/04: Changed "Y" and "N" for boolean to "T" and "F".
 * 
 */

package erst.forester.java.src.org.forester.phylogeny;

import java.util.StringTokenizer;

import erst.forester.java.src.org.forester.phylogeny.PhyloXMLmapping;

import java.net.URL;
import java.net.MalformedURLException;

/**
 * @author Christian Zmasek
 */
public class TagValueUnit extends Object implements Cloneable {

    public final static byte UNKNOWN_TYPE = 0, STRING_TYPE = 1,
            LONG_TYPE = 2, DOUBLE_TYPE = 3, BOOLEAN_TYPE = 4, URL_TYPE = 5;

    private final Object _value;

    private final String _tag, _unit;

    private final byte _type;


    /** Creates a new instance of ValueUnitType */
    public TagValueUnit( final String tag, final String value, final String unit ) {
        _tag = tag;
        _value = value;
        _unit = unit;
        _type = STRING_TYPE;
    }

    /** Creates a new instance of ValueUnitType */
    public TagValueUnit( final String tag, final long value, final String unit ) {
        _tag = tag;
        _value = new Long( value );
        _unit = unit;
        _type = LONG_TYPE;
    }

    /** Creates a new instance of ValueUnitType */
    public TagValueUnit( final String tag, final double value, final String unit ) {
        _tag = tag;
        _value = new Double( value );
        _unit = unit;
        _type = DOUBLE_TYPE;
    }

    /** Creates a new instance of ValueUnitType */
    public TagValueUnit( final String tag, final boolean value ) {
        _tag = tag;
        _value = new Boolean( value );
        _unit = "";
        _type = BOOLEAN_TYPE;
    }

    /** Creates a new instance of ValueUnitType */
    public TagValueUnit( final String tag, final URL value ) {
        _tag = tag;
        _value = value;
        _unit = "";
        _type = URL_TYPE;
    }

    /** Creates a new instance of ValueUnitType */
    private TagValueUnit( final String tag, final Object value,
            final String unit, final byte type ) {
        _tag = tag;
        _value = value;
        _unit = unit;
        _type = type;
    }

    protected Object clone() {
        return new TagValueUnit( this.getTag(), this.getValue(),
                this.getUnit(), this.getType() );
    }

    /**
     * Last modified: 12/31/04
     * 
     * @param nhx
     * @return
     * @throws IllegalArgumentException
     */
    public static TagValueUnit createInstance( final String nhx )
            throws IllegalArgumentException {

        StringTokenizer st = new StringTokenizer( nhx, "=" );
        int tokens = st.countTokens();
        String error = "Error in NHX custom tag format:\n"
                + "Expected: X[N|B|C]=[S|D|L|B|U]=<tag>=<value>[=<unit>]\n"
                + "Got: \"" + nhx + "\" instead";
        if ( tokens != 4 && tokens != 5 ) {
            throw new IllegalArgumentException( error );
        }
        String first = st.nextToken();
        if ( ! ( first.equals( "XN" ) || first.equals( "XB" ) || first
                .equals( "XC" ) ) ) {
            throw new IllegalArgumentException( error );
        }
        String type_string = st.nextToken();
        String tag_string = st.nextToken();
        String value_string = st.nextToken();
        String unit_string = "";
        if ( tokens == 5 ) {
            unit_string = st.nextToken();
        }
        TagValueUnit tvu = null;
        if ( type_string.equals( "S" ) ) {
            tvu = new TagValueUnit( tag_string, value_string, unit_string );
        }
        else if ( type_string.equals( "D" ) ) {
            try {
                tvu = new TagValueUnit( tag_string, Double
                        .parseDouble( value_string ), unit_string );
            }
            catch ( NumberFormatException e ) {
                throw new IllegalArgumentException(
                        "Error in NHX custom tag format:\n"
                                + "Could not parse double from " + value_string );
            }
        }
        else if ( type_string.equals( "L" ) ) {
            try {
                tvu = new TagValueUnit( tag_string, Long
                        .parseLong( value_string ), unit_string );
            }
            catch ( NumberFormatException e ) {
                throw new IllegalArgumentException(
                        "Error in NHX custom tag format:\n"
                                + "Could not parse integer from "
                                + value_string );
            }
        }
        else if ( type_string.equals( "B" ) ) {
            boolean b;
            if ( value_string.equals( "T" ) ) {
                b = true;
            }
            else if ( value_string.equals( "F" ) ) {
                b = false;
            }
            else {
                throw new IllegalArgumentException(
                        "Error in NHX custom tag format:\n"
                                + "If type is \"B\" (boolean), value must be "
                                + "either \"T\" or \"F\"\n" + "[\"" + nhx
                                + "\"]" );
            }
            if ( !unit_string.equals( "" ) ) {
                throw new IllegalArgumentException(
                        "Error in NHX custom tag format:\n"
                                + "If type is \"B\" (boolean), "
                                + "unit must not be set\n" + "[\"" + nhx
                                + "\"]" );
            }
            tvu = new TagValueUnit( tag_string, b );
        }
        else if ( type_string.equals( "U" ) ) {
            URL url;
            try {
                url = new URL( value_string.replace( '*', ':' ) );
            }
            catch ( MalformedURLException e ) {
                throw new IllegalArgumentException(
                        "Error in NHX custom tag format:\n"
                                + "Could not parse URL from " + value_string );
            }
            if ( !unit_string.equals( "" ) ) {
                throw new IllegalArgumentException(
                        "Error in NHX custom tag format:\n"
                                + "If type is \"U\" (URL), "
                                + "unit must not be set\n" + "[\"" + nhx
                                + "\"]" );
            }
            tvu = new TagValueUnit( tag_string, url );
        }
        else {
            throw new IllegalArgumentException( error );
        }

        return tvu;

    } // TagValueUnit createInstance( final String nhx )

    public String getTag() {
        return _tag;
    }

    public Object getValue() {
        return _value;
    }

    public String getUnit() {
        return _unit;
    }

    public byte getType() {
        return _type;
    }

    public String toNHX( boolean for_node ) {
        String type = "";
        StringBuffer nhx = new StringBuffer();
        nhx.append( ":X" );
        if ( for_node ) {
            nhx.append( "N=" );
        }
        else {
            nhx.append( "B=" );
        }
        if ( getType() == STRING_TYPE ) {
            type = "S";
        }
        else if ( getType() == LONG_TYPE ) {
            type = "L";
        }
        else if ( getType() == DOUBLE_TYPE ) {
            type = "D";
        }
        else if ( getType() == BOOLEAN_TYPE ) {
            type = "B";
        }
        else if ( getType() == URL_TYPE ) {
            type = "U";
        }
        nhx.append( type );
        nhx.append( "=" );
        nhx.append( getTag() );
        nhx.append( "=" );
        if ( getType() == BOOLEAN_TYPE ) {
            if ( ( ( Boolean ) getValue() ).booleanValue() ) {
                nhx.append( "T" );
            }
            else {
                nhx.append( "F" );
            }
        }
        else if ( getType() == URL_TYPE ) {
            nhx.append( getValue().toString().replace( ':', '*' ) );
        }
        else {
            nhx.append( getValue() );
        }
        if ( !getUnit().equals( "" ) ) {
            nhx.append( "=" );
            nhx.append( getUnit() );
        }
        return nhx.toString();
    }

    public String toXML( boolean for_node, boolean for_parent_branch,
            boolean for_clade ) {
        StringBuffer xml = new StringBuffer();
        xml.append( "<" );
        xml.append( getTag() );
        xml.append( " " );
        xml.append( PhyloXMLmapping.CUSTOM_ATTRIBUTE_TYPE );
        xml.append( "=\"" );
        if ( getType() == STRING_TYPE ) {
            xml.append( PhyloXMLmapping.CUSTOM_STRING_TYPE );
        }
        else if ( getType() == DOUBLE_TYPE ) {
            xml.append( PhyloXMLmapping.CUSTOM_DOUBLE_TYPE );
        }
        else if ( getType() == LONG_TYPE ) {
            xml.append( PhyloXMLmapping.CUSTOM_LONG_TYPE );
        }
        else if ( getType() == BOOLEAN_TYPE ) {
            xml.append( PhyloXMLmapping.CUSTOM_BOOLEAN_TYPE );
        }
        else if ( getType() == URL_TYPE ) {
            xml.append( PhyloXMLmapping.CUSTOM_URL_TYPE );
        }

        xml.append( "\" unit=\"" );
        xml.append( getUnit() );
        xml.append( "\" " );
        xml.append( PhyloXMLmapping.CUSTOM_ATTRIBUTE_PROPERTY );
        xml.append( "\"=\"" );
        if ( for_node ) {
            xml.append( PhyloXMLmapping.CUSTOM_NODE_PROPERTY );
        }
        else if ( for_parent_branch ) {
            xml.append( PhyloXMLmapping.CUSTOM_PARENT_BRANCH_PROPERTY );
        }
        else if ( for_clade ) {
            xml.append( PhyloXMLmapping.CUSTOM_CLADE_PROPERTY );
        }
        xml.append( "\"" );
        xml.append( ">" );

        if ( getType() == BOOLEAN_TYPE ) {
            if ( ( ( Boolean ) getValue() ).booleanValue() ) {
                xml.append( "true" );
            }
            else {
                xml.append( "false" );
            }
        }
        else {
            xml.append( getValue() );
        }
        xml.append( "</" );
        xml.append( getTag() );
        xml.append( ">" );
        return xml.toString();
    }

    public String toString() {
        String type = "";
        if ( getType() == STRING_TYPE ) {
            type = "String";
        }
        else if ( getType() == LONG_TYPE ) {
            type = "integer";
        }
        else if ( getType() == DOUBLE_TYPE ) {
            type = "double";
        }
        else if ( getType() == BOOLEAN_TYPE ) {
            type = "boolean";
        }
        else if ( getType() == URL_TYPE ) {
            type = "URL";
        }
        String s = "Tag  : " + getTag() + "\n" + "Value: " + getValue() + "\n"
                + "Unit : " + getUnit() + "\n" + "[Type: " + type + "]";
        return s;
    }

} // class TagValueUnit
