/*
 * Created on Jun 5, 2005
 *
 */
package erst.forester.java.src.org.forester.phylogeny.parsers;

import java.io.IOException;

import erst.forester.java.src.org.forester.phylogeny.Phylogeny;

/**
 * @author Christian Zmasek
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface PhylogenyParser {

    public void setSource( Object source ) throws PhylogenyParserException , IOException;
    
    public Phylogeny[] parse() throws PhylogenyParserException, IOException;
    
    
}
