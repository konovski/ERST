/*
 * Created on Nov 13, 2005
 *
 *
 */
package erst.forester.java.src.org.forester.phylogeny.data;

/**
 * @author Christian Zmasek
 * 
 * Interface for data for annotating a Phylogeny.
 * 
 */
public interface PhylogenyData extends Renderable {

  
    
    
   /**
    * This resets all data fields to their respective
    * default values.
    * 
    */
    public void init();
    

    /**
     * Creates a new PhylogenyData object with identical values as this
     * PhylogenyData (a deep copy).
     * 
     * 
     * @return a deep copy of this PhylogenyData
     */
    public PhylogenyData copy();

    /**
     * Compares this PhylogenyData to PhylogenyData data. In general, this
     * should return true if and only if all fiels are exactly identical.
     * 
     * @param PhylogenyData
     *            the PhylogenyData to compare to
     * @return in general, true if and only if all fiels are exactly identical,
     *         false otherwise
     */
    public boolean isEqual( final PhylogenyData data );
    
    /**
     * Writes a phyloXML representation of this PhylogenyData.
     * 
     * @param level
     *            the level of phyloXML
     * @return a phyloXML representation of this PhylogenyData
     */
    public StringBuffer toPhyloXML( int level );

}