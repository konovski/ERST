/*
 * ATVnodeGlyphPanel.java Added to ATV by Ethy Cannon 7/9/04
 */

package erst.forester.java.src.org.forester.atv;

import java.awt.*;

import javax.swing.*;

import erst.forester.java.src.org.forester.phylogeny.*;


public class ATVnodeGlyphPanel extends JPanel {

    protected JScrollPane glyph_pane;

    protected PhylogenyNode node;

    // width for all glyphs
    protected int         glyph_width  = 100;

    // real height of glyph list
    protected int         glyph_list_width;

    protected int         glyph_list_height;

    protected JPanel      button_panel = null;
    
    protected boolean     is_frame;

    public ATVnodeGlyphPanel() {
    }

    public Dimension getPreferedSize() {
        return new Dimension( glyph_list_width, glyph_list_height );
    }

    public Dimension getSize() {
        return new Dimension( glyph_list_width, glyph_list_height );
    }

    public void init( Container parent, PhylogenyNode n ) {
        is_frame = (parent instanceof Frame);
      
        node = n;
        if ( parent instanceof ATVnodeGlyphFrame ) {
            // use the parent's button panel
            button_panel = ( ( ATVnodeGlyphFrame ) parent ).getButtonPanel();
        }

        setLayout( new BorderLayout( 10, 10 ) );
    }

    public void setGlyphWidth( int new_width ) {
        glyph_width = new_width;
    }

    public void treeChanged( PhylogenyNode n ) {
    }
    
    
  
    public void update(PhylogenyNode node) {
    }
}