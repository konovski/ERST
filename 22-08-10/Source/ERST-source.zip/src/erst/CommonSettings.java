/**
 *
 * @author  Petar
 */
package erst;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;

public class CommonSettings extends JFrame implements ActionListener {
	
	JButton browseOutputFile;
	JButton browseShortReport;
	JButton browseHGTransferFile;
	JButton browsePoEquilFile;
	JButton buttonOK;
	JTextField gainPenaltyWeightBox;
	JTextField numberOfIterationsBox;
	JTextField outputFileBox;
	JTextField shortReportFileBox;
	JTextField hgTransferFileBox;
	JTextField poEquilFileBox;
	public CommonSettings() {
		
		super("Setting parameters and output files.");
		
		gainPenaltyWeightBox = new JTextField(4);
		gainPenaltyWeightBox.setText(CalcParameters.getGainPenalty_txt());
		gainPenaltyWeightBox.setToolTipText("Type the gain penalty weight here.");
		
		JLabel lblGPW  = new JLabel("Gain Penalty Weight:");
		JPanel textGPWpanel = new JPanel();
		BoxLayout tGpane = new BoxLayout(textGPWpanel, BoxLayout.Y_AXIS);
		textGPWpanel.setLayout(tGpane);
		textGPWpanel.add(lblGPW);
		textGPWpanel.add(gainPenaltyWeightBox);
		
		numberOfIterationsBox = new JTextField(4);
		numberOfIterationsBox.setText(CalcParameters.getNIterations_txt());
		numberOfIterationsBox.setToolTipText("Type the number of iterations for the ML reconstruction method.");
		JLabel lblItr = new JLabel("Number of Iterations:");
		JPanel textNIpanel = new JPanel();
		BoxLayout tNpane = new BoxLayout(textNIpanel, BoxLayout.Y_AXIS);
		textNIpanel.setLayout(tNpane);
		textNIpanel.add(lblItr);
		textNIpanel.add(numberOfIterationsBox);

		
		JPanel textControlsPanel = new JPanel();
		BoxLayout textPane = new BoxLayout(textControlsPanel, BoxLayout.Y_AXIS);
		textControlsPanel.setLayout(textPane);
		textControlsPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder("Numerical parameters"),
				                                                    BorderFactory.createEmptyBorder(5, 5, 5, 5)));
		textControlsPanel.add(textGPWpanel);
		textControlsPanel.add(textNIpanel);
		textControlsPanel.add(Box.createRigidArea(new Dimension(5,15)));
		
		
		// A dialogue to provide the name of the Output file.
		JLabel lblOutF = new JLabel("Output File");

		outputFileBox = new JTextField(30);
		outputFileBox.setText(CalcParameters.getOutputFile_TXT());
		outputFileBox.setToolTipText("Type the path to the output file or select it from the Browse menu.");

		JPanel labelFileBox = new JPanel();
		BoxLayout lfPane = new BoxLayout(labelFileBox, BoxLayout.Y_AXIS);
		labelFileBox.setLayout(lfPane);
		labelFileBox.add(lblOutF);
		labelFileBox.add(outputFileBox);
		
		browseOutputFile = new JButton("Browse");
		browseOutputFile.setToolTipText("Browse for the Output file.");
		browseOutputFile.addActionListener(this);
		
		JPanel outFileBoxPanel = new JPanel();
		BoxLayout oFPane = new BoxLayout(outFileBoxPanel, BoxLayout.X_AXIS);
		outFileBoxPanel.setLayout(oFPane);
		outFileBoxPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder("Output File"),
				                                                        BorderFactory.createEmptyBorder(8, 8, 8, 8)));
		outFileBoxPanel.add(outputFileBox);
		outFileBoxPanel.add(browseOutputFile);

		
		// A dialogue to provide the name of the Short Report file.
		JLabel lblShortR = new JLabel("Short Report");

		shortReportFileBox = new JTextField(30);
		shortReportFileBox.setText(CalcParameters.getShortReport_TXT());
		shortReportFileBox.setToolTipText("Type the path to the short report file or select it from the Browse menu.");
		
		JPanel labelSReportBox = new JPanel();
		BoxLayout lsrPane = new BoxLayout(labelSReportBox, BoxLayout.Y_AXIS);
		labelSReportBox.setLayout(lsrPane);
		labelSReportBox.add(lblShortR);
		labelSReportBox.add(shortReportFileBox);
		
		browseShortReport = new JButton("Browse");
		browseShortReport.setToolTipText("Browse for the Short Report  file.");
		browseShortReport.addActionListener(this);
		
		JPanel sReportBoxPanel = new JPanel();
		BoxLayout sRPane = new BoxLayout(sReportBoxPanel, BoxLayout.X_AXIS);
		sReportBoxPanel.setLayout(sRPane);
		sReportBoxPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder("Short Report File"),
				                                                        BorderFactory.createEmptyBorder(8, 8, 8, 8)));
		sReportBoxPanel.add(shortReportFileBox);
		sReportBoxPanel.add(browseShortReport);

		
		// A dialogue to provide the name of the Horizontal Gene Transfers file.
		JLabel lblHGTrans = new JLabel("Horizontal Gene Transfer Output");

		hgTransferFileBox = new JTextField(30);
		hgTransferFileBox.setText(CalcParameters.getHGTransferFile_TXT());
		hgTransferFileBox.setToolTipText("Type the path to the Horizontal Gene Transfer output file or select it from the Browse menu.");
		
		JPanel labelHGTransferBox = new JPanel();
		BoxLayout lhgPane = new BoxLayout(labelHGTransferBox, BoxLayout.Y_AXIS);
		labelHGTransferBox.setLayout(lhgPane);
		labelHGTransferBox.add(lblHGTrans);
		labelHGTransferBox.add(hgTransferFileBox);
		
		browseHGTransferFile = new JButton("Browse");
		browseHGTransferFile.setToolTipText("Browse for the Horizontal Gene Transfer Output File.");
		browseHGTransferFile.addActionListener(this);
		
		JPanel hgTransferFileBoxPanel = new JPanel();
		BoxLayout hGTPane = new BoxLayout(hgTransferFileBoxPanel, BoxLayout.X_AXIS);
		hgTransferFileBoxPanel.setLayout(hGTPane);
		hgTransferFileBoxPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder("Horizontal Gene Transfer Output File"),
				                                                        BorderFactory.createEmptyBorder(8, 8, 8, 8)));
		hgTransferFileBoxPanel.add(hgTransferFileBox);
		hgTransferFileBoxPanel.add(browseHGTransferFile);


		// A dialogue to provide the name of the Points of Equilibrium file.
		JLabel lblPoEquil = new JLabel("Points of Equilibrium Output");

		poEquilFileBox = new JTextField(30);
		poEquilFileBox.setText(CalcParameters.getPoEquilFile_TXT());
		poEquilFileBox.setToolTipText("Type the path to the Points of Equilibrium output file file or select it from the Browse menu.");
		
		JPanel labelPoEquilBox = new JPanel();
		BoxLayout lpoePane = new BoxLayout(labelPoEquilBox, BoxLayout.Y_AXIS);
		labelPoEquilBox.setLayout(lpoePane);
		labelPoEquilBox.add(lblPoEquil);
		labelPoEquilBox.add(poEquilFileBox);
		
		browsePoEquilFile = new JButton("Browse");
		browsePoEquilFile.setToolTipText("Browse for the Points of Equilibrium Output File.");
		browsePoEquilFile.addActionListener(this);
		
		JPanel poEquilFileBoxPanel = new JPanel();
		BoxLayout poEquilPane = new BoxLayout(poEquilFileBoxPanel, BoxLayout.X_AXIS);
		poEquilFileBoxPanel.setLayout(poEquilPane);
		poEquilFileBoxPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder("Points of Equilibrium Output File"),
				                                                        BorderFactory.createEmptyBorder(8, 8, 8, 8)));
		poEquilFileBoxPanel.add(poEquilFileBox);
		poEquilFileBoxPanel.add(browsePoEquilFile);		
		
		
		/*
		JPanel textComboPanel = new JPanel();
		BoxLayout joinBox = new BoxLayout(textComboPanel, BoxLayout.X_AXIS);
		textComboPanel.setLayout(joinBox);
		textComboPanel.add(textControlsPanel);
		textComboPanel.add(Box.createRigidArea(new Dimension(20,0)));
		/*
		*/
		
		JPanel okButtonPanel = new JPanel();
		BoxLayout buttonBox = new BoxLayout(okButtonPanel, BoxLayout.X_AXIS);
		okButtonPanel.setLayout(buttonBox);
		buttonOK = new JButton("OK");
		buttonOK.setToolTipText("Click this button to save the common settings.");
		buttonOK.addActionListener(this);
		okButtonPanel.add(buttonOK);
		
		
		JPanel contentPane = new JPanel();
		BoxLayout box = new BoxLayout(contentPane, BoxLayout.Y_AXIS);
		contentPane.setLayout(box);
		contentPane.add(Box.createRigidArea(new Dimension(10,10)));
		//contentPane.add(textComboPanel);
		contentPane.add(textControlsPanel);
		contentPane.add(Box.createRigidArea(new Dimension(10,10)));
		contentPane.add(outFileBoxPanel);
		contentPane.add(Box.createRigidArea(new Dimension(10,10)));
		contentPane.add(sReportBoxPanel);
		contentPane.add(Box.createRigidArea(new Dimension(10,10)));
		contentPane.add(hgTransferFileBoxPanel);
		contentPane.add(Box.createRigidArea(new Dimension(10,10)));
		contentPane.add(poEquilFileBoxPanel);
		contentPane.add(Box.createRigidArea(new Dimension(10,10)));
		contentPane.add(okButtonPanel);
		contentPane.add(Box.createRigidArea(new Dimension(10,10)));
		
		setContentPane(contentPane);
		
	} // End of public CommonSettings().
	

	public void actionPerformed(ActionEvent evt) {
		JButton button = (JButton)evt.getSource();
		if (button == browseOutputFile) {
			JFileChooser fileCh = new JFileChooser();
			int returnVal = fileCh.showOpenDialog(CommonSettings.this);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				File phOUT = fileCh.getSelectedFile();
				outputFileBox.setText(phOUT.getAbsolutePath());
			}
		} 
		else if (button == browseShortReport) {
			JFileChooser fileCh = new JFileChooser();
			int returnVal = fileCh.showOpenDialog(CommonSettings.this);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				File phOUT = fileCh.getSelectedFile();
				shortReportFileBox.setText(phOUT.getAbsolutePath());
			}
		} 
		else if (button == browseHGTransferFile) {
			JFileChooser fileCh = new JFileChooser();
			int returnVal = fileCh.showOpenDialog(CommonSettings.this);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				File phOUT = fileCh.getSelectedFile();
				hgTransferFileBox.setText(phOUT.getAbsolutePath());
			}
		} 

		else if (button == browsePoEquilFile) {
			JFileChooser fileCh = new JFileChooser();
			int returnVal = fileCh.showOpenDialog(CommonSettings.this);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				File phOUT = fileCh.getSelectedFile();
				poEquilFileBox.setText(phOUT.getAbsolutePath());
			}
		} 

		/*
		*/
		else { // Only button OK is expected here.
			CalcParameters.setGainPenalty_txt(gainPenaltyWeightBox.getText());
			CalcParameters.setNIterations_txt(numberOfIterationsBox.getText());
			CalcParameters.setOutputFile_TXT(outputFileBox.getText());
			CalcParameters.setShortReport_TXT(shortReportFileBox.getText());
			CalcParameters.setHGTransferFile_TXT(hgTransferFileBox.getText());
			CalcParameters.setPoEquilFile_TXT(poEquilFileBox.getText());
			CalcParameters.saveValues();
			dispose();
		}
		return;
	} // End of public void actionPerformed(ActionEvent evt)
	
} // End of class CommonSettings.