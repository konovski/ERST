/*
 * MainERST.java
 *
 * Created 2008-2021, partially based on a code by Renata.
 */


package erst;

import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Enumeration;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.lang.String;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import erst.forester.java.src.org.forester.atv.ATVapp;
import erst.forester.java.src.org.forester.phylogeny.PhylogenyNode;
import erst.genalg.InnerData;
//import erst.genalg.Max;


/**
 *
 * @author Petar
 */
public class MainERST extends JFrame implements ActionListener {
	
	MainMenu mainMenu = new MainMenu();
	JFrame InputFrame = new InputWindow();
	ATVapp ATVRun = new ATVapp();
	Cursor waitCursor = new Cursor(Cursor.WAIT_CURSOR);
	Cursor normalCursor = new Cursor(Cursor.DEFAULT_CURSOR);

	
	public MainERST() {
		
		// Set up the title of the main window and create the base of the class.
		super ("ERST - Evolutionary Reconstructions over Species Tree");
		
		// Check for the Java version.
		double minimalJavaVersion = 1.6;
		String javaVersion = System.getProperty("java.version");
		javaVersion = javaVersion.substring(0, 3);
		double javaV = Double.parseDouble(javaVersion);
		if (javaV < minimalJavaVersion) {
			JOptionPane.showMessageDialog(null, 
					"Your version of Java is " + javaVersion + 
					". \n The minimal required version is " + minimalJavaVersion + "*");
			System.exit(1);
		}
		// Add the main menu.
		setJMenuBar(mainMenu);
		
		// Add MainERST as a listener to the menu.
		mainMenu.addActionListener (this);
		
	} // End of MainERST()
	
	
	// Action Event Handler: actionPerformed
	public void actionPerformed(ActionEvent e) {
		
		//Extract the JMenuItem that generated this event
		JMenuItem item = (JMenuItem)e.getSource();
		
		//Find our which JMenuItem generated this event
		if (item == mainMenu.fileInput) {
			InputFrame.pack();
			InputFrame.setVisible(true);
		}
		else if (item == mainMenu.fileExit) {
			/*try {
				Files.deleteIfExists(Paths.get(CalcParameters.outputFile_ATV));
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		
			try {
				Files.deleteIfExists(Paths.get(CalcParameters.outputFile_FPROB));
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			try {
				Files.deleteIfExists(Paths.get(CalcParameters.outputFile_IPROB));
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			*/
			System.exit(0);
		}
		else if (item == mainMenu.commonSettings) {
			CommonSettings csWindow = new CommonSettings();
			csWindow.pack();
			csWindow.setVisible(true);
		}

		else if (item == mainMenu.maximumParsimony) {
			setCursor(waitCursor);
			MaxParsimony.execute();
			setCursor(normalCursor);
		}
		else if (item == mainMenu.maximumLikelihood) {
			setCursor(waitCursor);
			MaxLikelihood.execute();
			//Max.execute(); // Calculation and output of the coefficients for the minimax problem.
			
			setCursor(normalCursor);
		}
		else if (item == mainMenu.minimumEntropy) {
			setCursor(waitCursor);
			MinEntropy.execute();
			setCursor(normalCursor);
		}
		else if (item == MainMenu.viewAllHPFs) {
	        InnerData.chosenHPF = -1;
	        InnerData.GainsLossesSelected = true;
			String recATV = CalcParameters.outputFile_ATV; // Submit the file with the gains/losses (Petar).
			String[] treeEle = {recATV};
			PhylogenyNode.setNodeCount(0); // ATV software needs resetting the counter (Petar).
			setCursor(waitCursor);
			ATVRun.execute(treeEle);
			setCursor(normalCursor);
		}
		else if (item == MainMenu.viewChosenHPF) {
			setCursor(waitCursor);
			GraphTabPanel.execute();
			setCursor(normalCursor);
		}
		else if (item == MainMenu.viewProbMP) {
	        InnerData.chosenHPF = -1;
	        InnerData.GainsLossesSelected = false;
			String recInitProb = CalcParameters.outputFile_IPROB; // Use the file with the initial probabilities (Petar).
			String[] treeRecInitProb = {recInitProb};
			PhylogenyNode.setNodeCount(0);  // ATV software needs resetting the counter (Petar).
			setCursor(waitCursor);
			ATVRun.execute(treeRecInitProb);
			setCursor(normalCursor);
		}
		else if ((item==MainMenu.viewProbML) || (item==MainMenu.viewProbME)) {
	        InnerData.chosenHPF = -1;
	        InnerData.GainsLossesSelected = false;
			String recFinalProb = CalcParameters.outputFile_FPROB; // Use the file with the final probabilities (Petar).
			String[] treeRecFinalProb = {recFinalProb};
			PhylogenyNode.setNodeCount(0); // ATV software needs resetting the counter (Petar).
			setCursor(waitCursor);
			ATVRun.execute(treeRecFinalProb);
			setCursor(normalCursor);
		}
		else if (item == MainMenu.viewShortReport) {
			JOptionPane.showMessageDialog(this,InnerData.shortReport, "Short Report", JOptionPane.INFORMATION_MESSAGE);
		}
		else if (item == mainMenu.helpAbout) {
			JOptionPane.showMessageDialog(this,
					"       ERST Update 22-08-10 \n" + 
					"ERST has been implemented by Petar Konovski, Renata da Silva Camargo, and Trevor Fenner\n" + 
					"as part of the project of mapping the gene evolutionary histories for 30 " + 
					"complete herpesvirus genomes.\n" + 
					"This project was funded by the Welcome Trust. \n\n" + 
					"Members of the project are: \n- Boris Mirkin \n- Trevor Fenner \n" + 
					"- George Loizou \n- Paul Kellam \n- Renata da Silva Camargo \n" + 
					"- Petar Konovski", "About ERST",JOptionPane.INFORMATION_MESSAGE);
		}
		else if (item == mainMenu.helpContents) {
			TreeHelp.createAndShowGUI();
		}
	} // End of public void actionPerformed(ActionEvent e)
	
	/* This function which finds if the package is started from a '*.jar' archive.
	 * If that is the case, it extracts the resources needed for the execution in the current directory.
	 * The return value is 'true' if the extraction has happened successfully or the package
	 * starts not from a jar file. In the last case, the onus to provide any input data lays on the user.
	 */
private static boolean jarExtract (String resourceDir) {
		
		String jar = ".jar";
		String destPath = ".\\";
		String jarPath;
		
		// Find the full name of the .jar file, if existent.
		try {
			jarPath = (String)MainERST.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath();
		} catch (URISyntaxException e) {
			// TODO Catch anything anything odd at this point.
			e.printStackTrace();
			return false;
		}
		int len = jarPath.length();

		if (jarPath.indexOf(jar, len-4) == -1) {
			//System.out.println("That is not jar: " + jarPath); 
			return true;
		}
		
		InnerData.isJar = true;
		
		File dir = new File(resourceDir);
		if (dir.isDirectory()) {
			// If the resource directory exists already, skip the further proceedings.
			//dir.close();  
			return true;		
		}
		
		// The package is started from a jar file and the resourceDir does not exist. 
		// Perform the extraction.	
		try {
			JarFile jarFile = new JarFile(jarPath);
			
			Enumeration<JarEntry> enums = jarFile.entries();
			while (enums.hasMoreElements()) {
				JarEntry entry = enums.nextElement();
				if (entry.getName().startsWith("resources")) {
					File toWrite = new File(destPath + entry.getName());
					if (entry.isDirectory()) {
						toWrite.mkdirs();
						continue;
					}
					InputStream in = new BufferedInputStream(jarFile.getInputStream(entry));
					OutputStream out = new BufferedOutputStream(new FileOutputStream(toWrite));
					byte[] buffer = new byte[2048];
					for (;;) {
						int nBytes = in.read(buffer);
						if (nBytes <= 0) {
							out.close();
							break;
						}
						out.write(buffer, 0, nBytes);
					}
					out.flush();
					out.close();
					in.close();
				}
				//System.out.println(entry.getName());
			}
			jarFile.close();
		} catch (IOException ex) {
			return false;
		}		
		
		/*
		*/

		new File("output").mkdir(); // Create subdirectory 'output' in the current directory.
		
		return true;

	} // End of private static boolean jarExtract (String resourceDir)


	public static void main(String[] args) throws URISyntaxException {
		
		if (!jarExtract ("resources"))
			{
				//TODO: A proper error message.
				return;
			}
		

		MainERST mmexec = new MainERST();
		// Set our size
		
		ShowImage panel = new ShowImage();
		mmexec.getContentPane().add(panel);
		mmexec.setSize(800, 680);
		
		// Make our Main visible
		mmexec.setVisible(true);
		mmexec.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		return;
	}  //End of public static void main(String[] args).
} // End of public class MainERST extends JFrame implements ActionListener


// ShowImage has a single purpose to show an image in the MainERST window.
final class ShowImage extends Panel {
	
	private Image image; // Contains a picture for the background of the main window.
	
	private Image loadImage(String name)
	{
		Image result = null;
		MediaTracker tracker = new MediaTracker(this);
		
		InputStream inputStream = ShowImage.class.getResourceAsStream(name);
				
		try {
			result = ImageIO.read(inputStream);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		/*
		*/
		tracker.addImage(result, 0);
		try {
			tracker.waitForAll();
		} catch (InterruptedException e) {
			return null;
		}
		
		return result;
	} // End of private Image loadImage(String name).
	
	public ShowImage() {
		
		image = loadImage("/resources/ERSTlogo.png");
		
	}
	
	@Override // Overrides: paint(...) in Container.
	public void paint(Graphics g) {
		
		g.drawImage( image, 80, 80, null);
	}
} // End of final class ShowImage extends Panel
